import React, { useState, useEffect } from 'react';
import {
  X,
  Award,
  Plus,
  Trash2,
  Check,
  Sparkles,
  Calendar,
  Share2,
} from 'lucide-react';
import { GoodDeedRecord } from '../types';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface GoodDeedTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
  onDeedAdded?: () => void;
}

const PRESET_DEEDS = [
  {
    title: 'Smile at a fellow Muslim',
    titleBn: 'মুচকি হাসি দেওয়া (সাদাকার সমতুল্য)',
    category: 'Daily Sunnah',
    multiplierPoints: 10,
    dalil: 'সহিহ তিরমিজি: ১৯৫৬ (তোমার ভাইয়ের মুখে মুচকি হাসি দেওয়া একটি সাদাকা)',
  },
  {
    title: 'Removing harm from path',
    titleBn: 'রাস্তা থেকে কষ্টদায়ক বস্তু সরানো',
    category: 'Community/Environment',
    multiplierPoints: 20,
    dalil: 'সহিহ মুসলিম: ৫৮ (ইমানের অন্যতম শাখা)',
  },
  {
    title: 'Calling / Serving Parents',
    titleBn: 'পিতামাতার সেবা ও তাদের সাথে নরমভাবে কথা বলা',
    category: 'Kindness to Parents/Family',
    multiplierPoints: 50,
    dalil: 'সূরা বনি ইসরাঈল: ২৩',
  },
  {
    title: 'Giving Secret Sadaqah',
    titleBn: 'গোপনে সাদাকা প্রদান করা',
    category: 'Charity',
    multiplierPoints: 40,
    dalil: 'সহিহ বুখারি: ১৪২৩ (আল্লাহর আরশের ছায়া লাভ)',
  },
  {
    title: 'Reciting Ayat al-Kursi after Fard Salat',
    titleBn: 'ফরজ নামাজের পর আয়াতুল কুরসি তিলাওয়াত',
    category: 'Daily Sunnah',
    multiplierPoints: 30,
    dalil: 'সুনানে নাসায়ী কুবরা: ৯৮৪৮ (মৃত্যু ছাড়া জান্নাতে প্রবেশের কোনো বাধা থাকে না)',
  },
];

const INITIAL_DEEDS: GoodDeedRecord[] = [
  {
    id: 'deed-1',
    date: new Date().toISOString().split('T')[0],
    title: 'Fed a hungry stray cat outside the mosque',
    category: 'Charity',
    multiplierPoints: 25,
    completed: true,
  },
];

export const GoodDeedTrackerModal: React.FC<GoodDeedTrackerModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
  onDeedAdded,
}) => {
  const [deeds, setDeeds] = useState<GoodDeedRecord[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_good_deeds_ledger');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_DEEDS;
  });

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<GoodDeedRecord['category']>('Daily Sunnah');
  const [points, setPoints] = useState<number>(20);
  const [showAddCustom, setShowAddCustom] = useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_good_deeds_ledger', JSON.stringify(deeds));
    } catch {
      // ignore
    }
  }, [deeds]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleQuickAddPreset = (preset: typeof PRESET_DEEDS[0]) => {
    playNotificationTone(soundEnabled);
    const newRecord: GoodDeedRecord = {
      id: 'deed-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      title: `${preset.title} (${preset.titleBn})`,
      category: preset.category as GoodDeedRecord['category'],
      multiplierPoints: preset.multiplierPoints,
      completed: true,
    };
    setDeeds((prev) => [newRecord, ...prev]);
    showToast(`Alhamdulillah! +${preset.multiplierPoints} Hasanah points recorded!`);
    if (onDeedAdded) onDeedAdded();
  };

  const handleSaveCustom = () => {
    if (!title.trim()) {
      showToast('Please enter the good deed description');
      return;
    }

    playNotificationTone(soundEnabled);
    const newRecord: GoodDeedRecord = {
      id: 'deed-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      title: title.trim(),
      category,
      multiplierPoints: points,
      completed: true,
    };
    setDeeds((prev) => [newRecord, ...prev]);
    showToast(`Good deed saved (+${points} Hasanah)!`);
    if (onDeedAdded) onDeedAdded();
    setTitle('');
    setShowAddCustom(false);
  };

  const handleDelete = (id: string) => {
    setDeeds((prev) => prev.filter((d) => d.id !== id));
    showToast('Entry removed');
  };

  const totalPoints = deeds.reduce((acc, d) => acc + d.multiplierPoints, 0);

  return (
    <div
      id="modal-good-deed-tracker"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-black shadow-xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Good Deed Multiplier</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  নেক আমল ট্র্যাকার
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                &ldquo;Whoever comes with a good deed will have ten times the like thereof.&rdquo; (6:160)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="p-2.5 bg-amber-600 text-white text-xs font-bold text-center animate-in fade-in">
            {toastMsg}
          </div>
        )}

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Points Summary Banner */}
          <div
            className={`p-4 rounded-2xl border flex items-center justify-between ${
              darkMode ? 'bg-[#12281E]/80 border-[#1E4332]' : 'bg-[#FFFBEB] border-amber-200'
            }`}
          >
            <div>
              <span className="text-xs font-black text-amber-600 dark:text-amber-400 block">
                Total Hasanah Deed Points
              </span>
              <p className="text-[11px] text-stone-400 font-medium">
                {deeds.length} verified good deeds recorded
              </p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-amber-500">+{totalPoints}</span>
              <span className="text-[10px] text-stone-400 block font-bold">Hasanah</span>
            </div>
          </div>

          {/* Quick Presets Section */}
          <div className="space-y-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
              Quick Sunnah Deeds (এক ক্লিকে যুক্ত করুন)
            </h4>

            <div className="space-y-2">
              {PRESET_DEEDS.map((p, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                    darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <h5 className="text-xs font-black text-stone-900 dark:text-stone-100">
                      {p.title}
                    </h5>
                    <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium truncate">
                      {p.titleBn}
                    </p>
                    <p className="text-[10px] text-stone-400">{p.dalil}</p>
                  </div>

                  <button
                    onClick={() => handleQuickAddPreset(p)}
                    className="px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500 text-amber-600 hover:text-stone-950 text-xs font-black flex items-center gap-1 transition-all shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+{p.multiplierPoints}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Good Deed Toggle */}
          <button
            onClick={() => setShowAddCustom(!showAddCustom)}
            className="w-full py-2.5 rounded-xl border border-dashed border-emerald-500/40 hover:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-black text-xs flex items-center justify-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{showAddCustom ? 'Cancel Custom Entry' : '+ Add Custom Good Deed'}</span>
          </button>

          {showAddCustom && (
            <div
              className={`p-4 rounded-2xl border space-y-3 animate-in fade-in ${
                darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200'
              }`}
            >
              <span className="text-xs font-black text-emerald-500 block">
                Custom Good Deed Entry
              </span>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Cleaned the local mosque after Maghrib"
                className={`w-full p-2.5 rounded-xl border text-xs ${
                  darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                }`}
              />

              <div className="grid grid-cols-2 gap-2">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as GoodDeedRecord['category'])}
                  className={`w-full p-2 rounded-xl border text-xs ${
                    darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                  }`}
                >
                  <option value="Daily Sunnah">Daily Sunnah</option>
                  <option value="Charity">Charity</option>
                  <option value="Kindness to Parents/Family">Kindness to Parents/Family</option>
                  <option value="Knowledge/Teaching">Knowledge/Teaching</option>
                  <option value="Community/Environment">Community/Environment</option>
                </select>

                <input
                  type="number"
                  min={5}
                  max={100}
                  value={points}
                  onChange={(e) => setPoints(parseInt(e.target.value) || 10)}
                  className={`w-full p-2 rounded-xl border text-xs ${
                    darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                  }`}
                  placeholder="Points (e.g. 25)"
                />
              </div>

              <button
                onClick={handleSaveCustom}
                className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save Deed</span>
              </button>
            </div>
          )}

          {/* History List */}
          <div className="space-y-2 pt-1">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
              Recorded Deeds History ({deeds.length})
            </h4>

            <div className="space-y-1.5">
              {deeds.map((d) => (
                <div
                  key={d.id}
                  className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                    darkMode ? 'bg-[#12281E]/40 border-[#1E4332]' : 'bg-stone-50 border-stone-200'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-stone-800 dark:text-stone-100">{d.title}</span>
                      <span className="text-[10px] font-black text-amber-500">+{d.multiplierPoints}</span>
                    </div>
                    <span className="text-[10px] text-stone-400">{d.category} • {d.date}</span>
                  </div>

                  <button
                    onClick={() => handleDelete(d.id)}
                    className="p-1 text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
