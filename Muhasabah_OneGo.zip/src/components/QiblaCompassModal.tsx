import React, { useState, useEffect } from 'react';
import {
  Compass,
  X,
  MapPin,
  Sparkles,
  RotateCw,
  Navigation2,
  CheckCircle2,
  Info,
  ShieldCheck,
} from 'lucide-react';
import { calculateQibla, calculateDistanceToMakkah, getCardinalDirection } from '../utils/qibla';
import { LocationConfig } from '../types';

interface QiblaCompassModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  location: LocationConfig;
  onOpenLocationModal: () => void;
  onUpdateLocation?: () => void;
  isUpdatingLocation?: boolean;
}

export const QiblaCompassModal: React.FC<QiblaCompassModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  location,
  onOpenLocationModal,
  onUpdateLocation,
  isUpdatingLocation = false,
}) => {
  // Device heading in degrees (0 = North)
  const [deviceHeading, setDeviceHeading] = useState<number>(0);
  const [hasSensor, setHasSensor] = useState<boolean>(false);
  const [needsPermission, setNeedsPermission] = useState<boolean>(false);
  const [isCalibrated, setIsCalibrated] = useState<boolean>(true);
  const [manualHeading, setManualHeading] = useState<number>(0);
  const [useManualMode, setUseManualMode] = useState<boolean>(false);

  const qiblaAngle = calculateQibla(location.latitude, location.longitude);
  const distanceKm = calculateDistanceToMakkah(location.latitude, location.longitude);
  const cardinal = getCardinalDirection(qiblaAngle);

  // Active heading: sensor or manual slider
  const currentHeading = useManualMode ? manualHeading : deviceHeading;
  // Needle rotation relative to top of phone
  // If phone faces North (heading = 0), needle points to qiblaAngle.
  // If phone faces qiblaAngle (heading = qiblaAngle), needle points to 0 (straight up).
  const needleRotation = (qiblaAngle - currentHeading + 360) % 360;
  const isAligned = Math.abs(needleRotation) <= 4 || Math.abs(needleRotation - 360) <= 4;

  const requestPermission = async () => {
    if (
      typeof (DeviceOrientationEvent as any) !== 'undefined' &&
      typeof (DeviceOrientationEvent as any).requestPermission === 'function'
    ) {
      try {
        const response = await (DeviceOrientationEvent as any).requestPermission();
        if (response === 'granted') {
          setNeedsPermission(false);
          setHasSensor(true);
        }
      } catch (err) {
        console.error('Error requesting orientation permission:', err);
      }
    }
  };

  useEffect(() => {
    if (!isOpen) return;

    // Check if iOS 13+ permission required
    if (
      typeof (DeviceOrientationEvent as any) !== 'undefined' &&
      typeof (DeviceOrientationEvent as any).requestPermission === 'function'
    ) {
      setNeedsPermission(true);
    }

    let sensorDetected = false;

    const handleOrientation = (e: DeviceOrientationEvent) => {
      let rawHeading: number | null = null;
      // iOS webkitCompassHeading
      if ((e as any).webkitCompassHeading !== undefined && (e as any).webkitCompassHeading !== null) {
        rawHeading = (e as any).webkitCompassHeading;
      } else if (e.alpha !== null && e.alpha !== undefined) {
        // Standard absolute orientation: alpha is rotation around z-axis (0-360)
        // Invert to get compass heading clockwise from North
        rawHeading = (360 - e.alpha) % 360;
      }

      if (rawHeading !== null) {
        sensorDetected = true;
        setHasSensor(true);
        setNeedsPermission(false);
        // Exponential moving average for silky smooth needle rotation without jitter
        setDeviceHeading((prev) => {
          let diff = (rawHeading! - prev + 180) % 360 - 180;
          return Math.round((prev + diff * 0.35 + 360) % 360);
        });
      }
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientationabsolute' as any, handleOrientation, true);
      window.addEventListener('deviceorientation', handleOrientation, true);
    }

    // Fallback timer: if no sensor events received in 1.5s, enable interactive manual control
    const timer = setTimeout(() => {
      if (!sensorDetected && !needsPermission) {
        setHasSensor(false);
      }
    }, 1500);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('deviceorientationabsolute' as any, handleOrientation, true);
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, [isOpen, needsPermission]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`w-full max-w-md rounded-[28px] p-6 border shadow-2xl relative overflow-hidden transition-all ${
          darkMode
            ? 'bg-gradient-to-b from-[#0F261C] via-[#142B20] to-[#0A1710] border-[#D4AF37]/40 text-white'
            : 'bg-gradient-to-b from-[#1B4332] via-[#24543E] to-[#12281E] border-[#D4AF37]/50 text-white'
        }`}
      >
        {/* Background ambient gold/emerald glow */}
        <div className="absolute -top-20 -right-20 w-56 h-56 rounded-full bg-[#D4AF37]/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-56 h-56 rounded-full bg-[#52B788]/20 blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between relative z-10 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-black/30 border border-[#D4AF37]/50 text-[#D4AF37]">
              <Compass className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                <span>Holy Qibla Compass</span>
                {isAligned && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#52B788] text-stone-950 shadow-sm">
                    🕋 কিবলামুখী (Facing Qibla)
                  </span>
                )}
              </h2>
              <div className="flex items-center gap-1 text-xs text-emerald-200/90 font-medium">
                <MapPin className="w-3 h-3 text-[#D4AF37]" />
                <span>
                  {location.name}, {location.country} ({location.latitude.toFixed(2)}°N,{' '}
                  {location.longitude.toFixed(2)}°E)
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-black/30 text-white/80 hover:text-white border border-white/20 transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Alignment Status Banner */}
        {needsPermission && (
          <div className="relative z-10 my-2 p-3 rounded-2xl bg-amber-500/20 border border-[#D4AF37] text-[#F5E6B3] text-xs flex items-center justify-between shadow-md">
            <span>iPhone / iPad Compass Sensor Permission</span>
            <button
              onClick={requestPermission}
              className="px-3 py-1 bg-[#D4AF37] text-stone-950 font-black rounded-xl text-[11px] hover:brightness-110 active:scale-95"
            >
              Calibrate Sensor
            </button>
          </div>
        )}

        <div
          className={`relative z-10 my-2 px-4 py-2.5 rounded-2xl border flex items-center justify-between text-xs font-bold transition-all ${
            isAligned
              ? 'bg-[#2D6A4F]/80 border-[#52B788] text-white shadow-[0_0_20px_rgba(82,183,136,0.4)]'
              : 'bg-black/30 border-[#D4AF37]/30 text-[#F5E6B3]'
          }`}
        >
          <div className="flex items-center gap-2">
            {isAligned ? (
              <CheckCircle2 className="w-4 h-4 text-[#74C69D]" />
            ) : (
              <Navigation2 className="w-4 h-4 text-[#D4AF37] rotate-45" />
            )}
            <span>
              {isAligned
                ? 'Facing Holy Kaaba (সঠিক কিবলামুখী)'
                : `Rotate phone ${(needleRotation > 180 ? 360 - needleRotation : needleRotation).toFixed(0)}° ${
                    needleRotation > 180 ? 'left' : 'right'
                  } to face Qibla`}
            </span>
          </div>

          <span className="font-mono text-xs font-black text-[#D4AF37]">
            {qiblaAngle}° {cardinal}
          </span>
        </div>

        {/* Real-time Dynamic Compass Dial */}
        <div className="relative z-10 flex flex-col items-center justify-center my-4">
          <div
            className={`relative w-64 h-64 rounded-full border-4 flex items-center justify-center transition-all duration-300 shadow-[0_8px_32px_rgba(0,0,0,0.5)] ${
              isAligned
                ? 'border-[#52B788] ring-4 ring-[#52B788]/40 shadow-[0_0_35px_rgba(82,183,136,0.35)]'
                : 'border-[#D4AF37]/60'
            } bg-gradient-to-br from-[#10291D] via-[#163627] to-[#0A1810]`}
          >
            {/* Outer Cardinal Ring */}
            <div
              className="absolute inset-0 transition-transform duration-200"
              style={{ transform: `rotate(${-currentHeading}deg)` }}
            >
              {/* Cardinal Letters */}
              <span className="absolute top-2 left-1/2 -translate-x-1/2 font-black text-xs text-red-400">
                N
              </span>
              <span className="absolute bottom-2 left-1/2 -translate-x-1/2 font-black text-xs text-stone-300">
                S
              </span>
              <span className="absolute right-2 top-1/2 -translate-y-1/2 font-black text-xs text-stone-300">
                E
              </span>
              <span className="absolute left-2 top-1/2 -translate-y-1/2 font-black text-xs text-stone-300">
                W
              </span>

              {/* Kaaba Marker Pin on the Dial */}
              <div
                className="absolute top-1/2 left-1/2 w-full h-full -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                style={{ transform: `rotate(${qiblaAngle}deg)` }}
              >
                <div className="absolute top-2 left-1/2 -translate-x-1/2 flex flex-col items-center">
                  <div className="w-5 h-5 rounded-md bg-stone-950 border border-[#D4AF37] flex items-center justify-center shadow-md">
                    <span className="text-[9px]">🕋</span>
                  </div>
                  <span className="text-[8px] font-black text-[#D4AF37] mt-0.5">KAABA</span>
                </div>
              </div>

              {/* Dial Degree Ticks */}
              {Array.from({ length: 24 }).map((_, i) => {
                const angle = i * 15;
                const isMajor = angle % 90 === 0;
                return (
                  <div
                    key={i}
                    className="absolute top-0 left-1/2 w-0.5 h-full -translate-x-1/2 pointer-events-none"
                    style={{ transform: `rotate(${angle}deg)` }}
                  >
                    <div
                      className={`w-0.5 ${
                        isMajor
                          ? 'h-3 bg-[#D4AF37]'
                          : angle % 30 === 0
                          ? 'h-2 bg-stone-300/80'
                          : 'h-1 bg-stone-500/50'
                      }`}
                    />
                  </div>
                );
              })}
            </div>

            {/* Central Pointer Needle pointing directly to Qibla */}
            <div
              className="relative w-40 h-40 flex items-center justify-center transition-transform duration-150"
              style={{ transform: `rotate(${needleRotation}deg)` }}
            >
              {/* Golden Pointer Spear */}
              <div className="absolute top-1 left-1/2 -translate-x-1/2 flex flex-col items-center">
                <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-b-[24px] border-b-[#D4AF37] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]" />
                <div className="w-1.5 h-12 bg-gradient-to-b from-[#D4AF37] to-[#8C6D14]" />
              </div>

              {/* Opposite Needle Pointer (South) */}
              <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex flex-col items-center">
                <div className="w-1.5 h-10 bg-stone-600/70" />
                <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[18px] border-t-stone-500" />
              </div>

              {/* Center Hub */}
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#1B4332] to-[#2D6A4F] border-2 border-[#D4AF37] flex items-center justify-center shadow-lg z-20">
                <div className="w-2.5 h-2.5 rounded-full bg-[#D4AF37]" />
              </div>
            </div>

            {/* Live Bearing Overlay at Center */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/60 border border-[#D4AF37]/40 text-[10px] font-mono font-bold text-[#F4E0A5]">
              <span>Heading: {currentHeading}°</span>
            </div>
          </div>
        </div>

        {/* Distance and Location Stats */}
        <div className="grid grid-cols-2 gap-2.5 my-3 relative z-10 text-center">
          <div className="p-3 rounded-2xl bg-black/25 border border-[#D4AF37]/30">
            <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-200/80">
              Qibla Bearing
            </span>
            <div className="text-base font-black text-[#F4E0A5] font-mono mt-0.5">
              {qiblaAngle}° {cardinal}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-black/25 border border-[#D4AF37]/30">
            <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-200/80">
              Distance to Kaaba
            </span>
            <div className="text-base font-black text-[#F4E0A5] font-mono mt-0.5">
              {distanceKm.toLocaleString()} km
            </div>
          </div>
        </div>

        {/* Manual Calibration / Heading Slider & Sensor Fallback Notice */}
        <div className="my-2 p-3.5 rounded-2xl bg-black/35 border border-white/10 relative z-10 space-y-2">
          {!hasSensor && !needsPermission && (
            <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-200 text-[11px] leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold text-amber-300 mb-1">
                <Info className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span>লাইভ কম্পাস সেন্সর পাওয়া যায়নি (Live Sensor Unavailable)</span>
              </div>
              <p className="text-stone-300">
                এই ডিভাইসে বা ব্রাউজারে রিয়েল-টাইম ম্যাগনেটিক সেন্সর অনুপস্থিত। কিন্তু আপনার সঠিক কিবলা অ্যাঙ্গেল <strong className="text-white font-mono">{qiblaAngle}° ({cardinal})</strong>।
              </p>
              <p className="text-[10px] text-emerald-300/90 mt-1 font-medium">
                দিক-নির্দেশনা: উত্তর দিককে ০° ধরলে ঠিক {qiblaAngle}° কোণে পবিত্র কাবা। বাংলাদেশে সাধারণত পশ্চিম-উত্তর-পশ্চিম দিকে মুখ করলে কিবলামুখী হওয়া যায়।
              </p>
            </div>
          )}

          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-stone-300 flex items-center gap-1.5">
              <RotateCw className="w-3 h-3 text-[#D4AF37]" />
              <span>
                {hasSensor && !useManualMode
                  ? `🟢 লাইভ কম্পাস সেন্সর সক্রিয় (${currentHeading}°)`
                  : needsPermission
                  ? '🟠 সেন্সর অনুমতি প্রয়োজন (Permission Needed)'
                  : '🧭 ম্যানুয়াল কম্পাস দিক-সমন্বয় (Manual Direction)'}
              </span>
            </span>
            <button
              onClick={() => setUseManualMode(!useManualMode)}
              className="text-[10px] font-bold text-[#D4AF37] hover:underline cursor-pointer"
            >
              {useManualMode ? 'সেন্সর চেক' : 'ম্যানুয়াল দিক'}
            </button>
          </div>

          <input
            type="range"
            min="0"
            max="359"
            value={currentHeading}
            onChange={(e) => {
              setUseManualMode(true);
              setManualHeading(Number(e.target.value));
            }}
            className="w-full accent-[#D4AF37] cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-stone-400 font-mono">
            <span>0° (উত্তর / North)</span>
            <span>180° (দক্ষিণ / South)</span>
            <span>360°</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 flex flex-col gap-2 relative z-10">
          <div className="flex items-center gap-2">
            {onUpdateLocation && (
              <button
                onClick={onUpdateLocation}
                disabled={isUpdatingLocation}
                className="flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 bg-[#1B4332] hover:bg-[#2D6A4F] text-[#F4E0A5] border border-[#D4AF37]/60 flex items-center justify-center gap-1.5 shadow-sm"
              >
                <RotateCw className={`w-3.5 h-3.5 text-[#D4AF37] ${isUpdatingLocation ? 'animate-spin' : ''}`} />
                <span>{isUpdatingLocation ? 'Updating GPS...' : 'Update GPS Location'}</span>
              </button>
            )}

            <button
              onClick={onOpenLocationModal}
              className="flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 bg-black/30 hover:bg-black/50 text-[#F4E0A5] border border-[#D4AF37]/40 flex items-center justify-center gap-1.5"
            >
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Select City</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-full py-2.5 px-3 rounded-xl text-xs font-extrabold transition-all active:scale-95 bg-gradient-to-r from-[#D4AF37] to-[#E5C158] text-stone-950 border border-white/40 shadow-sm"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
