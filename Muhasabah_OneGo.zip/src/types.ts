export type TabType = 'dashboard' | 'salat' | 'dhikr' | 'calendar' | 'mal' | 'goals' | 'profile' | 'settings';

export type MoodType = 'Elevated' | 'Mindful' | 'Neutral' | 'Struggling' | 'Grateful';

export interface SelfAuditRecord {
  id: string;
  date: string;
  score: number; // 1-10
  note: string;
  salatQuality: number; // 1-5
  khushooRating: number; // 1-5
  createdAt: string;
  dayStateLabel?: 'খুব ভালো' | 'ভালো' | 'সাধারণ' | 'ঘাটতি ছিল';
  goodDeeds?: string;
  shortcomings?: string;
  lessonsLearned?: string;
  tomorrowImprovement?: string;
}

export interface DailyNiyyahRecord {
  id: string;
  date: string;
  intentionText: string;
  category: 'Worship' | 'Work/Halal Earning' | 'Family/Parents' | 'Knowledge' | 'Character';
  morningConfirmed: boolean;
  eveningFulfilled: boolean;
  reflection?: string;
  completed?: boolean;
  type?: string;
}

export interface GratitudeRecord {
  id: string;
  date: string;
  text: string;
  category: 'Spiritual' | 'Health' | 'Family' | 'Sustenance' | 'Trial Averted' | 'Peace';
  createdAt: string;
}

export interface GoodDeedRecord {
  id: string;
  date: string;
  title: string;
  category: 'Charity' | 'Kindness' | 'Parents/Family' | 'Community' | 'Sunnah' | 'Hidden';
  isHidden?: boolean; // Sirr ma'a Allah
  isSecret?: boolean;
  multiplierPoints?: number;
  completed: boolean;
  points?: number;
  reflection?: string;
}

export interface IstighfarRecord {
  id: string;
  date: string;
  count: number;
  target: number;
  selectedFormulas: string[];
  accountabilityChecklist: {
    id: string;
    label: string;
    checked: boolean;
  }[];
}

export interface PrayerItem {
  id: string;
  name: string;
  arabic: string;
  time: string;
  startTime?: string;
  endTime?: string;
  completed: boolean;
  isNext?: boolean;
  jamaah?: boolean;
  offsetMinutes?: number;
  baseTime?: string;
}

export interface MetricProgress {
  id: string;
  title: string;
  sub: string;
  percent: number;
  current: number;
  total: number;
  unit: string;
  color: string;
}

export type DuaCategory =
  | 'Morning'
  | 'Evening'
  | 'Before Sleep'
  | 'After Waking'
  | 'Eating'
  | 'Leaving Home'
  | 'Entering Home'
  | 'Travel'
  | 'Protection'
  | 'Forgiveness'
  | 'Parents'
  | 'Guidance'
  | 'Rizq'
  | 'Difficulty'
  | 'Quranic'
  | 'Essential'
  | 'General';

export interface DuaItem {
  id: string;
  title: string;
  bengaliTitle: string;
  arabic: string;
  transliteration: string;
  transliterationBn?: string;
  translationEn: string;
  translationBn: string;
  fazilat?: string;
  category: DuaCategory;
  count: number;
  target: number;
  completed: boolean;
  expanded?: boolean;
  audioUrl?: string;
}

export interface Achievement {
  id: string;
  title: string;
  desc: string;
  iconName: string;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
  dateUnlocked?: string;
}

export interface ReflectionEntry {
  id: string;
  date: string;
  text: string;
  mood: MoodType;
  tags: string[];
  imageUrl?: string;
  hasVoiceNote?: boolean;
}

export interface DayStreakItem {
  day: number;
  status: 'completed' | 'partial' | 'missed' | 'today' | 'future';
  score: number;
  dateStr: string;
}

// 6 Master Features Data Interfaces
export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  description: string;
  isBuiltIn?: boolean;
  category: 'National' | 'Hospital' | 'Police' | 'Fire' | 'Personal';
}

export interface ExpenseRecord {
  id: string;
  type?: 'save' | 'expense';
  title: string;
  amount: number;
  category: string;
  date: string; // YYYY-MM-DD
  note?: string;
}

export interface CustomGoal {
  id: string;
  title: string;
  target: number;
  current: number;
  unit: string;
  category: 'Salat' | 'Quran' | 'Dhikr' | 'Fasting' | 'Charity' | 'Habit' | 'Custom';
  completed: boolean;
  deadline?: string;
  createdAt?: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  source: 'Prothom Alo' | 'The Daily Star' | 'bdnews24' | 'BBC Bangla' | 'Reuters';
  category: 'Bangladesh' | 'International' | 'Politics' | 'Business' | 'Technology' | 'Sports' | 'Health' | 'World';
  publishedTime: string;
  summary: string;
  imageUrl: string;
  url: string;
}

export interface MedicineReminder {
  id: string;
  name: string;
  person: 'Me' | 'Father' | 'Mother' | string;
  category: 'Tablet' | 'Syrup' | 'Cream' | 'Drops' | 'Injection' | 'Other';
  dosage: string;
  mealInstruction: 'Before Food' | 'After Food' | 'With Food' | 'Empty Stomach';
  timeSlots: ('Morning' | 'Noon' | 'Night')[];
  exactTime: string;
  takenToday: boolean;
  snoozedUntil?: number | null; // epoch timestamp
}

export interface AgeCalculationResult {
  years: number;
  months: number;
  days: number;
  nextBirthdayMonths: number;
  nextBirthdayDays: number;
  nextBirthdayTotalDays: number;
  totalDaysLived: number;
  totalWeeksLived: number;
  totalMonthsLived: number;
  totalHoursLived: number;
  dayOfWeek: string;
}

export interface ObservanceDay {
  id: string;
  title: string;
  titleBn: string;
  date: string; // YYYY-MM-DD
  category: 'Islamic' | 'National' | 'International';
  description: string;
}

export interface LocationConfig {
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  timezoneOffset: number;
}

export interface WeatherInfo {
  temp: number;
  condition: string;
  conditionBn: string;
  humidity: number;
  windSpeed: number;
  airQuality: string;
}

export interface FinanceLevelInfo {
  level: number;
  levelName: string;
  levelNameBn: string;
  minSavings: number;
  nextTarget: number;
  badge: string;
  description: string;
}

export interface MyDayTask {
  id: string;
  title: string;
  category: 'Amal' | 'Work' | 'Health' | 'Study' | 'Family' | 'General';
  priority: 'High' | 'Medium' | 'Low';
  targetTime?: string;
  completed: boolean;
  notes?: string;
  createdAt: string;
}

export interface InspiringQuote {
  id: string;
  arabic?: string;
  quoteBn: string;
  quoteEn?: string;
  source: string;
  category: 'Quran' | 'Hadith' | 'Hikmah' | 'Sunnah';
}

// 1. Day Countdown / Target Tracker Interface
export interface TargetDayItem {
  id: string;
  title: string;
  titleBn: string;
  targetDate: string; // YYYY-MM-DD
  category: 'Islamic' | 'Personal' | 'Goal' | 'Family';
  notes?: string;
}

// 2. Sadaqah Log Interface
export interface SadaqahItem {
  id: string;
  title: string;
  amount: number;
  date: string;
  category: 'Secret' | 'Relatives' | 'Poor & Needy' | 'Mosque & Madrasa' | 'Water Well' | 'Emergency Aid' | 'Other';
  categoryBn: string;
  isAnonymous: boolean;
  notes?: string;
}

// 3. Dashboard Medical/Emergency Style Widgets Interfaces
export interface DailySelfAudit {
  id: string;
  date: string;
  score: number; // 1-10
  diaryNote: string;
  purityScore?: number;
}

export interface SunnahAdhkarStep {
  id: string;
  period: 'fajr' | 'morning' | 'duha' | 'evening' | 'night';
  periodLabel: string;
  periodLabelBn: string;
  title: string;
  titleBn: string;
  arabic: string;
  transliteration: string;
  meaningBn: string;
  count: number;
  target: number;
  completed: boolean;
}

export interface IstighfarLedgerRecord {
  id: string;
  date: string;
  sinAccountabilityNote: string;
  istighfarCount: number;
  targetCount: number;
  tawbahMade: boolean;
}

export interface SunnahHabitItem {
  id: string;
  title: string;
  titleBn: string;
  hadithSource: string;
  category: 'Daily' | 'Eating' | 'Sleep' | 'Speech' | 'Purity';
  completed: boolean;
}

export interface GratitudeEntry {
  id: string;
  date: string;
  blessing1: string;
  blessing2: string;
  blessing3: string;
}

export interface EmotionalHealingItem {
  id: string;
  feelingKey?: 'stressed' | 'anxious' | 'grieving' | 'angry' | 'weak_faith' | 'lonely' | 'guilt';
  feelingTitle?: string;
  feelingTitleBn?: string;
  feelingDesc?: string;
  quranAyat?: {
    surah: string;
    ayahNumber: number;
    arabic: string;
    translationBn: string;
    transliteration: string;
  };
  hadithGuidance?: {
    source: string;
    arabic?: string;
    translationBn: string;
  };
  therapeuticSteps?: string[];
  recommendedDhikr?: string;
  recitationCount?: number;
  dalilProof?: string;
  // Direct fields
  emotion?: string;
  titleEn?: string;
  titleBn?: string;
  arabic?: string;
  transliteration?: string;
  meaningBn?: string;
  actionAdvice?: string;
  reference?: string;
  recommendedCount?: number;
}

export interface DigitalVowItem {
  id: string;
  vowTitle: string;
  vowTitleBn: string;
  type: 'Promise to Allah (মানত/ওয়াদা)' | 'Personal Resolution (প্রতিজ্ঞা)' | 'Good Habit Pledge';
  dateMade: string;
  targetDate?: string;
  status: 'active' | 'fulfilled' | 'broken';
  notes?: string;
  kaffarahGuidance?: string;
}

export interface WisdomBookmark {
  id: string;
  title: string;
  arabic?: string;
  translationBn?: string;
  translationEn?: string;
  translation?: string;
  notes?: string;
  source: string;
  category: 'Quran' | 'Hadith' | 'Quote';
  savedAt?: string;
  dateAdded?: string;
}

export type WisdomBookmarkItem = WisdomBookmark;

export interface SurahLibraryItem {
  id: string;
  number: number;
  nameEn: string;
  nameBn: string;
  nameAr: string;
  totalVerses: number;
  revelationType: 'Meccan' | 'Medinan';
  fazilatBn: string;
  keyVerses: {
    ayahNumber: number;
    arabic: string;
    transliterationBn: string;
    meaningBn: string;
    audioUrl?: string;
  }[];
  audioUrl?: string;
}

export type PlannerTaskCategory = 'Fardh' | 'Sunnah' | 'Work' | 'Personal' | 'Khair';
export type PlannerTaskPriority = 'High' | 'Medium' | 'Low';

export interface PlannerGoal {
  id: string;
  title: string;
  category?: 'Worship' | 'Work' | 'Personal' | 'Knowledge' | 'General';
  completed: boolean;
  createdAt?: string;
}

export interface PlannerTask {
  id: string;
  createdAt: string;
  updatedAt?: string;
  date: string;
  title: string;
  content?: string;
  category: PlannerTaskCategory;
  priority: PlannerTaskPriority;
  completed: boolean;
  time?: string;
}

export interface DayPlanData {
  date: string;
  niyyah: string;
  dailyPlan: string;
  goals: PlannerGoal[];
  islamicGoal?: string;
  worldlyGoal?: string;
  quranTarget?: string;
  quranTargetCompleted?: boolean;
  tasks: PlannerTask[];
  reflection: string;
  barakahRating: number;
}

