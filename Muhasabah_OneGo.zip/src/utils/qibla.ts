import { PrayerItem, FinanceLevelInfo } from '../types';

// Accurate Qibla bearing calculation from latitude & longitude
// Kaaba coordinates: 21.422487° N, 39.826206° E

const KAABA_LAT = (21.422487 * Math.PI) / 180;
const KAABA_LNG = (39.826206 * Math.PI) / 180;

export function calculateQibla(latitude: number, longitude: number): number {
  const userLat = (latitude * Math.PI) / 180;
  const userLng = (longitude * Math.PI) / 180;
  const deltaLng = KAABA_LNG - userLng;

  const y = Math.sin(deltaLng);
  const x =
    Math.cos(userLat) * Math.tan(KAABA_LAT) -
    Math.sin(userLat) * Math.cos(deltaLng);

  let qibla = Math.atan2(y, x) * (180 / Math.PI);
  qibla = (qibla + 360) % 360;
  return Math.round(qibla * 10) / 10;
}

export function calculateDistanceToMakkah(latitude: number, longitude: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((21.422487 - latitude) * Math.PI) / 180;
  const dLon = ((39.826206 - longitude) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((latitude * Math.PI) / 180) *
      Math.cos((21.422487 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export function getCardinalDirection(angle: number): string {
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const index = Math.round(angle / 22.5) % 16;
  return directions[index];
}

export const BANGLADESH_LOCATIONS = [
  { name: 'Dhaka', country: 'Bangladesh', latitude: 23.8103, longitude: 90.4125, timezoneOffset: 6 },
  { name: 'Sirajganj', country: 'Bangladesh', latitude: 24.4534, longitude: 89.7008, timezoneOffset: 6 },
  { name: 'Chittagong', country: 'Bangladesh', latitude: 22.3569, longitude: 91.7832, timezoneOffset: 6 },
  { name: 'Sylhet', country: 'Bangladesh', latitude: 24.8949, longitude: 91.8687, timezoneOffset: 6 },
  { name: 'Rajshahi', country: 'Bangladesh', latitude: 24.3745, longitude: 88.6042, timezoneOffset: 6 },
  { name: 'Khulna', country: 'Bangladesh', latitude: 22.8456, longitude: 89.5403, timezoneOffset: 6 },
  { name: 'Barisal', country: 'Bangladesh', latitude: 22.7010, longitude: 90.3535, timezoneOffset: 6 },
  { name: 'Rangpur', country: 'Bangladesh', latitude: 25.7439, longitude: 89.2752, timezoneOffset: 6 },
  { name: 'Mymensingh', country: 'Bangladesh', latitude: 24.7471, longitude: 90.4203, timezoneOffset: 6 },
  { name: 'Bogura', country: 'Bangladesh', latitude: 24.8465, longitude: 89.3778, timezoneOffset: 6 },
];

export function getProhibitedTimes() {
  return [
    {
      id: 'sunrise',
      name: 'Sunrise (Shuruq)',
      nameBn: 'সূর্যোদয়ের সময়',
      timeRange: '05:48 AM - 06:05 AM',
      description: 'From start of sunrise until sun is well above horizon (~15-20 min). Strictly prohibited for any Salah.',
    },
    {
      id: 'zawwal',
      name: 'Midday Zenith (Zawwal / Istiwa)',
      nameBn: 'দ্বিপ্রহরের সময় (জাওয়াল)',
      timeRange: '11:48 AM - 12:02 PM',
      description: 'When sun is exactly at meridian until it starts to decline (~10-15 min before Dhuhr). Prohibited for Salah.',
    },
    {
      id: 'sunset',
      name: 'Sunset (Ghurub)',
      nameBn: 'সূর্যাস্তের সময়',
      timeRange: '05:50 PM - 06:08 PM',
      description: 'As the sun yellows and sets (~15-20 min before Maghrib). Prohibited to pray, except that day’s Asr if delayed.',
    },
  ];
}

export function getNawafilPrayers() {
  return [
    {
      id: 'tahajjud',
      name: 'Tahajjud (Qiyam-ul-Layl)',
      nameBn: 'তাহাজ্জুদ সালাত',
      timeRange: '03:15 AM - 04:20 AM',
      rakats: '2 to 12 Rakats',
      description: 'Performed in the last third of the night after sleeping. The most beloved voluntary prayer to Allah.',
    },
    {
      id: 'ishraq',
      name: 'Ishraq Prayer',
      nameBn: 'ইশরাক সালাত',
      timeRange: '06:15 AM - 07:15 AM',
      rakats: '2 to 4 Rakats',
      description: 'Offered ~15-20 minutes after sunrise. Equivalent to the reward of a complete Hajj and Umrah.',
    },
    {
      id: 'chasht',
      name: 'Chasht (Salat al-Duha)',
      nameBn: 'চাশত (সালাতুদ দুহা)',
      timeRange: '08:30 AM - 11:30 AM',
      rakats: '2, 4, or 8 Rakats',
      description: 'Mid-morning prayer when heat of sun begins. Sadaqah on behalf of every joint in the human body.',
    },
  ];
}

// Convert "hh:mm AM/PM" to minutes from midnight
export function timeStringToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.trim().split(' ');
  if (parts.length < 2) return 0;
  const [hm, meridiem] = parts;
  const [hStr, mStr] = hm.split(':');
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  if (meridiem.toUpperCase() === 'PM' && h !== 12) h += 12;
  if (meridiem.toUpperCase() === 'AM' && h === 12) h = 0;
  return h * 60 + m;
}

// Format minutes from midnight to "hh:mm AM/PM"
export function minutesToTimeString(minutes: number): string {
  let m = (minutes % 1440 + 1440) % 1440;
  let h = Math.floor(m / 60);
  const min = m % 60;
  const meridiem = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h < 10 ? '0' : ''}${h}:${min < 10 ? '0' : ''}${min} ${meridiem}`;
}

// Check if currently inside a Makruh period
export interface MakruhStatus {
  isMakruh: boolean;
  name?: string;
  nameBn?: string;
  timeRange?: string;
  reason?: string;
}

export function getCurrentMakruhStatus(now: Date = new Date()): MakruhStatus {
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  // 1. Sunrise: ~5:48 AM to 6:05 AM (348 to 365)
  if (currentMinutes >= 348 && currentMinutes <= 365) {
    return {
      isMakruh: true,
      name: 'Sunrise (সূর্যোদয়ের নিষিদ্ধ ওয়াক্ত)',
      nameBn: 'সূর্যোদয়ের সময়',
      timeRange: '05:48 AM - 06:05 AM',
      reason: 'সূর্য উদিত হওয়ার সময় সালাত আদায় করা সম্পূর্ণরূপে নিষিদ্ধ।',
    };
  }

  // 2. Zawwal: ~11:48 AM to 12:02 PM (708 to 722)
  if (currentMinutes >= 708 && currentMinutes <= 722) {
    return {
      isMakruh: true,
      name: 'Midday Zenith (দ্বিপ্রহর / জাওয়াল)',
      nameBn: 'দ্বিপ্রহরের সময়',
      timeRange: '11:48 AM - 12:02 PM',
      reason: 'সূর্য ঠিক মাথার উপরে থাকার সময় যেকোনো নামাজ পড়া নিষিদ্ধ।',
    };
  }

  // 3. Sunset: ~5:50 PM to 6:08 PM (1070 to 1088)
  if (currentMinutes >= 1070 && currentMinutes <= 1088) {
    return {
      isMakruh: true,
      name: 'Sunset (সূর্যাস্তের নিষিদ্ধ ওয়াক্ত)',
      nameBn: 'সূর্যাস্তের সময়',
      timeRange: '05:50 PM - 06:08 PM',
      reason: 'সূর্য রক্তিম হয়ে অস্তমিত হওয়ার সময় সালাত আদায় নিষিদ্ধ।',
    };
  }

  return { isMakruh: false };
}

// Dynamic Active Prayer Detection
export function getActivePrayerId(prayers: PrayerItem[], now: Date = new Date()): string {
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  for (const prayer of prayers) {
    if (prayer.startTime && prayer.endTime) {
      const startMin = timeStringToMinutes(prayer.startTime);
      let endMin = timeStringToMinutes(prayer.endTime);
      
      // Handle wrap-around midnight for Isha (e.g. 7:22 PM to 4:20 AM)
      if (endMin < startMin) {
        if (currentMinutes >= startMin || currentMinutes <= endMin) {
          return prayer.id;
        }
      } else {
        if (currentMinutes >= startMin && currentMinutes <= endMin) {
          return prayer.id;
        }
      }
    }
  }

  // Fallback to first prayer marked isNext or fajr
  return prayers.find((p) => p.isNext)?.id || 'fajr';
}

// Prayer times: University of Islamic Sciences, Karachi (MWL-style angles)
// Fajr = 18°, Isha = 18°, Asr = Hanafi (shadow factor 2).
// Sunrise/Sunset use the standard 0.833° solar-refraction angle.
// Times are calculated from the actual date + coordinates and converted to local time.
const KARACHI_FAJR_ANGLE = 18;
const KARACHI_ISHA_ANGLE = 18;
const SUNRISE_SUNSET_ANGLE = 0.833;
const DEFAULT_BANGLADESH_TZ = 6;

const degToRad = (deg: number) => (deg * Math.PI) / 180;
const radToDeg = (rad: number) => (rad * 180) / Math.PI;
const fixAngle = (angle: number) => ((angle % 360) + 360) % 360;
const fixHour = (hour: number) => ((hour % 24) + 24) % 24;

function julianDate(date: Date): number {
  return date.getTime() / 86400000 + 2440587.5;
}

function sunPosition(jd: number) {
  const D = jd - 2451545.0;
  const g = degToRad(fixAngle(357.529 + 0.98560028 * D));
  const q = fixAngle(280.459 + 0.98564736 * D);
  const L = degToRad(fixAngle(q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)));
  const e = degToRad(23.439 - 0.00000036 * D);

  const RA = radToDeg(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15;
  const eqt = q / 15 - fixHour(RA);
  const decl = radToDeg(Math.asin(Math.sin(e) * Math.sin(L)));
  return { declination: decl, equationOfTime: eqt };
}

function solarHourAngle(angle: number, latitude: number, declination: number): number {
  const numerator = -Math.sin(degToRad(angle)) - Math.sin(degToRad(latitude)) * Math.sin(degToRad(declination));
  const denominator = Math.cos(degToRad(latitude)) * Math.cos(degToRad(declination));
  const cosH = numerator / denominator;
  if (cosH <= -1) return 180;
  if (cosH >= 1) return 0;
  return radToDeg(Math.acos(cosH));
}

function asrHourAngle(latitude: number, declination: number, factor = 2): number {
  const angle = -radToDeg(Math.atan(1 / (factor + Math.tan(Math.abs(degToRad(latitude - declination))))));
  return solarHourAngle(angle, latitude, declination);
}

function calculateSolarTimes(latitude: number, longitude: number, date: Date, timezoneOffset: number) {
  const jd = julianDate(date);
  const { declination, equationOfTime } = sunPosition(jd);
  const noon = 12 - equationOfTime + timezoneOffset - longitude / 15;

  const fajrHA = solarHourAngle(KARACHI_FAJR_ANGLE, latitude, declination) / 15;
  const sunriseHA = solarHourAngle(SUNRISE_SUNSET_ANGLE, latitude, declination) / 15;
  const asrHA = asrHourAngle(latitude, declination, 2) / 15;
  const sunsetHA = sunriseHA;
  const ishaHA = solarHourAngle(KARACHI_ISHA_ANGLE, latitude, declination) / 15;

  return {
    fajr: noon - fajrHA,
    sunrise: noon - sunriseHA,
    dhuhr: noon,
    asr: noon + asrHA,
    sunset: noon + sunsetHA,
    isha: noon + ishaHA,
  };
}

export function calculatePrayerTimes(
  latitude: number,
  longitude: number,
  date: Date = new Date(),
  timezoneOffset: number = DEFAULT_BANGLADESH_TZ
): PrayerItem[] {
  // Use the local civil date represented by the supplied date. Bangladesh is UTC+6;
  // location presets/GPS in this app are Bangladesh locations, so this is deterministic.
  const times = calculateSolarTimes(latitude, longitude, date, timezoneOffset);
  const today = {
    fajr: times.fajr,
    sunrise: times.sunrise,
    dhuhr: times.dhuhr,
    asr: times.asr,
    sunset: times.sunset,
    isha: times.isha,
  };

  // Isha ends at the next day's Fajr. Calculate next-day Fajr separately so the
  // overnight interval remains correct for countdown/status calculations.
  const nextDate = new Date(date.getTime() + 86400000);
  const tomorrow = calculateSolarTimes(latitude, longitude, nextDate, timezoneOffset);

  const make = (
    id: PrayerItem['id'],
    name: string,
    arabic: string,
    start: number,
    end: number
  ): PrayerItem => ({
    id,
    name,
    arabic,
    baseTime: minutesToTimeString(Math.round(start * 60)),
    time: minutesToTimeString(Math.round(start * 60)),
    startTime: minutesToTimeString(Math.round(start * 60)),
    endTime: minutesToTimeString(Math.round(end * 60)),
    completed: false,
    isNext: false,
    jamaah: false,
    offsetMinutes: 0,
  });

  return [
    make('fajr', 'Fajr', 'الفجر', today.fajr, today.sunrise),
    make('dhuhr', 'Dhuhr', 'الظهر', today.dhuhr, today.asr),
    make('asr', 'Asr', 'العصر', today.asr, today.sunset),
    make('maghrib', 'Maghrib', 'المغرب', today.sunset, today.isha),
    make('isha', 'Isha', 'العشاء', today.isha, tomorrow.fajr),
  ];
}

// Gamified Financial Level System (Muhasabat al-Mal)
export function getFinanceLevel(netSavings: number): FinanceLevelInfo {
  if (netSavings >= 100000) {
    return {
      level: 5,
      levelName: 'Waqf Champion',
      levelNameBn: 'বরকতময় দাতা (ওয়াকফ চ্যাম্পিয়ন)',
      minSavings: 100000,
      nextTarget: 250000,
      badge: '👑 Master of Barakah',
      description: 'Exceptional financial stewardship with abundant capability for Waqf, family security, and continuous Sadaqah Jariyah.',
    };
  }
  if (netSavings >= 50000) {
    return {
      level: 4,
      levelName: 'Sahib al-Mal',
      levelNameBn: 'শৃঙ্খলিত অভিভাবক (সাহিব আল-মাল)',
      minSavings: 50000,
      nextTarget: 100000,
      badge: '💎 Disciplined Guardian',
      description: 'Steadfast reserve maintained with disciplined moderation, clear emergency buffer, and fulfilled rights.',
    };
  }
  if (netSavings >= 20000) {
    return {
      level: 3,
      levelName: 'Mutawakkil',
      levelNameBn: 'সুপরিকল্পনাকারী (মুতাওয়াক্কিল)',
      minSavings: 20000,
      nextTarget: 50000,
      badge: '🛡️ Steady Steward',
      description: 'Solid financial groundwork with consistent monthly halal savings and conscientious expense control.',
    };
  }
  if (netSavings >= 5000) {
    return {
      level: 2,
      levelName: 'Muqtasid',
      levelNameBn: 'পরিমিত ব্যয়কারী (মুকতাসিদ)',
      minSavings: 5000,
      nextTarget: 20000,
      badge: '🌱 Prudent Saver',
      description: 'Begun conscious budgeting, avoiding Israf (extravagance), and building a modest personal fund.',
    };
  }
  return {
    level: 1,
    levelName: 'Mubtadi’',
    levelNameBn: 'শিক্ষানবিস সঞ্চয়ী (মুবতাদি)',
    minSavings: 0,
    nextTarget: 5000,
    badge: '🌿 Starter Novice',
    description: 'Starting the spiritual accounting journey. Begin saving small sums daily and eliminating unnecessary outflows.',
  };
}

// Triple Calendar Helper Functions:
// 1. Gregorian (Standard)
// 2. Bengali Calendar (বঙ্গাব্দ)
// 3. Hijri / Islamic Calendar
const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export function toBengaliNumerals(num: number | string): string {
  return String(num).replace(/\d/g, (d) => BENGALI_DIGITS[parseInt(d, 10)]);
}

// Bangladesh's revised Bangla calendar (Bangla Academy / Bangladesh civil calendar).
// The civil date begins on 14 April; the first five months have 31 days,
// Ashwin through Magh have 30 days, Falgun has 29 (30 in Gregorian leap years),
// and Chaitra has 30 days.
const BANGLA_MONTHS = [
  { name: 'বৈশাখ', season: 'গ্রীষ্মকাল' },
  { name: 'জ্যৈষ্ঠ', season: 'গ্রীষ্মকাল' },
  { name: 'আষাঢ়', season: 'বর্ষাকাল' },
  { name: 'শ্রাবণ', season: 'বর্ষাকাল' },
  { name: 'ভাদ্র', season: 'শরৎকাল' },
  { name: 'আশ্বিন', season: 'শরৎকাল' },
  { name: 'কার্তিক', season: 'হেমন্তকাল' },
  { name: 'অগ্রহায়ণ', season: 'হেমন্তকাল' },
  { name: 'পৌষ', season: 'শীতকাল' },
  { name: 'মাঘ', season: 'শীতকাল' },
  { name: 'ফাল্গুন', season: 'বসন্তকাল' },
  { name: 'চৈত্র', season: 'বসন্তকাল' },
];

function getBangladeshCivilParts(date: Date) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value || 0);
  return { year: get('year'), month: get('month'), day: get('day') };
}

function isGregorianLeapYear(year: number) {
  return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
}

export function getBengaliDate(date: Date = new Date()) {
  const { year: gy, month: gm, day: gd } = getBangladeshCivilParts(date);

  // Bangladesh's civil Bangla year changes on 14 April.
  const banglaYear = gy - (gm > 4 || (gm === 4 && gd >= 14) ? 593 : 594);

  if (gm === 4 && gd >= 14 || gm > 4) {
    // Calculate days since 14 April of the Gregorian year.
    const start = Date.UTC(gy, 3, 14);
    const current = Date.UTC(gy, gm - 1, gd);
    let dayOfYear = Math.floor((current - start) / 86400000) + 1;
    const monthLengths = [31, 31, 31, 31, 31, 30, 30, 30, 30, 30, isGregorianLeapYear(gy) ? 30 : 29, 30];
    let monthIdx = 0;
    while (dayOfYear > monthLengths[monthIdx] && monthIdx < 11) {
      dayOfYear -= monthLengths[monthIdx];
      monthIdx += 1;
    }
    const monthInfo = BANGLA_MONTHS[monthIdx];
    return {
      day: toBengaliNumerals(dayOfYear),
      month: monthInfo.name,
      year: toBengaliNumerals(banglaYear),
      season: monthInfo.season,
      fullText: `${toBengaliNumerals(dayOfYear)} ${monthInfo.name} ${toBengaliNumerals(banglaYear)} বঙ্গাব্দ`,
    };
  }

  // January 1 through April 13 belongs to the previous Bangla year.
  const prevGy = gy - 1;
  const start = Date.UTC(prevGy, 3, 14);
  const current = Date.UTC(gy, gm - 1, gd);
  let dayOfYear = Math.floor((current - start) / 86400000) + 1;
  const monthLengths = [31, 31, 31, 31, 31, 30, 30, 30, 30, 30, isGregorianLeapYear(prevGy) ? 30 : 29, 30];
  let monthIdx = 0;
  while (dayOfYear > monthLengths[monthIdx] && monthIdx < 11) {
    dayOfYear -= monthLengths[monthIdx];
    monthIdx += 1;
  }
  const monthInfo = BANGLA_MONTHS[monthIdx];
  return {
    day: toBengaliNumerals(dayOfYear),
    month: monthInfo.name,
    year: toBengaliNumerals(banglaYear),
    season: monthInfo.season,
    fullText: `${toBengaliNumerals(dayOfYear)} ${monthInfo.name} ${toBengaliNumerals(banglaYear)} বঙ্গাব্দ`,
  };
}

const HIJRI_MONTHS_BN = [
  'মুহররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি',
  'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ',
];

export function getHijriDate(date: Date = new Date(), adjustment: number = 0) {
  // Bangladesh local civil date; optional -2..+2 adjustment is intentionally
  // kept outside Salat so the user can align the Hijri calendar with local
  // moon-sighting when needed.
  const adjusted = new Date(date.getTime() + Math.round(adjustment) * 86400000);
  try {
    const formatter = new Intl.DateTimeFormat('en-US-u-ca-islamic-umalqura', {
      timeZone: 'Asia/Dhaka', day: 'numeric', month: 'numeric', year: 'numeric',
    });
    const parts = formatter.formatToParts(adjusted);
    const day = Number(parts.find((p) => p.type === 'day')?.value || 0);
    const month = Number(parts.find((p) => p.type === 'month')?.value || 0);
    const year = Number(parts.find((p) => p.type === 'year')?.value || 0);
    const monthName = HIJRI_MONTHS_BN[month - 1] || '';
    const monthNamesEn = ['Muharram','Safar','Rabi al-Awwal','Rabi al-Thani','Jumada al-Awwal','Jumada al-Thani','Rajab','Sha’ban','Ramadan','Shawwal','Dhu al-Qi’dah','Dhu al-Hijjah'];
    const fullText = `${toBengaliNumerals(day)} ${monthName} ${toBengaliNumerals(year)} হিজরি`;
    const fullTextEn = `${day} ${monthNamesEn[month - 1] || ''} ${year} AH`;
    return {
      day: toBengaliNumerals(day), month: monthName,
      monthEn: monthNamesEn[month - 1] || '', year: toBengaliNumerals(year),
      yearEn: `${year} AH`, fullText, fullTextEn,
      isSacredMonth: [1, 7, 11, 12].includes(month),
    };
  } catch {
    return { day:'', month:'', monthEn:'', year:'', yearEn:'', fullText:'হিজরি তারিখ', fullTextEn:'Hijri date', isSacredMonth:false };
  }
}
