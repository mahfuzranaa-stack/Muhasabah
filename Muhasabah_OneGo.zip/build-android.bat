@echo off
setlocal
npm install
call npm run build
call npx cap add android
call npx cap sync android
if /I "%1"=="debug" (
  cd android
  call gradlew.bat assembleDebug
  cd ..
  copy /Y android\app\build\outputs\apk\debug\app-debug.apk public\Muhasabah.apk
) else (
  cd android
  call gradlew.bat assembleRelease
  cd ..
  echo Release APK built. Sign the release APK before publishing it as Muhasabah.apk.
)
