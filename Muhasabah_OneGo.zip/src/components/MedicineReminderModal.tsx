import React, { useState, useEffect } from 'react';
import {
  X,
  Pill,
  RotateCcw,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Circle,
  Clock,
  User,
  Bell,
  Check,
  AlertCircle,
} from 'lucide-react';
import { MedicineReminder } from '../types';
import { playNotificationTone } from '../utils/audio';

interface MedicineReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
  medicines: MedicineReminder[];
  onAddMedicine: (med: Omit<MedicineReminder, 'id'>) => void;
  onUpdateMedicine: (med: MedicineReminder) => void;
  onDeleteMedicine: (id: string) => void;
  onToggleTaken: (id: string) => void;
  onSnoozeMedicine: (id: string, minutes: number) => void;
  onResetMedicines?: () => void;
}

const PERSONS = ['Me', 'Father', 'Mother', 'Grandma', 'Child'];
const CATEGORIES: MedicineReminder['category'][] = [
  'Tablet',
  'Syrup',
  'Cream',
  'Drops',
  'Injection',
  'Other',
];
const MEAL_INSTRUCTIONS: MedicineReminder['mealInstruction'][] = [
  'Before Food',
  'After Food',
  'With Food',
  'Empty Stomach',
];
const TIME_SLOTS: ('Morning' | 'Noon' | 'Night')[] = ['Morning', 'Noon', 'Night'];

export const MedicineReminderModal: React.FC<MedicineReminderModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
  medicines,
  onAddMedicine,
  onUpdateMedicine,
  onDeleteMedicine,
  onToggleTaken,
  onSnoozeMedicine,
  onResetMedicines,
}) => {
  const [selectedPerson, setSelectedPerson] = useState<string>('All');
  const [isAdding, setIsAdding] = useState(false);
  const [editingMed, setEditingMed] = useState<MedicineReminder | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [person, setPerson] = useState('Me');
  const [category, setCategory] = useState<MedicineReminder['category']>('Tablet');
  const [dosage, setDosage] = useState('1 Tablet');
  const [mealInstruction, setMealInstruction] =
    useState<MedicineReminder['mealInstruction']>('After Food');
  const [selectedSlots, setSelectedSlots] = useState<('Morning' | 'Noon' | 'Night')[]>([
    'Morning',
  ]);
  const [exactTime, setExactTime] = useState('08:00 AM');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Live second ticker for snooze timers
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleStartEdit = (med: MedicineReminder) => {
    setEditingMed(med);
    setName(med.name);
    setPerson(med.person);
    setCategory(med.category);
    setDosage(med.dosage);
    setMealInstruction(med.mealInstruction);
    setSelectedSlots(med.timeSlots);
    setExactTime(med.exactTime);
    setIsAdding(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingMed) {
      onUpdateMedicine({
        ...editingMed,
        name: name.trim(),
        person,
        category,
        dosage: dosage.trim() || '1 Dose',
        mealInstruction,
        timeSlots: selectedSlots.length ? selectedSlots : ['Morning'],
        exactTime: exactTime.trim() || '08:00 AM',
      });
      showToast('Medicine schedule updated successfully');
    } else {
      onAddMedicine({
        name: name.trim(),
        person,
        category,
        dosage: dosage.trim() || '1 Dose',
        mealInstruction,
        timeSlots: selectedSlots.length ? selectedSlots : ['Morning'],
        exactTime: exactTime.trim() || '08:00 AM',
        takenToday: false,
      });
      showToast('New medicine reminder added');
    }

    // Reset
    setIsAdding(false);
    setEditingMed(null);
    setName('');
    setPerson('Me');
    setCategory('Tablet');
    setDosage('1 Tablet');
    setMealInstruction('After Food');
    setSelectedSlots(['Morning']);
    setExactTime('08:00 AM');
  };

  const handleSnooze = (id: string, name: string) => {
    onSnoozeMedicine(id, 5); // 5 minutes snooze
    playNotificationTone(soundEnabled);
    showToast(`⏰ Snoozed ${name} for 5 minutes!`);
  };

  const filteredMedicines = medicines.filter((m) => {
    if (selectedPerson === 'All') return true;
    return m.person === selectedPerson;
  });

  const takenCount = filteredMedicines.filter((m) => m.takenToday).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[90vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header with Deep Emerald Gradient */}
        <div className="p-4 border-b border-emerald-100/60 dark:border-[#254F3E] flex items-center justify-between bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-500 text-stone-950 shadow-md">
              <Pill className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Medicine Reminder
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#D4AF37] text-stone-950 font-black">
                  5-Min Snooze
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Family medicine schedules, meal instructions &amp; dosage alarms
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {onResetMedicines && <button onClick={() => { if (window.confirm('সব Medicine রেকর্ড রিসেট করবেন?')) onResetMedicines(); }} title="Reset medicines" className="p-2 rounded-xl hover:bg-white/10 text-rose-200 transition-all"><RotateCcw className="w-4 h-4" /></button>}
            <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
          </div>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="px-4 py-2 bg-[#2D6A4F] text-white text-xs font-bold text-center animate-fade-in">
            ✨ {toastMsg}
          </div>
        )}

        {/* Scrollable Container */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3.5">
          {/* Progress & Add Button */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#E8F5E9]/70 dark:bg-[#163024] border border-emerald-200/80 dark:border-emerald-800">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-stone-500 dark:text-stone-400">
                Today&apos;s Adherence
              </span>
              <div className="text-sm font-extrabold text-[#1B4332] dark:text-[#74C69D]">
                {takenCount} of {filteredMedicines.length} doses taken
              </div>
            </div>

            <button
              onClick={() => {
                setEditingMed(null);
                setName('');
                setPerson('Me');
                setCategory('Tablet');
                setDosage('1 Tablet');
                setMealInstruction('After Food');
                setSelectedSlots(['Morning']);
                setExactTime('08:00 AM');
                setIsAdding(!isAdding);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-extrabold bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>{isAdding ? 'Cancel' : 'Add Medicine'}</span>
            </button>
          </div>

          {/* Add / Edit Form */}
          {isAdding && (
            <form
              onSubmit={handleSave}
              className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#E8F5E9]/50 dark:bg-[#163024] space-y-2.5 animate-in fade-in"
            >
              <div className="text-xs font-black text-[#1B4332] dark:text-[#F4E0A5] uppercase tracking-wider">
                {editingMed ? 'Edit Medicine Schedule' : 'Add New Medicine Schedule'}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Medicine Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Paracetamol, Omeprazole"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Person</label>
                  <select
                    value={person}
                    onChange={(e) => setPerson(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  >
                    {PERSONS.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Form</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as MedicineReminder['category'])}
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Dosage</label>
                  <input
                    type="text"
                    value={dosage}
                    onChange={(e) => setDosage(e.target.value)}
                    placeholder="1 Tablet / 5ml"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Meal Rule</label>
                  <select
                    value={mealInstruction}
                    onChange={(e) =>
                      setMealInstruction(e.target.value as MedicineReminder['mealInstruction'])
                    }
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  >
                    {MEAL_INSTRUCTIONS.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Time Slots</label>
                  <div className="flex gap-1 mt-1">
                    {TIME_SLOTS.map((slot) => {
                      const active = selectedSlots.includes(slot);
                      return (
                        <button
                          key={slot}
                          type="button"
                          onClick={() => {
                            if (active) {
                              if (selectedSlots.length > 1) {
                                setSelectedSlots(selectedSlots.filter((s) => s !== slot));
                              }
                            } else {
                              setSelectedSlots([...selectedSlots, slot]);
                            }
                          }}
                          className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${
                            active
                              ? 'bg-[#1B4332] text-white'
                              : 'bg-stone-200 dark:bg-stone-800 text-stone-600'
                          }`}
                        >
                          {slot}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Alarm Time</label>
                  <input
                    type="text"
                    value={exactTime}
                    onChange={(e) => setExactTime(e.target.value)}
                    placeholder="08:00 AM"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-500 hover:text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] shadow-sm flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  Save Schedule
                </button>
              </div>
            </form>
          )}

          {/* Filter by Person */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {['All', ...PERSONS].map((p) => (
              <button
                key={p}
                onClick={() => setSelectedPerson(p)}
                className={`px-3 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all ${
                  selectedPerson === p
                    ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                    : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Medicines List */}
          <div className="space-y-2">
            {filteredMedicines.length === 0 ? (
              <div className="text-center py-8 text-xs text-stone-400">
                No medicine schedules logged for {selectedPerson}
              </div>
            ) : (
              filteredMedicines.map((med) => {
                const nowSec = Date.now();
                const isSnoozed = med.snoozedUntil && med.snoozedUntil > nowSec;
                const remainingSec = isSnoozed
                  ? Math.max(0, Math.floor((med.snoozedUntil! - nowSec) / 1000))
                  : 0;

                return (
                  <div
                    key={med.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col gap-2.5 shadow-xs ${
                      med.takenToday
                        ? 'bg-emerald-50/70 dark:bg-[#163024] border-emerald-300 dark:border-emerald-800 opacity-90'
                        : darkMode
                        ? 'bg-[#142B20] border-[#1C3B2E]'
                        : 'bg-white border-stone-200/80'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5 flex-1 min-w-0">
                        <button
                          onClick={() => {
                            onToggleTaken(med.id);
                            playNotificationTone(soundEnabled);
                            showToast(
                              `${med.name} marked ${!med.takenToday ? 'taken' : 'pending'}`
                            );
                          }}
                          className="mt-0.5 text-stone-400 hover:text-[#1B4332] dark:hover:text-[#74C69D] transition-all"
                        >
                          {med.takenToday ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-[#74C69D] fill-emerald-100 dark:fill-emerald-950" />
                          ) : (
                            <Circle className="w-5 h-5 text-stone-300 hover:text-[#D4AF37]" />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`font-black text-xs ${
                                med.takenToday
                                  ? 'line-through text-stone-500 dark:text-stone-400'
                                  : 'text-stone-900 dark:text-stone-100'
                              }`}
                            >
                              {med.name}
                            </span>
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                              {med.person}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[10px] text-stone-500 dark:text-stone-400 mt-1 flex-wrap">
                            <span className="font-semibold">{med.dosage}</span>
                            <span>•</span>
                            <span className="text-amber-700 dark:text-amber-300 font-bold">
                              {med.mealInstruction}
                            </span>
                            <span>•</span>
                            <span className="font-mono">{med.exactTime}</span>
                          </div>

                          <div className="flex gap-1 mt-1.5 flex-wrap">
                            {med.timeSlots.map((s) => (
                              <span
                                key={s}
                                className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300"
                              >
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Right side buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleStartEdit(med)}
                          className="p-1 rounded text-stone-400 hover:text-[#1B4332] dark:hover:text-[#F4E0A5]"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {deleteConfirmId === med.id ? (
                          <button
                            onClick={() => {
                              onDeleteMedicine(med.id);
                              setDeleteConfirmId(null);
                            }}
                            className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-600 text-white animate-pulse"
                          >
                            Confirm?
                          </button>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(med.id)}
                            className="p-1 rounded text-stone-400 hover:text-red-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Snooze 5-minute action row */}
                    {!med.takenToday && (
                      <div className="pt-2 border-t border-stone-100 dark:border-[#254F3E] flex items-center justify-between">
                        {isSnoozed ? (
                          <div className="flex items-center gap-1.5 text-[11px] font-mono font-black text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/60 px-2 py-0.5 rounded-lg animate-pulse">
                            <Clock className="w-3 h-3" />
                            <span>
                              Snoozed: {Math.floor(remainingSec / 60)}:
                              {remainingSec % 60 < 10 ? '0' : ''}
                              {remainingSec % 60} left
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-stone-400">Scheduled reminder</span>
                        )}

                        <button
                          onClick={() => handleSnooze(med.id, med.name)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-extrabold bg-[#D4AF37] hover:bg-[#b89528] active:scale-95 text-stone-950 shadow-xs transition-all"
                        >
                          <Bell className="w-3 h-3" />
                          <span>Snooze 5 Min</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] text-center text-[11px] text-stone-500">
          Tip: Tap the circle to mark medicine taken today. Use Snooze to delay alarm 5 minutes.
        </div>
      </div>
    </div>
  );
};
