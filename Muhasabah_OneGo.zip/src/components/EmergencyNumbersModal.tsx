import React, { useState } from 'react';
import {
  X,
  Phone,
  PhoneCall,
  Plus,
  Trash2,
  Share2,
  Edit2,
  ShieldAlert,
  Search,
  Check,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { EmergencyContact } from '../types';

interface EmergencyNumbersModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  contacts: EmergencyContact[];
  onAddContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  onUpdateContact: (contact: EmergencyContact) => void;
  onDeleteContact: (id: string) => void;
  onResetContacts?: () => void;
}

export const EmergencyNumbersModal: React.FC<EmergencyNumbersModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  contacts,
  onAddContact,
  onUpdateContact,
  onDeleteContact,
  onResetContacts,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isAdding, setIsAdding] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<EmergencyContact['category']>('Personal');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleStartEdit = (item: EmergencyContact) => {
    setEditingContact(item);
    setName(item.name);
    setPhone(item.phone);
    setDescription(item.description);
    setCategory(item.category);
    setIsAdding(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    if (editingContact) {
      onUpdateContact({
        ...editingContact,
        name: name.trim(),
        phone: phone.trim(),
        description: description.trim(),
        category,
      });
    } else {
      onAddContact({
        name: name.trim(),
        phone: phone.trim(),
        description: description.trim(),
        category,
        isBuiltIn: false,
      });
    }

    // Reset
    setIsAdding(false);
    setEditingContact(null);
    setName('');
    setPhone('');
    setDescription('');
    setCategory('Personal');
  };

  const handleDial = (phoneNumber: string) => {
    window.location.href = `tel:${phoneNumber.replace(/[^0-9+]/g, '')}`;
  };
  const handleShare = async (contact: EmergencyContact) => {
    const text = `${contact.name}\n${contact.phone}${contact.description ? `\n${contact.description}` : ''}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: contact.name, text });
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        alert('নাম্বারের তথ্য কপি হয়েছে।');
      }
    } catch {
      // User cancelled sharing; no action needed.
    }
  };

  const filteredContacts = contacts.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'All' || c.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[90vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-emerald-100/60 dark:border-[#254F3E] flex items-center justify-between bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-red-600/90 text-white shadow-md">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Emergency Numbers
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#D4AF37] text-stone-950 font-black">
                  BD &amp; Sirajganj
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Instant one-tap direct dialer &amp; custom contact manager
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {onResetContacts && (
              <button onClick={() => { if (window.confirm('সব Emergency নাম্বার রিসেট করবেন?')) onResetContacts(); }} title="Reset Emergency Numbers" className="p-2 rounded-xl hover:bg-white/10 text-rose-200 transition-all active:scale-95">
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3.5">
          {/* Quick Actions & Search */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search emergency services or numbers..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-200 dark:border-[#254F3E] bg-stone-50 dark:bg-[#0E1E17] text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
            <button
              onClick={() => {
                setEditingContact(null);
                setName('');
                setPhone('');
                setDescription('');
                setCategory('Personal');
                setIsAdding(!isAdding);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>{isAdding ? 'Close Form' : 'Add Custom'}</span>
            </button>
          </div>

          {/* Add / Edit Form */}
          {isAdding && (
            <form
              onSubmit={handleSave}
              className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#E8F5E9]/50 dark:bg-[#163024] space-y-2.5 animate-in fade-in"
            >
              <div className="text-xs font-black text-[#1B4332] dark:text-[#F4E0A5] uppercase tracking-wider">
                {editingContact ? 'Edit Emergency Contact' : 'Add New Custom Contact'}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Service / Person Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Family Doctor, Uncle"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Phone Number</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 017XXXXXXXX"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as EmergencyContact['category'])}
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  >
                    <option value="Personal">Personal Contact</option>
                    <option value="Hospital">Hospital / Medical</option>
                    <option value="Police">Police / Security</option>
                    <option value="Fire">Fire &amp; Rescue</option>
                    <option value="National">National Hotline</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Short Note</label>
                  <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="e.g. Available 24/7"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-500 hover:text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] shadow-sm flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  Save Contact
                </button>
              </div>
            </form>
          )}

          {/* Category Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {['All', 'National', 'Hospital', 'Police', 'Fire', 'Personal'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                    : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Contacts List */}
          <div className="space-y-2">
            {filteredContacts.length === 0 ? (
              <div className="text-center py-8 text-xs text-stone-400">
                No emergency numbers found matching &quot;{searchQuery}&quot;
              </div>
            ) : (
              filteredContacts.map((contact) => (
                <div
                  key={contact.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-2 shadow-xs ${
                    contact.category === 'National'
                      ? 'bg-red-50/50 dark:bg-red-950/20 border-red-200/80 dark:border-red-900/40'
                      : darkMode
                      ? 'bg-[#142B20] border-[#1C3B2E]'
                      : 'bg-white border-stone-200/80'
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-black text-xs text-stone-900 dark:text-stone-100 truncate">
                        {contact.name}
                      </span>
                      {contact.isBuiltIn && (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                          Verified
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-mono font-bold text-red-600 dark:text-red-400 mt-0.5">
                      {contact.phone}
                    </div>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400 truncate mt-0.5">
                      {contact.description}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {!contact.isBuiltIn && (
                      <button
                        onClick={() => handleStartEdit(contact)}
                        title="Edit number"
                        className="p-1.5 rounded-lg text-stone-400 hover:text-[#1B4332] dark:hover:text-[#F4E0A5] transition-all"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => handleShare(contact)}
                      title="Share number"
                      className="p-1.5 rounded-lg text-stone-400 hover:text-[#1B4332] dark:hover:text-[#74C69D] transition-all"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                    {deleteConfirmId === contact.id ? (
                      <button
                        onClick={() => {
                          onDeleteContact(contact.id);
                          setDeleteConfirmId(null);
                        }}
                        className="px-2 py-1 rounded-lg text-[10px] font-extrabold bg-red-600 text-white animate-pulse"
                      >
                        Confirm?
                      </button>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirmId(contact.id)}
                        title="Delete number"
                        className="p-1.5 rounded-lg text-stone-400 hover:text-red-600 transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      onClick={() => handleDial(contact.phone)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-extrabold bg-red-600 hover:bg-red-700 active:scale-95 text-white shadow-sm transition-all"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Dial</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] text-center text-[11px] text-stone-500">
          Tip: Tap &quot;Dial&quot; to initiate a direct call via your device&apos;s native dialer.
        </div>
      </div>
    </div>
  );
};
