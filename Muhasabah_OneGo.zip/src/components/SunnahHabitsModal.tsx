import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Check,
  Flame,
  Award,
  RotateCcw,
  Heart,
  ChevronRight,
  Smile,
  Moon,
  Sun,
} from 'lucide-react';
import { SunnahHabitItem } from '../types';
import { INITIAL_SUNNAH_HABITS } from '../data/islamicFeaturesData';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface SunnahHabitsModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

export const SunnahHabitsModal: React.FC<SunnahHabitsModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [habits, setHabits] = useState<SunnahHabitItem[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_sunnah_habits');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_SUNNAH_HABITS;
  });

  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_sunnah_habits', JSON.stringify(habits));
    } catch {
      // ignore
    }
  }, [habits]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleToggle = (id: string) => {
    playDhikrClick(soundEnabled);
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id !== id) return h;
        const willComplete = !h.completedToday;
        if (willComplete) {
          playNotificationTone(soundEnabled);
          showToast(`✨ Sunnah revived: ${h.titleEn}`);
        }
        return {
          ...h,
          completedToday: willComplete,
          streakDays: willComplete ? h.streakDays + 1 : Math.max(0, h.streakDays - 1),
        };
      })
    );
  };

  const handleResetDaily = () => {
    if (window.confirm('Reset all habit checkmarks for a new day? (Streaks are preserved)')) {
      setHabits((prev) => prev.map((h) => ({ ...h, completedToday: false })));
      showToast('Daily habit checklist reset');
    }
  };

  const completedCount = habits.filter((h) => h.completedToday).length;
  const totalStreaks = habits.reduce((sum, h) => sum + h.streakDays, 0);

  const categories = ['All', 'Daily', 'Night', 'Hygiene', 'Social'];

  const filtered = habits.filter((h) => {
    if (filterCategory === 'All') return true;
    return h.category === filterCategory;
  });

  return (
    <div
      id="modal-sunnah-habits"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] text-[#D4AF37] border border-[#D4AF37]/30 flex items-center justify-center font-black shadow-xs">
              <Heart className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                <span>Sunnah Lifestyle Tracker</span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400">
                  দৈনন্দিন সুন্নাত
                </span>
              </h3>
              <p className="text-xs text-stone-400 font-medium">
                Live by the prophetic habits, hygiene &amp; character daily
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats & Streak Banner */}
        <div
          className={`p-3 border-b flex items-center justify-between gap-2 text-xs ${
            darkMode ? 'bg-[#0A1710] border-[#1A3729]' : 'bg-stone-50 border-stone-200'
          }`}
        >
          <div className="flex items-center gap-3 font-bold">
            <span className="text-emerald-400 flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              {completedCount}/{habits.length} Done Today
            </span>
            <span className="text-amber-400 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5" />
              {totalStreaks} Total Streaks
            </span>
          </div>

          <button
            onClick={handleResetDaily}
            className="text-[11px] font-bold text-stone-400 hover:text-stone-200 underline flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>New Day Reset</span>
          </button>
        </div>

        {/* Filter Pills */}
        <div
          className={`px-4 py-2 border-b flex items-center gap-1.5 overflow-x-auto no-scrollbar ${
            darkMode ? 'bg-[#0E2017] border-[#1C3B2C]' : 'bg-white border-stone-200'
          }`}
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                filterCategory === cat
                  ? 'bg-[#1B4332] text-[#F4E0A5] shadow-xs'
                  : darkMode
                  ? 'bg-[#12281E] text-stone-400 hover:text-stone-200'
                  : 'bg-stone-100 text-stone-600 hover:text-stone-900'
              }`}
            >
              {cat === 'All' ? 'All Habits' : cat}
            </button>
          ))}
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 my-2 p-2 rounded-xl bg-emerald-600 text-white text-xs font-bold text-center shadow-md animate-bounce">
            {toastMsg}
          </div>
        )}

        {/* Scrollable Habits List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filtered.map((habit) => (
            <div
              key={habit.id}
              onClick={() => handleToggle(habit.id)}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                habit.completedToday
                  ? darkMode
                    ? 'bg-[#10251B] border-emerald-500/50 shadow-xs'
                    : 'bg-emerald-50/80 border-emerald-300 shadow-xs'
                  : darkMode
                  ? 'bg-[#12281E] border-[#224A37] hover:border-[#D4AF37]/40'
                  : 'bg-white border-stone-200 hover:border-emerald-300 shadow-xs'
              }`}
            >
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <button
                  type="button"
                  className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all mt-0.5 shrink-0 ${
                    habit.completedToday
                      ? 'bg-emerald-500 text-white'
                      : 'border-2 border-stone-400 dark:border-stone-600'
                  }`}
                >
                  {habit.completedToday && <Check className="w-4 h-4 stroke-[3]" />}
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-stone-900 dark:text-stone-100">
                      {habit.titleEn}
                    </span>
                    <span className="text-[10px] font-bold text-[#D4AF37]">
                      {habit.titleBn}
                    </span>
                  </div>

                  <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-0.5 leading-relaxed">
                    {habit.description}
                  </p>

                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-stone-200 dark:bg-stone-800 text-stone-500 dark:text-stone-400">
                      {habit.category}
                    </span>
                    <span className="text-[10px] text-stone-400 italic">
                      {habit.hadithRef}
                    </span>
                  </div>
                </div>
              </div>

              {/* Streak Badge */}
              <div className="flex flex-col items-center shrink-0">
                <span className="text-amber-500 text-xs font-black flex items-center gap-0.5">
                  <Flame className="w-3.5 h-3.5 fill-amber-500" />
                  {habit.streakDays}d
                </span>
                <span className="text-[9px] text-stone-400">streak</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
