import React, { useState, useEffect } from 'react';
import {
  X,
  BookMarked,
  Plus,
  Trash2,
  Edit2,
  Copy,
  Check,
  Search,
  Sparkles,
  Share2,
} from 'lucide-react';
import { WisdomBookmarkItem } from '../types';
import { INITIAL_WISDOM_BOOKMARKS } from '../data/islamicFeaturesData';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface WisdomBookmarksModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

export const WisdomBookmarksModal: React.FC<WisdomBookmarksModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [bookmarks, setBookmarks] = useState<WisdomBookmarkItem[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_wisdom_bookmarks');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_WISDOM_BOOKMARKS;
  });

  const [activeTab, setActiveTab] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [formTitle, setFormTitle] = useState('');
  const [formArabic, setFormArabic] = useState('');
  const [formTranslation, setFormTranslation] = useState('');
  const [formSource, setFormSource] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formCategory, setFormCategory] = useState<'Quran' | 'Hadith' | 'Quote' | 'Reflection'>('Quran');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_wisdom_bookmarks', JSON.stringify(bookmarks));
    } catch {
      // ignore
    }
  }, [bookmarks]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleCopy = (item: WisdomBookmarkItem) => {
    const text = `${item.title}\n\n${item.arabic ? item.arabic + '\n\n' : ''}${item.translation}\n\n— ${item.source}`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    showToast('Copied bookmark to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formTranslation.trim()) {
      alert('Please fill in title and text content');
      return;
    }

    if (editingId) {
      setBookmarks((prev) =>
        prev.map((b) =>
          b.id === editingId
            ? {
                ...b,
                title: formTitle.trim(),
                arabic: formArabic.trim() || undefined,
                translation: formTranslation.trim(),
                source: formSource.trim() || 'General',
                notes: formNotes.trim() || undefined,
                category: formCategory,
              }
            : b
        )
      );
      showToast('Updated bookmark');
    } else {
      const newItem: WisdomBookmarkItem = {
        id: `bm_${Date.now()}`,
        title: formTitle.trim(),
        arabic: formArabic.trim() || undefined,
        translation: formTranslation.trim(),
        source: formSource.trim() || 'Reflection',
        notes: formNotes.trim() || undefined,
        category: formCategory,
        dateAdded: new Date().toISOString().split('T')[0],
      };
      setBookmarks([newItem, ...bookmarks]);
      showToast('Added new bookmark to collection');
    }

    setShowAddForm(false);
    setEditingId(null);
    setFormTitle('');
    setFormArabic('');
    setFormTranslation('');
    setFormSource('');
    setFormNotes('');
  };

  const handleEdit = (item: WisdomBookmarkItem) => {
    setEditingId(item.id);
    setFormTitle(item.title);
    setFormArabic(item.arabic || '');
    setFormTranslation(item.translation);
    setFormSource(item.source);
    setFormNotes(item.notes || '');
    setFormCategory(item.category);
    setShowAddForm(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this wisdom bookmark?')) {
      setBookmarks((prev) => prev.filter((b) => b.id !== id));
      showToast('Deleted bookmark');
    }
  };

  const categories = ['All', 'Quran', 'Hadith', 'Quote', 'Reflection'];

  const filtered = bookmarks.filter((b) => {
    if (activeTab !== 'All' && b.category !== activeTab) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        b.title.toLowerCase().includes(q) ||
        b.translation.toLowerCase().includes(q) ||
        b.source.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div
      id="modal-wisdom-bookmarks"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] text-[#D4AF37] border border-[#D4AF37]/30 flex items-center justify-center font-black shadow-xs">
              <BookMarked className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                <span>Wisdom &amp; Bookmarks Hub</span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37]">
                  হিফজ ও জ্ঞান ভাণ্ডার
                </span>
              </h3>
              <p className="text-xs text-stone-400 font-medium">
                Saved Quran verses, Hadith treasures &amp; spiritual reflections
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subheader Toolbar */}
        <div
          className={`p-3 border-b flex items-center justify-between gap-2 ${
            darkMode ? 'bg-[#0A1710] border-[#1A3729]' : 'bg-stone-50 border-stone-200'
          }`}
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="Search wisdom, verses, sources..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-9 pr-3 py-1.5 rounded-xl border text-xs focus:outline-none ${
                darkMode
                  ? 'bg-[#142D21] border-[#224A37] text-white'
                  : 'bg-white border-stone-200 text-stone-900'
              }`}
            />
          </div>

          <button
            onClick={() => {
              setEditingId(null);
              setFormTitle('');
              setFormArabic('');
              setFormTranslation('');
              setFormSource('');
              setFormNotes('');
              setShowAddForm(!showAddForm);
            }}
            className="px-3 py-1.5 rounded-xl text-xs font-black bg-[#D4AF37] text-stone-950 hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shrink-0 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{showAddForm ? 'Close' : 'Add Wisdom'}</span>
          </button>
        </div>

        {/* Category Filter */}
        <div
          className={`px-4 py-2 border-b flex items-center gap-1.5 overflow-x-auto no-scrollbar ${
            darkMode ? 'bg-[#0E2017] border-[#1C3B2C]' : 'bg-white border-stone-200'
          }`}
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveTab(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                activeTab === cat
                  ? 'bg-[#1B4332] text-[#F4E0A5] shadow-xs'
                  : darkMode
                  ? 'bg-[#12281E] text-stone-400 hover:text-stone-200'
                  : 'bg-stone-100 text-stone-600 hover:text-stone-900'
              }`}
            >
              {cat === 'All' ? 'All Wisdom' : cat}
            </button>
          ))}
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 my-2 p-2 rounded-xl bg-emerald-600 text-white text-xs font-bold text-center shadow-md animate-bounce">
            {toastMsg}
          </div>
        )}

        {/* Add/Edit Form */}
        {showAddForm && (
          <form
            onSubmit={handleSave}
            className={`m-4 p-4 rounded-2xl border space-y-3 ${
              darkMode ? 'bg-[#142C20] border-[#D4AF37]/50' : 'bg-amber-50/70 border-amber-300'
            }`}
          >
            <div className="flex items-center justify-between pb-1 border-b border-stone-400/20">
              <span className="text-xs font-black text-[#D4AF37]">
                {editingId ? 'Edit Wisdom Bookmark' : 'Save New Wisdom / Verse'}
              </span>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="text-stone-400 hover:text-stone-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="text-[10px] font-bold text-stone-400 block mb-1">
                  Title / Subject *
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. আয়াতুল কুরসী বা সবর সংক্রান্ত হাদিস"
                  className={`w-full px-3 py-1.5 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#224A37] text-white'
                      : 'bg-white border-stone-300 text-stone-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-stone-400 block mb-1">
                  Category *
                </label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as any)}
                  className={`w-full px-3 py-1.5 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#224A37] text-white'
                      : 'bg-white border-stone-300 text-stone-900'
                  }`}
                >
                  <option value="Quran">Quran (কুরআনের আয়াত)</option>
                  <option value="Hadith">Hadith (সহীহ হাদিস)</option>
                  <option value="Quote">Quote (সালাফদের উক্তি)</option>
                  <option value="Reflection">Reflection (ব্যক্তিগত তাদাব্বুর)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-stone-400 block mb-1">
                Arabic Text (Optional)
              </label>
              <textarea
                value={formArabic}
                onChange={(e) => setFormArabic(e.target.value)}
                placeholder="Arabic matn or ayah..."
                rows={2}
                className={`w-full px-3 py-1.5 rounded-xl border text-sm font-arabic focus:outline-none ${
                  darkMode
                    ? 'bg-[#0E2017] border-[#224A37] text-white'
                    : 'bg-white border-stone-300 text-stone-900'
                }`}
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-stone-400 block mb-1">
                Translation / Meaning / Content *
              </label>
              <textarea
                value={formTranslation}
                onChange={(e) => setFormTranslation(e.target.value)}
                placeholder="Bengali or English translation & meaning..."
                rows={2}
                className={`w-full px-3 py-1.5 rounded-xl border text-xs focus:outline-none ${
                  darkMode
                    ? 'bg-[#0E2017] border-[#224A37] text-white'
                    : 'bg-white border-stone-300 text-stone-900'
                }`}
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="text-[10px] font-bold text-stone-400 block mb-1">
                  Source / Reference
                </label>
                <input
                  type="text"
                  value={formSource}
                  onChange={(e) => setFormSource(e.target.value)}
                  placeholder="e.g. Surah Al-Baqarah 2:255 or Sahih Bukhari"
                  className={`w-full px-3 py-1.5 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#224A37] text-white'
                      : 'bg-white border-stone-300 text-stone-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-stone-400 block mb-1">
                  Personal Reflection Note
                </label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Why this inspires me..."
                  className={`w-full px-3 py-1.5 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#224A37] text-white'
                      : 'bg-white border-stone-300 text-stone-900'
                  }`}
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 rounded-xl text-xs font-bold text-stone-400 hover:text-stone-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl text-xs font-black bg-[#D4AF37] text-stone-950 hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shadow-xs"
              >
                <Check className="w-3.5 h-3.5" />
                <span>{editingId ? 'Save Changes' : 'Add to Collection'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Bookmarks List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              className={`p-4 rounded-2xl border transition-all ${
                darkMode
                  ? 'bg-[#12281E] border-[#224A37]'
                  : 'bg-white border-emerald-900/10 shadow-xs'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                      {item.category}
                    </span>
                    <span className="text-[11px] font-bold text-stone-400">
                      {item.source}
                    </span>
                  </div>

                  <h4 className="text-sm font-black text-stone-900 dark:text-stone-100">
                    {item.title}
                  </h4>

                  {item.arabic && (
                    <div className="my-2 p-2 rounded-xl bg-black/5 dark:bg-black/30 border border-stone-300/20 text-center font-arabic text-base font-bold text-[#1B4332] dark:text-[#F4E0A5] leading-relaxed">
                      {item.arabic}
                    </div>
                  )}

                  <p className="text-xs text-stone-700 dark:text-stone-300 font-medium leading-relaxed mt-1">
                    {item.translation}
                  </p>

                  {item.notes && (
                    <p className="text-[11px] text-amber-500 italic mt-1.5 bg-amber-500/10 p-1.5 rounded-lg">
                      💡 &quot;{item.notes}&quot;
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-col items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleCopy(item)}
                    className="p-1.5 rounded-lg text-stone-400 hover:text-emerald-400 hover:bg-black/10 dark:hover:bg-white/10"
                    title="Copy Text"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    onClick={() => handleEdit(item)}
                    className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-black/10 dark:hover:bg-white/10"
                    title="Edit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="p-1.5 rounded-lg text-stone-400 hover:text-rose-400 hover:bg-black/10 dark:hover:bg-white/10"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="text-center py-10 text-stone-400 text-xs">
              No wisdom items found. Click &quot;Add Wisdom&quot; to save your first verse or quote!
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
