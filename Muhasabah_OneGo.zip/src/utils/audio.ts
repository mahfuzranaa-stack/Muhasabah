// Gentle audio synthesizer utility using Web Audio API + HTML5 Audio fallback

let audioCtx: AudioContext | null = null;
let currentRecitationAudio: HTMLAudioElement | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  try {
    if (!audioCtx) {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  } catch {
    // Ignore audio context errors
  }
  return audioCtx;
}

export function playDhikrClick(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    // Warm wooden bead / subtle bell sound
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.04);
    osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.12);

    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.16);
  } catch {
    // Ignore audio errors silently
  }
}

export function playNotificationTone(enabled: boolean = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, now); // A4
    osc.frequency.setValueAtTime(554.37, now + 0.12); // C#5
    osc.frequency.setValueAtTime(659.25, now + 0.24); // E5

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(now + 0.52);
  } catch {
    // Ignore
  }
}

// Synthesize pleasant ambient flute/adhan melody that always plays without network dependency
export function playSynthesizedRecitation() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const notes = [329.63, 392.0, 440.0, 493.88, 523.25, 493.88, 440.0];
    const now = ctx.currentTime;

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.35);

      gain.gain.setValueAtTime(0, now + idx * 0.35);
      gain.gain.linearRampToValueAtTime(0.08, now + idx * 0.35 + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.35 + 0.34);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.35);
      osc.stop(now + idx * 0.35 + 0.35);
    });
  } catch {
    // ignore
  }
}

// Full Surah Recitations by Mishary Rashid Alafasy from verified high-performance QuranicAudio & EveryAyah CDN
export const SURAH_AUDIO_URLS: Record<number, string> = {
  1: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/001.mp3', // Al-Fatihah
  18: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/018.mp3', // Al-Kahf
  36: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/036.mp3', // Ya-Sin
  55: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/055.mp3', // Ar-Rahman
  56: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/056.mp3', // Al-Waqi'ah
  67: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/067.mp3', // Al-Mulk
  94: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/094.mp3', // Ash-Sharh
  112: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/112.mp3', // Al-Ikhlas
  113: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/113.mp3', // Al-Falaq
  114: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/114.mp3', // An-Nas
};

// Map of verified high-quality Quranic audio and authentic Dua recitations (Strict zero-substitution mapping)
export const KNOWN_RECITATIONS: Record<string, string> = {
  // Surahs
  surah_fatihah: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/001.mp3',
  surah_kahf: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/018.mp3',
  surah_yasin: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/036.mp3',
  surah_rahman: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/055.mp3',
  surah_waqiah: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/056.mp3',
  surah_mulk: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/067.mp3',
  surah_sharh: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/094.mp3',
  surah_ikhlas: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/112.mp3',
  surah_falaq: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/113.mp3',
  surah_nas: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/114.mp3',

  // Duas & Adhkar (Authentic high quality recitations verified with CORS & instant CDN delivery)
  darood_sharif: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/53.mp3',
  sayyidul_istighfar: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/79.mp3',
  morning_dua: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/1.mp3',
  sleep_dua: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/105.mp3',
  protection_dua: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/86.mp3',
  leave_house: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/16.mp3',
  enter_house: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/18.mp3',
  eating_dua_start: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/178.mp3',
  eating_dua_end: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/180.mp3',
  dua_anxiety_debt: 'https://cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/121.mp3',
  ayatul_kursi: 'https://everyayah.com/data/Alafasy_128kbps/002255.mp3',
  passage_ayatul_kursi: 'https://everyayah.com/data/Alafasy_128kbps/002255.mp3',
  passage_baqarah_last: 'https://everyayah.com/data/Alafasy_128kbps/002285.mp3',
  passage_hashr: 'https://everyayah.com/data/Alafasy_128kbps/059022.mp3',
  travel_dua: 'https://everyayah.com/data/Alafasy_128kbps/043013.mp3',
  parents_dua: 'https://everyayah.com/data/Alafasy_128kbps/017024.mp3',
  rabbana_dua: 'https://everyayah.com/data/Alafasy_128kbps/002201.mp3',
  dua_yunus: 'https://everyayah.com/data/Alafasy_128kbps/021087.mp3',
  dua_knowledge: 'https://everyayah.com/data/Alafasy_128kbps/020114.mp3',
  hasbunallah_dua: 'https://everyayah.com/data/Alafasy_128kbps/003173.mp3',
};

// Automatic sanitizer ensuring github raw URLs are replaced by fast CORS CDN
export function normalizeAudioUrl(url?: string): string | undefined {
  if (!url) return undefined;
  let clean = url.trim();
  if (clean.includes('raw.githubusercontent.com/rn0x/Adhkar-json/main/audio/')) {
    clean = clean.replace(
      'raw.githubusercontent.com/rn0x/Adhkar-json/main/audio/',
      'cdn.jsdelivr.net/gh/rn0x/Adhkar-json@main/audio/'
    );
  }
  return clean;
}

export interface AudioProgressInfo {
  currentTime: number;
  duration: number;
  progressPercent: number;
  isPlaying: boolean;
  isPaused: boolean;
  currentUrl?: string;
  currentId?: string;
}

export type AudioProgressCallback = (info: AudioProgressInfo) => void;

let activeProgressCallback: AudioProgressCallback | null = null;
let currentPlayingId: string | null = null;
let isAudioPausedState: boolean = false;

function emitProgressUpdate() {
  if (!currentRecitationAudio) {
    if (activeProgressCallback) {
      activeProgressCallback({
        currentTime: 0,
        duration: 0,
        progressPercent: 0,
        isPlaying: false,
        isPaused: false,
      });
    }
    return;
  }
  const cur = currentRecitationAudio.currentTime || 0;
  const dur = currentRecitationAudio.duration || 0;
  const percent = dur > 0 ? Math.min(100, Math.max(0, (cur / dur) * 100)) : 0;
  if (activeProgressCallback) {
    activeProgressCallback({
      currentTime: cur,
      duration: dur,
      progressPercent: percent,
      isPlaying: !currentRecitationAudio.paused,
      isPaused: currentRecitationAudio.paused && cur > 0,
      currentUrl: currentRecitationAudio.src,
      currentId: currentPlayingId || undefined,
    });
  }
}

export function getCurrentPlayingId(): string | null {
  return currentPlayingId;
}

export function playRecitationAudio(
  audioSourceOrUrl?: string | number,
  onEnded?: () => void,
  onProgress?: AudioProgressCallback,
  onError?: (msg: string) => void
): { success: boolean; error?: string } {
  try {
    if (typeof window === 'undefined') {
      return { success: false, error: 'Window audio not supported' };
    }

    // Determine target URL strictly based on provided source or mapping
    let targetUrl: string | null = null;

    if (audioSourceOrUrl !== undefined && audioSourceOrUrl !== null) {
      const srcStr = String(audioSourceOrUrl).trim();

      if (srcStr.startsWith('http://') || srcStr.startsWith('https://')) {
        targetUrl = normalizeAudioUrl(srcStr) || srcStr;
      } else if (KNOWN_RECITATIONS[srcStr]) {
        targetUrl = KNOWN_RECITATIONS[srcStr];
      } else if (typeof audioSourceOrUrl === 'number' && SURAH_AUDIO_URLS[audioSourceOrUrl]) {
        targetUrl = SURAH_AUDIO_URLS[audioSourceOrUrl];
      } else {
        // Try parsing number
        const num = parseInt(srcStr.replace(/\D/g, ''), 10);
        if (!isNaN(num) && SURAH_AUDIO_URLS[num]) {
          targetUrl = SURAH_AUDIO_URLS[num];
        }
      }
    }

    if (targetUrl) {
      targetUrl = normalizeAudioUrl(targetUrl) || targetUrl;
    }

    // STRICT ZERO-SUBSTITUTION RULE: If no audio exists for this specific item, NEVER substitute another audio!
    if (!targetUrl) {
      if (onError) onError('Audio unavailable');
      return { success: false, error: 'Audio unavailable' };
    }

    // Thoroughly reset and clean any existing audio before playing new source
    stopAllAudio();

    const audio = new Audio(targetUrl);
    currentRecitationAudio = audio;
    currentPlayingId = String(audioSourceOrUrl || targetUrl);
    activeProgressCallback = onProgress || null;
    isAudioPausedState = false;

    audio.ontimeupdate = () => {
      emitProgressUpdate();
    };

    audio.onloadedmetadata = () => {
      emitProgressUpdate();
    };

    audio.oncanplay = () => {
      emitProgressUpdate();
    };

    audio.onended = () => {
      emitProgressUpdate();
      stopRecitationAudio();
      if (onEnded) onEnded();
    };

    audio.onerror = () => {
      stopRecitationAudio();
      if (onError) onError('Audio unavailable');
      if (onEnded) onEnded();
    };

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          emitProgressUpdate();
        })
        .catch((err) => {
          console.warn('Audio play request interrupted or blocked:', err);
          if (onError) onError('Playback was blocked. Tap Play to listen.');
        });
    }

    return { success: true };
  } catch (err) {
    if (onError) onError('Audio unavailable');
    return { success: false, error: 'Audio unavailable' };
  }
}

export function pauseRecitationAudio(): boolean {
  if (currentRecitationAudio && !currentRecitationAudio.paused) {
    currentRecitationAudio.pause();
    isAudioPausedState = true;
    emitProgressUpdate();
    return true;
  }
  return false;
}

export function resumeRecitationAudio(): boolean {
  if (currentRecitationAudio && currentRecitationAudio.paused) {
    currentRecitationAudio.play().catch(() => {});
    isAudioPausedState = false;
    emitProgressUpdate();
    return true;
  }
  return false;
}

export function seekRecitationAudio(seconds: number): void {
  if (currentRecitationAudio && !isNaN(seconds)) {
    currentRecitationAudio.currentTime = Math.max(0, Math.min(seconds, currentRecitationAudio.duration || 0));
    emitProgressUpdate();
  }
}

export function isRecitationPlaying(): boolean {
  return currentRecitationAudio !== null && !currentRecitationAudio.paused;
}

export function isRecitationPaused(): boolean {
  return currentRecitationAudio !== null && currentRecitationAudio.paused;
}

export function getRecitationProgress(): AudioProgressInfo {
  if (!currentRecitationAudio) {
    return {
      currentTime: 0,
      duration: 0,
      progressPercent: 0,
      isPlaying: false,
      isPaused: false,
    };
  }
  const cur = currentRecitationAudio.currentTime || 0;
  const dur = currentRecitationAudio.duration || 0;
  return {
    currentTime: cur,
    duration: dur,
    progressPercent: dur > 0 ? (cur / dur) * 100 : 0,
    isPlaying: !currentRecitationAudio.paused,
    isPaused: currentRecitationAudio.paused,
    currentUrl: currentRecitationAudio.src,
    currentId: currentPlayingId || undefined,
  };
}

export function playAyahAudio(
  audioUrl?: string,
  arabicText?: string,
  transliteration?: string,
  onEnded?: () => void,
  onProgress?: AudioProgressCallback,
  onError?: (msg: string) => void
): boolean {
  try {
    stopAllAudio();

    const cleanUrl = normalizeAudioUrl(audioUrl);
    if (cleanUrl && (cleanUrl.startsWith('http://') || cleanUrl.startsWith('https://'))) {
      const audio = new Audio(cleanUrl);
      currentRecitationAudio = audio;
      currentPlayingId = cleanUrl;
      activeProgressCallback = onProgress || null;
      isAudioPausedState = false;

      audio.ontimeupdate = () => {
        emitProgressUpdate();
      };

      audio.onended = () => {
        emitProgressUpdate();
        currentRecitationAudio = null;
        currentPlayingId = null;
        activeProgressCallback = null;
        if (onEnded) onEnded();
      };

      audio.onerror = () => {
        currentRecitationAudio = null;
        currentPlayingId = null;
        activeProgressCallback = null;
        if (onError) onError('Ayah audio unavailable');
        if (onEnded) onEnded();
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          if (onError) onError('Playback was blocked');
          if (onEnded) onEnded();
        });
      }
      return true;
    }

    if (onError) onError('Ayah audio unavailable');
    return false;
  } catch {
    if (onError) onError('Ayah audio unavailable');
    return false;
  }
}

let activeSpeechUtterance: SpeechSynthesisUtterance | null = null;
let currentDuaAudio: HTMLAudioElement | null = null;

export function playDuaAudio(
  duaId: string,
  explicitAudioUrl?: string,
  onEnded?: () => void,
  onProgress?: AudioProgressCallback,
  onError?: (msg: string) => void
): boolean {
  try {
    stopAllAudio();

    const rawTarget = explicitAudioUrl || KNOWN_RECITATIONS[duaId];
    const targetUrl = normalizeAudioUrl(rawTarget);

    if (targetUrl && (targetUrl.startsWith('http://') || targetUrl.startsWith('https://'))) {
      const audio = new Audio(targetUrl);
      currentDuaAudio = audio;
      currentRecitationAudio = audio;
      currentPlayingId = duaId;
      activeProgressCallback = onProgress || null;

      audio.ontimeupdate = () => {
        emitProgressUpdate();
      };

      audio.onended = () => {
        emitProgressUpdate();
        currentDuaAudio = null;
        currentRecitationAudio = null;
        currentPlayingId = null;
        activeProgressCallback = null;
        if (onEnded) onEnded();
      };

      audio.onerror = () => {
        currentDuaAudio = null;
        currentRecitationAudio = null;
        currentPlayingId = null;
        activeProgressCallback = null;
        if (onError) onError('Dua audio unavailable');
        if (onEnded) onEnded();
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          if (onError) onError('Playback blocked');
          if (onEnded) onEnded();
        });
      }
      return true;
    }

    if (onError) onError('Audio unavailable for this item');
    return false;
  } catch {
    if (onError) onError('Playback error');
    return false;
  }
}

function fallbackSpeechOrTone(
  arabicText: string,
  transliteration?: string,
  onEnded?: () => void
): boolean {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
      const textToSpeak = arabicText || transliteration || '';
      const utterance = new SpeechSynthesisUtterance(textToSpeak);

      // Check available voices for Arabic
      const voices = window.speechSynthesis.getVoices();
      const arabicVoice = voices.find((v) => v.lang.startsWith('ar'));
      if (arabicVoice) {
        utterance.voice = arabicVoice;
        utterance.lang = 'ar-SA';
      } else {
        // If no Arabic voice installed, speak transliteration or clear pronunciation
        if (transliteration) {
          utterance.text = transliteration;
          utterance.lang = 'en-US';
        } else {
          utterance.lang = 'ar';
        }
      }

      utterance.rate = 0.85; // Slightly slower, reverent recitation pace
      utterance.pitch = 1.0;

      utterance.onend = () => {
        activeSpeechUtterance = null;
        if (onEnded) onEnded();
      };

      utterance.onerror = () => {
        activeSpeechUtterance = null;
        playSynthesizedRecitation();
        if (onEnded) onEnded();
      };

      activeSpeechUtterance = utterance;
      window.speechSynthesis.speak(utterance);
      return true;
    } catch {
      playSynthesizedRecitation();
      if (onEnded) onEnded();
      return true;
    }
  }

  playSynthesizedRecitation();
  if (onEnded) {
    setTimeout(onEnded, 2500);
  }
  return true;
}

export function stopAllAudio() {
  stopRecitationAudio();
  if (currentDuaAudio) {
    try {
      currentDuaAudio.pause();
      currentDuaAudio.ontimeupdate = null;
      currentDuaAudio.onended = null;
      currentDuaAudio.onerror = null;
      currentDuaAudio.onloadedmetadata = null;
      currentDuaAudio.src = '';
      currentDuaAudio = null;
    } catch {
      // ignore
    }
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
      activeSpeechUtterance = null;
    } catch {
      // ignore
    }
  }
}

export function stopRecitationAudio() {
  try {
    if (currentRecitationAudio) {
      currentRecitationAudio.pause();
      currentRecitationAudio.ontimeupdate = null;
      currentRecitationAudio.onended = null;
      currentRecitationAudio.onerror = null;
      currentRecitationAudio.onloadedmetadata = null;
      currentRecitationAudio.oncanplay = null;
      currentRecitationAudio.src = '';
      currentRecitationAudio = null;
    }
  } catch {
    // ignore
  }
  currentPlayingId = null;
  activeProgressCallback = null;
  isAudioPausedState = false;
}

// -------------------------------------------------------------
// IMMERSIVE AMBIENT AUDIO SANCTUARY (RAIN, WIND, STREAM, BIRDS)
// -------------------------------------------------------------
let activeAmbientNode: {
  stop: () => void;
  type: string;
} | null = null;

export function isAmbientPlaying(): boolean {
  return activeAmbientNode !== null;
}

export function getCurrentAmbientType(): string | null {
  return activeAmbientNode ? activeAmbientNode.type : null;
}

export function stopAmbientSound() {
  if (activeAmbientNode) {
    try {
      activeAmbientNode.stop();
    } catch {
      // ignore
    }
    activeAmbientNode = null;
  }
}

export function startAmbientSound(type: 'rain' | 'wind' | 'stream' | 'birds'): boolean {
  stopAmbientSound();
  const ctx = getAudioContext();
  if (!ctx) return false;

  try {
    if (type === 'rain') {
      // Pink/Brown noise generator with bandpass filter simulating gentle rain
      const bufferSize = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        // Brown noise filter
        data[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5; // Gain boost
      }

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, ctx.currentTime);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.08, ctx.currentTime);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      noise.start();
      activeAmbientNode = {
        type: 'rain',
        stop: () => {
          try {
            gain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + 0.5);
            setTimeout(() => noise.stop(), 550);
          } catch {
            noise.stop();
          }
        },
      };
      return true;
    }

    if (type === 'wind') {
      // Low modulated wind resonance
      const bufferSize = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        data[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        data[i] *= 0.11;
        b6 = white * 0.115926;
      }

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(320, ctx.currentTime);
      filter.Q.setValueAtTime(3.0, ctx.currentTime);

      // Low frequency oscillator to modulate wind gust
      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.2, ctx.currentTime);
      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(150, ctx.currentTime);
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start();

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.09, ctx.currentTime);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      noise.start();
      activeAmbientNode = {
        type: 'wind',
        stop: () => {
          try {
            lfo.stop();
            noise.stop();
          } catch {
            // ignore
          }
        },
      };
      return true;
    }

    if (type === 'stream') {
      // Gentle running stream water
      const bufferSize = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * 0.35;
      }

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(650, ctx.currentTime);
      filter.Q.setValueAtTime(1.5, ctx.currentTime);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.07, ctx.currentTime);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      noise.start();
      activeAmbientNode = {
        type: 'stream',
        stop: () => {
          try {
            noise.stop();
          } catch {
            // ignore
          }
        },
      };
      return true;
    }

    if (type === 'birds') {
      // Soft ambient nature tone with gentle high bell chime intervals
      let intervalId: any;
      const playChime = () => {
        try {
          const notes = [1318.51, 1567.98, 1760.0, 2093.0];
          const note = notes[Math.floor(Math.random() * notes.length)];
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(note, ctx.currentTime);
          gain.gain.setValueAtTime(0.04, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.8);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.85);
        } catch {
          // ignore
        }
      };

      playChime();
      intervalId = setInterval(playChime, 2200);

      activeAmbientNode = {
        type: 'birds',
        stop: () => {
          clearInterval(intervalId);
        },
      };
      return true;
    }

    return false;
  } catch {
    return false;
  }
}
