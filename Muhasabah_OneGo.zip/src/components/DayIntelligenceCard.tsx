import React, { useMemo, useState } from 'react';
import { CalendarClock, CheckCircle2, ChevronDown, ChevronUp, Clock3, MoonStar, Sparkles, Wand2 } from 'lucide-react';
import { PrayerItem, MetricProgress } from '../types';

interface DayIntelligenceCardProps {
  darkMode: boolean;
  prayers: PrayerItem[];
  metrics: MetricProgress[];
  dhikrCount: number;
}

interface PlanStep { time: string; label: string; kind: 'prayer' | 'task' | 'rest'; }

const todayKey = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const toMinutes = (time?: string) => {
  if (!time) return null;
  const m = time.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!m) return null;
  let h = Number(m[1]); const min = Number(m[2]); const ap = m[3]?.toUpperCase();
  if (ap === 'PM' && h < 12) h += 12;
  if (ap === 'AM' && h === 12) h = 0;
  return h * 60 + min;
};
const formatMinutes = (mins: number) => {
  const h24 = Math.floor(mins / 60) % 24; const m = mins % 60;
  const ap = h24 >= 12 ? 'PM' : 'AM'; const h = h24 % 12 || 12;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')} ${ap}`;
};
const addMinutes = (base: number, delta: number) => base + delta;

export const DayIntelligenceCard: React.FC<DayIntelligenceCardProps> = ({ darkMode, prayers, metrics, dhikrCount }) => {
  const [plan, setPlan] = useState<PlanStep[]>([]);
  const [weatherText, setWeatherText] = useState('অনলাইন আবহাওয়া যাচাই হয়নি');
  const [open, setOpen] = useState(true);
  const [timeAudit, setTimeAudit] = useState<Record<string, number>>(() => {
    try { return JSON.parse(localStorage.getItem('muhasabah_time_audit') || '{}'); } catch { return {}; }
  });

  const planner = useMemo(() => {
    try {
      const all = JSON.parse(localStorage.getItem('muhasabah_daily_planner_state') || '{}');
      return all?.[todayKey()] || { tasks: [] };
    } catch { return { tasks: [] }; }
  }, [plan.length]);

  const incompleteTasks = (planner.tasks || []).filter((t: any) => !t.completed);
  const medicines = useMemo(() => { try { return JSON.parse(localStorage.getItem('muhasabah_medicines') || '[]'); } catch { return []; } }, [plan.length]);
  const availableMinutes = Math.max(0, 23 * 60 - (new Date().getHours() * 60 + new Date().getMinutes()));
  const nextPrayer = useMemo(() => {
    const now = new Date(); const current = now.getHours() * 60 + now.getMinutes();
    return prayers
      .map((p) => ({ p, m: toMinutes(p.time) }))
      .filter((x) => x.m !== null && (x.m as number) > current)
      .sort((a, b) => (a.m as number) - (b.m as number))[0]?.p;
  }, [prayers]);

  const buildPlan = async () => {
    if (navigator.onLine) {
      try {
        const lat = Number((localStorage.getItem('muhasabah_location') && JSON.parse(localStorage.getItem('muhasabah_location') || '{}').latitude) || 0);
        const lon = Number((localStorage.getItem('muhasabah_location') && JSON.parse(localStorage.getItem('muhasabah_location') || '{}').longitude) || 0);
        if (lat && lon) {
          const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&timezone=auto`, { cache: 'no-store' });
          const j = await r.json();
          const code = Number(j?.current?.weather_code ?? 0);
          setWeatherText(`${Math.round(Number(j?.current?.temperature_2m || 0))}°C • ${code >= 51 ? 'বৃষ্টির সম্ভাবনা/মেঘলা' : 'আবহাওয়া স্বাভাবিক'}`);
        }
      } catch { setWeatherText('আবহাওয়া পাওয়া যায়নি — offline/নেটওয়ার্ক সমস্যা'); }
    }
    const now = new Date();
    let cursor = now.getHours() * 60 + now.getMinutes();
    const steps: PlanStep[] = [];
    if (nextPrayer?.time) {
      const pm = toMinutes(nextPrayer.time);
      if (pm !== null && pm >= cursor) { steps.push({ time: nextPrayer.time, label: `${nextPrayer.name} সালাত`, kind: 'prayer' }); cursor = pm + 15; }
    }
    const nowMin = cursor;
    const nextMedicine = medicines
      .map((m: any) => ({ m, min: toMinutes(m.exactTime) }))
      .filter((x: any) => x.min !== null && x.min >= nowMin && x.min < 23 * 60 && !x.m.takenToday)
      .sort((a: any, b: any) => a.min - b.min)[0];
    if (nextMedicine) steps.push({ time: nextMedicine.m.exactTime, label: `ঔষধ: ${nextMedicine.m.name}`, kind: 'task' });
    incompleteTasks.slice(0, 3).forEach((task: any) => {
      const tm = toMinutes(task.time);
      const duration = 20;
      const taskTime = tm !== null && tm >= cursor ? tm : cursor;
      if (taskTime < 23 * 60) {
        steps.push({ time: formatMinutes(taskTime), label: task.title, kind: 'task' });
        cursor = addMinutes(taskTime, duration);
      }
    });
    const prayerTimes = prayers.map(p => ({ p, m: toMinutes(p.time) })).filter(x => x.m !== null && (x.m as number) >= cursor && (x.m as number) < 23 * 60).sort((a,b)=>(a.m as number)-(b.m as number));
    prayerTimes.slice(0, 2).forEach(({p,m}) => {
      if (!steps.some(s => s.kind === 'prayer' && s.label.startsWith(p.name))) {
        steps.push({ time: p.time, label: `${p.name} সালাত`, kind: 'prayer' });
      }
    });
    steps.sort((a,b)=>(toMinutes(a.time)!)-(toMinutes(b.time)!));
    steps.push({ time: '11:00 PM', label: 'ঘুম / দিনের সমাপ্তি', kind: 'rest' });
    setPlan(steps.slice(0, 7));
  };

  const completedTasks = (planner.tasks || []).filter((t: any) => t.completed).length;
  const totalTasks = (planner.tasks || []).length;
  const salatDone = prayers.filter(p => p.completed).length;
  const quran = metrics.find(m => m.id === 'quran');
  const goals = metrics.find(m => m.id === 'goals');
  const selfAuditDone = (() => { try { const a = JSON.parse(localStorage.getItem('muhasabah_self_audit_records') || '[]'); return a.some((x: any) => x.date === todayKey()); } catch { return false; } })();
  const sadaqahToday = (() => { try { const a = JSON.parse(localStorage.getItem('muhasabah_sadaqah_log') || '[]'); return a.filter((x: any) => x.date === todayKey()).reduce((s: number, x: any) => s + Number(x.amount || 0), 0); } catch { return 0; } })();
  const unaccounted = Math.max(0, Number(timeAudit.unplanned || 0));

  const addAudit = (key: string) => {
    const value = Number(window.prompt('কত মিনিট?', '30'));
    if (!Number.isFinite(value) || value <= 0) return;
    const next = { ...timeAudit, [key]: (timeAudit[key] || 0) + Math.round(value) };
    setTimeAudit(next);
    localStorage.setItem('muhasabah_time_audit', JSON.stringify(next));
  };

  return (
    <div className={`rounded-[22px] border overflow-hidden ${darkMode ? 'bg-[#10251B] border-[#2A5A43]' : 'bg-white border-emerald-100 shadow-sm'}`}>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#D4AF37]/15 flex items-center justify-center"><Wand2 className="w-4 h-4 text-[#D4AF37]" /></div>
            <div><h3 className={`text-sm font-black ${darkMode ? 'text-stone-100' : 'text-[#1B4332]'}`}>আজকের সময় ও হিসাব</h3><p className="text-[10px] text-stone-400">Planner-এর সাথে যুক্ত স্মার্ট সহায়তা</p></div>
          </div>
          <button onClick={() => setOpen(v => !v)} className="p-1.5 rounded-lg text-stone-400">{open ? <ChevronUp className="w-4 h-4"/> : <ChevronDown className="w-4 h-4"/>}</button>
        </div>
        {open && <>
          <button onClick={buildPlan} className="mt-3 w-full rounded-2xl px-4 py-3 bg-gradient-to-r from-[#D4AF37] to-[#E5C158] text-stone-950 font-black text-sm flex items-center justify-center gap-2 active:scale-[0.99]">
            <Sparkles className="w-4 h-4" /> আজকে গুছিয়ে দিন
          </button>
          <div className="mt-2 flex items-center justify-between gap-2 text-[10px] text-stone-400"><span>🕐 আজকের বাকি সময়: {Math.floor(availableMinutes / 60)}ঘ {availableMinutes % 60}মি</span><span className="truncate">🌤️ {weatherText}</span></div>
          {plan.length > 0 && <div className="mt-3 space-y-1.5">
            {plan.map((s, i) => <div key={`${s.time}-${i}`} className="flex items-center gap-2 text-xs">
              <span className="w-[64px] font-black text-[#D4AF37]">{s.time}</span><span className={`w-1.5 h-1.5 rounded-full ${s.kind === 'prayer' ? 'bg-emerald-400' : s.kind === 'rest' ? 'bg-stone-400' : 'bg-blue-400'}`} /><span className={darkMode ? 'text-stone-200' : 'text-stone-700'}>{s.label}</span>
            </div>)}
          </div>}

          <div className={`mt-4 rounded-2xl p-3 border ${darkMode ? 'bg-black/10 border-white/10' : 'bg-emerald-50/40 border-emerald-100'}`}>
            <div className="grid grid-cols-2 gap-x-4 gap-y-2.5">
              <div>
                <div className="flex items-center gap-1.5 text-[10px] font-black text-stone-400"><CheckCircle2 className="w-3.5 h-3.5"/> আজকের হিসাব</div>
                <div className="mt-1.5 grid grid-cols-2 gap-x-2 gap-y-1 text-[11px] font-bold">
                  <span>🕌 {salatDone}/5</span><span>📿 {dhikrCount}</span>
                  <span>📖 {quran?.current || 0}</span><span>🎯 {goals?.current || 0}</span>
                  <span>💰 ৳{sadaqahToday}</span><span>📝 {selfAuditDone ? 'সম্পন্ন' : 'বাকি'}</span>
                </div>
              </div>
              <div className="border-l border-white/10 pl-3">
                <div className="flex items-center gap-1.5 text-[10px] font-black text-stone-400"><Clock3 className="w-3.5 h-3.5"/> সময় কোথায় গেল?</div>
                <div className="mt-1 text-lg font-black text-[#D4AF37]">{unaccounted} মিনিট</div>
                <p className="text-[9px] text-stone-400">Unplanned time</p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {['phone','rest','unplanned'].map(k => <button key={k} onClick={() => addAudit(k)} className="px-2 py-1 rounded-lg text-[9px] font-bold bg-stone-500/10">+ {k === 'phone' ? 'Phone' : k === 'rest' ? 'Rest' : 'Unplanned'}</button>)}
                </div>
              </div>
            </div>
            <div className="mt-2 pt-2 border-t border-white/10 text-[9px] text-stone-400">Planner-এর incomplete কাজ: {incompleteTasks.length}</div>
          </div>
        </>}
      </div>
    </div>
  );
};
