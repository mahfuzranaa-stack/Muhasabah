import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'bn' | 'en';

export interface TranslationDictionary {
  [key: string]: {
    bn: string;
    en: string;
  };
}

export const TRANSLATIONS: TranslationDictionary = {
  // App Identity
  'app.name': {
    bn: 'মুহাসাবাহ',
    en: 'Muhasabah',
  },
  'app.fullName': {
    bn: 'মুহাসাবাহ (Muhasabah)',
    en: 'Muhasabah (মুহাসাবাহ)',
  },
  'app.tagline': {
    bn: 'দৈনন্দিন আত্মশুদ্ধি ও ইবাদত সঙ্গী',
    en: 'Daily Self-Accounting & Spiritual Companion',
  },
  'app.version': {
    bn: 'ভার্সন ৩.০ (প্রোডাকশন)',
    en: 'Version 3.0 (Production)',
  },

  // Navigation Tabs
  'nav.home': {
    bn: 'মূলপাতা',
    en: 'Home',
  },
  'nav.salat': {
    bn: 'সালাত',
    en: 'Salat',
  },
  'nav.dhikr': {
    bn: 'জিকির',
    en: 'Dhikr',
  },
  'nav.calendar': {
    bn: 'ক্যালেন্ডার',
    en: 'Calendar',
  },
  'nav.goals': {
    bn: 'লক্ষ্য',
    en: 'Goals',
  },
  'nav.mal': {
    bn: 'হিসাব',
    en: 'Al-Mal',
  },
  'nav.profile': {
    bn: 'প্রোফাইল',
    en: 'Profile',
  },
  'nav.settings': {
    bn: 'সেটিংস',
    en: 'Settings',
  },

  // Common UI
  'common.back': {
    bn: 'ফিরে যান',
    en: 'Back',
  },
  'common.close': {
    bn: 'বন্ধ করুন',
    en: 'Close',
  },
  'common.save': {
    bn: 'সংরক্ষণ করুন',
    en: 'Save',
  },
  'common.saved': {
    bn: 'সংরক্ষিত হয়েছে',
    en: 'Saved',
  },
  'common.cancel': {
    bn: 'বাতিল',
    en: 'Cancel',
  },
  'common.reset': {
    bn: 'রিসেট',
    en: 'Reset',
  },
  'common.confirm': {
    bn: 'নিশ্চিত করুন',
    en: 'Confirm',
  },
  'common.delete': {
    bn: 'মুছুন',
    en: 'Delete',
  },
  'common.edit': {
    bn: 'সম্পাদনা',
    en: 'Edit',
  },
  'common.play': {
    bn: 'প্লে',
    en: 'Play',
  },
  'common.pause': {
    bn: 'পজ',
    en: 'Pause',
  },
  'common.resume': {
    bn: 'চালান',
    en: 'Resume',
  },
  'common.stop': {
    bn: 'থামান',
    en: 'Stop',
  },
  'common.audioUnavailable': {
    bn: 'অডিও পাওয়া যায়নি',
    en: 'Audio unavailable',
  },
  'common.loading': {
    bn: 'লোড হচ্ছে...',
    en: 'Loading...',
  },
  'common.search': {
    bn: 'অনুসন্ধান...',
    en: 'Search...',
  },
  'common.all': {
    bn: 'সব',
    en: 'All',
  },
  'common.completed': {
    bn: 'সম্পন্ন',
    en: 'Completed',
  },
  'common.pending': {
    bn: 'অপেক্ষমাণ',
    en: 'Pending',
  },

  // Home Screen
  'home.dailyServices': {
    bn: 'দৈনিক সেবা ও সারসংক্ষেপ',
    en: 'Daily Services & Summary',
  },
  'home.emergencyHelpline': {
    bn: 'জরুরি হেল্পলাইন',
    en: 'Emergency Helpline',
  },
  'home.emergencyDesc': {
    bn: 'জাতীয় হেল্পলাইন, অ্যাম্বুলেন্স ও ফায়ার সার্ভিস সরাসরি ডায়াল।',
    en: 'National helpline, ambulance & emergency services speed dial.',
  },
  'home.openDialer': {
    bn: 'ডায়ালার খুলুন',
    en: 'Open Dialer',
  },
  'home.medReminder': {
    bn: 'ঔষধ রিমাইন্ডার',
    en: 'Medicine Reminder',
  },
  'home.medDesc': {
    bn: 'প্রেসক্রিপশন ও সময়মতো ঔষধ গ্রহণের অ্যালার্ট।',
    en: 'Prescription schedule and punctual medication alerts.',
  },
  'home.manageMeds': {
    bn: 'ঔষধ দেখুন',
    en: 'Manage Meds',
  },
  'home.newsBulletin': {
    bn: 'সংবাদ বুলেটিন',
    en: 'News Bulletin',
  },
  'home.newsDesc': {
    bn: 'জাতীয় ও আন্তর্জাতিক গুরুত্বপূর্ণ সংবাদ এক নজরে।',
    en: 'National and international news headlines at a glance.',
  },
  'home.readHeadlines': {
    bn: 'সংবাদ পড়ুন',
    en: 'Read Headlines',
  },
  'home.dailySummary': {
    bn: 'দৈনিক পর্যালোচনা ও বিশ্লেষণ',
    en: 'Daily Summary & Analysis',
  },
  'home.salatScore': {
    bn: 'সালাত সম্পন্ন',
    en: 'Prayers Completed',
  },
  'home.quranVerses': {
    bn: 'কুরআন তিলাওয়াত',
    en: 'Quran Verses',
  },
  'home.dhikrTotal': {
    bn: 'যিকির তাসবীহ',
    en: 'Dhikr Tasbih',
  },
  'home.niyyahLabel': {
    bn: 'আজকের নিয়ত',
    en: "Today's Intention",
  },
  'home.viewSummary': {
    bn: 'সারসংক্ষেপ দেখুন',
    en: 'View Summary',
  },
  'home.spiritualAccountability': {
    bn: 'মুহাসাবা ও আত্মশুদ্ধি',
    en: 'Spiritual Accountability',
  },

  // Salat Screen
  'salat.dashboardTitle': {
    bn: 'সালাত ড্যাশবোর্ড',
    en: 'Salat Dashboard',
  },
  'salat.time': {
    bn: 'সালাতের ওয়াক্ত',
    en: 'Prayer Time',
  },
  'salat.waqtStart': {
    bn: 'ওয়াক্ত শুরু',
    en: 'Waqt Start',
  },
  'salat.waqtEnd': {
    bn: 'ওয়াক্ত শেষ',
    en: 'Waqt End',
  },
  'salat.jamaah': {
    bn: 'জামাত',
    en: 'Jamaah',
  },
  'salat.fard': {
    bn: 'ফরজ আদায়',
    en: 'Fard Prayed',
  },
  'salat.qibla': {
    bn: 'কিবলা কম্পাস',
    en: 'Qibla Compass',
  },

  // Dhikr & Dua
  'dhikr.title': {
    bn: 'যিকির ও দোয়া হাব',
    en: 'Dhikr & Dua Sanctuary',
  },
  'dhikr.counter': {
    bn: 'ডিজিটাল তাসবীহ',
    en: 'Digital Tasbih',
  },
  'dhikr.duaList': {
    bn: 'প্রয়োজনীয় দোয়া ও যিকির',
    en: 'Essential Duas & Adhkar',
  },
  'dhikr.surahLibrary': {
    bn: 'কুরআন তিলাওয়াত লাইব্রেরি',
    en: 'Quran Recitation Library',
  },
  'dhikr.tapCount': {
    bn: 'গণনা করতে চাপুন',
    en: 'Tap to Count',
  },
  'dhikr.resetCounter': {
    bn: 'কাউন্টার রিসেট',
    en: 'Reset Counter',
  },
  'dhikr.nowPlaying': {
    bn: 'চলমান অডিও',
    en: 'Now Playing',
  },

  // Settings
  'settings.title': {
    bn: 'অ্যাপ সেটিংস',
    en: 'App Settings',
  },
  'settings.subtitle': {
    bn: 'ভাষা, থিম এবং সিস্টেম পছন্দসমূহ',
    en: 'Language, Theme & System Preferences',
  },
  'settings.languageSection': {
    bn: 'ভাষা নির্বাচন (Language)',
    en: 'Language Selection',
  },
  'settings.languageDesc': {
    bn: 'অ্যাপ্লিকেশনের মূল ভাষা নির্বাচন করুন। এটি সমগ্র অ্যাপে সাথে সাথে প্রযোজ্য হবে।',
    en: 'Choose primary application language. Applied immediately across the entire app.',
  },
  'settings.themeSection': {
    bn: 'থিম ও ডিসপ্লে (Theme & Display)',
    en: 'Theme & Display',
  },
  'settings.themeDesc': {
    bn: 'ডার্ক বা লাইট মোড নির্বাচন করুন। আপনার পছন্দ ডিভাইসে সংরক্ষিত থাকবে।',
    en: 'Select Dark or Light mode. Your choice is permanently saved on device.',
  },
  'settings.themeDark': {
    bn: 'ইসলামিক ডার্ক মোড (Dark)',
    en: 'Islamic Dark Mode',
  },
  'settings.themeLight': {
    bn: 'লাইট মোড (Light)',
    en: 'Light Mode',
  },
  'settings.aboutSection': {
    bn: 'অ্যাপ পরিচিতি (About App)',
    en: 'About App',
  },
  'settings.aboutDesc': {
    bn: 'মুহাসাবাহ (Muhasabah) একটি পূর্ণাঙ্গ ইসলামি আত্মশুদ্ধি, সালাত ট্র্যাকার, যিকির ও কুরআন সহকারী।',
    en: 'Muhasabah (মুহাসাবাহ) is an all-in-one Islamic spiritual accountability, prayer tracker, dhikr and Quran companion.',
  },
  'settings.developer': {
    bn: 'উন্নয়ন ও স্বত্ব',
    en: 'Developer & Copyright',
  },
  'settings.copyright': {
    bn: 'মুহাসাবাহ ওপেন সোর্স টিম • সর্বস্বত্ব সংরক্ষিত',
    en: 'Muhasabah Open Source Team • All rights reserved',
  },
  'settings.apkBuildInfo': {
    bn: 'অ্যান্ড্রয়েড ইনস্টলেশন কনফিগারেশন',
    en: 'Android Installation Config',
  },
  'settings.apkDesc': {
    bn: 'Google Play Store এর জন্য AAB এবং সরাসরি ইনস্টলের জন্য APK বিল্ড কনফিগারেশন প্রস্তুত।',
    en: 'Production AAB for Play Store and direct APK build profiles configured.',
  },
  'settings.backupSection': {
    bn: 'ডাটা ব্যাকআপ ও পুনরুদ্ধার',
    en: 'Data Backup & Restore',
  },
  'settings.backupDesc': {
    bn: 'আপনার সকল ইবাদত রেকর্ড ও সেটিংস ব্যাকআপ ফাইল হিসেবে ডাউনলোড বা রিস্টোর করুন।',
    en: 'Export or import your spiritual records and configuration as a secure JSON backup.',
  },

  // Profile
  'profile.title': {
    bn: 'ব্যক্তিগত প্রোফাইল ও আত্মশুদ্ধি',
    en: 'Personal Profile & Self-Audit',
  },
  'profile.resetTracker': {
    bn: 'দৈনন্দিন ট্র্যাকার রিসেট করুন',
    en: 'Reset Daily Tracker',
  },
  'profile.resetDesc': {
    bn: 'সালাতের টিক, তাসবীহ কাউন্ট ও আজকের রেকর্ড নতুন করে শুরু করুন।',
    en: 'Reset prayer checks, tasbih counts and daily records back to zero.',
  },
  'profile.settingsBtn': {
    bn: 'সেটিংস',
    en: 'Settings',
  },
  'profile.settingsBtnDesc': {
    bn: 'ভাষা, থিম, অডিও এবং সিস্টেম কনফিগারেশন পরিবর্তন করুন।',
    en: 'Change language, theme, audio, and system configuration.',
  },

  // Goals
  'goals.title': {
    bn: 'আমল লক্ষ্য ও স্ট্রিক্স',
    en: 'Spiritual Goals & Streaks',
  },
  'goals.subtitle': {
    bn: 'ধারাবাহিক ইবাদত, দীর্ঘমেয়াদী লক্ষ্য ও প্রাপ্ত পদকসমূহ',
    en: 'Consistent worship, long-term goals & unlocked milestones',
  },
  'goals.achievements': {
    bn: 'আমল পদক ও স্বীকৃতি',
    en: 'Spiritual Badges & Milestones',
  },
  'goals.customGoals': {
    bn: 'ব্যক্তিগত লক্ষ্যসমূহ',
    en: 'Personal Targets',
  },
  'goals.addGoal': {
    bn: 'নতুন লক্ষ্য যোগ করুন',
    en: 'Add New Target',
  },

  // Al-Mal (হিসাব)
  'mal.title': {
    bn: 'মুহাসাবাতুল মাল — হালাল অর্থ ব্যবস্থাপনা',
    en: 'Muhasabat Al-Mal — Halal Wealth Accounting',
  },
  'mal.subtitle': {
    bn: 'হালাল উপার্জন, পরিমিত ব্যয় ও সাদাকাহ পর্যবেক্ষণ',
    en: 'Halal income, mindful spending & charity tracking',
  },
  'mal.netSavings': {
    bn: 'মোট সঞ্চয়',
    en: 'Net Savings',
  },
  'mal.totalIncome': {
    bn: 'মোট আয়',
    en: 'Total Income',
  },
  'mal.totalExpense': {
    bn: 'মোট ব্যয়',
    en: 'Total Expense',
  },
  'mal.sadaqah': {
    bn: 'সাদাকাহ ও দান',
    en: 'Charity & Sadaqah',
  },

  // Calendar
  'calendar.title': {
    bn: 'ইসলামিক ও বাংলা ক্যালেন্ডার',
    en: 'Islamic & Bengali Calendar',
  },
  'calendar.subtitle': {
    bn: 'হিজরি তারিখ, বাংলা সন ও গুরুত্বপূর্ণ আমল দিবস',
    en: 'Hijri dates, Bengali era & important Islamic observances',
  },
  'calendar.ageCalc': {
    bn: 'বয়স ও হায়াত হিসাব',
    en: 'Age & Lifespan Calculation',
  },

  // Inner Tools
  'inner.selfAudit': {
    bn: 'মুহাসাবাতুন নাফস',
    en: 'Self-Audit (Nafs)',
  },
  'inner.selfAuditDesc': {
    bn: 'আত্মশুদ্ধি, খুশু রেটিং ও আধ্যাত্মিক ডায়েরি।',
    en: 'Daily soul audit, Khushoo rating & spiritual diary.',
  },
  'inner.dailyNiyyah': {
    bn: 'দৈনিক নিয়ত ও সংকল্প',
    en: 'Daily Niyyah & Resolve',
  },
  'inner.dailyNiyyahDesc': {
    bn: 'সকালের আন্তরিক সংকল্প ও রাতের হিসাব।',
    en: 'Morning sincere intentions & night accountability.',
  },
  'inner.istighfar': {
    bn: 'ইস্তিগফার ও তাওবাহ',
    en: 'Istighfar & Repentance',
  },
  'inner.istighfarDesc': {
    bn: '১০০ বার তাসবীহ, সাইয়্যিদুল ইস্তিগফার ও তাওবাহ।',
    en: '100x counter, Sayyidul Istighfar & repentance ledger.',
  },
  'inner.gratitude': {
    bn: 'শুকর ও নিয়ামত ডায়েরি',
    en: 'Gratitude & Blessings',
  },
  'inner.gratitudeDesc': {
    bn: 'তাহদীস বিন নি\'মাহ, সুস্বাস্থ্য ও কৃতজ্ঞতা নোট।',
    en: 'Tahdith bin Ni\'mah, health & gratitude journal.',
  },
  'inner.goodDeeds': {
    bn: 'গোপন নেক আমল',
    en: 'Secret Good Deeds',
  },
  'inner.goodDeedsDesc': {
    bn: 'আল্লাহর সাথে গোপন সম্পর্ক — যা শুধু আল্লাহই জানেন।',
    en: 'Sirr ma\'a Allah — secret good deeds only Allah knows.',
  },
  'inner.audioSanctuary': {
    bn: 'অডিও প্রশান্তি',
    en: 'Audio Sanctuary',
  },
  'inner.audioSanctuaryDesc': {
    bn: 'শান্ত বৃষ্টি, বাতাস, হারামের আযান ও প্রশান্তিময় সুর।',
    en: 'Gentle rain, wind, Haramain Azan & calming ambient audio.',
  },
  'inner.vowTracker': {
    bn: 'মানত ও কাফফারা',
    en: 'Vows & Kaffarah',
  },
  'inner.vowTrackerDesc': {
    bn: 'মানত পূরণ, প্রতিজ্ঞা ও শপথের হিসাব রাখা।',
    en: 'Nadhr fulfilment, solemn vows & oath accountability.',
  },
  'inner.angerReset': {
    bn: 'রাগ ও রিপু নিয়ন্ত্রণ',
    en: 'Anger Reset Protocol',
  },
  'inner.angerResetDesc': {
    bn: '৫ ধাপের সুন্নাহ প্রেসক্রিপশন: তা\'আউউয, ওযু ও বসার ভঙ্গি।',
    en: '5-step Sunnah anger reset: Ta\'awwudh, Wudu & posture.',
  },
};

export const getTranslation = (key: string, lang: Language = 'bn'): string => {
  const item = TRANSLATIONS[key];
  if (!item) return key;
  return item[lang] || item['en'] || key;
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'bn',
  setLanguage: () => {},
  t: (key: string) => key,
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_language');
      if (saved === 'en' || saved === 'bn') return saved;
    } catch (e) {
      console.warn('Could not read language from storage', e);
    }
    return 'bn';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('muhasabah_language', lang);
    } catch (e) {
      console.warn('Could not persist language to storage', e);
    }
  };

  const t = (key: string): string => {
    return getTranslation(key, language);
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
