import React, { useState } from 'react';
import { X, Copy, Check, Code, ExternalLink, Smartphone } from 'lucide-react';
import { EXPO_SNACK_CODE } from '../data/expoSnackCode';

interface ExportExpoModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const ExportExpoModal: React.FC<ExportExpoModalProps> = ({
  isOpen,
  onClose,
  darkMode,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(EXPO_SNACK_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-2xl max-h-[85vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#163024] border-[#224735] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-emerald-100/50 dark:border-[#224735] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#2D6A4F] text-white">
              <Code className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight">
                Single-File React Native (Expo) Code
              </h3>
              <p className="text-[11px] text-stone-400">
                Ready for Expo Snack (snack.expo.dev), Replit, or StackBlitz
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#2D6A4F] text-white hover:bg-[#23533E]'
              }`}
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Code'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Instructions banner */}
        <div className="p-3 bg-emerald-50/70 dark:bg-[#12281E] text-xs flex items-center justify-between border-b border-emerald-100/50 dark:border-[#224735]">
          <div className="flex items-center gap-1.5 text-stone-700 dark:text-stone-300">
            <Smartphone className="w-4 h-4 text-[#2D6A4F] dark:text-[#74C69D]" />
            <span>
              Contains all 5 screens (Dashboard, Salat, Dhikr, Goals, Profile) in one React Native file.
            </span>
          </div>
          <a
            href="https://snack.expo.dev"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-[11px] font-bold text-[#2D6A4F] dark:text-[#74C69D] hover:underline"
          >
            <span>Open Expo Snack</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Code View */}
        <div className="flex-1 overflow-auto p-4 bg-[#0d1f16] text-[#A7F3D0] font-mono text-xs leading-relaxed">
          <pre>{EXPO_SNACK_CODE}</pre>
        </div>

        {/* Footer */}
        <div className="p-3 bg-stone-50 dark:bg-[#10241A] border-t border-stone-200 dark:border-[#224735] flex items-center justify-between">
          <span className="text-[11px] text-stone-400">
            Dependencies: react-native, lucide-react-native
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-bold text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
