import React, { useState, useEffect } from 'react';
import {
  BarChart2,
  Award,
  Flame,
  CheckCircle2,
  Calendar,
  Sparkles,
  Lock,
  HeartHandshake,
  Moon,
  BookOpen,
  Plus,
  Trash2,
  Target,
  ChevronRight,
  TrendingUp,
  X,
  RotateCcw,
} from 'lucide-react';
import { Achievement, DayStreakItem, CustomGoal, MetricProgress } from '../types';
import { INITIAL_ACHIEVEMENTS, INITIAL_MONTH_DAYS } from '../data/initialData';
import { useLanguage } from '../utils/i18n';

interface GoalsScreenProps {
  darkMode: boolean;
  metrics?: MetricProgress[];
  soundEnabled?: boolean;
}

const STORAGE_KEY_CUSTOM_GOALS = 'muhasabah_custom_goals_v2';
const STORAGE_KEY_ACHIEVEMENTS = 'muhasabah_achievements_v2';

export const GoalsScreen: React.FC<GoalsScreenProps> = ({
  darkMode,
  metrics = [],
  soundEnabled = true,
}) => {
  const { language } = useLanguage();
  // Day streak selection
  const [selectedDay, setSelectedDay] = useState<DayStreakItem>(INITIAL_MONTH_DAYS[0]);
  const [selectedBadge, setSelectedBadge] = useState<Achievement | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Predefined Achievements state (persisted)
  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACHIEVEMENTS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return INITIAL_ACHIEVEMENTS;
  });

  // Custom Goals state (persisted)
  const [customGoals, setCustomGoals] = useState<CustomGoal[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CUSTOM_GOALS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return [
      {
        id: 'goal-tasbih-10k',
        title: '10,000 Astaghfirullah Recitation',
        category: 'Dhikr',
        target: 10000,
        current: 0,
        unit: 'Times',
        completed: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'goal-charity-ramadan',
        title: 'Ramadan Sadaqah Fund',
        category: 'Charity',
        target: 5000,
        current: 0,
        unit: 'BDT',
        completed: false,
        createdAt: new Date().toISOString(),
      },
    ];
  });

  // New custom goal modal state
  const [showAddGoalModal, setShowAddGoalModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTarget, setNewTarget] = useState<number>(1000);
  const [newUnit, setNewUnit] = useState('Times');
  const [newCategory, setNewCategory] = useState<CustomGoal['category']>('Dhikr');

  // Custom increment modal/input
  const [customIncGoalId, setCustomIncGoalId] = useState<string | null>(null);
  const [customIncAmount, setCustomIncAmount] = useState<number>(50);

  const handleResetCustomGoals = () => {
    if (!window.confirm(language === 'bn' ? 'সব ব্যক্তিগত লক্ষ্য রিসেট করবেন?' : 'Reset all custom goals?')) return;
    setCustomGoals([]);
    try { localStorage.removeItem(STORAGE_KEY_CUSTOM_GOALS); } catch {}
    setToastMsg(language === 'bn' ? 'ব্যক্তিগত লক্ষ্য রিসেট হয়েছে' : 'Custom goals reset');
  };

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ACHIEVEMENTS, JSON.stringify(achievements));
    } catch {
      // ignore
    }
  }, [achievements]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CUSTOM_GOALS, JSON.stringify(customGoals));
    } catch {
      // ignore
    }
  }, [customGoals]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  // Habit metrics calculated from genuine user actions or initial 0
  const salatMetric = metrics.find((m) => m.id === 'salat');
  const quranMetric = metrics.find((m) => m.id === 'quran');
  const dhikrMetric = metrics.find((m) => m.id === 'dhikr');
  const tasksMetric = metrics.find((m) => m.id === 'tasks');

  const habits = [
    {
      name: language === 'bn' ? 'সালাত' : 'Salat',
      percent: salatMetric ? salatMetric.percent : 0,
      color: '#2D6A4F',
      detail: salatMetric
        ? (language === 'bn' ? `${salatMetric.current}/${salatMetric.total} ওয়াক্ত আদায়` : `${salatMetric.current}/${salatMetric.total} Waqt completed`)
        : (language === 'bn' ? '০/৫ ওয়াক্ত আদায়' : '0/5 Waqt completed'),
    },
    {
      name: language === 'bn' ? 'কুরআন' : 'Quran',
      percent: quranMetric ? quranMetric.percent : 0,
      color: '#52B788',
      detail: quranMetric
        ? (language === 'bn' ? `${quranMetric.current}/${quranMetric.total} আয়াত তিলাওয়াত` : `${quranMetric.current}/${quranMetric.total} Verses recited`)
        : (language === 'bn' ? '০/১০ আয়াত তিলাওয়াত' : '0/10 Verses recited'),
    },
    {
      name: language === 'bn' ? 'যিকির' : 'Dhikr',
      percent: dhikrMetric ? dhikrMetric.percent : 0,
      color: '#D4AF37',
      detail: dhikrMetric
        ? (language === 'bn' ? `${dhikrMetric.current}/${dhikrMetric.total} তাসবীহ পাঠ` : `${dhikrMetric.current}/${dhikrMetric.total} Tasbih logged`)
        : (language === 'bn' ? '০/১০০ তাসবীহ পাঠ' : '0/100 Tasbih logged'),
    },
    {
      name: language === 'bn' ? 'সৎকর্ম' : 'Kind Deed',
      percent: tasksMetric ? tasksMetric.percent : 0,
      color: '#74C69D',
      detail: tasksMetric
        ? (language === 'bn' ? `${tasksMetric.current}/${tasksMetric.total} আমল সম্পন্ন` : `${tasksMetric.current}/${tasksMetric.total} Deeds & Tazkiyah`)
        : (language === 'bn' ? '০/৪ আমল সম্পন্ন' : '0/4 Deeds & Tazkiyah'),
    },
  ];

  const avgHabitPercent = Math.round(
    habits.reduce((acc, h) => acc + h.percent, 0) / (habits.length || 1)
  );

  const getStatusColor = (status: DayStreakItem['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-[#2D6A4F] text-white border-[#2D6A4F]';
      case 'partial':
        return 'bg-[#D4AF37] text-stone-900 border-[#D4AF37]';
      case 'missed':
        return 'bg-rose-500 text-white border-rose-500';
      case 'today':
        return 'bg-[#74C69D] text-stone-950 ring-2 ring-[#2D6A4F] font-black';
      case 'future':
        return darkMode
          ? 'bg-[#183326]/50 text-stone-600 border-[#224735]'
          : 'bg-stone-100 text-stone-300 border-stone-200';
      default:
        return 'bg-stone-100 text-stone-400';
    }
  };

  // Custom Goal Handlers
  const handleAddCustomGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      showToast('Please enter a goal title');
      return;
    }
    if (newTarget <= 0) {
      showToast('Target must be greater than zero');
      return;
    }

    const newGoal: CustomGoal = {
      id: `goal-${Date.now()}`,
      title: newTitle.trim(),
      category: newCategory,
      target: newTarget,
      current: 0,
      unit: newUnit,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    setCustomGoals((prev) => [newGoal, ...prev]);
    setShowAddGoalModal(false);
    setNewTitle('');
    setNewTarget(1000);
    showToast(`Created goal: "${newGoal.title}"`);
  };

  const handleIncrementGoal = (id: string, delta: number) => {
    setCustomGoals((prev) =>
      prev.map((g) => {
        if (g.id !== id) return g;
        const newCurrent = Math.max(0, g.current + delta);
        const completed = newCurrent >= g.target;
        if (completed && !g.completed) {
          showToast(`🎉 Goal "${g.title}" Achieved! Masha'Allah!`);
        }
        return {
          ...g,
          current: newCurrent,
          completed,
        };
      })
    );
  };

  const handleDeleteGoal = (id: string) => {
    setCustomGoals((prev) => prev.filter((g) => g.id !== id));
    showToast('Goal removed');
  };

  const handleIncrementAchievement = (id: string, delta: number) => {
    setAchievements((prev) =>
      prev.map((badge) => {
        if (badge.id !== id) return badge;
        const newProg = Math.min(badge.maxProgress, badge.progress + delta);
        const unlocked = newProg >= badge.maxProgress;
        if (unlocked && !badge.unlocked) {
          showToast(`🏆 Milestone Unlocked: "${badge.title}"!`);
        }
        return {
          ...badge,
          progress: newProg,
          unlocked,
          dateUnlocked: unlocked && !badge.unlocked ? new Date().toLocaleDateString() : badge.dateUnlocked,
        };
      })
    );
  };

  return (
    <div id="screen-goals-analytics" className="space-y-4 pb-6">
      {/* Toast */}
      {toastMsg && (
        <div className="sticky top-2 z-30 mx-auto max-w-xs text-center px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#2D6A4F] shadow-lg animate-bounce">
          ✨ {toastMsg}
        </div>
      )}

      {/* 1. WEEKLY HABIT COMPLETION RINGS (Starts at 0% fresh from genuine user progress) */}
      <div
        id="card-weekly-habit-rings"
        className={`rounded-[20px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D]">
              <BarChart2 className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-stone-900 dark:text-stone-100 uppercase tracking-wider">
                {language === 'bn' ? 'সাপ্তাহিক অভ্যাসের অগ্রগতি' : 'Weekly Habit Completion'}
              </h2>
              <p className="text-[11px] text-stone-400 font-medium">
                {language === 'bn'
                  ? 'দৈনন্দিন নিয়মিততা ও আমলের ধারাবাহিকতা'
                  : 'Live Daily Consistency & Amal Steadfastness'}
              </p>
            </div>
          </div>

          <span className="text-xs font-black px-3 py-1 rounded-full bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-[#FFF9E6] border border-[#D4AF37]/50 shadow-xs">
            {avgHabitPercent}% {language === 'bn' ? 'গড়' : 'Average'}
          </span>
        </div>

        {/* Concentric Progress Rings Visual */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {habits.map((habit) => {
            const radius = 24;
            const circumference = 2 * Math.PI * radius;
            const strokeDashoffset = circumference - (habit.percent / 100) * circumference;

            return (
              <div
                key={habit.name}
                className={`p-3.5 rounded-[20px] border text-center flex flex-col items-center justify-center transition-all ${
                  darkMode
                    ? 'bg-[#12281E] border-[#224735]'
                    : 'bg-gradient-to-b from-[#E8F5E9]/50 to-white border-emerald-900/10 shadow-xs'
                }`}
              >
                <div className="relative w-18 h-18 flex items-center justify-center mb-1.5">
                  <svg className="w-18 h-18 -rotate-90" viewBox="0 0 64 64">
                    <circle
                      cx="32"
                      cy="32"
                      r={radius}
                      fill="none"
                      stroke={darkMode ? '#1A382B' : '#E8F5E9'}
                      strokeWidth="5"
                    />
                    <circle
                      cx="32"
                      cy="32"
                      r={radius}
                      fill="none"
                      stroke={habit.percent === 100 ? '#D4AF37' : habit.color}
                      strokeWidth="5.5"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      style={{
                        filter:
                          habit.percent > 0
                            ? 'drop-shadow(0 0 3px rgba(45, 106, 79, 0.3))'
                            : 'none',
                      }}
                    />
                  </svg>
                  <span className="absolute text-xs font-black text-stone-900 dark:text-stone-100 font-mono">
                    {habit.percent}%
                  </span>
                </div>

                <div className="font-extrabold text-xs text-stone-900 dark:text-stone-100">
                  {habit.name}
                </div>
                <div className="text-[10px] font-semibold text-stone-500 dark:text-stone-400 mt-0.5">
                  {habit.detail}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. CUSTOM GOALS & TARGETS (Requirement 10: Custom Target e.g., 10,000) */}
      <div
        id="card-custom-goals-section"
        className={`rounded-[20px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-2xl bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D]">
              <Target className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'ব্যক্তিগত লক্ষ্য ও সংকল্প' : 'Custom Goals & Targets'}
              </h3>
              <p className="text-[11px] text-stone-400 font-medium">
                {language === 'bn'
                  ? 'নিজস্ব আধ্যাত্মিক লক্ষ্য (যেমন: ১০,০০০ যিকির) নির্ধারণ ও ট্র্যাক করুন'
                  : 'Set custom spiritual targets (e.g. 10,000 Dhikr) & track progress'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button onClick={handleResetCustomGoals} title="Reset custom goals" className="p-2 rounded-xl border border-rose-300/60 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all"><RotateCcw className="w-4 h-4" /></button>
            <button
            id="btn-add-custom-goal"
            onClick={() => setShowAddGoalModal(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-black transition-all active:scale-95 bg-gradient-to-r from-[#D4AF37] to-[#E5C158] text-stone-950 border border-white/40 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>{language === 'bn' ? 'নতুন লক্ষ্য' : 'New Goal'}</span>
          </button>
          </div>
        </div>

        {/* Custom Goals List */}
        <div className="space-y-3">
          {customGoals.length === 0 ? (
            <div className="text-center py-6 text-stone-400 text-xs font-medium border border-dashed rounded-xl border-stone-300 dark:border-stone-700">
              {language === 'bn'
                ? 'এখনও কোনো ব্যক্তিগত লক্ষ্য তৈরি করা হয়নি। "নতুন লক্ষ্য" বাটনে চাপুন।'
                : 'No custom goals set yet. Click "New Goal" to set a personal target!'}
            </div>
          ) : (
            customGoals.map((goal) => {
              const percent = Math.min(100, Math.round((goal.current / (goal.target || 1)) * 100));

              return (
                <div
                  key={goal.id}
                  id={`goal-item-${goal.id}`}
                  className={`p-4 rounded-[18px] border transition-all ${
                    goal.completed
                      ? darkMode
                        ? 'bg-[#153322] border-[#D4AF37]/50'
                        : 'bg-emerald-50/60 border-[#D4AF37]/50'
                      : darkMode
                      ? 'bg-[#12281E] border-[#1C3B2E]'
                      : 'bg-stone-50/80 border-stone-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-stone-900 dark:text-stone-100">
                          {goal.title}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800">
                          {goal.category}
                        </span>
                        {goal.completed && (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">
                            Achieved 🎉
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-stone-500 dark:text-stone-400 mt-1 font-semibold">
                        Progress:{' '}
                        <span className="font-bold text-[#1B4332] dark:text-[#74C69D] font-mono">
                          {goal.current.toLocaleString()}
                        </span>{' '}
                        / {goal.target.toLocaleString()} {goal.unit} ({percent}%)
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteGoal(goal.id)}
                      className="p-1.5 text-stone-400 hover:text-rose-500 transition-colors"
                      title="Delete Goal"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-2.5 w-full bg-stone-200/80 dark:bg-stone-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300 bg-gradient-to-r from-[#2D6A4F] via-[#52B788] to-[#D4AF37]"
                      style={{ width: `${percent}%` }}
                    />
                  </div>

                  {/* Real-Time Increment Buttons */}
                  <div className="mt-3 pt-2.5 border-t border-stone-200/70 dark:border-stone-800/80 flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleIncrementGoal(goal.id, 1)}
                        className="px-2.5 py-1 rounded-xl text-xs font-black bg-white dark:bg-[#163024] text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800 hover:bg-[#D4AF37] hover:text-stone-950 transition-all active:scale-95 shadow-2xs"
                      >
                        +1
                      </button>
                      <button
                        onClick={() => handleIncrementGoal(goal.id, 10)}
                        className="px-2.5 py-1 rounded-xl text-xs font-black bg-white dark:bg-[#163024] text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800 hover:bg-[#D4AF37] hover:text-stone-950 transition-all active:scale-95 shadow-2xs"
                      >
                        +10
                      </button>
                      <button
                        onClick={() => handleIncrementGoal(goal.id, 100)}
                        className="px-2.5 py-1 rounded-xl text-xs font-black bg-white dark:bg-[#163024] text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800 hover:bg-[#D4AF37] hover:text-stone-950 transition-all active:scale-95 shadow-2xs"
                      >
                        +100
                      </button>
                      <button
                        onClick={() => {
                          setCustomIncGoalId(goal.id);
                        }}
                        className="px-2.5 py-1 rounded-xl text-xs font-black bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:text-stone-900 transition-all"
                      >
                        +Custom
                      </button>
                    </div>

                    <button
                      onClick={() => handleIncrementGoal(goal.id, -1)}
                      className="text-[11px] font-bold text-stone-400 hover:text-stone-600 transition-colors"
                    >
                      Undo -1
                    </button>
                  </div>

                  {/* Inline Custom Increment Box */}
                  {customIncGoalId === goal.id && (
                    <div className="mt-2 p-2 rounded-xl bg-white dark:bg-[#163024] border border-[#D4AF37]/50 flex items-center gap-2">
                      <input
                        type="number"
                        value={customIncAmount}
                        onChange={(e) => setCustomIncAmount(Number(e.target.value))}
                        className="w-24 px-2 py-1 text-xs rounded border border-stone-300 dark:border-stone-700 bg-transparent text-stone-900 dark:text-stone-100 font-mono"
                        placeholder="Amount"
                      />
                      <button
                        onClick={() => {
                          if (customIncAmount > 0) {
                            handleIncrementGoal(goal.id, customIncAmount);
                            setCustomIncGoalId(null);
                          }
                        }}
                        className="px-3 py-1 rounded text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F]"
                      >
                        Add
                      </button>
                      <button
                        onClick={() => setCustomIncGoalId(null)}
                        className="p-1 text-stone-400 hover:text-stone-600"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 3. MONTHLY STREAK GRID: 30-day interactive calendar dots */}
      <div
        id="card-monthly-streak-grid"
        className={`rounded-[20px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-[#D4AF37]">
              <Flame className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'মাসিক ইস্তিকামাত স্ট্রিক' : 'Monthly Istiqamah Streak'}
              </h3>
              <p className="text-[11px] text-stone-400 font-medium">
                {language === 'bn'
                  ? '৩০ দিনের আমল পর্যালোচনা মেট্রিক্স'
                  : '30-Day Activity Matrix (Starts fresh Day 1)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-extrabold text-[#1B4332] dark:text-[#74C69D] px-2.5 py-1 rounded-full bg-[#E8F5E9] dark:bg-[#1E3E30] border border-emerald-200 dark:border-emerald-800">
            <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{language === 'bn' ? '১ম দিন সক্রিয়' : 'Day 1 Active'}</span>
          </div>
        </div>

        {/* 30-Day Grid */}
        <div className="grid grid-cols-6 gap-2 my-2">
          {INITIAL_MONTH_DAYS.map((item) => {
            const isSelected = selectedDay.day === item.day;
            const statusClass = getStatusColor(item.status);

            return (
              <button
                key={item.day}
                id={`streak-day-${item.day}`}
                onClick={() => setSelectedDay(item)}
                className={`h-9 rounded-[14px] flex flex-col items-center justify-center text-xs font-black transition-transform active:scale-95 border ${statusClass} ${
                  isSelected ? 'scale-110 shadow-md ring-2 ring-offset-1 ring-[#D4AF37]' : ''
                }`}
              >
                <span>{item.day}</span>
              </button>
            );
          })}
        </div>

        {/* Selected Day Status Inspector */}
        <div className="mt-3.5 p-3.5 rounded-[16px] bg-[#E8F5E9]/70 dark:bg-[#12281E] border border-[#D4AF37]/30 flex items-center justify-between">
          <div>
            <span className="text-xs font-extrabold text-stone-900 dark:text-stone-100">
              {selectedDay.dateStr}:{' '}
              {selectedDay.status === 'completed'
                ? (language === 'bn' ? 'সম্পূর্ণ' : 'COMPLETED')
                : selectedDay.status === 'partial'
                ? (language === 'bn' ? 'আংশিক' : 'PARTIAL')
                : selectedDay.status === 'today'
                ? (language === 'bn' ? 'আজ' : 'TODAY')
                : selectedDay.status === 'future'
                ? (language === 'bn' ? 'আসন্ন' : 'UPCOMING')
                : (language === 'bn' ? 'অনুপস্থিত' : 'MISSED')}
            </span>
            <div className="text-[11px] text-stone-600 dark:text-stone-400 font-medium mt-0.5">
              {language === 'bn'
                ? `আমল স্কোর: ${selectedDay.score}% • ৫ ওয়াক্ত সালাত ও যিকিরের লগ`
                : `Score: ${selectedDay.score}% • Daily obligatory Salats and Adhkar recorded`}
            </div>
          </div>
          <span className="text-sm font-black text-[#1B4332] dark:text-[#74C69D] font-mono">
            {selectedDay.score}%
          </span>
        </div>

        {/* Legend */}
        <div className="mt-3 flex items-center justify-center gap-4 text-[10px] font-bold text-stone-500 dark:text-stone-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#1B4332]" />{' '}
            {language === 'bn' ? 'সম্পূর্ণ' : 'Completed'}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D4AF37]" />{' '}
            {language === 'bn' ? 'আংশিক' : 'Partial'}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />{' '}
            {language === 'bn' ? 'বাকি' : 'Missed'}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#74C69D]" />{' '}
            {language === 'bn' ? 'আজকের দিন' : 'Today'}
          </span>
        </div>
      </div>

      {/* 4. PREDEFINED LONG-TERM ACHIEVEMENT BADGES (Starts at zero progress) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3
              className={`text-xs font-black uppercase tracking-wider ${
                darkMode ? 'text-stone-300' : 'text-[#1B4332]'
              }`}
            >
              {language === 'bn' ? 'দীর্ঘমেয়াদী অর্জন ও স্মারক' : 'Long-Term Achievements'}
            </h3>
            <p className="text-[10px] text-stone-400 font-semibold">
              {language === 'bn'
                ? '২ মাসের সালাত ধারাবাহিকতা, সিয়াম, ১০০ আয়াত, তাহাজ্জুদ ও সদকা'
                : '2-month Salat streak, 5 Fardh fasts, 100 Ayah, Tahajjud & Sadaqah'}
            </p>
          </div>
          <span className="text-[11px] font-semibold text-stone-400">
            {language === 'bn' ? 'ব্যাজে স্পর্শ করে দেখুন' : 'Tap badge to inspect'}
          </span>
        </div>

        <div className="space-y-2.5">
          {achievements.map((badge) => {
            const getBadgeIcon = () => {
              switch (badge.iconName) {
                case 'BookOpen':
                  return <BookOpen className="w-5 h-5 text-[#1B4332] dark:text-[#74C69D]" />;
                case 'Flame':
                  return <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />;
                case 'Sparkles':
                  return <Sparkles className="w-5 h-5 text-[#D4AF37] fill-[#D4AF37]" />;
                case 'Moon':
                  return <Moon className="w-5 h-5 text-indigo-400" />;
                case 'HeartHandshake':
                  return <HeartHandshake className="w-5 h-5 text-rose-500" />;
                default:
                  return <Award className="w-5 h-5 text-[#D4AF37]" />;
              }
            };

            const percent = Math.min(
              100,
              Math.round((badge.progress / (badge.maxProgress || 1)) * 100)
            );

            return (
              <div
                key={badge.id}
                id={`badge-item-${badge.id}`}
                onClick={() => setSelectedBadge(badge)}
                className={`cursor-pointer w-full text-left p-4 rounded-[20px] border flex flex-col gap-2 transition-all duration-200 active:scale-[0.99] ${
                  badge.unlocked
                    ? darkMode
                      ? 'bg-[#183326] border-[#D4AF37]/50 shadow-[0_4px_16px_rgba(0,0,0,0.2)]'
                      : 'bg-white border-emerald-900/10 shadow-[0_6px_20px_rgba(27,67,50,0.05)] ring-1 ring-black/5 hover:border-[#D4AF37]/50'
                    : darkMode
                    ? 'bg-[#12281E]/80 border-[#1C3B2E]'
                    : 'bg-white border-stone-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div
                      className={`p-2.5 rounded-2xl ${
                        badge.unlocked
                          ? 'bg-[#E8F5E9] dark:bg-[#1E3E30] border border-[#D4AF37]/40'
                          : 'bg-stone-100 dark:bg-stone-800'
                      }`}
                    >
                      {getBadgeIcon()}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-stone-900 dark:text-stone-100 tracking-tight">
                          {badge.title}
                        </span>
                        {badge.unlocked ? (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#D4AF37]">
                            Unlocked
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400">
                            {badge.progress}/{badge.maxProgress}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-stone-500 dark:text-stone-400 mt-0.5 font-medium">
                        {badge.desc}
                      </div>
                    </div>
                  </div>

                  <div>
                    {badge.unlocked ? (
                      <Award className="w-5 h-5 text-[#D4AF37] fill-[#D4AF37]/20" />
                    ) : (
                      <Lock className="w-4 h-4 text-stone-400" />
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-stone-200 dark:bg-stone-800 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full bg-gradient-to-r from-[#2D6A4F] to-[#D4AF37] transition-all"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MODAL: Add Custom Goal */}
      {showAddGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div
            className={`w-full max-w-md rounded-[24px] p-6 border shadow-2xl animate-in zoom-in-95 duration-150 ${
              darkMode
                ? 'bg-[#152E22] border-[#2E5E47] text-white'
                : 'bg-white border-emerald-200 text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="text-base font-extrabold">
                  {language === 'bn' ? 'নতুন ব্যক্তিগত লক্ষ্য যোগ করুন' : 'Create New Custom Goal'}
                </h3>
              </div>
              <button
                onClick={() => setShowAddGoalModal(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddCustomGoal} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-stone-600 dark:text-stone-300 mb-1">
                  {language === 'bn' ? 'লক্ষ্যের শিরোনাম / নাম' : 'Goal Title / Name'}
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder={
                    language === 'bn'
                      ? 'যেমন: ১০,০০০ বার ইস্তিগফার পাঠ'
                      : 'e.g. 10,000 Astaghfirullah Recitations'
                  }
                  className="w-full px-3 py-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-[#12241B] text-stone-900 dark:text-stone-100 font-medium"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-300 mb-1">
                    {language === 'bn' ? 'টার্গেট সংখ্যা' : 'Target Target (Count)'}
                  </label>
                  <input
                    type="number"
                    value={newTarget}
                    onChange={(e) => setNewTarget(Number(e.target.value))}
                    min="1"
                    className="w-full px-3 py-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-[#12241B] text-stone-900 dark:text-stone-100 font-mono font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-300 mb-1">
                    {language === 'bn' ? 'পরিমাপের একক' : 'Unit of Measurement'}
                  </label>
                  <select
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-[#12241B] text-stone-900 dark:text-stone-100 font-medium"
                  >
                    <option value="Times">{language === 'bn' ? 'বার' : 'Times'}</option>
                    <option value="Ayahs">{language === 'bn' ? 'আয়াত' : 'Ayahs'}</option>
                    <option value="Days">{language === 'bn' ? 'দিন' : 'Days'}</option>
                    <option value="BDT">{language === 'bn' ? 'টাকা' : 'BDT'}</option>
                    <option value="Pages">{language === 'bn' ? 'পৃষ্ঠা' : 'Pages'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-600 dark:text-stone-300 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Dhikr', 'Quran', 'Salat', 'Charity', 'Habit', 'Custom'] as const).map(
                    (cat) => (
                      <button
                        type="button"
                        key={cat}
                        onClick={() => setNewCategory(cat)}
                        className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all ${
                          newCategory === cat
                            ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950 shadow-xs'
                            : 'bg-stone-100 dark:bg-[#163024] text-stone-600 dark:text-stone-300'
                        }`}
                      >
                        {cat === 'Dhikr'
                          ? (language === 'bn' ? 'যিকির' : 'Dhikr')
                          : cat === 'Quran'
                          ? (language === 'bn' ? 'কুরআন' : 'Quran')
                          : cat === 'Salat'
                          ? (language === 'bn' ? 'সালাত' : 'Salat')
                          : cat === 'Charity'
                          ? (language === 'bn' ? 'সদকা' : 'Charity')
                          : cat === 'Habit'
                          ? (language === 'bn' ? 'অভ্যাস' : 'Habit')
                          : (language === 'bn' ? 'অন্যান্য' : 'Custom')}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddGoalModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-stone-500 hover:text-stone-700"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-extrabold bg-[#2D6A4F] text-white hover:bg-[#1B4332] shadow-sm"
                >
                  {language === 'bn' ? 'লক্ষ্য সংরক্ষণ' : 'Create Goal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Badge Details Modal Dialog */}
      {selectedBadge && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div
            className={`w-full max-w-sm rounded-[24px] p-6 text-center border shadow-2xl animate-in zoom-in-95 duration-150 ${
              darkMode
                ? 'bg-[#183326] border-[#224735] text-white'
                : 'bg-white border-emerald-100 text-stone-900'
            }`}
          >
            <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center bg-amber-50 dark:bg-amber-950/50 mb-3 border-2 border-[#D4AF37]">
              <Award className="w-8 h-8 text-[#D4AF37]" />
            </div>

            <h3 className="text-lg font-extrabold">{selectedBadge.title}</h3>
            <p className="text-xs text-stone-500 dark:text-stone-300 mt-1">{selectedBadge.desc}</p>

            <div className="my-4 p-3 rounded-xl bg-emerald-50/70 dark:bg-[#12281E] text-xs">
              <div className="font-bold">
                {language === 'bn' ? 'বর্তমান অগ্রগতি:' : 'Current Progress:'} {selectedBadge.progress} / {selectedBadge.maxProgress}
              </div>
              {selectedBadge.dateUnlocked && (
                <div className="text-emerald-700 dark:text-emerald-300 font-semibold mt-1">
                  {language === 'bn' ? 'অর্জিত হয়েছে:' : 'Achieved:'} {selectedBadge.dateUnlocked}
                </div>
              )}
            </div>

            {/* Quick Increment towards milestone */}
            {!selectedBadge.unlocked && (
              <div className="mb-4 pt-2 border-t border-emerald-100 dark:border-[#224735] flex items-center justify-center gap-2">
                <button
                  onClick={() => handleIncrementAchievement(selectedBadge.id, 1)}
                  className="px-3 py-1.5 rounded-xl text-xs font-black bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D] hover:bg-[#D4AF37] hover:text-stone-950 transition-all"
                >
                  {language === 'bn' ? '+১ ব্যাজ অগ্রগতি যোগ' : 'Log +1 Toward Badge'}
                </button>
              </div>
            )}

            <button
              onClick={() => setSelectedBadge(null)}
              className="w-full py-2.5 rounded-xl text-xs font-bold bg-[#2D6A4F] text-white hover:bg-[#23533E]"
            >
              {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
