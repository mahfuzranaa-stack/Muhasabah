import React, { useState } from 'react';
import {
  X,
  Calendar,
  Sparkles,
  Clock,
  Plus,
  Trash2,
  Moon,
  Flag,
  Globe,
  Check,
  Award,
  RotateCcw,
} from 'lucide-react';
import { ObservanceDay } from '../types';

interface NextImportantDayModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  days: ObservanceDay[];
  onAddDay: (day: Omit<ObservanceDay, 'id'>) => void;
  onDeleteDay: (id: string) => void;
  onResetDays?: () => void;
}

export function formatStrictCountdown(targetDateStr: string): {
  label: string;
  daysRemaining: number;
  isToday: boolean;
  isPassed: boolean;
} {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const [y, m, d] = targetDateStr.split('-').map(Number);
  const target = new Date(y, m - 1, d);

  const diffMs = target.getTime() - today.getTime();
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    return { label: 'Today', daysRemaining: 0, isToday: true, isPassed: false };
  }
  if (diffDays < 0) {
    return { label: 'Passed', daysRemaining: diffDays, isToday: false, isPassed: true };
  }

  // Calculate calendar months and days
  let months =
    target.getMonth() - today.getMonth() + (target.getFullYear() - today.getFullYear()) * 12;
  let days = target.getDate() - today.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonthDays = new Date(target.getFullYear(), target.getMonth(), 0).getDate();
    days += prevMonthDays;
  }

  // User Strict Rule:
  // If > 1 month remaining (months >= 1 and diffDays > 31): show "Months & Days Left"
  // If ~1 month or < 1 month remaining: show ONLY "Days Left" (e.g. "25 Days Left", never "0 Months 25 Days Left")
  if (months >= 1 && diffDays > 31) {
    return {
      label: `${months} ${months === 1 ? 'Month' : 'Months'} & ${days} ${
        days === 1 ? 'Day' : 'Days'
      } Left`,
      daysRemaining: diffDays,
      isToday: false,
      isPassed: false,
    };
  } else {
    return {
      label: `${diffDays} ${diffDays === 1 ? 'Day' : 'Days'} Left`,
      daysRemaining: diffDays,
      isToday: false,
      isPassed: false,
    };
  }
}

export const NextImportantDayModal: React.FC<NextImportantDayModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  days,
  onAddDay,
  onDeleteDay,
  onResetDays,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [date, setDate] = useState('');
  const [category, setCategory] = useState<ObservanceDay['category']>('Islamic');
  const [description, setDescription] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date) return;

    onAddDay({
      title: title.trim(),
      titleBn: titleBn.trim() || title.trim(),
      date,
      category,
      description: description.trim() || 'Important observance day',
    });

    setIsAdding(false);
    setTitle('');
    setTitleBn('');
    setDate('');
    setDescription('');
  };

  // Sort upcoming observance days from nearest to furthest
  const processedDays = days
    .map((d) => ({
      ...d,
      countdown: formatStrictCountdown(d.date),
    }))
    .filter((d) => !d.countdown.isPassed || d.countdown.isToday)
    .filter((d) => filterCategory === 'All' || d.category === filterCategory)
    .sort((a, b) => a.countdown.daysRemaining - b.countdown.daysRemaining);

  const nearestDay = processedDays[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[90vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header with Deep Emerald Gradient */}
        <div className="p-4 border-b border-emerald-100/60 dark:border-[#254F3E] flex items-center justify-between bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#D4AF37] text-stone-950 shadow-md">
              <Calendar className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Next Important Day
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 text-[#FFF9E6] font-bold">
                  Countdown
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Islamic milestones, national holidays &amp; personal celebrations
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {onResetDays && <button onClick={() => { if (window.confirm('সব গুরুত্বপূর্ণ দিনের রেকর্ড রিসেট করবেন?')) onResetDays(); }} title="Reset dates" className="p-2 rounded-xl hover:bg-white/10 text-rose-200 transition-all"><RotateCcw className="w-4 h-4" /></button>}
            <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
          </div>
        </div>

        {/* Scrollable Container */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {/* Nearest Highlight Banner */}
          {nearestDay && (
            <div
              className={`rounded-2xl p-4.5 border relative overflow-hidden transition-all shadow-md ${
                darkMode
                  ? 'bg-gradient-to-br from-[#0F261C] to-[#1B4332] border-[#D4AF37]/40 text-white'
                  : 'bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] border-[#D4AF37]/40 text-white'
              }`}
            >
              <div className="flex items-center justify-between gap-2 relative z-10">
                <div>
                  <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-black/30 text-[#F4E0A5] border border-[#D4AF37]/30">
                    <Clock className="w-3 h-3 text-[#D4AF37]" />
                    Nearest Upcoming Event
                  </span>
                  <h4 className="text-lg font-black text-white mt-1.5 leading-snug">
                    {nearestDay.title}
                  </h4>
                  <div className="text-xs text-[#D4AF37] font-bold">
                    {nearestDay.titleBn}
                  </div>
                  <p className="text-[11px] text-emerald-100/80 mt-1 max-w-xs">
                    {nearestDay.description}
                  </p>
                </div>

                <div className="text-right shrink-0 bg-black/25 p-3 rounded-2xl border border-[#D4AF37]/30 backdrop-blur-xs">
                  <div
                    className={`text-xl font-black font-mono tracking-tight ${
                      nearestDay.countdown.isToday ? 'text-amber-300 animate-pulse' : 'text-white'
                    }`}
                  >
                    {nearestDay.countdown.label}
                  </div>
                  <div className="text-[10px] text-emerald-200/90 font-medium mt-0.5">
                    {nearestDay.date}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Filter & Add Button */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {['All', 'Islamic', 'National', 'International'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilterCategory(cat)}
                  className={`px-3 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all ${
                    filterCategory === cat
                      ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                      : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 transition-all shadow-xs shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAdding ? 'Close' : 'Add Event'}</span>
            </button>
          </div>

          {/* Add Event Form */}
          {isAdding && (
            <form
              onSubmit={handleSave}
              className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#E8F5E9]/50 dark:bg-[#163024] space-y-2.5 animate-in fade-in"
            >
              <div className="text-xs font-black text-[#1B4332] dark:text-[#F4E0A5] uppercase tracking-wider">
                Add Custom Important Date
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Event Title (English)</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Ramadan 1st, Exam Date"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Bengali Name</label>
                  <input
                    type="text"
                    value={titleBn}
                    onChange={(e) => setTitleBn(e.target.value)}
                    placeholder="e.g. রমজানুল মুবারক"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Target Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ObservanceDay['category'])}
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  >
                    <option value="Islamic">Islamic Milestone</option>
                    <option value="National">National Holiday</option>
                    <option value="International">International</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-stone-500">Short Significance</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Fasting, Taraweeh and Quran tilawat"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-500 hover:text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] shadow-sm flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  Save Event
                </button>
              </div>
            </form>
          )}

          {/* List of Observances */}
          <div className="space-y-2">
            {processedDays.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 shadow-xs ${
                  item.countdown.isToday
                    ? 'bg-amber-50 dark:bg-[#2A2310] border-[#D4AF37]'
                    : darkMode
                    ? 'bg-[#142B20] border-[#1C3B2E]'
                    : 'bg-white border-stone-200/80'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-[#1B4332] dark:text-[#74C69D] flex items-center justify-center font-bold text-sm shrink-0">
                    {item.category === 'Islamic' ? (
                      <Moon className="w-4 h-4 text-emerald-700 dark:text-[#74C69D]" />
                    ) : (
                      <Flag className="w-4 h-4 text-[#D4AF37]" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="font-black text-xs text-stone-900 dark:text-stone-100 truncate">
                      {item.title}
                    </div>
                    <div className="text-[11px] font-bold text-[#1B4332] dark:text-[#74C69D] truncate">
                      {item.titleBn}
                    </div>
                    <p className="text-[10px] text-stone-400 truncate mt-0.5">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Right Countdown strictly formatted */}
                <div className="text-right shrink-0 flex items-center gap-2">
                  <div>
                    <div
                      className={`text-xs font-black font-mono tracking-tight ${
                        item.countdown.isToday
                          ? 'text-amber-600 dark:text-amber-300 font-extrabold'
                          : 'text-[#1B4332] dark:text-[#74C69D]'
                      }`}
                    >
                      {item.countdown.label}
                    </div>
                    <span className="text-[10px] text-stone-400 block font-mono">
                      {item.date}
                    </span>
                  </div>

                  {deleteConfirmId === item.id ? (
                    <button
                      onClick={() => {
                        onDeleteDay(item.id);
                        setDeleteConfirmId(null);
                      }}
                      className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-600 text-white animate-pulse"
                    >
                      Confirm?
                    </button>
                  ) : (
                    <button
                      onClick={() => setDeleteConfirmId(item.id)}
                      className="p-1 rounded text-stone-400 hover:text-red-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] text-center text-[11px] text-stone-500">
          Strict Countdown Display: &gt; 1 Month shows &quot;Months &amp; Days Left&quot;, &le; 1 Month shows &quot;Days Left&quot;.
        </div>
      </div>
    </div>
  );
};
