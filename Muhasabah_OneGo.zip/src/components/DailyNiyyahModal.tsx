import React, { useState, useEffect } from 'react';
import {
  X,
  Compass,
  Check,
  Calendar,
  Sparkles,
  Award,
  Sun,
  Moon,
  TrendingUp,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Circle,
  BarChart3,
} from 'lucide-react';
import { DailyNiyyahRecord } from '../types';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface DailyNiyyahModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
  onNiyyahUpdated?: () => void;
}

const INITIAL_NIYYAHS: DailyNiyyahRecord[] = [
  {
    id: 'niyyah-1',
    date: new Date().toISOString().split('T')[0],
    intentionText: 'আজকের কাজগুলো সততা ও নিষ্ঠার সাথে সম্পাদন করব যেন তা হালাল উপার্জনের মাধ্যম হয়।',
    category: 'Work/Halal Earning',
    morningConfirmed: true,
    eveningFulfilled: true,
    completed: true,
  },
  {
    id: 'niyyah-2',
    date: new Date().toISOString().split('T')[0],
    intentionText: 'পিতা-মাতার সাথে হাসিমুখে কথা বলব ও তাদের বিশেষ সেবা করব।',
    category: 'Family/Parents',
    morningConfirmed: true,
    eveningFulfilled: false,
    completed: false,
  },
  {
    id: 'niyyah-3',
    date: new Date().toISOString().split('T')[0],
    intentionText: 'প্রতিটি সালাত প্রথম ওয়াক্তে আদায়ের চেষ্টা করব এবং একাগ্রতা বজায় রাখব।',
    category: 'Worship',
    morningConfirmed: true,
    eveningFulfilled: true,
    completed: true,
  },
];

const NIYYAH_CATEGORIES: DailyNiyyahRecord['category'][] = [
  'Worship',
  'Work/Halal Earning',
  'Family/Parents',
  'Knowledge',
  'Character',
];

const CATEGORY_BN: Record<DailyNiyyahRecord['category'], string> = {
  'Worship': 'ইবাদত ও সালাত',
  'Work/Halal Earning': 'হালাল উপার্জন',
  'Family/Parents': 'পরিবার সেবা',
  'Knowledge': 'ইলম ও জ্ঞান',
  'Character': 'চরিত্র ও আখলাক',
};

export const DailyNiyyahModal: React.FC<DailyNiyyahModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
  onNiyyahUpdated,
}) => {
  const [niyyahs, setNiyyahs] = useState<DailyNiyyahRecord[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_daily_niyyah_records');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_NIYYAHS;
  });

  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [intentionText, setIntentionText] = useState('');
  const [category, setCategory] = useState<DailyNiyyahRecord['category']>('Worship');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_daily_niyyah_records', JSON.stringify(niyyahs));
    } catch {
      // ignore
    }
  }, [niyyahs]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleSaveNiyyah = (e: React.FormEvent) => {
    e.preventDefault();
    if (!intentionText.trim()) {
      showToast('অনুগ্রহ করে নিয়তের বিবরণ লিখুন');
      return;
    }

    playNotificationTone(soundEnabled);

    if (editingId) {
      setNiyyahs((prev) =>
        prev.map((n) =>
          n.id === editingId
            ? {
                ...n,
                intentionText: intentionText.trim(),
                category,
                date: selectedDate,
              }
            : n
        )
      );
      setEditingId(null);
      showToast('নিয়ত সফলভাবে আপডেট হয়েছে');
    } else {
      // Create a brand new distinct Niyyah record — MULTIPLE ALLOWED PER DAY
      const newItem: DailyNiyyahRecord = {
        id: 'niyyah-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
        date: selectedDate,
        intentionText: intentionText.trim(),
        category,
        morningConfirmed: true,
        eveningFulfilled: false,
        completed: false,
      };
      setNiyyahs((prev) => [newItem, ...prev]);
      showToast('নতুন নিয়ত সফলভাবে যুক্ত হয়েছে!');
    }

    if (onNiyyahUpdated) {
      onNiyyahUpdated();
    }
    setIntentionText('');
  };

  const handleToggleCompleted = (id: string) => {
    playDhikrClick(soundEnabled);
    setNiyyahs((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const nextVal = !n.eveningFulfilled;
          return { ...n, eveningFulfilled: nextVal, completed: nextVal };
        }
        return n;
      })
    );
    if (onNiyyahUpdated) {
      onNiyyahUpdated();
    }
  };

  const handleEdit = (n: DailyNiyyahRecord) => {
    setEditingId(n.id);
    setIntentionText(n.intentionText);
    setCategory(n.category);
    setSelectedDate(n.date);
  };

  const handleDelete = (id: string) => {
    setNiyyahs((prev) => prev.filter((n) => n.id !== id));
    setDeleteConfirmId(null);
    showToast('নিয়ত মুছে ফেলা হয়েছে');
    if (onNiyyahUpdated) {
      onNiyyahUpdated();
    }
  };

  // Filter niyyahs for selected date
  const filteredNiyyahs = niyyahs.filter((n) => n.date === selectedDate);
  const totalCount = filteredNiyyahs.length;
  const completedCount = filteredNiyyahs.filter((n) => n.eveningFulfilled || n.completed).length;
  const incompleteCount = totalCount - completedCount;
  const completionPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const incompletePercent = totalCount > 0 ? 100 - completionPercent : 0;

  return (
    <div
      id="modal-daily-niyyah"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-xl rounded-[28px] border shadow-2xl flex flex-col max-h-[94vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-500 flex items-center justify-center font-black shadow-xs">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Daily Niyyah System</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  নিয়ত ও সংকল্প
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                &ldquo;নিশ্চয়ই সমস্ত আমল নিয়তের ওপর নির্ভরশীল&rdquo; (সহিহ বুখারি: ১)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="p-2.5 bg-indigo-600 text-white text-xs font-bold text-center animate-in fade-in">
            {toastMsg}
          </div>
        )}

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Date Picker Header */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-500" />
              <span className="text-xs font-black text-stone-700 dark:text-stone-300">
                তারিখ নির্বাচন:
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSelectedDate(todayStr)}
                className={`px-2 py-1 rounded-lg text-[11px] font-bold ${
                  selectedDate === todayStr
                    ? 'bg-indigo-600 text-white'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-500'
                }`}
              >
                আজ
              </button>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className={`text-xs px-2.5 py-1 rounded-xl border font-semibold ${
                  darkMode
                    ? 'bg-[#163324] border-[#224C38] text-stone-200'
                    : 'bg-stone-50 border-stone-200 text-stone-800'
                }`}
              />
            </div>
          </div>

          {/* DAILY ANALYSIS CARD */}
          <div
            id="card-daily-niyyah-analysis"
            className={`p-4 rounded-2xl border transition-all ${
              darkMode
                ? 'bg-gradient-to-br from-[#12241B] to-[#152F23] border-[#1E4332]'
                : 'bg-gradient-to-br from-indigo-50/60 to-emerald-50/60 border-indigo-100'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-indigo-500" />
                <h4 className="text-xs font-black uppercase tracking-wider text-stone-800 dark:text-stone-200">
                  দৈনিক বিশ্লেষণ (Daily Analysis Card)
                </h4>
              </div>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                {selectedDate === todayStr ? 'আজকের অগ্রগতি' : selectedDate}
              </span>
            </div>

            {/* Metric Counters Grid */}
            <div className="grid grid-cols-3 gap-2.5 mb-3 text-center">
              <div className="p-2.5 rounded-xl bg-white/70 dark:bg-[#0E2017]/80 border border-stone-200 dark:border-[#1E4332]">
                <span className="text-[10px] text-stone-400 font-bold block">মোট নিয়ত</span>
                <span className="text-base font-black text-stone-900 dark:text-stone-100 font-mono">
                  {totalCount}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60">
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block">
                  অর্জিত (Completed)
                </span>
                <span className="text-base font-black text-emerald-600 dark:text-emerald-400 font-mono">
                  {completedCount} <span className="text-[11px]">({completionPercent}%)</span>
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60">
                <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold block">
                  বাকি (Incomplete)
                </span>
                <span className="text-base font-black text-amber-600 dark:text-amber-400 font-mono">
                  {incompleteCount} <span className="text-[11px]">({incompletePercent}%)</span>
                </span>
              </div>
            </div>

            {/* Visual Dual Progress Bar */}
            <div className="space-y-1">
              <div className="h-2.5 w-full rounded-full bg-stone-200 dark:bg-stone-800 overflow-hidden flex">
                <div
                  className="bg-emerald-500 transition-all duration-300 h-full"
                  style={{ width: `${completionPercent}%` }}
                />
                <div
                  className="bg-amber-400 transition-all duration-300 h-full"
                  style={{ width: `${incompletePercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] font-bold text-stone-500 dark:text-stone-400 pt-0.5">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                  অর্জিত: {completionPercent}%
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
                  বাকি: {incompletePercent}%
                </span>
              </div>
            </div>
          </div>

          {/* Add / Edit Niyyah Form */}
          <form
            onSubmit={handleSaveNiyyah}
            className={`p-4 rounded-2xl border space-y-3 ${
              darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                {editingId ? 'নিয়ত সম্পাদনা করুন' : 'নতুন নিয়ত বা সংকল্প যোগ করুন'}
              </span>
              {editingId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(null);
                    setIntentionText('');
                  }}
                  className="text-[10px] text-stone-400 hover:text-stone-600 underline"
                >
                  বাতিল
                </button>
              )}
            </div>

            {/* Category Pills */}
            <div className="flex flex-wrap gap-1.5">
              {NIYYAH_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                    category === cat
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {CATEGORY_BN[cat]}
                </button>
              ))}
            </div>

            <textarea
              rows={2}
              value={intentionText}
              onChange={(e) => setIntentionText(e.target.value)}
              placeholder="আমার নিয়ত এই যে, আমি আল্লাহ তায়ালার সন্তুষ্টির উদ্দেশ্যে..."
              className={`w-full p-3 rounded-xl border text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden ${
                darkMode
                  ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                  : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
              }`}
            />

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              {editingId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              <span>{editingId ? 'নিয়ত আপডেট করুন' : 'নিয়ত যুক্ত করুন (Add Niyyah)'}</span>
            </button>
          </form>

          {/* List of Niyyahs for Selected Date */}
          <div className="space-y-2 pt-1">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400 flex items-center justify-between">
              <span>{selectedDate} এর নিয়তসমূহ ({filteredNiyyahs.length})</span>
              <span className="text-[10px] text-indigo-500 font-bold">
                ক্লিক করে সম্পন্ন মার্ক করুন
              </span>
            </h4>

            {filteredNiyyahs.length === 0 ? (
              <div className="text-center py-6 border border-dashed rounded-2xl border-stone-200 dark:border-stone-800">
                <Compass className="w-6 h-6 mx-auto mb-1 text-stone-400" />
                <p className="text-xs text-stone-400">
                  এই তারিখে এখনো কোনো নিয়ত যোগ করা হয়নি।
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredNiyyahs.map((item) => {
                  const isDone = item.eveningFulfilled || item.completed;
                  return (
                    <div
                      key={item.id}
                      className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                        isDone
                          ? 'bg-emerald-50/40 dark:bg-[#10241A] border-emerald-200/80 dark:border-emerald-900/50'
                          : darkMode
                          ? 'bg-[#12281E]/60 border-[#1E4332]'
                          : 'bg-white border-stone-200 shadow-xs'
                      }`}
                    >
                      {/* Checkbox */}
                      <button
                        type="button"
                        onClick={() => handleToggleCompleted(item.id)}
                        className="mt-0.5 text-emerald-600 dark:text-emerald-400 shrink-0 cursor-pointer"
                        title={isDone ? 'Mark as incomplete' : 'Mark as completed'}
                      >
                        {isDone ? (
                          <CheckCircle2 className="w-5 h-5 fill-emerald-100 dark:fill-emerald-950" />
                        ) : (
                          <Circle className="w-5 h-5 text-stone-300 dark:text-stone-600 hover:text-emerald-500" />
                        )}
                      </button>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                            {CATEGORY_BN[item.category] || item.category}
                          </span>
                          {isDone && (
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                              ✓ অর্জিত
                            </span>
                          )}
                        </div>
                        <p
                          className={`text-xs leading-relaxed font-medium ${
                            isDone
                              ? 'line-through text-stone-400 dark:text-stone-500'
                              : 'text-stone-800 dark:text-stone-200'
                          }`}
                        >
                          {item.intentionText}
                        </p>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleEdit(item)}
                          className="p-1 text-stone-400 hover:text-indigo-500 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {deleteConfirmId === item.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleDelete(item.id)}
                              className="px-2 py-0.5 rounded text-[10px] font-black bg-rose-600 text-white"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-1.5 py-0.5 rounded text-[10px] text-stone-400"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(item.id)}
                            className="p-1 text-stone-400 hover:text-rose-500 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
