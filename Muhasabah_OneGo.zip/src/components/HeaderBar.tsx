import React, { useState, useEffect } from 'react';
import {
  CloudSun,
  PlusCircle,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Quote,
  Settings as SettingsIcon,
  RefreshCw,
} from 'lucide-react';
import { InspiringQuote, WeatherInfo } from '../types';
import { INITIAL_WEATHER } from '../data/initialData';
import { EXPANDED_ISLAMIC_QUOTES, getNextRotatedQuoteIndex } from '../data/islamicQuotesData';
import { getBengaliDate, getHijriDate } from '../utils/qibla';
import { useLanguage } from '../utils/i18n';

interface HeaderBarProps {
  darkMode: boolean;
  onOpenMyDay: () => void;
  onOpenSettings?: () => void;
  onUpdateLocation?: () => void;
  isUpdatingLocation?: boolean;
  locationName?: string;
  latitude?: number;
  longitude?: number;
  onRefreshTimeFeatures?: () => void;
  timeRefreshKey?: number;
  hijriAdjustment?: number;
  weather?: WeatherInfo;
  quotes?: InspiringQuote[];
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  darkMode,
  onOpenMyDay,
  onOpenSettings,
  onUpdateLocation,
  isUpdatingLocation = false,
  locationName = 'Dhaka, Bangladesh',
  latitude = 23.8103,
  longitude = 90.4125,
  onRefreshTimeFeatures,
  timeRefreshKey = 0,
  hijriAdjustment = 0,
  weather = INITIAL_WEATHER,
  quotes = EXPANDED_ISLAMIC_QUOTES,
}) => {
  const { language } = useLanguage();
  const [liveWeather, setLiveWeather] = useState<WeatherInfo>(weather);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [timeStr, setTimeStr] = useState('');
  const allQuotes = quotes && quotes.length > 0 ? quotes : EXPANDED_ISLAMIC_QUOTES;
  const [currentQuoteIdx, setCurrentQuoteIdx] = useState(() => {
    return getNextRotatedQuoteIndex(allQuotes.length);
  });
  const [isPaused, setIsPaused] = useState(false);

  // Live weather: Open-Meteo requires no API key and updates whenever location/time refreshes.
  useEffect(() => {
    let cancelled = false;
    const fetchWeather = async () => {
      if (!navigator.onLine) return;
      setWeatherLoading(true);
      try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(latitude)}&longitude=${encodeURIComponent(longitude)}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto`;
        const response = await fetch(url, { cache: 'no-store' });
        if (!response.ok) throw new Error('Weather request failed');
        const data = await response.json();
        const code = Number(data?.current?.weather_code ?? 0);
        const labels: Record<number, [string, string]> = {
          0: ['Clear sky', 'পরিষ্কার আকাশ'], 1: ['Mainly clear', 'মূলত পরিষ্কার'], 2: ['Partly cloudy', 'আংশিক মেঘলা'], 3: ['Overcast', 'মেঘাচ্ছন্ন'],
          45: ['Fog', 'কুয়াশা'], 48: ['Rime fog', 'কুয়াশা'], 51: ['Light drizzle', 'হালকা গুঁড়ি বৃষ্টি'], 53: ['Drizzle', 'গুঁড়ি বৃষ্টি'], 55: ['Heavy drizzle', 'ভারী গুঁড়ি বৃষ্টি'],
          61: ['Light rain', 'হালকা বৃষ্টি'], 63: ['Rain', 'বৃষ্টি'], 65: ['Heavy rain', 'ভারী বৃষ্টি'], 71: ['Light snow', 'হালকা তুষার'], 73: ['Snow', 'তুষারপাত'], 75: ['Heavy snow', 'ভারী তুষার'],
          80: ['Rain showers', 'বৃষ্টির ঝরনা'], 81: ['Rain showers', 'বৃষ্টির ঝরনা'], 82: ['Heavy rain showers', 'ভারী বৃষ্টির ঝরনা'], 95: ['Thunderstorm', 'বজ্রঝড়'], 96: ['Thunderstorm + hail', 'বজ্রঝড় ও শিলা'], 99: ['Thunderstorm + hail', 'বজ্রঝড় ও শিলা'],
        };
        const [condition, conditionBn] = labels[code] || ['Current weather', 'বর্তমান আবহাওয়া'];
        if (!cancelled) {
          setLiveWeather({
            temp: Math.round(Number(data.current?.temperature_2m ?? weather.temp)),
            condition, conditionBn,
            humidity: Math.round(Number(data.current?.relative_humidity_2m ?? weather.humidity)),
            windSpeed: Math.round(Number(data.current?.wind_speed_10m ?? weather.windSpeed)),
            airQuality: 'Live',
          });
        }
      } catch {
        // Keep the last known weather when offline/request fails.
      } finally {
        if (!cancelled) setWeatherLoading(false);
      }
    };
    fetchWeather();
    return () => { cancelled = true; };
  }, [latitude, longitude, timeRefreshKey]);

  // Live Digital Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12;
      setTimeStr(`${hours}:${minutes}:${seconds} ${ampm}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Auto-rotating inspiring quotes banner every 8 seconds
  useEffect(() => {
    if (isPaused || allQuotes.length === 0) return;
    const timer = setInterval(() => {
      setCurrentQuoteIdx((prev) => (prev + 1) % allQuotes.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [isPaused, allQuotes.length]);

  const activeQuote = allQuotes[currentQuoteIdx] || allQuotes[0];
  const bengaliDate = getBengaliDate(new Date());
  const hijriDate = getHijriDate(new Date(), hijriAdjustment);

  const handlePrevQuote = () => {
    setCurrentQuoteIdx((prev) => (prev - 1 + allQuotes.length) % allQuotes.length);
  };

  const handleNextQuote = () => {
    setCurrentQuoteIdx((prev) => (prev + 1) % allQuotes.length);
  };

  return (
    <header
      id="muhasabah-header-bar"
      className={`px-3 py-2 border-b transition-colors duration-200 ${
        darkMode
          ? 'bg-[#12281E] border-[#1C3B2E] text-[#E8F5E9]'
          : 'bg-white/95 border-emerald-100 text-stone-800 shadow-xs'
      }`}
    >
      {/* Top Utilities Row */}
      <div className="flex items-center justify-between gap-1.5 mb-2">
        {/* Left: App Title & + MY DAY button */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <img
              src="/assets/icon.png"
              alt="Muhasabah app logo"
              className="w-8 h-8 rounded-lg object-cover shadow-sm border border-[#D4AF37]/45 shrink-0"
            />
            <span className="font-black text-[18px] sm:text-xl tracking-[0.08em] uppercase whitespace-nowrap text-[#1B4332] dark:text-[#F4E0A5]">
              Muhasabah
            </span>
          </div>

          <button
            id="btn-open-my-day"
            onClick={onOpenMyDay}
            className="inline-flex items-center gap-0.5 px-2 py-1 rounded-full text-[10px] font-bold whitespace-nowrap tracking-wide transition-all shadow-xs active:scale-95 bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-[#FFF9E6] border border-[#D4AF37]/50 hover:border-[#D4AF37] hover:shadow-md"
          >
            <PlusCircle className="w-3 h-3 text-[#D4AF37]" />
            <span>{language === 'bn' ? 'আজকের দিন' : 'My Day'}</span>
          </button>
        </div>

        {/* Right: GPS Update Button & App Controls */}
        <div className="flex items-center gap-1.5">
          {/* Online time-feature refresh button */}
          <button
            id="btn-refresh-time-features"
            onClick={onRefreshTimeFeatures}
            title={language === 'bn' ? 'আজকের সময় আপডেট করুন' : 'Update today’s time features'}
            className={`p-2 rounded-xl border transition-all flex items-center gap-1 cursor-pointer ${
              darkMode
                ? 'bg-[#183326] border-[#D4AF37]/40 text-[#D4AF37] hover:bg-[#204533]'
                : 'bg-white border-emerald-200 text-[#1B4332] hover:bg-emerald-50 shadow-xs'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${weatherLoading ? 'animate-spin' : ''}`} />
          </button>

          {/* Settings Screen Shortcut */}
          {onOpenSettings && (
            <button
              id="btn-open-settings"
              onClick={onOpenSettings}
              title="Open Settings"
              className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
                darkMode
                  ? 'bg-[#183326] border-[#224735] text-stone-300 hover:text-[#D4AF37]'
                  : 'bg-white border-emerald-100 text-stone-600 hover:bg-stone-50 hover:text-[#1B4332]'
              }`}
            >
              <SettingsIcon className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Info Row: Clock + Triple Dates + Live Weather */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div>
          <div className="flex items-center gap-2">
            <span
              id="header-digital-clock"
              className="text-base font-extrabold tracking-tight font-mono text-[#1B4332] dark:text-[#74C69D]"
            >
              {timeStr}
            </span>
            <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300/40">
              {language === 'bn' ? 'সরাসরি' : 'Live'}
            </span>
            <span className="flex items-center gap-1 text-[11px] font-semibold text-stone-600 dark:text-stone-300">
              <MapPin className="w-3 h-3 text-[#D4AF37]" />
              {locationName}
            </span>
          </div>

          {/* Localized Dates: English, Bengali, and Hijri clearly displayed */}
          <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-medium mt-0.5 text-stone-700 dark:text-stone-200">
            <span className="font-bold text-[#1B4332] dark:text-[#74C69D]">
              {new Date().toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
                weekday: 'short',
                day: 'numeric',
                month: 'short',
                year: 'numeric',
              })}
            </span>
            <span className="text-stone-400">•</span>
            <span title="বাংলা দিনপঞ্জিকা" className="text-stone-600 dark:text-stone-300">
              {bengaliDate.fullText}
            </span>
            <span className="text-stone-400">•</span>
            <span title="হিজরি ক্যালেন্ডার" className="text-[#B8860B] dark:text-[#D4AF37] font-semibold">
              {hijriDate.fullText}
            </span>
          </div>
        </div>

        {/* Dynamic Weather Badge */}
        <button
          id="header-weather-badge"
          type="button"
          onClick={() => window.open(`https://www.google.com/search?q=${encodeURIComponent(`weather ${locationName}`)}`, '_blank', 'noopener,noreferrer')}
          title={language === 'bn' ? 'Google Weather খুলুন' : 'Open Google Weather'}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs border ${
            darkMode
              ? 'bg-[#183326] border-[#224735] text-stone-200'
              : 'bg-emerald-50/80 border-emerald-100 text-stone-800'
          }`}
        >
          <CloudSun className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <div className="text-right leading-tight">
            <div className="font-bold text-[11px]">
              {liveWeather.temp}°C • {language === 'bn' ? liveWeather.conditionBn : liveWeather.condition}
            </div>
            <div className="text-[9px] text-stone-500 dark:text-stone-400">
              {liveWeather.airQuality} • {language === 'bn' ? 'আর্দ্রতা' : 'Hum'} {liveWeather.humidity}%
            </div>
          </div>
        </button>
      </div>

      {/* Dynamic Auto-Rotating Islamic Quotes & Verses Banner */}
      {activeQuote && (
        <div
          id="header-inspiring-quotes-banner"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          className={`relative rounded-xl px-3 py-2 border transition-all duration-300 flex items-center justify-between gap-2 ${
            darkMode
              ? 'bg-gradient-to-r from-[#142C20] via-[#18382A] to-[#142C20] border-[#D4AF37]/30 text-stone-100'
              : 'bg-gradient-to-r from-emerald-50/90 via-amber-50/50 to-emerald-50/90 border-emerald-200/80 text-stone-800 shadow-xs'
          }`}
        >
          <div className="flex items-start gap-2 flex-1 min-w-0">
            <Quote className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5 opacity-80" />
            <div className="min-w-0 flex-1">
              {activeQuote.arabic && (
                <p className="font-arabic text-xs font-semibold text-amber-700 dark:text-[#E8D08D] leading-snug tracking-wide truncate">
                  {activeQuote.arabic}
                </p>
              )}
              <p className="text-[11px] font-medium leading-relaxed line-clamp-1 text-stone-800 dark:text-stone-100">
                {activeQuote.quoteBn}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-[9px] uppercase tracking-wider font-extrabold px-1.5 py-0.2 rounded bg-[#1B4332] text-[#D4AF37] dark:bg-[#0B1A12] dark:border dark:border-[#D4AF37]/30">
                  {activeQuote.category}
                </span>
                <span className="text-[10px] text-stone-500 dark:text-stone-400 font-semibold truncate">
                  — {activeQuote.source}
                </span>
              </div>
            </div>
          </div>

          {/* Quote Carousel Navigation Controls */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={handlePrevQuote}
              title="Previous Quote"
              className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 text-stone-500 dark:text-stone-400 transition-colors"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="text-[9px] font-mono font-bold text-[#D4AF37]">
              {currentQuoteIdx + 1}/{quotes.length}
            </span>
            <button
              onClick={handleNextQuote}
              title="Next Quote"
              className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 text-stone-500 dark:text-stone-400 transition-colors"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
