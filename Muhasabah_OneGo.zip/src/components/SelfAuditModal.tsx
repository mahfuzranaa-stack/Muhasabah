import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Check,
  Calendar,
  Sparkles,
  BookOpen,
  Trash2,
  Edit2,
  ChevronRight,
  TrendingUp,
  Smile,
  Meh,
  Frown,
  Heart,
  AlertCircle,
  Award,
} from 'lucide-react';
import { SelfAuditRecord } from '../types';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface SelfAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
  onAuditSaved?: (score: number) => void;
}

const INITIAL_AUDITS: SelfAuditRecord[] = [
  {
    id: 'audit-1',
    date: new Date().toISOString().split('T')[0],
    score: 8,
    dayStateLabel: 'ভালো',
    salatQuality: 4,
    khushooRating: 4,
    goodDeeds: '৫ ওয়াক্ত সালাত জামাআতে আদায়, ১০০ বার ইস্তিগফার ও সূরা মুলক পাঠ।',
    shortcomings: 'ফজর সালাতের পর অলসতায় কিছুটা সময় নষ্ট হয়েছে।',
    lessonsLearned: 'সকালের সময় অত্যন্ত বরকতময়, একে কাজে লাগানো অপরিহার্য।',
    tomorrowImprovement: 'ফজরের পরপরই কুরআন তিলাওয়াত ও সকালের আদকার শেষ করা।',
    note: 'Completed all 5 prayers on time today. Felt peaceful during Fajr and Isha. Good day of remembrance.',
    createdAt: new Date().toISOString(),
  },
];

type DayState = 'খুব ভালো' | 'ভালো' | 'সাধারণ' | 'ঘাটতি ছিল';

const STATE_OPTIONS: { label: DayState; score: number; icon: string; color: string; desc: string }[] = [
  {
    label: 'খুব ভালো',
    score: 10,
    icon: '🌟',
    color: 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
    desc: 'আমল ও খুশূতে পরিপূর্ণ',
  },
  {
    label: 'ভালো',
    score: 8,
    icon: '✨',
    color: 'border-teal-500 bg-teal-500/10 text-teal-600 dark:text-teal-400',
    desc: 'ফরজ ও সুন্নাত পালিত',
  },
  {
    label: 'সাধারণ',
    score: 6,
    icon: '⚖️',
    color: 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400',
    desc: 'মৌলিক আমল হয়েছে',
  },
  {
    label: 'ঘাটতি ছিল',
    score: 4,
    icon: '⚠️',
    color: 'border-rose-500 bg-rose-500/10 text-rose-600 dark:text-rose-400',
    desc: 'তওবা ও নতুন সংকল্প দরকার',
  },
];

export const SelfAuditModal: React.FC<SelfAuditModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
  onAuditSaved,
}) => {
  const [audits, setAudits] = useState<SelfAuditRecord[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_self_audit_records');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_AUDITS;
  });

  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [dayState, setDayState] = useState<DayState>('ভালো');
  const [score, setScore] = useState<number>(8);
  const [salatQuality, setSalatQuality] = useState<number>(4);
  const [khushooRating, setKhushooRating] = useState<number>(4);

  // 4 Structured Sections
  const [goodDeeds, setGoodDeeds] = useState<string>('');
  const [shortcomings, setShortcomings] = useState<string>('');
  const [lessonsLearned, setLessonsLearned] = useState<string>('');
  const [tomorrowImprovement, setTomorrowImprovement] = useState<string>('');

  const [editingId, setEditingId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_self_audit_records', JSON.stringify(audits));
    } catch {
      // ignore
    }
  }, [audits]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleSelectDayState = (option: typeof STATE_OPTIONS[0]) => {
    setDayState(option.label);
    setScore(option.score);
    playDhikrClick(soundEnabled);
  };

  const handleSave = () => {
    if (!goodDeeds.trim() && !shortcomings.trim() && !lessonsLearned.trim() && !tomorrowImprovement.trim()) {
      showToast('অনুগ্রহ করে অন্তত একটি বিভাগে আপনার আত্মপর্যালোচনা লিখুন');
      return;
    }

    playNotificationTone(soundEnabled);

    const fullNote = [
      goodDeeds ? `[ভালো কাজ]: ${goodDeeds}` : '',
      shortcomings ? `[ঘাটতি]: ${shortcomings}` : '',
      lessonsLearned ? `[আজকের শিক্ষা]: ${lessonsLearned}` : '',
      tomorrowImprovement ? `[আগামীকালের পরিকল্পনা]: ${tomorrowImprovement}` : '',
    ]
      .filter(Boolean)
      .join(' | ');

    if (editingId) {
      setAudits((prev) =>
        prev.map((a) =>
          a.id === editingId
            ? {
                ...a,
                date,
                score,
                dayStateLabel: dayState,
                salatQuality,
                khushooRating,
                goodDeeds: goodDeeds.trim(),
                shortcomings: shortcomings.trim(),
                lessonsLearned: lessonsLearned.trim(),
                tomorrowImprovement: tomorrowImprovement.trim(),
                note: fullNote,
              }
            : a
        )
      );
      setEditingId(null);
      showToast('মুহাসাবাহ রেকর্ড আপডেট করা হয়েছে!');
    } else {
      const newEntry: SelfAuditRecord = {
        id: 'audit-' + Date.now(),
        date,
        score,
        dayStateLabel: dayState,
        salatQuality,
        khushooRating,
        goodDeeds: goodDeeds.trim(),
        shortcomings: shortcomings.trim(),
        lessonsLearned: lessonsLearned.trim(),
        tomorrowImprovement: tomorrowImprovement.trim(),
        note: fullNote,
        createdAt: new Date().toISOString(),
      };
      setAudits((prev) => [newEntry, ...prev]);
      showToast('আজকের মুহাসাবাহ সফলভাবে সংরক্ষিত হয়েছে!');
    }

    if (onAuditSaved) {
      onAuditSaved(score);
    }

    // Reset fields
    setGoodDeeds('');
    setShortcomings('');
    setLessonsLearned('');
    setTomorrowImprovement('');
  };

  const handleEdit = (audit: SelfAuditRecord) => {
    setEditingId(audit.id);
    setDate(audit.date);
    setScore(audit.score);
    setDayState(audit.dayStateLabel || 'ভালো');
    setSalatQuality(audit.salatQuality);
    setKhushooRating(audit.khushooRating);
    setGoodDeeds(audit.goodDeeds || '');
    setShortcomings(audit.shortcomings || '');
    setLessonsLearned(audit.lessonsLearned || '');
    setTomorrowImprovement(audit.tomorrowImprovement || '');
  };

  const handleDelete = (id: string) => {
    setAudits((prev) => prev.filter((a) => a.id !== id));
    setDeleteConfirmId(null);
    showToast('মুহাসাবাহ রেকর্ড মুছে ফেলা হয়েছে');
  };

  return (
    <div
      id="modal-self-audit"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-xl rounded-[28px] border shadow-2xl flex flex-col max-h-[94vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-black shadow-xs">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Daily Self-Audit</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  মুহাসাবাতুন নাফস
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                &ldquo;হিসাব নেওয়ার পূর্বে নিজেরাই নিজেদের আমলের হিসাব নাও&rdquo; — উমর (রা.)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="p-2.5 bg-emerald-600 text-white text-xs font-bold text-center animate-in fade-in">
            {toastMsg}
          </div>
        )}

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Date Selector */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-stone-500 dark:text-stone-400">
              <Calendar className="w-4 h-4 text-emerald-500" />
              <span>মুহাসাবাহর তারিখ:</span>
            </div>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className={`text-xs px-2.5 py-1 rounded-xl border font-semibold ${
                darkMode
                  ? 'bg-[#163324] border-[#224C38] text-stone-200'
                  : 'bg-stone-50 border-stone-200 text-stone-800'
              }`}
            />
          </div>

          {/* 1. Today's State: আজকের দিন কেমন কাটল? */}
          <div
            className={`p-4 rounded-2xl border ${
              darkMode ? 'bg-[#12281E]/70 border-[#1E4332]' : 'bg-[#F4FAF5] border-emerald-100'
            }`}
          >
            <h4 className="text-xs font-black text-stone-800 dark:text-stone-200 mb-2 flex items-center justify-between">
              <span>আজকের দিন কেমন কাটল? (Today&apos;s State)</span>
              <span className="text-[11px] font-black text-emerald-600 dark:text-[#D4AF37]">
                স্কোর: {score}/10
              </span>
            </h4>

            {/* Quick Rating Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
              {STATE_OPTIONS.map((opt) => {
                const isSelected = dayState === opt.label;
                return (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => handleSelectDayState(opt)}
                    className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                      isSelected
                        ? `${opt.color} ring-2 ring-emerald-500 font-black shadow-xs`
                        : darkMode
                        ? 'bg-[#163324] border-[#204735] text-stone-400 hover:text-stone-200'
                        : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <span className="text-base">{opt.icon}</span>
                    <span className="text-xs font-bold">{opt.label}</span>
                    <span className="text-[9px] opacity-75">{opt.desc}</span>
                  </button>
                );
              })}
            </div>

            {/* Fine 1-10 Slider */}
            <div className="space-y-1 pt-1">
              <div className="flex justify-between text-[10px] text-stone-400 font-bold px-1">
                <span>১ (ঘাটতি বেশি)</span>
                <span>৫ (মাঝারি)</span>
                <span>১০ (ইহসান ও সর্বোচ্চ বরকত)</span>
              </div>
              <input
                type="range"
                min={1}
                max={10}
                step={1}
                value={score}
                onChange={(e) => {
                  setScore(parseInt(e.target.value));
                  playDhikrClick(soundEnabled);
                }}
                className="w-full accent-emerald-500 cursor-pointer h-2 bg-stone-200 dark:bg-stone-700 rounded-lg"
              />
            </div>
          </div>

          {/* 2. Structured Sections (ভালো কাজ, ভুল/ঘাটতি, আজকের শিক্ষা, আগামীকাল কী উন্নতি করব) */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-emerald-500" />
              <span>৪ টি মূল বিভাগে মূল্যায়ন (Structured Reflection)</span>
            </h4>

            {/* A. ভালো কাজ */}
            <div
              className={`p-3 rounded-2xl border transition-all ${
                darkMode ? 'bg-[#142D21]/80 border-[#1F4432]' : 'bg-white border-emerald-200'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-extrabold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                  <span>🌟 ভালো কাজ (Good Deeds Today)</span>
                </label>
                <span className="text-[10px] text-stone-400">দ্রুত যোগ করুন:</span>
              </div>
              <div className="flex flex-wrap gap-1 mb-2">
                {[
                  '৫ ওয়াক্ত জামাআতে সালাত',
                  'কুরআন তিলাওয়াত',
                  'সকাল-সন্ধ্যার জিকির',
                  'সদকা দান',
                  'পিতা-মাতার খিদমত',
                  'সত্য কথা ও আমানত',
                ].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setGoodDeeds((prev) => (prev ? `${prev}, ${tag}` : tag));
                      playDhikrClick(soundEnabled);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900 transition-colors"
                  >
                    + {tag}
                  </button>
                ))}
              </div>
              <textarea
                rows={2}
                value={goodDeeds}
                onChange={(e) => setGoodDeeds(e.target.value)}
                placeholder="ওয়াক্তমতো নামাজ, কারো উপকার, সদকা, কুরআন তিলাওয়াত..."
                className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                  darkMode
                    ? 'bg-[#0F241A] border-[#1C3E2D] text-stone-100 placeholder-stone-500'
                    : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                }`}
              />
            </div>

            {/* B. ভুল / ঘাটতি */}
            <div
              className={`p-3 rounded-2xl border transition-all ${
                darkMode ? 'bg-[#221013]/60 border-rose-900/40' : 'bg-white border-rose-200'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-extrabold text-rose-700 dark:text-rose-400 flex items-center gap-1.5">
                  <span>⚠️ ভুল / ঘাটতি (Lapses & Mistakes)</span>
                </label>
                <span className="text-[10px] text-stone-400">দ্রুত যোগ করুন:</span>
              </div>
              <div className="flex flex-wrap gap-1 mb-2">
                {[
                  'সালাতে দেরি হওয়া',
                  'মোবাইলে অনর্থক সময় নষ্ট',
                  'রাগ ও মেজাজ প্রদর্শন',
                  'অলসতা ও গাফিলতি',
                  'চোখের হেফাজতের ঘাটতি',
                ].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setShortcomings((prev) => (prev ? `${prev}, ${tag}` : tag));
                      playDhikrClick(soundEnabled);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900 hover:bg-rose-100 dark:hover:bg-rose-900 transition-colors"
                  >
                    + {tag}
                  </button>
                ))}
              </div>
              <textarea
                rows={2}
                value={shortcomings}
                onChange={(e) => setShortcomings(e.target.value)}
                placeholder="অনর্থক সময় নষ্ট, জবানের অসতর্কতা, নামাজে খুশূর অভাব..."
                className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-rose-500 focus:outline-hidden ${
                  darkMode
                    ? 'bg-[#180C0E] border-rose-950 text-stone-100 placeholder-stone-500'
                    : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                }`}
              />
            </div>

            {/* C. আজকের শিক্ষা */}
            <div
              className={`p-3 rounded-2xl border transition-all ${
                darkMode ? 'bg-[#12281E]/60 border-[#224735]' : 'bg-white border-amber-200'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-extrabold text-amber-700 dark:text-[#D4AF37] flex items-center gap-1.5">
                  <span>💡 আজকের শিক্ষা (Today&apos;s Lesson)</span>
                </label>
                <span className="text-[10px] text-stone-400">দ্রুত যোগ করুন:</span>
              </div>
              <div className="flex flex-wrap gap-1 mb-2">
                {[
                  'সময় অমূল্য নিয়ামত',
                  'ধৈর্যে প্রশান্তি মেলে',
                  'একাকীত্বে আল্লাহর নজরদারি',
                  'ক্ষমা চাইলে হৃদয় হালকা হয়',
                ].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setLessonsLearned((prev) => (prev ? `${prev}, ${tag}` : tag));
                      playDhikrClick(soundEnabled);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-[#F4E0A5] border border-amber-200 dark:border-amber-900 hover:bg-amber-100 dark:hover:bg-amber-900 transition-colors"
                  >
                    + {tag}
                  </button>
                ))}
              </div>
              <textarea
                rows={2}
                value={lessonsLearned}
                onChange={(e) => setLessonsLearned(e.target.value)}
                placeholder="আজকের অভিজ্ঞতা বা উপলব্ধি থেকে আপনি কী নতুন শিক্ষা নিলেন..."
                className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-[#D4AF37] focus:outline-hidden ${
                  darkMode
                    ? 'bg-[#0F241A] border-[#1C3E2D] text-stone-100 placeholder-stone-500'
                    : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                }`}
              />
            </div>

            {/* D. আগামীকাল কী উন্নতি করব */}
            <div
              className={`p-3 rounded-2xl border transition-all ${
                darkMode ? 'bg-[#11232B]/60 border-cyan-900/40' : 'bg-white border-cyan-200'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-extrabold text-cyan-700 dark:text-cyan-400 flex items-center gap-1.5">
                  <span>🎯 আগামীকাল কী উন্নতি করব (Tomorrow&apos;s Target)</span>
                </label>
                <span className="text-[10px] text-stone-400">দ্রুত যোগ করুন:</span>
              </div>
              <div className="flex flex-wrap gap-1 mb-2">
                {[
                  'ফজরে প্রথম কাতারে জামাআত',
                  'মোবাইল স্ক্রিন টাইম হ্রাস',
                  '১০০ বার ইস্তিগফার ও দুরুদ',
                  'কথায় নম্রতা বজায় রাখা',
                ].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setTomorrowImprovement((prev) => (prev ? `${prev}, ${tag}` : tag));
                      playDhikrClick(soundEnabled);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-900 hover:bg-cyan-100 dark:hover:bg-cyan-900 transition-colors"
                  >
                    + {tag}
                  </button>
                ))}
              </div>
              <textarea
                rows={2}
                value={tomorrowImprovement}
                onChange={(e) => setTomorrowImprovement(e.target.value)}
                placeholder="আগামীকালের জন্য সুনির্দিষ্ট পদক্ষেপ ও পরিবর্তনের সংকল্প..."
                className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-cyan-500 focus:outline-hidden ${
                  darkMode
                    ? 'bg-[#0C1B22] border-cyan-950 text-stone-100 placeholder-stone-500'
                    : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                }`}
              />
            </div>
          </div>

          {/* Save Action Button */}
          <button
            onClick={handleSave}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] hover:from-[#23533E] hover:to-[#388563] active:scale-98 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
          >
            <Check className="w-4 h-4 text-[#D4AF37]" />
            <span>{editingId ? 'মুহাসাবাহ রেকর্ড আপডেট করুন' : 'আজকের মুহাসাবাতুন নাফস সংরক্ষণ করুন'}</span>
          </button>

          {/* 3. Past History Logs */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
                পূর্ববর্তী মুহাসাবাহ ইতিহাস ({audits.length})
              </h4>
              <span className="text-[10px] font-bold text-emerald-500">
                গড় স্কোর: {(audits.reduce((acc, a) => acc + a.score, 0) / (audits.length || 1)).toFixed(1)}/10
              </span>
            </div>

            {audits.length === 0 ? (
              <p className="text-center py-4 text-xs text-stone-400">
                কোনো মুহাসাবাহ রেকর্ড পাওয়া যায়নি।
              </p>
            ) : (
              <div className="space-y-2.5">
                {audits.map((a) => (
                  <div
                    key={a.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      darkMode ? 'bg-[#12281E]/60 border-[#1E4332]' : 'bg-white border-stone-200 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-600 dark:text-[#D4AF37]">
                          {a.dayStateLabel || 'মূল্যায়ন'}: {a.score}/10
                        </span>
                        <span className="text-[10px] font-semibold text-stone-400">
                          {a.date}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleEdit(a)}
                          className="p-1 text-stone-400 hover:text-emerald-500 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {deleteConfirmId === a.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleDelete(a.id)}
                              className="px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-600 text-white"
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-1.5 py-0.5 rounded-md text-[10px] text-stone-400"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(a.id)}
                            className="p-1 text-stone-400 hover:text-rose-500 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="space-y-1 text-xs">
                      {a.goodDeeds && (
                        <p className="text-stone-700 dark:text-stone-300">
                          <strong className="text-emerald-600 dark:text-emerald-400 font-extrabold">ভালো কাজ:</strong> {a.goodDeeds}
                        </p>
                      )}
                      {a.shortcomings && (
                        <p className="text-stone-700 dark:text-stone-300">
                          <strong className="text-rose-600 dark:text-rose-400 font-extrabold">ঘাটতি:</strong> {a.shortcomings}
                        </p>
                      )}
                      {a.lessonsLearned && (
                        <p className="text-stone-700 dark:text-stone-300">
                          <strong className="text-amber-600 dark:text-[#D4AF37] font-extrabold">শিক্ষা:</strong> {a.lessonsLearned}
                        </p>
                      )}
                      {a.tomorrowImprovement && (
                        <p className="text-stone-700 dark:text-stone-300">
                          <strong className="text-cyan-600 dark:text-cyan-400 font-extrabold">উন্নতি:</strong> {a.tomorrowImprovement}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
