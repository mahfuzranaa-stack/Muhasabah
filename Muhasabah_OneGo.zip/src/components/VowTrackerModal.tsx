import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Plus,
  Trash2,
  Edit2,
  Check,
  AlertTriangle,
  BookOpen,
  Calendar,
} from 'lucide-react';
import { DigitalVowItem } from '../types';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface VowTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

const INITIAL_VOWS: DigitalVowItem[] = [
  {
    id: 'vow-1',
    vowTitle: 'Fast on 3 White Days this month',
    vowTitleBn: 'চলতি মাসে আইয়ামে বিদের ৩টি রোজা রাখা',
    type: 'Promise to Allah (মানত/ওয়াদা)',
    dateMade: new Date().toISOString().split('T')[0],
    targetDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
    status: 'active',
    notes: 'Fast on 13, 14, 15 of lunar month to seek closeness to Allah.',
    kaffarahGuidance: 'মানত ভঙ্গ করলে কাফফারা প্রযোজ্য: ১০ জন মিসকিনকে দু’বেলা খাওয়ানো বা রোজা রাখা (সূরা আল-মায়েদাহ: ৮৯)।',
  },
];

export const VowTrackerModal: React.FC<VowTrackerModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [vows, setVows] = useState<DigitalVowItem[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_digital_vows');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_VOWS;
  });

  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [type, setType] = useState<DigitalVowItem['type']>('Promise to Allah (মানত/ওয়াদা)');
  const [targetDate, setTargetDate] = useState('');
  const [notes, setNotes] = useState('');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_digital_vows', JSON.stringify(vows));
    } catch {
      // ignore
    }
  }, [vows]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleSave = () => {
    if (!title.trim()) {
      showToast('Please enter the vow or promise title');
      return;
    }

    playNotificationTone(soundEnabled);

    if (editingId) {
      setVows((prev) =>
        prev.map((v) =>
          v.id === editingId
            ? {
                ...v,
                vowTitle: title.trim(),
                vowTitleBn: titleBn.trim() || title.trim(),
                type,
                targetDate: targetDate || undefined,
                notes: notes.trim() || undefined,
              }
            : v
        )
      );
      setEditingId(null);
      showToast('Vow record updated');
    } else {
      const newVow: DigitalVowItem = {
        id: 'vow-' + Date.now(),
        vowTitle: title.trim(),
        vowTitleBn: titleBn.trim() || title.trim(),
        type,
        dateMade: new Date().toISOString().split('T')[0],
        targetDate: targetDate || undefined,
        status: 'active',
        notes: notes.trim() || undefined,
        kaffarahGuidance:
          'মানত বা কসম ভঙ্গ করলে কাফফারা দিতে হবে: ১০ জন মিসকিনকে মধ্যম ধরনের খাদ্য খাওয়ানো বা বস্ত্রদান করা (আল-মায়েদাহ: ৮৯)।',
      };
      setVows((prev) => [newVow, ...prev]);
      showToast('Vow / pledge logged securely');
    }

    setTitle('');
    setTitleBn('');
    setNotes('');
    setTargetDate('');
    setShowAddForm(false);
  };

  const handleStatusChange = (id: string, status: DigitalVowItem['status']) => {
    playDhikrClick(soundEnabled);
    setVows((prev) => prev.map((v) => (v.id === id ? { ...v, status } : v)));
    showToast(`Vow marked as ${status}`);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this vow record?')) {
      setVows((prev) => prev.filter((v) => v.id !== id));
      showToast('Vow deleted');
    }
  };

  return (
    <div
      id="modal-vow-tracker"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-black shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Vow &amp; Promise Tracker</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  মানত ও অঙ্গীকার
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                &ldquo;They fulfill their vows and fear a Day whose evil will be widespread.&rdquo; (76:7)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="p-2.5 bg-amber-600 text-white text-xs font-bold text-center animate-in fade-in">
            {toastMsg}
          </div>
        )}

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Islamic Dalil Info Card */}
          <div
            className={`p-3.5 rounded-2xl border text-xs leading-relaxed ${
              darkMode ? 'bg-[#12281E]/60 border-[#1E4332] text-stone-300' : 'bg-amber-50 border-amber-200 text-amber-950'
            }`}
          >
            <span className="font-black block text-amber-500 dark:text-amber-400 mb-1">
              📜 মানত ও অঙ্গীকারের শরঈ বিধান
            </span>
            নেক কাজের মানত করলে তা পূরণ করা ওয়াজিব। রাসূলুল্লাহ ﷺ বলেছেন: &ldquo;যে ব্যক্তি আল্লাহর আনুগত্যের মানত করে, সে যেন তাঁর আনুগত্য করে।&rdquo; (সহিহ বুখারি: ৬৬৯৬)।
          </div>

          {/* Add Vow Button */}
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="w-full py-2.5 rounded-xl border border-dashed border-emerald-500/40 hover:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-black text-xs flex items-center justify-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{showAddForm ? 'Close Form' : '+ Record New Vow / Promise'}</span>
          </button>

          {/* Form */}
          {showAddForm && (
            <div
              className={`p-4 rounded-2xl border space-y-3 animate-in fade-in ${
                darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
              }`}
            >
              <span className="text-xs font-black text-emerald-500 block">
                {editingId ? 'Edit Vow / Pledge' : 'New Vow / Pledge (নতুন মানত/ওয়াদা)'}
              </span>

              <div>
                <label className="text-[11px] font-bold text-stone-400 block mb-1">Title (English)</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Give ৳500 Sadaqah if examination results are good"
                  className={`w-full p-2.5 rounded-xl border text-xs ${
                    darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-stone-400 block mb-1">Title (বাংলা)</label>
                <input
                  type="text"
                  value={titleBn}
                  onChange={(e) => setTitleBn(e.target.value)}
                  placeholder="যেমন: পরীক্ষায় ভালো ফলাফল পেলে ৫০০ টাকা সাদাকা দিব"
                  className={`w-full p-2.5 rounded-xl border text-xs ${
                    darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-stone-400 block mb-1">Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as DigitalVowItem['type'])}
                    className={`w-full p-2 rounded-xl border text-xs ${
                      darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                    }`}
                  >
                    <option value="Promise to Allah (মানত/ওয়াদা)">Promise to Allah (মানত)</option>
                    <option value="Personal Resolution (প্রতিজ্ঞা)">Personal Resolution (প্রতিজ্ঞা)</option>
                    <option value="Good Habit Pledge">Good Habit Pledge</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-stone-400 block mb-1">Target Date</label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className={`w-full p-2 rounded-xl border text-xs ${
                      darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                    }`}
                  />
                </div>
              </div>

              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Additional details, conditions or notes..."
                className={`w-full p-2.5 rounded-xl border text-xs ${
                  darkMode ? 'bg-[#0E2017] border-[#1E4332] text-white' : 'bg-white border-stone-200'
                }`}
              />

              <button
                onClick={handleSave}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Check className="w-4 h-4" />
                <span>Save Vow Record</span>
              </button>
            </div>
          )}

          {/* Vow List */}
          <div className="space-y-2.5 pt-1">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
              Active &amp; Past Vows ({vows.length})
            </h4>

            {vows.length === 0 ? (
              <p className="text-center py-6 text-xs text-stone-400">
                No vows or sacred promises currently recorded.
              </p>
            ) : (
              <div className="space-y-2">
                {vows.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border space-y-2 transition-all ${
                      item.status === 'fulfilled'
                        ? 'bg-emerald-500/10 border-emerald-500/40'
                        : item.status === 'broken'
                        ? 'bg-rose-500/10 border-rose-500/40'
                        : darkMode
                        ? 'bg-[#12281E]/60 border-[#1E4332]'
                        : 'bg-white border-stone-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                        {item.type}
                      </span>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-1 text-stone-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-xs font-black text-stone-900 dark:text-stone-100">
                        {item.vowTitle}
                      </h4>
                      <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                        {item.vowTitleBn}
                      </p>
                      {item.notes && (
                        <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
                          {item.notes}
                        </p>
                      )}
                    </div>

                    {/* Status Selection Buttons */}
                    <div className="flex items-center gap-1.5 pt-1 border-t border-stone-100 dark:border-stone-800/80">
                      <span className="text-[10px] text-stone-400 font-bold mr-1">Status:</span>
                      {(['active', 'fulfilled', 'broken'] as const).map((st) => (
                        <button
                          key={st}
                          onClick={() => handleStatusChange(item.id, st)}
                          className={`px-2 py-0.5 rounded-md text-[10px] font-black capitalize transition-all ${
                            item.status === st
                              ? st === 'fulfilled'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : st === 'broken'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'bg-amber-600 text-white shadow-xs'
                              : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'
                          }`}
                        >
                          {st === 'fulfilled' ? '✓ Fulfilled' : st === 'broken' ? '✗ Broken' : 'Active'}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
