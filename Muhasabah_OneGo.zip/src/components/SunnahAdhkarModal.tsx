import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Check,
  RotateCcw,
  Sun,
  Moon,
  Volume2,
  CheckCircle2,
  ChevronRight,
  BookOpen,
} from 'lucide-react';
import { SunnahAdhkarStep } from '../types';
import { INITIAL_SUNNAH_ADHKAR } from '../data/islamicFeaturesData';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface SunnahAdhkarModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

export const SunnahAdhkarModal: React.FC<SunnahAdhkarModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [adhkarList, setAdhkarList] = useState<SunnahAdhkarStep[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_sunnah_adhkar');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_SUNNAH_ADHKAR;
  });

  const [filterPeriod, setFilterPeriod] = useState<'All' | 'Morning' | 'Evening' | 'Both'>('All');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_sunnah_adhkar', JSON.stringify(adhkarList));
    } catch {
      // ignore
    }
  }, [adhkarList]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleIncrement = (id: string) => {
    playDhikrClick(soundEnabled);
    setAdhkarList((prev) =>
      prev.map((step) => {
        if (step.id !== id) return step;
        const newCount = step.currentCount + 1;
        const isDone = newCount >= step.targetCount;
        if (isDone && !step.completed) {
          playNotificationTone(soundEnabled);
          showToast(`MashaAllah! Completed ${step.titleEn}`);
        }
        return {
          ...step,
          currentCount: newCount,
          completed: isDone,
        };
      })
    );
  };

  const handleReset = (id: string) => {
    setAdhkarList((prev) =>
      prev.map((step) => (step.id === id ? { ...step, currentCount: 0, completed: false } : step))
    );
    showToast('Reset counter');
  };

  const handleResetAll = () => {
    if (window.confirm('Reset all daily Sunnah Adhkar counts?')) {
      setAdhkarList((prev) => prev.map((step) => ({ ...step, currentCount: 0, completed: false })));
      showToast('All Adhkar counters reset for a new day');
    }
  };

  const completedCount = adhkarList.filter((a) => a.completed).length;
  const progressPercent = Math.round((completedCount / (adhkarList.length || 1)) * 100);

  const filtered = adhkarList.filter((a) => {
    if (filterPeriod === 'All') return true;
    if (filterPeriod === 'Both') return a.period === 'Both';
    return a.period === filterPeriod || a.period === 'Both';
  });

  return (
    <div
      id="modal-sunnah-adhkar"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] text-[#D4AF37] border border-[#D4AF37]/30 flex items-center justify-center font-black shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                <span>Sunnah Adhkar Checklist</span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37]">
                  সকাল-সন্ধ্যা যিকর
                </span>
              </h3>
              <p className="text-xs text-stone-400 font-medium">
                Step-by-step authentic morning &amp; evening fortress supplications
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress & Quick Actions Bar */}
        <div
          className={`p-3 border-b flex items-center justify-between gap-3 ${
            darkMode ? 'bg-[#0A1710] border-[#1A3729]' : 'bg-stone-50 border-stone-200'
          }`}
        >
          <div className="flex items-center gap-2 flex-1">
            <div className="w-full bg-stone-200 dark:bg-stone-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-500 to-[#D4AF37] h-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-xs font-black text-[#D4AF37] shrink-0 font-mono">
              {completedCount}/{adhkarList.length} ({progressPercent}%)
            </span>
          </div>

          <button
            onClick={handleResetAll}
            className="p-1.5 rounded-lg text-stone-400 hover:text-amber-400 hover:bg-black/10 dark:hover:bg-white/10 transition-colors shrink-0"
            title="Reset All Counts"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Pills */}
        <div
          className={`px-4 py-2 border-b flex items-center gap-1.5 overflow-x-auto no-scrollbar ${
            darkMode ? 'bg-[#0E2017] border-[#1C3B2C]' : 'bg-white border-stone-200'
          }`}
        >
          {(['All', 'Morning', 'Evening', 'Both'] as const).map((period) => (
            <button
              key={period}
              onClick={() => setFilterPeriod(period)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1 ${
                filterPeriod === period
                  ? 'bg-[#1B4332] text-[#F4E0A5] shadow-xs'
                  : darkMode
                  ? 'bg-[#12281E] text-stone-400 hover:text-stone-200'
                  : 'bg-stone-100 text-stone-600 hover:text-stone-900'
              }`}
            >
              {period === 'Morning' && <Sun className="w-3 h-3 text-amber-400" />}
              {period === 'Evening' && <Moon className="w-3 h-3 text-blue-400" />}
              <span>{period === 'All' ? 'All Adhkar' : period}</span>
            </button>
          ))}
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 my-2 p-2 rounded-xl bg-emerald-600 text-white text-xs font-bold text-center shadow-md animate-bounce">
            {toastMsg}
          </div>
        )}

        {/* Scrollable List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.map((step) => {
            const isFinished = step.currentCount >= step.targetCount;
            return (
              <div
                key={step.id}
                className={`p-4 rounded-2xl border transition-all ${
                  isFinished
                    ? darkMode
                      ? 'bg-[#10251B] border-emerald-500/40 ring-1 ring-emerald-500/20'
                      : 'bg-emerald-50/80 border-emerald-300 ring-1 ring-emerald-400/20'
                    : darkMode
                    ? 'bg-[#12281E] border-[#224A37]'
                    : 'bg-white border-stone-200 shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span
                        className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          step.period === 'Morning'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : step.period === 'Evening'
                            ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        }`}
                      >
                        {step.period}
                      </span>
                      <span className="text-[10px] font-bold text-stone-400">
                        Goal: {step.targetCount}x
                      </span>
                    </div>

                    <h4 className="text-sm font-black text-stone-900 dark:text-stone-100">
                      {step.titleEn}
                    </h4>
                    <span className="text-xs font-bold text-[#D4AF37] block">
                      {step.titleBn}
                    </span>

                    {/* Arabic Text */}
                    <div className="my-2.5 p-2.5 rounded-xl bg-black/5 dark:bg-black/30 border border-stone-300/20 text-center font-arabic text-lg font-bold text-[#1B4332] dark:text-[#F4E0A5] leading-relaxed">
                      {step.arabic}
                    </div>

                    <p className="text-[11px] text-stone-500 dark:text-stone-400 italic mb-1 font-medium">
                      &quot;{step.transliteration}&quot;
                    </p>
                    <p className="text-xs text-stone-700 dark:text-stone-300 font-medium leading-relaxed">
                      অর্থ: {step.meaningBn}
                    </p>

                    {step.virtue && (
                      <p className="text-[10px] text-amber-600 dark:text-amber-400/90 font-semibold mt-1.5 bg-amber-500/10 p-1.5 rounded-lg border border-amber-500/20">
                        فضيلة: {step.virtue}
                      </p>
                    )}
                  </div>

                  {/* Tactile Counter Button */}
                  <div className="flex flex-col items-center shrink-0 gap-2">
                    <button
                      onClick={() => handleIncrement(step.id)}
                      className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center transition-all active:scale-95 shadow-md ${
                        isFinished
                          ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                          : 'bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] text-[#F4E0A5] hover:brightness-110 border border-[#D4AF37]/40'
                      }`}
                    >
                      <span className="text-base font-black leading-none font-mono">
                        {step.currentCount}
                      </span>
                      <span className="text-[9px] font-bold opacity-80 mt-0.5">
                        /{step.targetCount}
                      </span>
                    </button>

                    {step.currentCount > 0 && (
                      <button
                        onClick={() => handleReset(step.id)}
                        className="text-[10px] text-stone-400 hover:text-stone-200 underline"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
