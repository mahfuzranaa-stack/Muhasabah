#!/usr/bin/env bash
set -euo pipefail

# One-command Android build for Muhasabah.
# Requirements: Node.js, npm, Java 17+, Android SDK/Android Studio.
MODE="${1:-release}"

npm install
npm run build
npx cap add android 2>/dev/null || true
npx cap sync android

if [[ "$MODE" == "debug" ]]; then
  (cd android && ./gradlew assembleDebug)
  mkdir -p public
  cp android/app/build/outputs/apk/debug/app-debug.apk public/Muhasabah.apk
else
  (cd android && ./gradlew assembleRelease)
  mkdir -p public
  cp android/app/build/outputs/apk/release/app-release-unsigned.apk public/Muhasabah-unsigned.apk
  echo "Release APK built. Sign the release APK before publishing it as Muhasabah.apk."
fi
