import React, { useState } from 'react';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  DollarSign,
  Search,
  Check,
  Award,
  TrendingUp,
  ShieldCheck,
  Sparkles,
  Info,
  ChevronRight,
  PiggyBank,
  Receipt,
  HeartHandshake,
  RotateCcw,
} from 'lucide-react';
import { ExpenseRecord } from '../types';
import { getFinanceLevel } from '../utils/qibla';

interface ExpenseTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  expenses: ExpenseRecord[];
  onAddExpense: (expense: Omit<ExpenseRecord, 'id'>) => void;
  onUpdateExpense?: (expense: ExpenseRecord) => void;
  onDeleteExpense: (id: string) => void;
  onResetExpenses?: () => void;
}

const CATEGORIES: ExpenseRecord['category'][] = [
  'Food',
  'Transport',
  'Bills',
  'Health',
  'Education',
  'Shopping',
  'Sadaqah (সদকা ও দান)',
  'Emergency Fund',
  'Investment',
  'Personal',
  'Other',
];

export const ExpenseTrackerModal: React.FC<ExpenseTrackerModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  expenses,
  onAddExpense,
  onUpdateExpense,
  onDeleteExpense,
  onResetExpenses,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'expense' | 'save' | 'sadaqah'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [isAdding, setIsAdding] = useState(false);
  const [editingItem, setEditingItem] = useState<ExpenseRecord | null>(null);

  // Form states
  const [recordType, setRecordType] = useState<'expense' | 'save'>('expense');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseRecord['category']>('Food');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  if (!isOpen) return null;

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  // Financial aggregates
  const totalExpense = expenses
    .filter((e) => !e.type || e.type === 'expense')
    .reduce((sum, e) => sum + e.amount, 0);

  const totalSavings = expenses
    .filter((e) => e.type === 'save')
    .reduce((sum, e) => sum + e.amount, 0);

  const totalSadaqah = expenses
    .filter((e) => e.category.toLowerCase().includes('sadaqah') || e.title.toLowerCase().includes('sadaqah'))
    .reduce((sum, e) => sum + e.amount, 0);

  const netReserve = totalSavings - totalExpense;
  const financeLevel = getFinanceLevel(totalSavings);
  const progressPercent = Math.min(
    100,
    Math.round((totalSavings / (financeLevel.nextTarget || 1)) * 100)
  );

  const todayExpense = expenses
    .filter((e) => (!e.type || e.type === 'expense') && e.date === todayStr)
    .reduce((sum, e) => sum + e.amount, 0);

  const handleStartEdit = (item: ExpenseRecord) => {
    setEditingItem(item);
    setRecordType(item.type || 'expense');
    setTitle(item.title);
    setAmount(item.amount.toString());
    setCategory(item.category);
    setDate(item.date);
    setNote(item.note || '');
    setIsAdding(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!title.trim() || isNaN(numAmount) || numAmount <= 0) return;

    if (editingItem && onUpdateExpense) {
      onUpdateExpense({
        ...editingItem,
        type: recordType,
        title: title.trim(),
        amount: numAmount,
        category,
        date,
        note: note.trim() || undefined,
      });
    } else {
      onAddExpense({
        type: recordType,
        title: title.trim(),
        amount: numAmount,
        category,
        date,
        note: note.trim() || undefined,
      });
    }

    // Reset
    setIsAdding(false);
    setEditingItem(null);
    setTitle('');
    setAmount('');
    setRecordType('expense');
    setCategory('Food');
    setDate(todayStr);
    setNote('');
  };

  const filteredExpenses = expenses
    .filter((e) => {
      const currentType = e.type || 'expense';
      if (activeTab === 'expense' && currentType !== 'expense') return false;
      if (activeTab === 'save' && currentType !== 'save') return false;
      if (
        activeTab === 'sadaqah' &&
        !e.category.toLowerCase().includes('sadaqah') &&
        !e.title.toLowerCase().includes('sadaqah')
      )
        return false;

      const matchSearch =
        e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (e.note && e.note.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchCat = filterCategory === 'All' || e.category === filterCategory;
      return matchSearch && matchCat;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[92vh] rounded-[26px] border shadow-2xl flex flex-col overflow-hidden transition-all ${
          darkMode
            ? 'bg-[#10241A] border-[#224A37] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Master Header: Deep Emerald & Gold Accents */}
        <div className="p-4 border-b border-emerald-800/40 flex items-center justify-between bg-gradient-to-r from-[#1B4332] via-[#245842] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#D4AF37] text-stone-950 shadow-md">
              <PiggyBank className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Muhasabat al-Mal (হিসাব-নিকাশ)
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/30 text-[#F5E6B3] border border-[#D4AF37]/50 font-bold">
                  BDT ৳
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Gamified Halal Finance, Savings Level &amp; Anti-Israf Tracker
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {onResetExpenses && <button onClick={() => { if (window.confirm('সব হিসাব-নিকাশ রেকর্ড রিসেট করবেন?')) onResetExpenses(); }} title="Reset records" className="p-2 rounded-xl hover:bg-white/10 text-rose-200 transition-all"><RotateCcw className="w-4 h-4" /></button>}
            <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {/* ============================================================ */}
          {/* 1. GAMIFIED FINANCIAL LEVEL CARD (Requirement B) */}
          {/* ============================================================ */}
          <div
            id="gamified-finance-level-card"
            className={`rounded-2xl p-4 border relative overflow-hidden transition-all shadow-md ${
              darkMode
                ? 'bg-gradient-to-br from-[#0B1E15] via-[#143224] to-[#1D4733] border-[#D4AF37]/40 text-white'
                : 'bg-gradient-to-br from-[#1B4332] via-[#225740] to-[#2D6A4F] border-[#D4AF37]/50 text-white'
            }`}
          >
            <div className="flex items-start justify-between gap-3 relative z-10">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-lg">{financeLevel.badge}</span>
                  <span className="text-xs font-black uppercase tracking-wider text-[#F4E0A5]">
                    Financial Discipline: Level {financeLevel.level}
                  </span>
                </div>
                <h4 className="text-xl font-black text-white mt-0.5 font-mono">
                  {financeLevel.levelName}
                </h4>
                <div className="text-[11px] text-emerald-200/90 font-medium">
                  {financeLevel.levelNameBn}
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-emerald-200 block">
                  Total Halal Savings
                </span>
                <span className="text-xl font-black font-mono text-[#D4AF37]">
                  ৳{totalSavings.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Level Target Progress Bar */}
            <div className="mt-3 relative z-10">
              <div className="flex justify-between items-center text-[10px] font-bold text-emerald-100/90 mb-1">
                <span>
                  Next Target:{' '}
                  <span className="text-[#F4E0A5]">৳{financeLevel.nextTarget.toLocaleString()}</span>
                </span>
                <span>{progressPercent}% achieved</span>
              </div>
              <div className="w-full h-2 rounded-full bg-black/40 overflow-hidden border border-white/15">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#D4AF37] to-[#52B788] transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Islamic Barakah Tip */}
            <div className="mt-3 pt-2.5 border-t border-white/15 flex items-start gap-2 text-[11px] text-emerald-100/90 leading-relaxed relative z-10">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
              <span>
                <strong>মুহাসাবা গাইডলাইন:</strong> {financeLevel.description}
              </span>
            </div>
          </div>

          {/* Quick Aggregate Balance Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-[#152E22] border border-emerald-200 dark:border-emerald-800">
              <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 block">
                Total Saved
              </span>
              <span className="text-sm sm:text-base font-black text-[#1B4332] dark:text-[#52B788]">
                +৳{totalSavings.toLocaleString()}
              </span>
              <span className="text-[9px] text-stone-400 block mt-0.5">Asset Reserve</span>
            </div>

            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-[#28151A] border border-rose-200 dark:border-rose-900/60">
              <span className="text-[10px] font-bold text-rose-700 dark:text-rose-300 block">
                Total Spent
              </span>
              <span className="text-sm sm:text-base font-black text-rose-600 dark:text-rose-400">
                -৳{totalExpense.toLocaleString()}
              </span>
              <span className="text-[9px] text-stone-400 block mt-0.5">Expenditures</span>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50 dark:bg-[#272314] border border-amber-200 dark:border-amber-800/80">
              <span className="text-[10px] font-bold text-amber-800 dark:text-amber-300 block">
                Sadaqah Given
              </span>
              <span className="text-sm sm:text-base font-black text-[#B48A14] dark:text-[#D4AF37]">
                ৳{totalSadaqah.toLocaleString()}
              </span>
              <span className="text-[9px] text-stone-400 block mt-0.5">Barakah Charity</span>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 dark:bg-[#1A2620] border border-stone-200 dark:border-[#254F3E]">
              <span className="text-[10px] font-bold text-stone-700 dark:text-stone-300 block">
                Net Reserve
              </span>
              <span
                className={`text-sm sm:text-base font-black ${
                  netReserve >= 0
                    ? 'text-emerald-700 dark:text-[#D4AF37]'
                    : 'text-red-600 dark:text-red-400'
                }`}
              >
                {netReserve >= 0 ? `৳${netReserve.toLocaleString()}` : `-৳${Math.abs(netReserve).toLocaleString()}`}
              </span>
              <span className="text-[9px] text-stone-400 block mt-0.5">
                {netReserve >= 0 ? 'Surplus' : 'Deficit'}
              </span>
            </div>
          </div>

          {/* Tab Switcher: All vs Expense vs Savings vs Sadaqah */}
          <div className="flex p-1 bg-stone-100 dark:bg-[#142C20] rounded-xl border border-stone-200 dark:border-[#224A37]">
            <button
              onClick={() => setActiveTab('all')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'all'
                  ? 'bg-white dark:bg-[#1B4332] text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              All ({expenses.length})
            </button>
            <button
              onClick={() => setActiveTab('expense')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                activeTab === 'expense'
                  ? 'bg-white dark:bg-[#1B4332] text-rose-600 dark:text-rose-300 shadow-xs'
                  : 'text-stone-500 hover:text-rose-600'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Cost</span>
            </button>
            <button
              onClick={() => setActiveTab('save')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                activeTab === 'save'
                  ? 'bg-white dark:bg-[#1B4332] text-emerald-600 dark:text-[#D4AF37] shadow-xs'
                  : 'text-stone-500 hover:text-emerald-600'
              }`}
            >
              <PiggyBank className="w-3.5 h-3.5" />
              <span>Save</span>
            </button>
            <button
              onClick={() => setActiveTab('sadaqah')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                activeTab === 'sadaqah'
                  ? 'bg-white dark:bg-[#1B4332] text-amber-600 dark:text-[#D4AF37] shadow-xs'
                  : 'text-stone-500 hover:text-amber-600'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Sadaqah</span>
            </button>
          </div>

          {/* Quick Search & Add Trigger */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search description or note..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-200 dark:border-[#254F3E] bg-stone-50 dark:bg-[#0E1E17] text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
            <button
              onClick={() => {
                setEditingItem(null);
                setTitle('');
                setAmount('');
                setRecordType(activeTab === 'save' ? 'save' : 'expense');
                setCategory('Food');
                setDate(todayStr);
                setNote('');
                setIsAdding(!isAdding);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>{isAdding ? 'Close' : 'Add Record'}</span>
            </button>
          </div>

          {/* Add / Edit Form */}
          {isAdding && (
            <form
              onSubmit={handleSave}
              className="p-3.5 rounded-2xl border border-[#D4AF37]/50 bg-[#E8F5E9]/60 dark:bg-[#163024] space-y-2.5 animate-in fade-in"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#1B4332] dark:text-[#F4E0A5] uppercase tracking-wider">
                  {editingItem ? 'Edit Transaction' : 'Record Transaction'}
                </span>

                {/* Type toggle: Expense vs Save */}
                <div className="flex items-center bg-black/10 dark:bg-black/30 rounded-lg p-0.5 border border-stone-300 dark:border-stone-700">
                  <button
                    type="button"
                    onClick={() => setRecordType('expense')}
                    className={`px-2.5 py-1 rounded text-[11px] font-extrabold transition-all ${
                      recordType === 'expense'
                        ? 'bg-rose-700 text-white shadow-xs'
                        : 'text-stone-600 dark:text-stone-300'
                    }`}
                  >
                    Expense (খরচ)
                  </button>
                  <button
                    type="button"
                    onClick={() => setRecordType('save')}
                    className={`px-2.5 py-1 rounded text-[11px] font-extrabold transition-all ${
                      recordType === 'save'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-stone-600 dark:text-stone-300'
                    }`}
                  >
                    Savings (সঞ্চয়)
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Title / Purpose</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={recordType === 'save' ? 'e.g. Monthly Savings, Gold' : 'e.g. Grocery, Bus, Milk'}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Amount (৳ BDT)</label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="e.g. 500"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseRecord['category'])}
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-stone-500">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-2 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-stone-500">Notes / Reflection</label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Essential family need, zero waste"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-500 hover:text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] shadow-sm flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  Save Record
                </button>
              </div>
            </form>
          )}

          {/* Category Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {['All', ...CATEGORIES].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all ${
                  filterCategory === cat
                    ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                    : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Transaction History List */}
          <div className="space-y-2">
            {filteredExpenses.length === 0 ? (
              <div className="text-center py-8 text-xs text-stone-400">
                No transactions found for this filter
              </div>
            ) : (
              filteredExpenses.map((item) => {
                const isSavings = item.type === 'save';
                return (
                  <div
                    key={item.id}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 shadow-xs ${
                      isSavings
                        ? darkMode
                          ? 'bg-[#132C20] border-emerald-800/60'
                          : 'bg-emerald-50/70 border-emerald-200'
                        : darkMode
                        ? 'bg-[#142B20] border-[#1C3B2E]'
                        : 'bg-white border-stone-200/80'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          isSavings
                            ? 'bg-emerald-200 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-100'
                            : 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-200'
                        }`}
                      >
                        {isSavings ? '💰' : item.category === 'Food' ? '🍛' : item.category === 'Transport' ? '🚌' : item.category === 'Bills' ? '⚡' : item.category === 'Health' ? '💊' : '🏷️'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-xs text-stone-900 dark:text-stone-100 truncate">
                            {item.title}
                          </span>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-black uppercase ${
                              isSavings
                                ? 'bg-emerald-600 text-white'
                                : 'bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300'
                            }`}
                          >
                            {isSavings ? 'Savings' : 'Expense'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-stone-500 dark:text-stone-400 mt-0.5">
                          <span className="font-medium">{item.category}</span>
                          <span>•</span>
                          <span>{item.date}</span>
                        </div>
                        {item.note && (
                          <p className="text-[10px] text-stone-400 truncate mt-0.5 italic">
                            {item.note}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`text-sm font-black font-mono ${
                          isSavings
                            ? 'text-emerald-600 dark:text-[#52B788]'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {isSavings ? `+৳${item.amount.toLocaleString()}` : `-৳${item.amount.toLocaleString()}`}
                      </span>

                      {onUpdateExpense && (
                        <button
                          onClick={() => handleStartEdit(item)}
                          className="p-1 rounded text-stone-400 hover:text-[#1B4332] dark:hover:text-[#F4E0A5]"
                          title="Edit transaction"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {deleteConfirmId === item.id ? (
                        <button
                          onClick={() => {
                            onDeleteExpense(item.id);
                            setDeleteConfirmId(null);
                          }}
                          className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-600 text-white animate-pulse"
                        >
                          Confirm?
                        </button>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirmId(item.id)}
                          className="p-1 rounded text-stone-400 hover:text-red-600"
                          title="Delete transaction"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] flex items-center justify-between text-[11px] text-stone-500">
          <span>Anti-Israf &amp; Barakah Ledger</span>
          <span className="font-bold text-[#1B4332] dark:text-[#74C69D]">
            Net Balance: ৳{netReserve.toLocaleString()}
          </span>
        </div>
      </div>
    </div>
  );
};
