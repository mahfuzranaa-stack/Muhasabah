import React, { useState, useEffect } from 'react';
import {
  X,
  RotateCcw,
  Sparkles,
  Check,
  ShieldAlert,
  BookOpen,
  Volume2,
  Copy,
  Plus,
  Minus,
} from 'lucide-react';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface IstighfarLedgerModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

interface IstighfarFormula {
  id: string;
  title: string;
  titleBn: string;
  arabic: string;
  transliteration: string;
  meaningBn: string;
  hadithRef: string;
}

const ISTIGHFAR_FORMULAS: IstighfarFormula[] = [
  {
    id: 'sayyidul',
    title: 'Sayyidul Istighfar (Master of Forgiveness)',
    titleBn: 'সাইয়্যিদুল ইস্তিগফার (তওবার শ্রেষ্ঠ দুআ)',
    arabic: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ',
    transliteration: "Allahumma Anta Rabbi, la ilaha illa Anta, khalaqtani wa ana 'abduka, wa ana 'ala 'ahdika wa wa'dika mastata'tu, a'udhu bika min sharri ma sana'tu, abu'u laka bini'matika 'alayya, wa abu'u bidhanbi faghfir li fa-innahu la yaghfirudh-dhunuba illa Anta.",
    meaningBn: 'হে আল্লাহ! আপনি আমার রব, আপনি ছাড়া কোনো উপাস্য নেই। আপনি আমাকে সৃষ্টি করেছেন এবং আমি আপনার বান্দা। আমি আপনার প্রতিশ্রুতি ও অঙ্গীকারের ওপর সাধ্যানুযায়ী অবিচল রয়েছি। আমার কৃতকর্মের অনিষ্ট থেকে আপনার আশ্রয় চাই। আমার ওপর আপনার যে অনুগ্রহ রয়েছে তা স্বীকার করছি এবং আমার গুনাহও স্বীকার করছি। সুতরাং আপনি আমাকে ক্ষমা করে দিন; কারণ আপনি ছাড়া গুনাহ ক্ষমা করার আর কেউ নেই।',
    hadithRef: 'সহিহ বুখারি: ৬৩০৬ (যে ব্যক্তি দৃঢ় বিশ্বাসের সাথে দিনে পড়বে এবং সন্ধ্যায় মারা যাবে, সে জান্নাতি)',
  },
  {
    id: 'short1',
    title: 'Astaghfirullah wa Atubu Ilayh',
    titleBn: 'আস্তাগফিরুল্লাহ ওয়া আতূবু ইলাইহ',
    arabic: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
    transliteration: "Astaghfirullaha wa atubu ilayh.",
    meaningBn: 'আমি আল্লাহর নিকট ক্ষমা প্রার্থনা করছি এবং তাঁর দিকেই তওবা করে ফিরে আসছি।',
    hadithRef: 'সহিহ বুখারি: ৬৩০৭ (রাসূলুল্লাহ ﷺ দৈনিক ৭০ থেকে ১০০ বারের বেশি তওবা করতেন)',
  },
  {
    id: 'deep1',
    title: 'Rabbighfir li wa tub alayya',
    titleBn: 'রব্বিগফির লী ওয়া তুব আলাইয়্যা',
    arabic: 'رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ',
    transliteration: "Rabbighfir li wa tub 'alayya innaka Antat-Tawwabur-Rahim.",
    meaningBn: 'হে আমার রব! আমাকে ক্ষমা করুন এবং আমার তওবা কবুল করুন; নিশ্চয় আপনি অতিশয় তওবা কবুলকারী, পরম দয়ালু।',
    hadithRef: 'সুনানে তিরমিজি: ৩৪৩৪ (এক বৈঠকে সাহাবিগণ রাসূলুল্লাহ ﷺ-কে এই দুআ ১০০ বার পড়তে গুনতেন)',
  },
];

const DEFAULT_AREAS = [
  { id: '1', label: 'Gaze & Screen time (দৃষ্টির হেফাজত ও অনর্থক স্ক্রল)', checked: false },
  { id: '2', label: 'Speech & Backbiting (জিহ্বার হেফাজত ও গীবত থেকে বিরত থাকা)', checked: false },
  { id: '3', label: 'Prayer Delay or Rushed Focus (নামাজে গাফিলতি বা অসাবধানতা)', checked: false },
  { id: '4', label: 'Impatience or Anger at Home (পরিবারে রাগ ও অধৈর্য হওয়া)', checked: false },
  { id: '5', label: 'Wasted Time & Idle Habits (সময়ের অপচয় ও অপ্রয়োজনীয় কাজ)', checked: false },
];

export const IstighfarLedgerModal: React.FC<IstighfarLedgerModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [count, setCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_istighfar_count');
      if (saved) return parseInt(saved) || 0;
    } catch {
      // ignore
    }
    return 0;
  });

  const [target, setTarget] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_istighfar_target');
      if (saved) return parseInt(saved) || 100;
    } catch {
      // ignore
    }
    return 100;
  });

  const [selectedFormulaId, setSelectedFormulaId] = useState<string>('sayyidul');
  const [checklist, setChecklist] = useState(() => {
    try {
      const saved = localStorage.getItem('muhasabah_istighfar_checklist');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_AREAS;
  });

  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_istighfar_count', count.toString());
      localStorage.setItem('muhasabah_istighfar_target', target.toString());
      localStorage.setItem('muhasabah_istighfar_checklist', JSON.stringify(checklist));
    } catch {
      // ignore
    }
  }, [count, target, checklist]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleIncrement = (amount: number = 1) => {
    playDhikrClick(soundEnabled);
    setCount((prev) => prev + amount);
    if (count + amount === target) {
      playNotificationTone(soundEnabled);
      showToast(`MashaAllah! Target of ${target} Istighfar reached.`);
    }
  };

  const handleReset = () => {
    setCount(0);
    setShowResetConfirm(false);
    showToast('কাউন্টার শূন্য করা হয়েছে');
  };

  const handleCopyDua = (formula: IstighfarFormula) => {
    const text = `${formula.titleBn}\n${formula.arabic}\n${formula.transliteration}\nঅর্থ: ${formula.meaningBn}\nসূত্র: ${formula.hadithRef}`;
    navigator.clipboard.writeText(text);
    showToast('দুআ ক্লিপবোর্ডে কপি করা হয়েছে');
  };

  const toggleChecklist = (id: string) => {
    setChecklist((prev: typeof DEFAULT_AREAS) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const selectedFormula =
    ISTIGHFAR_FORMULAS.find((f) => f.id === selectedFormulaId) || ISTIGHFAR_FORMULAS[0];

  const percent = Math.min(100, Math.round((count / (target || 1)) * 100));

  return (
    <div
      id="modal-istighfar-ledger"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-500 flex items-center justify-center font-black shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Istighfar &amp; Repentance</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/30">
                  ইস্তিগফার ও তওবা
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                &ldquo;Ask forgiveness of your Lord; indeed, He is ever a Perpetual Forgiver.&rdquo; (71:10)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast message */}
        {toastMsg && (
          <div className="p-2.5 bg-teal-600 text-white text-xs font-bold text-center animate-in fade-in">
            {toastMsg}
          </div>
        )}

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Main Counter Hub */}
          <div
            className={`p-5 rounded-2xl border text-center relative overflow-hidden ${
              darkMode ? 'bg-[#12281E]/60 border-[#1E4332]' : 'bg-[#F0FDF4] border-emerald-100'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-stone-400 font-bold mb-3">
              <span>Today&apos;s Istighfar</span>
              <div className="flex items-center gap-1.5">
                <span>Target:</span>
                {[70, 100, 300, 500].map((t) => (
                  <button
                    key={t}
                    onClick={() => setTarget(t)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-black transition-all ${
                      target === t
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Giant Count */}
            <div className="py-2">
              <span className="text-5xl sm:text-6xl font-black tracking-tight text-teal-600 dark:text-teal-400">
                {count}
              </span>
              <span className="text-sm font-semibold text-stone-400 block mt-1">
                of {target} ({percent}%)
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-stone-200 dark:bg-stone-700 rounded-full overflow-hidden my-3">
              <div
                className="h-full bg-teal-500 rounded-full transition-all duration-300"
                style={{ width: `${percent}%` }}
              />
            </div>

            {/* Control Buttons */}
            <div className="grid grid-cols-4 gap-2 pt-1">
              <button
                onClick={() => handleIncrement(1)}
                className="col-span-2 py-3.5 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-base font-black flex items-center justify-center gap-1.5 shadow-md transition-all"
              >
                <Plus className="w-5 h-5" />
                <span>+1 Istighfar</span>
              </button>

              <button
                onClick={() => handleIncrement(10)}
                className="py-3.5 rounded-xl bg-stone-200 dark:bg-stone-700 hover:bg-stone-300 active:scale-95 text-stone-800 dark:text-stone-100 text-xs font-black transition-all"
              >
                +10
              </button>

              {showResetConfirm ? (
                <div className="flex items-center gap-1">
                  <button
                    onClick={handleReset}
                    className="flex-1 py-2 rounded-xl bg-rose-600 text-white text-[11px] font-black"
                  >
                    Reset
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="px-2 py-2 rounded-xl bg-stone-200 dark:bg-stone-700 text-[11px] font-bold"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="py-3.5 rounded-xl bg-stone-200 dark:bg-stone-700 hover:bg-rose-500 hover:text-white active:scale-95 text-stone-500 text-xs font-black flex items-center justify-center transition-all cursor-pointer"
                  title="Reset counter"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Selected Authentic Dua Formula Display */}
          <div
            className={`p-4 rounded-2xl border space-y-2.5 ${
              darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
            }`}
          >
            {/* Formula Selector Tabs */}
            <div className="flex items-center justify-between gap-1.5 pb-1">
              <div className="flex gap-1.5 overflow-x-auto">
                {ISTIGHFAR_FORMULAS.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setSelectedFormulaId(f.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-black whitespace-nowrap transition-all ${
                      selectedFormulaId === f.id
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    {f.id === 'sayyidul' ? 'সাইয়্যিদুল ইস্তিগফার' : f.titleBn}
                  </button>
                ))}
              </div>

              <button
                onClick={() => handleCopyDua(selectedFormula)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-teal-500 shrink-0"
                title="Copy Dua"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>

            <div className="pt-1">
              <h4 className="text-xs font-black text-teal-500 mb-1">{selectedFormula.title}</h4>
              <p
                className="text-right text-lg sm:text-xl font-bold font-serif leading-loose tracking-wide py-2 text-stone-900 dark:text-stone-100 select-all"
                dir="rtl"
              >
                {selectedFormula.arabic}
              </p>
              <p className="text-xs text-stone-500 italic mt-1">{selectedFormula.transliteration}</p>
              <p className="text-xs text-stone-700 dark:text-stone-300 font-medium mt-1 leading-relaxed">
                <span className="font-black text-teal-500">অর্থ: </span>
                {selectedFormula.meaningBn}
              </p>
              <p className="text-[10px] text-stone-400 font-semibold mt-1">
                {selectedFormula.hadithRef}
              </p>
            </div>
          </div>

          {/* Sincere Self-Accountability Checklist (নাফসের সচেতনতা) */}
          <div className="space-y-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-teal-500" />
              <span>Conscious Repentance Focus (আজকের তওবার সংকল্প)</span>
            </h4>
            <div className="space-y-1.5">
              {checklist.map((item: typeof DEFAULT_AREAS[0]) => (
                <button
                  key={item.id}
                  onClick={() => toggleChecklist(item.id)}
                  className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between text-xs transition-all ${
                    item.checked
                      ? 'bg-teal-500/10 border-teal-500/40 text-teal-600 dark:text-teal-400 font-bold'
                      : 'bg-stone-50 dark:bg-[#12281E]/40 border-stone-200 dark:border-[#1E4332] text-stone-600 dark:text-stone-300'
                  }`}
                >
                  <span>{item.label}</span>
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all ${
                      item.checked
                        ? 'bg-teal-500 border-teal-500 text-white'
                        : 'border-stone-300 dark:border-stone-600'
                    }`}
                  >
                    {item.checked && <Check className="w-3.5 h-3.5" />}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
