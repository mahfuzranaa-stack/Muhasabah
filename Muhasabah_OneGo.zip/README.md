<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/3725469a-a7bd-405e-9103-b3d75d205561

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Netlify PWA installation
This build is configured as a standards-based installable PWA:
- HTTPS deployment required (Netlify provides this).
- Manifest has a stable app id, standalone display mode, icons, scope and start URL.
- Service worker is registered at `/sw.js` with root scope.
- `netlify.toml` supplies SPA fallback and correct PWA headers.
- Chrome/Android may expose **Install app** via the browser install prompt. A web app cannot programmatically uninstall itself; uninstall is controlled by Android/Chrome (App info > Uninstall or the browser's installed-app menu).
