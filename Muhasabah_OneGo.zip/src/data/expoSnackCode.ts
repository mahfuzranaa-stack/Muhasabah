// Standalone, fully runnable single-file React Native (Expo) code
// Ready for StackBlitz, Replit, or Expo Snack (snack.expo.dev)

export const EXPO_SNACK_CODE = `import React, { useState, useMemo, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  StatusBar,
  Dimensions,
  Alert,
  Modal,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Home,
  Compass,
  BookOpen,
  BarChart2,
  User,
  CheckCircle2,
  Circle,
  Play,
  Pause,
  Plus,
  RotateCcw,
  CloudSun,
  Flame,
  Sparkles,
  Trash2,
  Edit3,
  RefreshCw,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

// 1. Initial Pristine States (Zero hardcoded dummy data)
const INITIAL_PRAYERS = [
  { id: '1', name: 'Fajr', time: '04:35 AM', completed: false, isNext: true },
  { id: '2', name: 'Dhuhr', time: '12:02 PM', completed: false, isNext: false },
  { id: '3', name: 'Asr', time: '03:25 PM', completed: false, isNext: false },
  { id: '4', name: 'Maghrib', time: '06:08 PM', completed: false, isNext: false },
  { id: '5', name: 'Isha', time: '07:22 PM', completed: false, isNext: false },
];

const INITIAL_TASKS = [
  { id: 't1', title: 'Morning Adhkar & Ayat al-Kursi', completed: false },
  { id: 't2', title: 'Recite Surah Al-Mulk (Ayah 1-10)', completed: false },
  { id: 't3', title: 'Give Sadaqah or Help Family Member', completed: false },
  { id: 't4', title: 'Istighfar (Astaghfirullah 100x)', completed: false },
  { id: 't5', title: 'Evening Adhkar & Tahajjud Intention', completed: false },
];

const STORAGE_KEYS = {
  USER_NAME: '@muhasabah_user_name',
  PRAYERS: '@muhasabah_prayers',
  TASKS: '@muhasabah_tasks',
  DHIKR_COUNT: '@muhasabah_dhikr_count',
  TASBIH_CYCLES: '@muhasabah_tasbih_cycles',
  QURAN_VERSES: '@muhasabah_quran_verses',
  STUDY_MINUTES: '@muhasabah_study_minutes',
  REFLECTIONS: '@muhasabah_reflections',
};

// Safe AsyncStorage helpers that never crash in any runner environment
const safeGetItem = async (key) => {
  try {
    if (typeof AsyncStorage !== 'undefined' && AsyncStorage && AsyncStorage.getItem) {
      return await AsyncStorage.getItem(key);
    }
  } catch (e) {
    // fallback gracefully
  }
  return null;
};

const safeSetItem = async (key, val) => {
  try {
    if (typeof AsyncStorage !== 'undefined' && AsyncStorage && AsyncStorage.setItem) {
      await AsyncStorage.setItem(key, val);
    }
  } catch (e) {
    // fallback gracefully
  }
};

const safeClear = async () => {
  try {
    if (typeof AsyncStorage !== 'undefined' && AsyncStorage && AsyncStorage.clear) {
      await AsyncStorage.clear();
    }
  } catch (e) {
    // fallback gracefully
  }
};

export default function MuhasabahApp() {
  // Navigation & Display Settings
  const [activeTab, setActiveTab] = useState('dashboard');
  const [darkMode, setDarkMode] = useState(false);

  // 1. User Profile: Pure Fresh Start (Zero pre-existing dummy names)
  const [userName, setUserName] = useState('');
  const [userLocation, setUserLocation] = useState('Dhaka, Bangladesh');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [tempName, setTempName] = useState('');

  // 2. Core Productivity States: Strictly initialized at 0 or empty
  const [prayers, setPrayers] = useState(INITIAL_PRAYERS);
  const [tasks, setTasks] = useState(INITIAL_TASKS);
  const [dhikrCount, setDhikrCount] = useState(0);
  const [dhikrTarget, setDhikrTarget] = useState(33);
  const [tasbihCycles, setTasbihCycles] = useState(0);
  const [quranVerses, setQuranVerses] = useState(0);
  const [studyMinutes, setStudyMinutes] = useState(0);

  // Audio & Journal Reflections: Strictly initialized at 0 or empty
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [selectedMood, setSelectedMood] = useState('Grateful');
  const [journalNote, setJournalNote] = useState('');
  const [reflections, setReflections] = useState([]);

  // Load persisted state from AsyncStorage on initial launch
  useEffect(() => {
    const loadSavedState = async () => {
      try {
        const savedName = await safeGetItem(STORAGE_KEYS.USER_NAME);
        if (savedName) setUserName(savedName);

        const savedPrayers = await safeGetItem(STORAGE_KEYS.PRAYERS);
        if (savedPrayers) setPrayers(JSON.parse(savedPrayers));

        const savedTasks = await safeGetItem(STORAGE_KEYS.TASKS);
        if (savedTasks) setTasks(JSON.parse(savedTasks));

        const savedDhikr = await safeGetItem(STORAGE_KEYS.DHIKR_COUNT);
        if (savedDhikr !== null) setDhikrCount(Number(savedDhikr));

        const savedCycles = await safeGetItem(STORAGE_KEYS.TASBIH_CYCLES);
        if (savedCycles !== null) setTasbihCycles(Number(savedCycles));

        const savedQuran = await safeGetItem(STORAGE_KEYS.QURAN_VERSES);
        if (savedQuran !== null) setQuranVerses(Number(savedQuran));

        const savedStudy = await safeGetItem(STORAGE_KEYS.STUDY_MINUTES);
        if (savedStudy !== null) setStudyMinutes(Number(savedStudy));

        const savedReflections = await safeGetItem(STORAGE_KEYS.REFLECTIONS);
        if (savedReflections) setReflections(JSON.parse(savedReflections));
      } catch (err) {
        // Safe start with zero state
      }
    };
    loadSavedState();
  }, []);

  // Sync state changes with AsyncStorage
  useEffect(() => {
    safeSetItem(STORAGE_KEYS.USER_NAME, userName);
  }, [userName]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.PRAYERS, JSON.stringify(prayers));
  }, [prayers]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.DHIKR_COUNT, dhikrCount.toString());
  }, [dhikrCount]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.TASBIH_CYCLES, tasbihCycles.toString());
  }, [tasbihCycles]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.QURAN_VERSES, quranVerses.toString());
  }, [quranVerses]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.STUDY_MINUTES, studyMinutes.toString());
  }, [studyMinutes]);

  useEffect(() => {
    safeSetItem(STORAGE_KEYS.REFLECTIONS, JSON.stringify(reflections));
  }, [reflections]);

  // Dynamic calculations derived strictly from active user input
  const completedPrayers = useMemo(() => prayers.filter((p) => p.completed).length, [prayers]);
  const salatPercent = useMemo(() => Math.round((completedPrayers / 5) * 100), [completedPrayers]);

  const completedTasks = useMemo(() => tasks.filter((t) => t.completed).length, [tasks]);
  const taskPercent = useMemo(
    () => (tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0),
    [completedTasks, tasks.length]
  );

  const quranPercent = useMemo(() => Math.min(100, Math.round((quranVerses / 10) * 100)), [quranVerses]);
  const studyPercent = useMemo(() => Math.min(100, Math.round((studyMinutes / 60) * 100)), [studyMinutes]);

  const overallAverage = useMemo(
    () => Math.round((salatPercent + quranPercent + taskPercent + studyPercent) / 4),
    [salatPercent, quranPercent, taskPercent, studyPercent]
  );

  const totalDeedsDone = useMemo(
    () =>
      completedPrayers +
      completedTasks +
      (dhikrCount > 0 ? 1 : 0) +
      (quranVerses > 0 ? 1 : 0) +
      (reflections.length > 0 ? 1 : 0),
    [completedPrayers, completedTasks, dhikrCount, quranVerses, reflections.length]
  );

  const streakDays = useMemo(() => (totalDeedsDone > 0 ? 1 : 0), [totalDeedsDone]);

  const userLevel = useMemo(() => {
    if (totalDeedsDone === 0) return 'Fresh Start Seeker';
    if (totalDeedsDone <= 3) return 'Level 1 Muhasib';
    if (totalDeedsDone <= 7) return 'Level 2 Muhasib';
    return 'Level 3 Muhasib';
  }, [totalDeedsDone]);

  // Prayer toggling directly syncing with dashboard
  const togglePrayer = (id) => {
    setPrayers((prev) =>
      prev.map((p) => (p.id === id ? { ...p, completed: !p.completed } : p))
    );
  };

  // Task toggling
  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  // Tap Dhikr increment with cycle tracking
  const handleTapDhikr = () => {
    setDhikrCount((prev) => {
      const next = prev + 1;
      if (next >= dhikrTarget && next % dhikrTarget === 0) {
        setTasbihCycles((c) => c + 1);
      }
      return next;
    });
  };

  // Journal adding
  const handleAddReflection = () => {
    if (!journalNote.trim()) {
      Alert.alert('Empty Note', 'Please enter your reflection before saving.');
      return;
    }
    const newEntry = {
      id: Date.now().toString(),
      text: journalNote.trim(),
      mood: selectedMood,
      date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setReflections([newEntry, ...reflections]);
    setJournalNote('');
    Alert.alert('Saved', 'Reflection saved to your Muhasabah journal.');
  };

  const handleDeleteReflection = (id) => {
    setReflections((prev) => prev.filter((r) => r.id !== id));
  };

  // 2. FULLY FUNCTIONAL GLOBAL RESET: Clears React states AND AsyncStorage back to pristine zero
  const handleGlobalReset = () => {
    Alert.alert(
      'Reset All Data & Start Fresh?',
      'This will clear all prayer checks, tasbih counts, Quran verses, daily tasks, and reflections from active memory and local storage back to absolute 0.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset All Data',
          style: 'destructive',
          onPress: async () => {
            // 1. Wipe AsyncStorage
            await safeClear();

            // 2. Reset all React states to pristine zero
            setPrayers(INITIAL_PRAYERS.map((p) => ({ ...p, completed: false })));
            setTasks(INITIAL_TASKS.map((t) => ({ ...t, completed: false })));
            setDhikrCount(0);
            setTasbihCycles(0);
            setQuranVerses(0);
            setStudyMinutes(0);
            setReflections([]);
            setJournalNote('');
            setUserName('');
            setSelectedMood('Grateful');
            setIsPlayingAudio(false);

            Alert.alert(
              'Fresh Slate Restored',
              'All prayers, tasbih counts, Quran verses, and reflections have been reset to 0.'
            );
          },
        },
      ]
    );
  };

  // Profile name modal handler
  const handleSaveProfile = () => {
    setUserName(tempName.trim());
    setIsEditingProfile(false);
  };

  // Luxury Color System: Deep Emerald Green (#1B4332 - #2D6A4F), Pastel Mint (#E8F5E9), Muted Gold (#D4AF37)
  const colors = {
    bg: darkMode ? '#0A1711' : '#E8F5E9',
    card: darkMode ? '#12261E' : '#FFFFFF',
    cardBorder: darkMode ? 'rgba(212,175,55,0.25)' : 'rgba(27,67,50,0.08)',
    primaryDark: '#1B4332',
    primary: '#2D6A4F',
    primaryLight: '#52B788',
    text: darkMode ? '#F0FDF4' : '#142920',
    subText: darkMode ? '#95B3A5' : '#4E6A5D',
    accent: '#D4AF37',
    accentLight: '#F5E6A3',
    danger: '#D90429',
  };

  // User avatar initials
  const avatarInitials = useMemo(() => {
    if (!userName.trim()) return '?';
    const parts = userName.trim().split(' ');
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }, [userName]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.bg }]}>
      <StatusBar barStyle={darkMode ? 'light-content' : 'dark-content'} />

      {/* Top Header */}
      <View style={[styles.header, { backgroundColor: colors.card, borderBottomColor: colors.cardBorder }]}>
        <View>
          <View style={styles.headerTitleRow}>
            <View style={styles.myDayPill}>
              <Text style={styles.myDayText}>+ MY DAY</Text>
            </View>
            <Text style={[styles.brandTitle, { color: colors.primaryDark }]}>MUHASABAH</Text>
          </View>
          <Text style={[styles.dateText, { color: colors.subText }]}>
            Personal Islamic Accountability
          </Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={[styles.clockText, { color: colors.primaryDark }]}>Live Tracker</Text>
          <View style={styles.weatherBadge}>
            <CloudSun size={13} color="#D4AF37" />
            <Text style={styles.weatherText}> {userLocation}</Text>
          </View>
        </View>
      </View>

      {/* Main Content Area */}
      <ScrollView style={styles.contentContainer} showsVerticalScrollIndicator={false}>
        {/* ======================================================== */}
        {/* TAB 1: DASHBOARD                                         */}
        {/* ======================================================== */}
        {activeTab === 'dashboard' && (
          <View>
            {/* Hero Luxury Card with Deep Emerald & Gold Styling */}
            <View style={styles.heroCard}>
              <View style={styles.heroGlow} />
              <View style={styles.heroHeaderRow}>
                <View>
                  <Text style={styles.heroSubHeader}>
                    {userName ? \`ASSALAMU ALAYKUM, \${userName.toUpperCase()}\` : 'ASSALAMU ALAYKUM'}
                  </Text>
                  <Text style={styles.heroGreeting}>Muhasabah Planner</Text>
                </View>
                <View style={styles.goldBadge}>
                  <Flame size={13} color="#1B4332" />
                  <Text style={styles.goldBadgeText}>
                    {streakDays > 0 ? \`\${streakDays}d Active\` : 'Fresh Day'}
                  </Text>
                </View>
              </View>

              <Text style={styles.heroDescription}>
                {totalDeedsDone === 0
                  ? 'Your day is fresh. Start with your first prayer, tasbih count, or morning Adhkar.'
                  : \`\${totalDeedsDone} deeds logged today • \${overallAverage}% overall consistency\`}
              </Text>

              <View style={styles.amalStatusPill}>
                <Sparkles size={13} color="#D4AF37" />
                <Text style={styles.amalStatusText}>
                  {overallAverage === 0
                    ? 'Fresh Start (0%) • Begin with Bismillah'
                    : overallAverage < 40
                    ? \`In Progress (\${overallAverage}%)\`
                    : overallAverage < 75
                    ? \`Good Steadfastness (\${overallAverage}%)\`
                    : \`Excellent Ihsan (\${overallAverage}%)\`}
                </Text>
              </View>
            </View>

            {/* Quick Interactive Actions Row */}
            <View style={[styles.quickActionsCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={styles.quickActionsLabel}>QUICK AMAL LOGGING</Text>
              <View style={styles.quickActionsRow}>
                <TouchableOpacity
                  style={styles.quickBtn}
                  onPress={() => setDhikrCount((c) => c + 10)}
                  activeOpacity={0.7}
                >
                  <Plus size={14} color="#1B4332" />
                  <Text style={styles.quickBtnText}>+10 Dhikr</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.quickBtn}
                  onPress={() => setQuranVerses((v) => Math.min(10, v + 1))}
                  activeOpacity={0.7}
                >
                  <Plus size={14} color="#1B4332" />
                  <Text style={styles.quickBtnText}>+1 Ayah</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.quickBtn}
                  onPress={() => setStudyMinutes((m) => Math.min(60, m + 15))}
                  activeOpacity={0.7}
                >
                  <Plus size={14} color="#1B4332" />
                  <Text style={styles.quickBtnText}>+15m Study</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* 4 Dynamic Progress Metric Cards with interactive rings */}
            <View style={styles.gridRow}>
              {/* Salat Progress */}
              <TouchableOpacity
                onPress={() => setActiveTab('salat')}
                style={[styles.gridCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}
                activeOpacity={0.8}
              >
                <View style={styles.metricHeader}>
                  <Text style={[styles.gridTitle, { color: colors.text }]}>Salat Tracker</Text>
                  <View style={[styles.ringBadge, { borderColor: salatPercent > 0 ? '#D4AF37' : '#C7D9CF' }]}>
                    <Text style={[styles.ringText, { color: colors.primaryDark }]}>{salatPercent}%</Text>
                  </View>
                </View>
                <Text style={styles.gridSub}>{completedPrayers}/5 Prayers Logged</Text>
                <View style={styles.progressBarBg}>
                  <View
                    style={[
                      styles.progressBarFill,
                      { width: \`\${salatPercent}%\`, backgroundColor: '#D4AF37' },
                    ]}
                  />
                </View>
              </TouchableOpacity>

              {/* Quran Progress */}
              <TouchableOpacity
                onPress={() => setActiveTab('dhikr')}
                style={[styles.gridCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}
                activeOpacity={0.8}
              >
                <View style={styles.metricHeader}>
                  <Text style={[styles.gridTitle, { color: colors.text }]}>Quran Tilawat</Text>
                  <View style={[styles.ringBadge, { borderColor: quranPercent > 0 ? '#52B788' : '#C7D9CF' }]}>
                    <Text style={[styles.ringText, { color: '#2D6A4F' }]}>{quranPercent}%</Text>
                  </View>
                </View>
                <Text style={styles.gridSub}>{quranVerses}/10 Verses Read</Text>
                <View style={styles.progressBarBg}>
                  <View
                    style={[
                      styles.progressBarFill,
                      { width: \`\${quranPercent}%\`, backgroundColor: '#52B788' },
                    ]}
                  />
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.gridRow}>
              {/* Tasks Progress */}
              <View style={[styles.gridCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
                <View style={styles.metricHeader}>
                  <Text style={[styles.gridTitle, { color: colors.text }]}>Daily Tasks</Text>
                  <View style={[styles.ringBadge, { borderColor: taskPercent > 0 ? '#D4AF37' : '#C7D9CF' }]}>
                    <Text style={[styles.ringText, { color: '#B08D1E' }]}>{taskPercent}%</Text>
                  </View>
                </View>
                <Text style={styles.gridSub}>{completedTasks}/{tasks.length} Completed</Text>
                <View style={styles.progressBarBg}>
                  <View
                    style={[
                      styles.progressBarFill,
                      { width: \`\${taskPercent}%\`, backgroundColor: '#D4AF37' },
                    ]}
                  />
                </View>
              </View>

              {/* Study Progress */}
              <View style={[styles.gridCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
                <View style={styles.metricHeader}>
                  <Text style={[styles.gridTitle, { color: colors.text }]}>Study & Tafsir</Text>
                  <View style={[styles.ringBadge, { borderColor: studyPercent > 0 ? '#2D6A4F' : '#C7D9CF' }]}>
                    <Text style={[styles.ringText, { color: '#2D6A4F' }]}>{studyPercent}%</Text>
                  </View>
                </View>
                <Text style={styles.gridSub}>{studyMinutes}m / 60m Logged</Text>
                <View style={styles.progressBarBg}>
                  <View
                    style={[
                      styles.progressBarFill,
                      { width: \`\${studyPercent}%\`, backgroundColor: '#2D6A4F' },
                    ]}
                  />
                </View>
              </View>
            </View>

            {/* Dhikr of the Day Card */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <View style={styles.cardHeaderRow}>
                <Text style={[styles.cardLabel, { color: colors.accent }]}>Dhikr of the Day</Text>
                <Sparkles size={15} color="#D4AF37" />
              </View>
              <Text style={styles.arabicText}>سُبْحَانَ اللَّهِ وَبِحَمْدِهِ</Text>
              <Text style={[styles.bengaliText, { color: colors.primaryDark }]}>
                সুবহানাল্লাহি ওয়া বিহামদিহি • Glory be to Allah & Praise Him
              </Text>
              <Text style={[styles.transText, { color: colors.subText }]}>
                Recite 100 times daily for profound forgiveness and serenity.
              </Text>
            </View>
          </View>
        )}

        {/* ======================================================== */}
        {/* TAB 2: SALAT TRACKER (Instant sync with dashboard)        */}
        {/* ======================================================== */}
        {activeTab === 'salat' && (
          <View>
            <View style={styles.heroCard}>
              <Text style={styles.heroSubHeader}>CONGREGATION & PRAYER</Text>
              <Text style={styles.heroGreeting}>Salat Accountability</Text>
              <Text style={styles.heroDescription}>
                {completedPrayers === 0
                  ? 'No prayers logged yet today. Check off each prayer as you complete it.'
                  : \`\${completedPrayers}/5 Prayers completed (\${salatPercent}%)\`}
              </Text>
            </View>

            {prayers.map((item) => (
              <TouchableOpacity
                key={item.id}
                onPress={() => togglePrayer(item.id)}
                activeOpacity={0.7}
                style={[
                  styles.prayerCard,
                  {
                    backgroundColor: colors.card,
                    borderColor: item.completed ? '#D4AF37' : colors.cardBorder,
                    borderWidth: item.completed ? 1.5 : 1,
                  },
                ]}
              >
                <View style={styles.prayerInfo}>
                  <Text style={[styles.prayerName, { color: colors.text }]}>{item.name}</Text>
                  <Text style={{ color: colors.subText, fontSize: 12 }}>{item.time}</Text>
                </View>

                {item.isNext && !item.completed && (
                  <View style={styles.nextPill}>
                    <Text style={styles.nextPillText}>Next</Text>
                  </View>
                )}

                {item.completed ? (
                  <CheckCircle2 color="#D4AF37" size={28} />
                ) : (
                  <Circle color={colors.subText} size={28} />
                )}
              </TouchableOpacity>
            ))}

            {/* Qibla Compass Card */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder, alignItems: 'center' }]}>
              <Text style={[styles.cardLabel, { color: colors.accent }]}>Qibla Compass</Text>
              <Text style={[styles.qiblaDegrees, { color: colors.primaryDark }]}>260° W (Makkah Direction)</Text>
              <View style={styles.compassCircle}>
                <Compass size={86} color="#D4AF37" />
              </View>
              <Text style={{ color: colors.subText, fontSize: 12, marginTop: 4 }}>
                Calibrated to {userLocation}
              </Text>
            </View>
          </View>
        )}

        {/* ======================================================== */}
        {/* TAB 3: DHIKR & QURAN (Live tap counter from 0)            */}
        {/* ======================================================== */}
        {activeTab === 'dhikr' && (
          <View>
            {/* Interactive Live Tap Counter */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder, alignItems: 'center' }]}>
              <Text style={{ color: colors.subText, fontWeight: '700', fontSize: 11, letterSpacing: 0.5 }}>
                DIGITAL TASBIH SESSION
              </Text>

              <Text style={[styles.dhikrNumber, { color: colors.primaryDark }]}>
                {dhikrCount.toLocaleString()}
              </Text>

              {tasbihCycles > 0 && (
                <Text style={{ fontSize: 12, fontWeight: '800', color: '#D4AF37', marginBottom: 6 }}>
                  {tasbihCycles} Completed {tasbihCycles === 1 ? 'Cycle' : 'Cycles'} ({tasbihCycles * dhikrTarget} tasbih)
                </Text>
              )}

              {/* Target chips */}
              <View style={styles.targetRow}>
                {[33, 100, 300].map((t) => (
                  <TouchableOpacity
                    key={t}
                    onPress={() => setDhikrTarget(t)}
                    style={[
                      styles.targetChip,
                      dhikrTarget === t && { backgroundColor: '#1B4332', borderColor: '#D4AF37' },
                    ]}
                  >
                    <Text
                      style={[
                        styles.targetChipText,
                        dhikrTarget === t && { color: '#FFF9E6', fontWeight: '900' },
                      ]}
                    >
                      Target {t}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Big Tap Button */}
              <TouchableOpacity
                onPress={handleTapDhikr}
                style={styles.bigDhikrBtn}
                activeOpacity={0.8}
              >
                <Text style={styles.bigDhikrBtnText}>+ DHIKR</Text>
                <Text style={styles.tapSubText}>Tap to Count</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  Alert.alert('Reset Dhikr Counter?', 'Set tasbih count back to 0?', [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Reset', onPress: () => { setDhikrCount(0); setTasbihCycles(0); } },
                  ]);
                }}
                style={styles.resetBtn}
              >
                <RotateCcw size={14} color={colors.subText} />
                <Text style={{ color: colors.subText, fontSize: 12, marginLeft: 5 }}>Reset Counter</Text>
              </TouchableOpacity>
            </View>

            {/* Quran Tilawat Card */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={[styles.cardLabel, { color: colors.accent }]}>Quran Recitation</Text>
              <Text style={[styles.prayerName, { color: colors.text, fontSize: 16 }]}>
                Surah Al-Mulk (Ayah {quranVerses}/10 target)
              </Text>

              <View style={styles.quranProgressRow}>
                <TouchableOpacity
                  onPress={() => setQuranVerses((v) => Math.min(10, v + 1))}
                  style={styles.verseIncrementBtn}
                  activeOpacity={0.8}
                >
                  <Plus size={16} color="#FFF" />
                  <Text style={styles.verseIncrementText}>Log +1 Ayah Read</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setQuranVerses(0)}
                  style={styles.verseResetBtn}
                  activeOpacity={0.8}
                >
                  <RotateCcw size={14} color={colors.subText} />
                </TouchableOpacity>
              </View>

              <TouchableOpacity
                onPress={() => setIsPlayingAudio(!isPlayingAudio)}
                style={styles.audioBtn}
                activeOpacity={0.8}
              >
                {isPlayingAudio ? <Pause size={18} color="#FFF" /> : <Play size={18} color="#D4AF37" />}
                <Text style={styles.audioBtnText}>
                  {isPlayingAudio ? 'Pause Audio Recitation' : 'Play Audio Recitation'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ======================================================== */}
        {/* TAB 4: GOALS & ANALYTICS                                 */}
        {/* ======================================================== */}
        {activeTab === 'goals' && (
          <View>
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={[styles.cardLabel, { color: colors.accent }]}>Real-Time Habit Completion</Text>

              <View style={styles.goalItem}>
                <Text style={[styles.goalText, { color: colors.text }]}>Salat Consistency</Text>
                <Text style={styles.goalPercent}>{salatPercent}%</Text>
              </View>
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: \`\${salatPercent}%\`, backgroundColor: '#1B4332' }]} />
              </View>

              <View style={[styles.goalItem, { marginTop: 12 }]}>
                <Text style={[styles.goalText, { color: colors.text }]}>Dhikr & Tasbih ({dhikrCount}/{dhikrTarget})</Text>
                <Text style={styles.goalPercent}>
                  {Math.min(100, Math.round((dhikrCount / dhikrTarget) * 100))}%
                </Text>
              </View>
              <View style={styles.progressBarBg}>
                <View
                  style={[
                    styles.progressBarFill,
                    {
                      width: \`\${Math.min(100, Math.round((dhikrCount / dhikrTarget) * 100))}%\`,
                      backgroundColor: '#D4AF37',
                    },
                  ]}
                />
              </View>

              <View style={[styles.goalItem, { marginTop: 12 }]}>
                <Text style={[styles.goalText, { color: colors.text }]}>Quran Tilawat ({quranVerses}/10 Ayahs)</Text>
                <Text style={styles.goalPercent}>{quranPercent}%</Text>
              </View>
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: \`\${quranPercent}%\`, backgroundColor: '#52B788' }]} />
              </View>

              <View style={[styles.goalItem, { marginTop: 12 }]}>
                <Text style={[styles.goalText, { color: colors.text }]}>Daily Tasks ({completedTasks}/{tasks.length})</Text>
                <Text style={styles.goalPercent}>{taskPercent}%</Text>
              </View>
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: \`\${taskPercent}%\`, backgroundColor: '#2D6A4F' }]} />
              </View>
            </View>

            {/* Dynamic Milestones: Locked at 0, unlocks strictly on real progress */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={[styles.cardLabel, { color: colors.accent }]}>Milestones & Achievements</Text>

              <View style={styles.milestoneRow}>
                <Text style={[styles.achievementTitle, { color: colors.text }]}>
                  {dhikrCount >= 33 ? '🏅 33+ Dhikr Milestone (Unlocked)' : '🔒 33 Dhikr Milestone (Locked)'}
                </Text>
                <Text style={[styles.achievementSub, { color: colors.subText }]}>
                  {dhikrCount >= 33 ? 'Completed in tasbih counter' : \`Progress: \${dhikrCount}/33\`}
                </Text>
              </View>

              <View style={[styles.milestoneRow, { marginTop: 10 }]}>
                <Text style={[styles.achievementTitle, { color: colors.text }]}>
                  {completedPrayers === 5 ? '🔥 5/5 Daily Prayers (Unlocked)' : '🔒 5/5 Daily Prayers (Locked)'}
                </Text>
                <Text style={[styles.achievementSub, { color: colors.subText }]}>
                  {completedPrayers === 5 ? 'All prayers completed today' : \`Progress: \${completedPrayers}/5\`}
                </Text>
              </View>

              <View style={[styles.milestoneRow, { marginTop: 10 }]}>
                <Text style={[styles.achievementTitle, { color: colors.text }]}>
                  {reflections.length > 0 ? '📝 Muhasabah Reflection (Unlocked)' : '🔒 Daily Reflection (Locked)'}
                </Text>
                <Text style={[styles.achievementSub, { color: colors.subText }]}>
                  {reflections.length > 0 ? 'First entry recorded' : 'Record an entry in your journal'}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* ======================================================== */}
        {/* TAB 5: PROFILE, REFLECTION & GLOBAL RESET BUTTON         */}
        {/* ======================================================== */}
        {activeTab === 'profile' && (
          <View>
            {/* User Profile Card */}
            <View style={styles.profileHeroCard}>
              <View style={styles.avatarContainer}>
                <Text style={styles.avatarText}>{avatarInitials}</Text>
              </View>
              <Text style={styles.profileNameText}>
                {userName ? userName : 'My Profile'}
              </Text>
              <Text style={styles.profileSubText}>
                {userLocation} • {userLevel}
              </Text>

              <TouchableOpacity
                onPress={() => {
                  setTempName(userName);
                  setIsEditingProfile(true);
                }}
                style={styles.editProfileBtn}
                activeOpacity={0.8}
              >
                <Edit3 size={12} color="#1B4332" />
                <Text style={styles.editProfileBtnText}>
                  {userName ? 'Edit Name' : '+ Set Your Name'}
                </Text>
              </TouchableOpacity>
            </View>

            {/* Daily Mood Selector */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={[styles.cardLabel, { color: colors.accent }]}>Spiritual Heart State</Text>
              <View style={styles.moodRow}>
                {['Grateful', 'Peaceful', 'Reflective', 'Istighfar'].map((m) => (
                  <TouchableOpacity
                    key={m}
                    onPress={() => setSelectedMood(m)}
                    style={[
                      styles.moodBtn,
                      selectedMood === m && { backgroundColor: '#1B4332', borderColor: '#D4AF37' },
                    ]}
                  >
                    <Text
                      style={[
                        styles.moodBtnText,
                        selectedMood === m && { color: '#FFF9E6', fontWeight: '900' },
                      ]}
                    >
                      {m}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Reflection Journal Input */}
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
              <Text style={[styles.cardLabel, { color: colors.accent }]}>Daily Reflection (Muhasabah)</Text>
              <TextInput
                style={[styles.journalInput, { color: colors.text, backgroundColor: darkMode ? '#0A1711' : '#E8F5E930' }]}
                placeholder="Take an honest self-accounting before sleep. Where did you excel? Where do you seek forgiveness?"
                placeholderTextColor="#7C9287"
                value={journalNote}
                onChangeText={setJournalNote}
                multiline
              />
              <TouchableOpacity onPress={handleAddReflection} style={styles.saveBtn} activeOpacity={0.8}>
                <Text style={styles.saveBtnText}>Save Reflection</Text>
              </TouchableOpacity>
            </View>

            {/* Saved Reflections List with Empty State */}
            <View style={{ marginBottom: 16 }}>
              <Text style={[styles.sectionTitle, { color: colors.primaryDark }]}>
                Journal History ({reflections.length})
              </Text>
              {reflections.length === 0 ? (
                <View style={[styles.emptyReflectionsCard, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}>
                  <Sparkles size={18} color="#D4AF37" />
                  <Text style={[styles.emptyReflectionsTitle, { color: colors.text }]}>
                    No reflections logged yet
                  </Text>
                  <Text style={[styles.emptyReflectionsSub, { color: colors.subText }]}>
                    Account for your deeds before sleep and record your first entry above.
                  </Text>
                </View>
              ) : (
                reflections.map((item) => (
                  <View
                    key={item.id}
                    style={[styles.reflectionItem, { backgroundColor: colors.card, borderColor: colors.cardBorder }]}
                  >
                    <View style={styles.reflectionHeader}>
                      <View style={styles.moodPill}>
                        <Text style={styles.moodPillText}>{item.mood}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text style={{ fontSize: 11, color: colors.subText, marginRight: 8 }}>
                          {item.date}
                        </Text>
                        <TouchableOpacity onPress={() => handleDeleteReflection(item.id)}>
                          <Trash2 size={14} color="#E63946" />
                        </TouchableOpacity>
                      </View>
                    </View>
                    <Text style={[styles.reflectionBody, { color: colors.text }]}>{item.text}</Text>
                  </View>
                ))
              )}
            </View>

            {/* 3. FULLY FUNCTIONAL PROMINENT GLOBAL RESET / START FRESH BUTTON */}
            <View style={styles.resetSectionCard}>
              <View style={styles.resetHeaderRow}>
                <View style={styles.dangerIconBg}>
                  <RotateCcw size={16} color="#D90429" />
                </View>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={styles.resetTitle}>Reset All Data / Start Fresh</Text>
                  <Text style={styles.resetSubtitle}>
                    Clear all prayers, tasbih counts, Quran verses, tasks, and journal notes.
                  </Text>
                </View>
              </View>

              <TouchableOpacity
                onPress={handleGlobalReset}
                style={styles.globalResetBtn}
                activeOpacity={0.8}
              >
                <RefreshCw size={15} color="#FFFFFF" />
                <Text style={styles.globalResetBtnText}>Reset All Data & Start Fresh</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Edit Profile Name Modal */}
      <Modal visible={isEditingProfile} transparent animationType="fade">
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.primaryDark }]}>Enter Your Name</Text>
            <Text style={[styles.modalSub, { color: colors.subText }]}>
              Customize your personal Muhasabah planner
            </Text>
            <TextInput
              style={[styles.modalInput, { color: colors.text }]}
              placeholder="e.g. Abdullah, Fatima, Omar"
              placeholderTextColor="#8C9A93"
              value={tempName}
              onChangeText={setTempName}
              autoFocus
            />
            <View style={styles.modalBtnRow}>
              <TouchableOpacity
                onPress={() => setIsEditingProfile(false)}
                style={styles.modalCancelBtn}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSaveProfile}
                style={styles.modalSaveBtn}
              >
                <Text style={styles.modalSaveText}>Save Name</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Bottom Navigation Dock */}
      <View style={[styles.bottomDock, { backgroundColor: colors.card, borderTopColor: colors.cardBorder }]}>
        <TouchableOpacity onPress={() => setActiveTab('dashboard')} style={styles.tabItem}>
          <Home size={22} color={activeTab === 'dashboard' ? '#1B4332' : '#8CA397'} />
          <Text style={[styles.tabLabel, { color: activeTab === 'dashboard' ? '#1B4332' : '#8CA397', fontWeight: activeTab === 'dashboard' ? 'bold' : 'normal' }]}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('salat')} style={styles.tabItem}>
          <Compass size={22} color={activeTab === 'salat' ? '#1B4332' : '#8CA397'} />
          <Text style={[styles.tabLabel, { color: activeTab === 'salat' ? '#1B4332' : '#8CA397', fontWeight: activeTab === 'salat' ? 'bold' : 'normal' }]}>Salat</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('dhikr')} style={styles.tabItem}>
          <BookOpen size={22} color={activeTab === 'dhikr' ? '#1B4332' : '#8CA397'} />
          <Text style={[styles.tabLabel, { color: activeTab === 'dhikr' ? '#1B4332' : '#8CA397', fontWeight: activeTab === 'dhikr' ? 'bold' : 'normal' }]}>Dhikr</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('goals')} style={styles.tabItem}>
          <BarChart2 size={22} color={activeTab === 'goals' ? '#1B4332' : '#8CA397'} />
          <Text style={[styles.tabLabel, { color: activeTab === 'goals' ? '#1B4332' : '#8CA397', fontWeight: activeTab === 'goals' ? 'bold' : 'normal' }]}>Goals</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('profile')} style={styles.tabItem}>
          <User size={22} color={activeTab === 'profile' ? '#1B4332' : '#8CA397'} />
          <Text style={[styles.tabLabel, { color: activeTab === 'profile' ? '#1B4332' : '#8CA397', fontWeight: activeTab === 'profile' ? 'bold' : 'normal' }]}>Profile</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
  },
  headerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  myDayPill: {
    backgroundColor: '#1B4332',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  myDayText: { color: '#D4AF37', fontWeight: '900', fontSize: 10 },
  brandTitle: { fontSize: 13, fontWeight: '900', letterSpacing: 0.5 },
  dateText: { fontSize: 11, marginTop: 3 },
  clockText: { fontSize: 14, fontWeight: '900' },
  weatherBadge: { flexDirection: 'row', alignItems: 'center', marginTop: 2 },
  weatherText: { fontSize: 11, color: '#4B6B5C', fontWeight: '600' },
  contentContainer: { flex: 1, padding: 16 },

  // Hero Card with Deep Emerald & Gold Styling (20px radius)
  heroCard: {
    backgroundColor: '#1B4332',
    padding: 20,
    borderRadius: 20,
    marginBottom: 14,
    shadowColor: '#1B4332',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 5,
    borderWidth: 1,
    borderColor: 'rgba(212,175,55,0.35)',
  },
  heroGlow: {
    position: 'absolute',
    right: -10,
    bottom: -10,
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(212,175,55,0.12)',
  },
  heroHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  heroSubHeader: { fontSize: 10, fontWeight: '900', color: '#D4AF37', letterSpacing: 0.8 },
  heroGreeting: { fontSize: 20, fontWeight: '900', color: '#FFFFFF', marginTop: 2 },
  goldBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D4AF37',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
    gap: 4,
  },
  goldBadgeText: { fontSize: 11, fontWeight: '900', color: '#1B4332' },
  heroDescription: { fontSize: 12, color: 'rgba(232,245,233,0.85)', marginTop: 8, lineHeight: 17 },
  amalStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(212,175,55,0.4)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
    marginTop: 12,
    alignSelf: 'flex-start',
  },
  amalStatusText: { color: '#FFF9E6', fontSize: 12, fontWeight: '700' },

  // Quick Action Strip
  quickActionsCard: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: 'rgba(27,67,50,0.08)',
  },
  quickActionsLabel: { fontSize: 10, fontWeight: '900', color: '#1B4332', letterSpacing: 0.8, marginBottom: 8 },
  quickActionsRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  quickBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#E8F5E9',
    paddingVertical: 8,
    borderRadius: 10,
    gap: 4,
  },
  quickBtnText: { fontSize: 11, fontWeight: '800', color: '#1B4332' },

  // Grid Widgets (20px rounded)
  gridRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  gridCard: {
    width: (width - 44) / 2,
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
    shadowColor: '#1B4332',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 3,
  },
  metricHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  gridTitle: { fontSize: 13, fontWeight: '800', color: '#142920' },
  ringBadge: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 3,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringText: { fontSize: 10, fontWeight: '900' },
  gridSub: { fontSize: 11, color: '#6A8A7C', marginTop: 8 },
  progressBarBg: { height: 5, backgroundColor: 'rgba(0,0,0,0.06)', borderRadius: 4, marginTop: 8, overflow: 'hidden' },
  progressBarFill: { height: '100%', borderRadius: 4 },

  // Standard Card (20px rounded)
  card: {
    padding: 18,
    borderRadius: 20,
    marginBottom: 16,
    borderWidth: 1,
    shadowColor: '#1B4332',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 3,
  },
  cardHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  cardLabel: { fontSize: 11, fontWeight: '900', textTransform: 'uppercase', letterSpacing: 0.8 },
  arabicText: { fontSize: 24, textAlign: 'center', marginVertical: 8, color: '#1B4332', fontWeight: 'bold' },
  bengaliText: { fontSize: 14, textAlign: 'center', fontWeight: '800' },
  transText: { fontSize: 12, textAlign: 'center', marginTop: 4, fontStyle: 'italic' },

  // Salat Item
  prayerCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderRadius: 20,
    marginBottom: 10,
    shadowColor: '#1B4332',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  prayerInfo: { flex: 1 },
  prayerName: { fontSize: 15, fontWeight: '800' },
  nextPill: {
    backgroundColor: 'rgba(212,175,55,0.15)',
    borderWidth: 1,
    borderColor: '#D4AF37',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    marginRight: 10,
  },
  nextPillText: { fontSize: 10, fontWeight: '800', color: '#B08D1E' },
  qiblaDegrees: { fontSize: 18, fontWeight: '900', marginTop: 4 },
  compassCircle: {
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 2,
    borderColor: 'rgba(212,175,55,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 14,
    backgroundColor: 'rgba(232,245,233,0.4)',
  },

  // Dhikr Counter
  dhikrNumber: { fontSize: 50, fontWeight: '900', marginVertical: 8 },
  targetRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  targetChip: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: '#E8F5E9',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  targetChipText: { fontSize: 11, fontWeight: '700', color: '#1B4332' },
  bigDhikrBtn: {
    backgroundColor: '#1B4332',
    width: 144,
    height: 144,
    borderRadius: 72,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#D4AF37',
    shadowColor: '#1B4332',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 6,
  },
  bigDhikrBtnText: { color: '#FFFFFF', fontSize: 18, fontWeight: '900' },
  tapSubText: { color: '#D4AF37', fontSize: 10, fontWeight: '700', marginTop: 4 },
  resetBtn: { flexDirection: 'row', alignItems: 'center', marginTop: 14 },

  // Quran Tilawat
  quranProgressRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 10 },
  verseIncrementBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1B4332',
    paddingVertical: 10,
    borderRadius: 12,
    gap: 6,
  },
  verseIncrementText: { color: '#FFFFFF', fontSize: 12, fontWeight: '800' },
  verseResetBtn: {
    padding: 10,
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
  },
  audioBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1B4332',
    borderWidth: 1,
    borderColor: 'rgba(212,175,55,0.4)',
    paddingVertical: 12,
    borderRadius: 16,
    marginTop: 12,
  },
  audioBtnText: { color: '#FFFFFF', fontWeight: '800', marginLeft: 8, fontSize: 13 },

  // Goals
  goalItem: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  goalText: { fontSize: 13, fontWeight: '700' },
  goalPercent: { fontSize: 13, fontWeight: '900', color: '#D4AF37' },
  milestoneRow: { paddingVertical: 4 },
  achievementTitle: { fontSize: 13, fontWeight: '800' },
  achievementSub: { fontSize: 12, marginTop: 2 },

  // Profile (20px rounded)
  profileHeroCard: {
    backgroundColor: '#1B4332',
    padding: 22,
    borderRadius: 20,
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(212,175,55,0.3)',
    shadowColor: '#1B4332',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 5,
  },
  avatarContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#0F261C',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#D4AF37',
    marginBottom: 8,
  },
  avatarText: { color: '#FFF9E6', fontSize: 20, fontWeight: '900' },
  profileNameText: { color: '#FFFFFF', fontSize: 18, fontWeight: '900' },
  profileSubText: { color: '#A3C4B5', fontSize: 12, marginTop: 2 },
  editProfileBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#D4AF37',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
    marginTop: 10,
  },
  editProfileBtnText: { color: '#1B4332', fontSize: 11, fontWeight: '800' },

  // Mood
  moodRow: { flexDirection: 'row', gap: 6, marginTop: 4 },
  moodBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#E8F5E9',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  moodBtnText: { fontSize: 11, fontWeight: '700', color: '#1B4332' },

  // Journal
  journalInput: {
    borderWidth: 1,
    borderColor: 'rgba(27,67,50,0.15)',
    borderRadius: 16,
    padding: 14,
    minHeight: 85,
    textAlignVertical: 'top',
    fontSize: 13,
    marginTop: 8,
  },
  saveBtn: {
    backgroundColor: '#1B4332',
    borderWidth: 1,
    borderColor: 'rgba(212,175,55,0.4)',
    paddingVertical: 12,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 10,
  },
  saveBtnText: { color: '#FFFFFF', fontWeight: '900', fontSize: 13 },
  sectionTitle: { fontSize: 13, fontWeight: '900', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  emptyReflectionsCard: {
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  emptyReflectionsTitle: { fontSize: 13, fontWeight: '800', marginTop: 6 },
  emptyReflectionsSub: { fontSize: 11, textAlign: 'center', marginTop: 2 },
  reflectionItem: {
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 10,
  },
  reflectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  moodPill: { backgroundColor: '#E8F5E9', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  moodPillText: { fontSize: 10, fontWeight: '800', color: '#1B4332' },
  reflectionBody: { fontSize: 13, lineHeight: 18 },

  // Prominent Global Reset Card (20px rounded)
  resetSectionCard: {
    backgroundColor: '#FFF5F5',
    borderWidth: 1.5,
    borderColor: '#F8D7DA',
    padding: 18,
    borderRadius: 20,
    marginBottom: 20,
  },
  resetHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  dangerIconBg: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFE3E3',
    alignItems: 'center',
    justifyContent: 'center',
  },
  resetTitle: { fontSize: 14, fontWeight: '900', color: '#D90429' },
  resetSubtitle: { fontSize: 11, color: '#721C24', marginTop: 2, lineHeight: 15 },
  globalResetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#D90429',
    paddingVertical: 12,
    borderRadius: 14,
    gap: 8,
  },
  globalResetBtnText: { color: '#FFFFFF', fontSize: 13, fontWeight: '900' },

  // Modal
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    width: '100%',
    padding: 20,
    borderRadius: 20,
  },
  modalTitle: { fontSize: 16, fontWeight: '900' },
  modalSub: { fontSize: 12, marginTop: 2, marginBottom: 14 },
  modalInput: {
    borderWidth: 1,
    borderColor: 'rgba(27,67,50,0.2)',
    borderRadius: 12,
    padding: 12,
    fontSize: 14,
    marginBottom: 16,
  },
  modalBtnRow: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10 },
  modalCancelBtn: { paddingHorizontal: 14, paddingVertical: 8 },
  modalCancelText: { color: '#6A8A7C', fontWeight: '700' },
  modalSaveBtn: {
    backgroundColor: '#1B4332',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 10,
  },
  modalSaveText: { color: '#FFFFFF', fontWeight: '900' },

  // Bottom Navigation Dock
  bottomDock: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    borderTopWidth: 1,
  },
  tabItem: { alignItems: 'center', minWidth: 50 },
  tabLabel: { fontSize: 11, marginTop: 3 },
});
`;
