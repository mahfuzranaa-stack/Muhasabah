import React from 'react';
import { MuhasabatAlMalModal } from './MuhasabatAlMalModal';
import { ExpenseRecord } from '../types';

interface MuhasabatAlMalScreenProps {
  darkMode: boolean;
  finances: ExpenseRecord[];
  onAddRecord: (record: Omit<ExpenseRecord, 'id'>) => void;
  onDeleteRecord: (id: string) => void;
}

export const MuhasabatAlMalScreen: React.FC<MuhasabatAlMalScreenProps> = ({
  darkMode,
  finances,
  onAddRecord,
  onDeleteRecord,
}) => {
  return (
    <div id="screen-muhasabat-al-mal-view" className="space-y-4 pb-6">
      <MuhasabatAlMalModal
        isOpen={true}
        isScreenMode={true}
        onClose={() => {}}
        darkMode={darkMode}
        finances={finances}
        onAddRecord={onAddRecord}
        onDeleteRecord={onDeleteRecord}
      />
    </div>
  );
};
