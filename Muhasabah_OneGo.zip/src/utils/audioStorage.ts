// IndexedDB Audio Storage for Muhasabah App

export interface UserAudioTrack {
  id: string;
  name: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  duration?: number;
  dateAdded: string;
  blob: Blob;
}

const DB_NAME = 'muhasabah_audio_db';
const DB_VERSION = 1;
const STORE_NAME = 'user_audio_tracks';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not supported on this device/browser.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Failed to open audio database.'));
  });
}

export async function saveUserAudio(
  name: string,
  file: File,
  duration?: number
): Promise<UserAudioTrack> {
  const db = await openDB();
  const track: UserAudioTrack = {
    id: 'user-audio-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
    name: name.trim() || file.name.replace(/\.[^/.]+$/, ''),
    fileName: file.name,
    fileType: file.type || 'audio/mpeg',
    fileSize: file.size,
    duration,
    dateAdded: new Date().toISOString(),
    blob: file,
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.add(track);

    request.onsuccess = () => resolve(track);
    request.onerror = () => reject(request.error || new Error('Failed to save audio file.'));
  });
}

export async function getAllUserAudios(): Promise<UserAudioTrack[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const tracks = (request.result as UserAudioTrack[]) || [];
        // Sort newest first
        tracks.sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime());
        resolve(tracks);
      };
      request.onerror = () => reject(request.error || new Error('Failed to load audios.'));
    });
  } catch (error) {
    console.warn('Could not read user audios from IndexedDB:', error);
    return [];
  }
}

export async function deleteUserAudio(id: string): Promise<boolean> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => resolve(true);
    request.onerror = () => reject(request.error || new Error('Failed to delete audio.'));
  });
}
