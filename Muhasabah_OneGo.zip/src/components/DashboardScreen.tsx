import React, { useState, useEffect } from 'react';
import {
  Clock,
  MoonStar,
  BookOpenCheck,
  Sunrise,
  Sun,
  CloudSun,
  Sunset,
  Sparkles,
  CheckCircle2,
  BookOpen,
  CheckSquare,
  GraduationCap,
  Plus,
  Volume2,
  ChevronRight,
  TrendingUp,
  Flame,
  ShieldAlert,
  DollarSign,
  Newspaper,
  Pill,
  Calendar,
  Gift,
  ArrowRight,
  Compass,
  Moon,
  Sun,
  HeartHandshake,
  Sliders,
  RotateCcw,
  Heart,
  Headphones,
  ShieldCheck,
  Scale,
} from 'lucide-react';
import { DayIntelligenceCard } from './DayIntelligenceCard';
import { MetricProgress, TabType, PrayerItem } from '../types';
import { playDhikrClick } from '../utils/audio';
import { useLanguage } from '../utils/i18n';
import { getActivePrayerId } from '../utils/qibla';

interface DashboardScreenProps {
  darkMode: boolean;
  soundEnabled: boolean;
  metrics: MetricProgress[];
  prayers?: PrayerItem[];
  dhikrCount?: number;
  totalExpensesAmount?: number;
  pendingMedsCount?: number;
  nextEventTitle?: string;
  nextEventCountdown?: string;
  onUpdateMetric: (id: string, delta: number) => void;
  onNavigateTab: (tab: TabType) => void;
  onQuickAddAyah: () => void;
  onOpenMyDay: () => void;
  onIncrementDhikr: (count?: number) => void;
  onOpenEmergencyModal: () => void;
  onOpenExpenseModal: () => void;
  onOpenNewsModal: () => void;
  onOpenMedicineModal: () => void;
  onOpenAgeCalcModal: () => void;
  onOpenCountdownModal: () => void;
  onOpenSelfAuditModal?: () => void;
  onOpenNiyyahModal?: () => void;
  onOpenIstighfarModal?: () => void;
  onOpenGratitudeModal?: () => void;
  onOpenDeedsModal?: () => void;
  onOpenAudioSanctuaryModal?: () => void;
  onOpenVowModal?: () => void;
  onOpenAngerResetModal?: () => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  darkMode,
  soundEnabled,
  metrics,
  prayers = [],
  dhikrCount = 0,
  totalExpensesAmount = 0,
  pendingMedsCount = 0,
  nextEventTitle = 'Holy Ramadan',
  nextEventCountdown = 'Upcoming',
  onUpdateMetric,
  onNavigateTab,
  onQuickAddAyah,
  onOpenMyDay,
  onIncrementDhikr,
  onOpenEmergencyModal,
  onOpenExpenseModal,
  onOpenNewsModal,
  onOpenMedicineModal,
  onOpenAgeCalcModal,
  onOpenCountdownModal,
  onOpenSelfAuditModal,
  onOpenNiyyahModal,
  onOpenIstighfarModal,
  onOpenGratitudeModal,
  onOpenDeedsModal,
  onOpenAudioSanctuaryModal,
  onOpenVowModal,
  onOpenAngerResetModal,
}) => {
  const { language, t } = useLanguage();
  // Live ticking hands for the Analog Clock
  const [clockDegrees, setClockDegrees] = useState({ sec: 0, min: 0, hr: 0 });
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const totalDone = metrics.reduce((acc, m) => acc + m.current, 0);
  const avgPercent = Math.round(
    metrics.reduce((acc, m) => acc + m.percent, 0) / (metrics.length || 1)
  );

  // Dynamic real data computations for 4th Card
  const completedPrayersCount = prayers.filter((p) => p.completed).length;
  const salatScorePercent = Math.round((completedPrayersCount / 5) * 100);
  const quranVersesCount = metrics.find((m) => m.id === 'quran')?.current || 0;
  const realDhikrCount = typeof dhikrCount === 'number' ? dhikrCount : 0;
  const overallDailyScore = Math.round(salatScorePercent * 0.5 + avgPercent * 0.5);

  const prayerOrder = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const orderedPrayers = prayerOrder
    .map((id) => prayers.find((p) => p.id === id))
    .filter((p): p is PrayerItem => Boolean(p));
  const activePrayerId = orderedPrayers.length ? getActivePrayerId(orderedPrayers) : '';
  const activeIndex = orderedPrayers.findIndex((p) => p.id === activePrayerId);
  const nextPrayer = orderedPrayers.length
    ? orderedPrayers[(activeIndex + 1 + orderedPrayers.length) % orderedPrayers.length] || orderedPrayers[0]
    : undefined;
  const prayerName = (prayer?: PrayerItem) => {
    if (!prayer) return language === 'bn' ? 'নামাজের সময়' : 'Prayer Time';
    const names: Record<string, { bn: string; en: string }> = {
      fajr: { bn: 'ফজর', en: 'Fajr' },
      dhuhr: { bn: 'যোহর', en: 'Dhuhr' },
      asr: { bn: 'আসর', en: 'Asr' },
      maghrib: { bn: 'মাগরিব', en: 'Maghrib' },
      isha: { bn: 'ইশা', en: 'Isha' },
    };
    return language === 'bn' ? (names[prayer.id]?.bn || prayer.name) : (names[prayer.id]?.en || prayer.name);
  };

  const getSavedNiyyah = () => {
    try {
      const saved = localStorage.getItem('muhasabah_daily_niyyah');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.text) return parsed.text;
        if (parsed.primaryNiyyah) return parsed.primaryNiyyah;
      }
    } catch {
      // fallback
    }
    return language === 'bn' ? 'ইখলাস ও আত্মশুদ্ধি অর্জন' : 'Sincerity & Spiritual Purification';
  };

  const activeNiyyahText = getSavedNiyyah();
  const achievementHighlight =
    completedPrayersCount === 5
      ? (language === 'bn' ? '৫ ওয়াক্ত সালাত সম্পন্ন' : 'All 5 Prayers Completed')
      : completedPrayersCount >= 3
      ? (language === 'bn' ? 'ওয়াক্ত সংরক্ষণ ও জামাত' : 'Preserved Prayers & Jamaat')
      : realDhikrCount >= 100
      ? (language === 'bn' ? '১০০+ তাসবীহ সম্পন্ন' : '100+ Dhikr Logged')
      : (language === 'bn' ? 'দৈনিক আত্মশুদ্ধি চলমান' : 'Daily Muhasabah Active');

  useEffect(() => {
    const tick = () => {
      const d = new Date();
      const s = d.getSeconds();
      const m = d.getMinutes();
      const h = d.getHours() % 12;
      setClockDegrees({
        sec: s * 6,
        min: m * 6 + s * 0.1,
        hr: h * 30 + m * 0.5,
      });
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleDhikrOfDay = () => {
    playDhikrClick(soundEnabled);
    onIncrementDhikr(33);
    showToast('SubhanAllah logged +33 Dhikr!');
  };

  return (
    <div id="screen-dashboard" className="space-y-4 pb-6">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="sticky top-2 z-30 mx-auto max-w-xs text-center px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#2D6A4F] shadow-lg animate-bounce">
          ✨ {toastMsg}
        </div>
      )}

      {/* 1. HERO CARD: Deep Rich Emerald Green Gradient (#1B4332 to #2D6A4F) + Fine Gold Typography */}
      <div
        id="dashboard-hero-banner"
        className={`relative overflow-hidden rounded-[20px] p-5 transition-all shadow-[0_12px_32px_rgba(27,67,50,0.22)] border ${
          darkMode
            ? 'bg-gradient-to-br from-[#0F261C] via-[#163527] to-[#1B4332] border-[#D4AF37]/30 text-white'
            : 'bg-gradient-to-br from-[#1B4332] via-[#225540] to-[#2D6A4F] border-[#D4AF37]/35 text-white'
        }`}
      >
        <div className="absolute -right-6 -top-6 w-40 h-40 rounded-full bg-radial from-[#D4AF37]/15 to-transparent blur-2xl pointer-events-none" />
        <div className="absolute -left-10 -bottom-10 w-32 h-32 rounded-full bg-[#74C69D]/10 blur-xl pointer-events-none" />

        <div className="flex items-center justify-between gap-3 relative z-10">
          <div className="space-y-1.5 flex-1">
            <h1 className="text-2xl font-black tracking-tight text-white drop-shadow-xs">
              {language === 'bn' ? 'আজকের মুহাসাবাহ' : "Today's Muhasabah"}
            </h1>
            <p className="text-xs text-emerald-100/90 font-medium leading-relaxed max-w-xs">
              {language === 'bn'
                ? '“হিসাব নেওয়ার পূর্বেই নিজেদের হিসাব গ্রহণ করো।” — হযরত উমর (রা.)'
                : '"Account for yourselves before you are held to account." — Umar (R.A.)'}
            </p>

            <div className="pt-2">
              <button
                id="btn-open-my-day"
                onClick={onOpenMyDay}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-black tracking-wide transition-all active:scale-95 shadow-md bg-gradient-to-r from-[#D4AF37] via-[#E5C158] to-[#D4AF37] text-stone-950 border border-white/60 hover:brightness-105"
              >
                <span>{language === 'bn' ? 'দৈনিক প্ল্যানার' : 'Daily Planner'}</span>
                <ChevronRight className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Luxury Analog Clock & Overall Percentage Badge */}
          <div className="flex flex-col items-center shrink-0">
            <div className="relative w-[104px] h-[104px] rounded-full border-2 border-[#D4AF37]/75 bg-[radial-gradient(circle_at_50%_45%,#214F3B_0%,#12281E_68%,#0B1C14_100%)] shadow-[0_8px_24px_rgba(0,0,0,0.42),inset_0_0_0_4px_rgba(212,175,55,0.08)] flex items-center justify-center">
              <div className="absolute inset-[7px] rounded-full border border-[#D4AF37]/30" />
              {Array.from({ length: 12 }).map((_, i) => {
                const angle = i * 30;
                return (
                  <span
                    key={i}
                    className="absolute left-1/2 top-1/2 w-1 h-2.5 rounded-full bg-[#D4AF37] origin-center"
                    style={{ transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(-42px)` }}
                  />
                );
              })}
              <MoonStar className="absolute w-7 h-7 text-[#D4AF37]/25" />

              <div
                className="absolute w-1 h-7 bg-[#F7F1D0] rounded-full origin-bottom bottom-1/2 left-1/2 -translate-x-1/2 shadow-[0_0_5px_rgba(255,255,255,0.3)]"
                style={{ transform: `rotate(${clockDegrees.hr}deg)` }}
              />
              <div
                className="absolute w-1 h-9 bg-[#74C69D] rounded-full origin-bottom bottom-1/2 left-1/2 -translate-x-1/2"
                style={{ transform: `rotate(${clockDegrees.min}deg)` }}
              />
              <div
                className="absolute w-[2px] h-10 bg-[#D4AF37] rounded-full origin-bottom bottom-1/2 left-1/2 -translate-x-1/2"
                style={{ transform: `rotate(${clockDegrees.sec}deg)` }}
              />
              <div className="w-3 h-3 rounded-full bg-[#D4AF37] z-10 ring-2 ring-[#10261C]" />
            </div>

            <span className="text-[10px] font-black tracking-widest text-[#F4E0A5] uppercase mt-1.5">
              {avgPercent}% Daily Goal
            </span>
          </div>
        </div>
        <div className="relative z-10 mt-3 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => onNavigateTab('dhikr')}
            className="min-h-[62px] rounded-2xl border border-[#74C69D]/35 bg-black/20 px-3 py-2 text-left backdrop-blur-md transition-all active:scale-[0.98] hover:bg-black/30"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-[#F3DF95]">
                <BookOpenCheck className="w-4 h-4 text-[#D4AF37]" />
                {language === 'bn' ? 'আজকের যিকির' : "Today's Dhikr"}
              </span>
              <span className="text-[11px] font-black text-[#74C69D]">{realDhikrCount}</span>
            </div>
            <div className="mt-1 text-[10px] font-semibold text-emerald-100/85">
              {language === 'bn' ? 'যিকির সেকশনে যান' : 'Open Dhikr'}
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('salat')}
            className="min-h-[62px] rounded-2xl border border-[#D4AF37]/35 bg-black/20 px-3 py-2 text-left backdrop-blur-md transition-all active:scale-[0.98] hover:bg-black/30"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-[#F3DF95]">
                <Clock className="w-4 h-4 text-[#D4AF37]" />
                {language === 'bn' ? 'পরবর্তী নামাজ' : 'Next Prayer'}
              </span>
              <span className="text-[11px] font-black text-[#74C69D]">{nextPrayer?.time || '—'}</span>
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-[11px] font-black text-white">
              {nextPrayer?.id === 'fajr' && <Sunrise className="w-3.5 h-3.5 text-amber-300" />}
              {nextPrayer?.id === 'dhuhr' && <Sun className="w-3.5 h-3.5 text-yellow-300" />}
              {nextPrayer?.id === 'asr' && <CloudSun className="w-3.5 h-3.5 text-emerald-300" />}
              {nextPrayer?.id === 'maghrib' && <Sunset className="w-3.5 h-3.5 text-orange-300" />}
              {nextPrayer?.id === 'isha' && <MoonStar className="w-3.5 h-3.5 text-teal-300" />}
              <span>{prayerName(nextPrayer)}</span>
            </div>
          </button>
        </div>
      </div>

      <DayIntelligenceCard
        darkMode={darkMode}
        prayers={prayers}
        metrics={metrics}
        dhikrCount={dhikrCount}
      />

      {/* 2. ESSENTIAL DAILY SERVICES & SUMMARY (জরুরি সেবা ও দৈনিক পর্যালোচনা) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <h3
              className={`text-xs font-black uppercase tracking-wider ${
                darkMode ? 'text-stone-300' : 'text-[#1B4332]'
              }`}
            >
              {language === 'bn'
                ? 'দৈনিক সেবা ও সারসংক্ষেপ'
                : 'Daily Services & Summary'}
            </h3>
          </div>
          <span className="text-[10px] font-bold text-stone-400">
            Real-Time • Interactive
          </span>
        </div>

        {/* 2-Column Continuous Balanced Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* 1. Emergency Numbers */}
          <div
            id="card-emergency-numbers"
            onClick={onOpenEmergencyModal}
            className={`cursor-pointer rounded-[22px] p-4 border transition-all duration-200 hover:scale-[1.01] active:scale-98 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-red-900/40 hover:border-red-600/70'
                : 'bg-white border-red-200/80 hover:border-red-500 shadow-[0_6px_20px_rgba(239,68,68,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <div className="w-10 h-10 rounded-2xl bg-red-100 dark:bg-red-950/80 text-red-600 flex items-center justify-center font-black shadow-xs">
                  <ShieldAlert className="w-5 h-5 animate-pulse" />
                </div>
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900/50">
                  999 Hotline
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'জরুরি হেল্পলাইন' : 'Emergency Helpline'}
              </h4>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1 line-clamp-2 leading-snug">
                {language === 'bn'
                  ? 'বাংলাদেশ জাতীয় হেল্পলাইন, অ্যাম্বুলেন্স ও ফায়ার সার্ভিস সরাসরি ডায়াল।'
                  : 'Direct dial national helpline, ambulance & emergency services.'}
              </p>
            </div>
            <div className="mt-3.5 pt-2.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs font-bold text-red-600 dark:text-red-400">
              <span>{language === 'bn' ? 'ডায়ালার খুলুন' : 'Open Helpline'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* 2. Medicine Reminder */}
          <div
            id="card-medicine-reminder"
            onClick={onOpenMedicineModal}
            className={`cursor-pointer rounded-[22px] p-4 border transition-all duration-200 hover:scale-[1.01] active:scale-98 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-amber-800/40 hover:border-[#D4AF37]'
                : 'bg-white border-amber-200/80 hover:border-[#D4AF37] shadow-[0_6px_20px_rgba(212,175,55,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-[#D4AF37] flex items-center justify-center font-black shadow-xs">
                  <Pill className="w-5 h-5" />
                </div>
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  {pendingMedsCount > 0
                    ? `${pendingMedsCount} ${language === 'bn' ? 'বাকি' : 'Pending'}`
                    : (language === 'bn' ? 'সম্পন্ন' : 'All Taken')}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'ঔষধ রিমাইন্ডার' : 'Medicine Reminder'}
              </h4>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1 line-clamp-2 leading-snug">
                {language === 'bn'
                  ? 'নিজের ও পিতা-মাতার নিয়মিত প্রেসক্রিপশন ও স্নুজ নোটিফিকেশন।'
                  : 'Manage personal & family prescriptions with dosage alerts.'}
              </p>
            </div>
            <div className="mt-3.5 pt-2.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs font-bold text-amber-800 dark:text-[#D4AF37]">
              <span>{language === 'bn' ? 'ঔষধ তালিকা' : 'Manage Meds'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* 3. News Section */}
          <div
            id="card-news-bulletin"
            onClick={onOpenNewsModal}
            className={`cursor-pointer rounded-[22px] p-4 border transition-all duration-200 hover:scale-[1.01] active:scale-98 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-teal-800/40 hover:border-[#52B788]'
                : 'bg-white border-teal-200/80 hover:border-[#52B788] shadow-[0_6px_20px_rgba(45,106,79,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <div className="w-10 h-10 rounded-2xl bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black shadow-xs">
                  <Newspaper className="w-5 h-5" />
                </div>
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  Live Feeds
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'সংবাদ বুলেটিন' : 'News Bulletin'}
              </h4>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1 line-clamp-2 leading-snug">
                {language === 'bn'
                  ? 'প্রথম আলো, ডেইলি স্টার, বিবিসি বাংলা ও আন্তর্জাতিক সংবাদ এক নজরে।'
                  : 'Daily trusted national, international and community updates.'}
              </p>
            </div>
            <div className="mt-3.5 pt-2.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs font-bold text-teal-700 dark:text-teal-300">
              <span>{language === 'bn' ? 'শিরোনাম পড়ুন' : 'Read Headlines'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* 4. Daily Summary / Analysis (দৈনিক পর্যালোচনা / সারসংক্ষেপ) */}
          <div
            id="card-daily-summary-analysis"
            onClick={onOpenMyDay}
            className={`cursor-pointer rounded-[22px] p-4 border transition-all duration-200 hover:scale-[1.01] active:scale-98 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-emerald-700/50 hover:border-[#D4AF37]'
                : 'bg-white border-emerald-200/90 hover:border-[#2D6A4F] shadow-[0_6px_20px_rgba(45,106,79,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 text-[#1B4332] dark:text-[#D4AF37] flex items-center justify-center font-black shadow-xs">
                  <Scale className="w-5 h-5" />
                </div>
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  {overallDailyScore}% Score
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'দৈনিক পর্যালোচনা' : 'Daily Summary'}
              </h4>
              <div className="mt-1.5 space-y-1 text-[11px] leading-snug">
                <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                  <span>{language === 'bn' ? 'সালাত:' : 'Salat:'}</span>
                  <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300">
                    {completedPrayersCount}/5 {language === 'bn' ? 'ওয়াক্ত' : 'prayers'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-stone-600 dark:text-stone-300">
                  <span>{language === 'bn' ? 'কুরআন ও যিকির:' : 'Quran & Dhikr:'}</span>
                  <span className="font-mono font-bold text-[#D4AF37]">
                    {quranVersesCount} {language === 'bn' ? 'আয়াত' : 'Ayah'} • {realDhikrCount} {language === 'bn' ? 'যিকির' : 'Dhikr'}
                  </span>
                </div>
                <div className="truncate text-stone-500 dark:text-stone-400 text-[10px] pt-0.5">
                  <span className="font-bold text-stone-700 dark:text-stone-300">
                    {language === 'bn' ? 'নিয়ত: ' : 'Niyyah: '}
                  </span>
                  {activeNiyyahText}
                </div>
              </div>
            </div>
            <div className="mt-3.5 pt-2.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs font-bold text-emerald-700 dark:text-[#D4AF37]">
              <span>{achievementHighlight}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </div>

      {/* 2B. SPIRITUAL ACCOUNTABILITY & INNER PEACE SANCTUARY (মুহাসাবা ও আত্মশুদ্ধি) */}
      <div id="section-spiritual-accountability" className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <h3
              className={`text-xs font-black uppercase tracking-wider ${
                darkMode ? 'text-stone-300' : 'text-[#1B4332]'
              }`}
            >
              {language === 'bn' ? 'মুহাসাবা ও আত্মশুদ্ধি' : 'Spiritual Accountability'}
            </h3>
          </div>
          <span className="text-[10px] font-bold text-[#D4AF37]">
            {language === 'bn' ? '৮টি আধ্যাত্মিক টুলস' : '8 Inner Tools'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* 1. Nafs Self Audit */}
          <button
            type="button"
            id="btn-open-self-audit"
            onClick={onOpenSelfAuditModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-emerald-800/60 hover:border-[#D4AF37]'
                : 'bg-white border-emerald-200 hover:border-[#1B4332] shadow-[0_4px_16px_rgba(27,67,50,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-[#1B4332] dark:text-[#74C69D] flex items-center justify-center font-black">
                  <Sliders className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  {language === 'bn' ? '১-১০ স্কোর' : '1-10 Score'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'মুহাসাবাতুন নাফস' : 'Soul Accounting'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? 'দৈনিক আত্মশুদ্ধি, খুশু ও আধ্যাত্মিক হিসাব।'
                  : 'Daily soul audit, Khushoo rating & spiritual diary.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-[#1B4332] dark:text-[#74C69D]">
              <span>{language === 'bn' ? 'হিসাব করুন' : 'Audit Nafs'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 2. Daily Niyyah */}
          <button
            type="button"
            id="btn-open-daily-niyyah"
            onClick={onOpenNiyyahModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-amber-800/60 hover:border-[#D4AF37]'
                : 'bg-white border-amber-200 hover:border-[#D4AF37] shadow-[0_4px_16px_rgba(212,175,55,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-[#F4E0A5] flex items-center justify-center font-black">
                  <Compass className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  {language === 'bn' ? 'ইখলাস' : 'Sincerity'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'দৈনিক নিয়ত ও সংকল্প' : 'Daily Niyyah & Intent'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? 'সকালের খাঁটি নিয়ত ও রাতের আত্মপর্যালোচনা।'
                  : 'Morning sincere intentions & night accountability.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-amber-800 dark:text-[#D4AF37]">
              <span>{language === 'bn' ? 'নিয়ত নির্ধারণ' : 'Set Intention'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 3. Istighfar Ledger */}
          <button
            type="button"
            id="btn-open-istighfar"
            onClick={onOpenIstighfarModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-teal-800/60 hover:border-[#52B788]'
                : 'bg-white border-teal-200 hover:border-[#52B788] shadow-[0_4px_16px_rgba(45,106,79,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-[#74C69D] flex items-center justify-center font-black">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  {language === 'bn' ? 'তাওবাহ' : 'Tawbah'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'ইস্তিগফার ও তাওবাহ' : 'Istighfar & Repentance'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? '১০০ বার তাসবিহ ও সাইয়্যিদুল ইস্তিগফার।'
                  : '100x counter, Sayyidul Istighfar & habit checklists.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-teal-700 dark:text-[#74C69D]">
              <span>{language === 'bn' ? 'তাওবাহ করুন' : 'Repent Now'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 4. Gratitude Journal */}
          <button
            type="button"
            id="btn-open-gratitude"
            onClick={onOpenGratitudeModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-rose-800/60 hover:border-rose-500'
                : 'bg-white border-rose-200 hover:border-rose-500 shadow-[0_4px_16px_rgba(244,63,94,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 flex items-center justify-center font-black">
                  <Heart className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                  {language === 'bn' ? 'শুকরিয়া' : 'Gratitude'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'শুকর ও নেয়ামত ডায়েরি' : 'Gratitude Journal'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? 'তাহদীস বিন নেয়ামত ও সুস্থতার শুকরিয়া লগ।'
                  : 'Tahdith bin Ni\'mah, health & spiritual gratitude logger.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-rose-700 dark:text-rose-300">
              <span>{language === 'bn' ? 'নেয়ামত লিখুন' : 'Log Blessing'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 5. Good Deeds Tracker */}
          <button
            type="button"
            id="btn-open-good-deeds"
            onClick={onOpenDeedsModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-purple-800/60 hover:border-purple-500'
                : 'bg-white border-purple-200 hover:border-purple-500 shadow-[0_4px_16px_rgba(168,85,247,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 flex items-center justify-center font-black">
                  <Sparkles className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950 text-purple-800 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                  {language === 'bn' ? 'গোপন আমল' : 'Secret Deeds'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'গোপন নেক আমল' : 'Hidden Good Deeds'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? 'সিরুন মাআল্লা — আল্লাহর সন্তুষ্টির গোপন আমল।'
                  : 'Sirr ma\'a Allah — secret good deeds only Allah knows.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-purple-700 dark:text-purple-300">
              <span>{language === 'bn' ? 'আমল ট্র্যাক করুন' : 'Track Deeds'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 6. Audio Sanctuary */}
          <button
            type="button"
            id="btn-open-audio-sanctuary"
            onClick={onOpenAudioSanctuaryModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-cyan-800/60 hover:border-cyan-500'
                : 'bg-white border-cyan-200 hover:border-cyan-500 shadow-[0_4px_16px_rgba(6,182,212,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-100 dark:bg-cyan-950/80 text-cyan-700 dark:text-cyan-300 flex items-center justify-center font-black">
                  <Headphones className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950 text-cyan-800 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800">
                  {language === 'bn' ? 'বৃষ্টি ও আযান' : 'Rain & Azan'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'অডিও প্রশান্তি' : 'Audio Sanctuary'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? 'মৃদু বৃষ্টি, বাতাস ও হারামাইন আযানের আম্বিয়েন্স।'
                  : 'Gentle rain, wind, Haramain Azan & calming ambient audio.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-cyan-700 dark:text-cyan-300">
              <span>{language === 'bn' ? 'শব্দ শুনুন' : 'Play Sounds'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 7. Vow Tracker */}
          <button
            type="button"
            id="btn-open-vows"
            onClick={onOpenVowModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-blue-800/60 hover:border-blue-500'
                : 'bg-white border-blue-200 hover:border-blue-500 shadow-[0_4px_16px_rgba(59,130,246,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 flex items-center justify-center font-black">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  {language === 'bn' ? 'মানত ও ওয়াদা' : 'Vows & Oaths'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'মানত ও কাফফারা' : 'Vow & Kafarah Tracker'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? 'মানত পূরণ, প্রতিজ্ঞা রক্ষা ও কাফফারা ট্র্যাকার।'
                  : 'Nadhr fulfilment, solemn vows & oath accountability.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-blue-700 dark:text-blue-300">
              <span>{language === 'bn' ? 'ওয়াদা পরিচালনা' : 'Manage Vows'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* 8. Anger Reset */}
          <button
            type="button"
            id="btn-open-anger-reset"
            onClick={onOpenAngerResetModal}
            className={`text-left rounded-2xl p-3 border transition-all duration-200 hover:scale-[1.02] active:scale-95 shadow-xs flex flex-col justify-between ${
              darkMode
                ? 'bg-[#15271F] border-orange-800/60 hover:border-orange-500'
                : 'bg-white border-orange-200 hover:border-orange-500 shadow-[0_4px_16px_rgba(249,115,22,0.06)]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <div className="w-8 h-8 rounded-xl bg-orange-100 dark:bg-orange-950/80 text-orange-700 dark:text-orange-300 flex items-center justify-center font-black">
                  <Flame className="w-4 h-4" />
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-orange-50 dark:bg-orange-950 text-orange-800 dark:text-orange-300 border border-orange-200 dark:border-orange-800">
                  {language === 'bn' ? 'সুন্নাহ প্রেসক্রিপশন' : 'Sunnah Reset'}
                </span>
              </div>
              <h4 className="font-extrabold text-[11px] text-stone-900 dark:text-stone-100">
                {language === 'bn' ? 'রাগ ও রিপু নিয়ন্ত্রণ' : 'Anger & Nafs Reset'}
              </h4>
              <p className="text-[9px] text-stone-500 dark:text-stone-400 mt-0.5 leading-snug line-clamp-2">
                {language === 'bn'
                  ? '৫ ধাপের সুন্নাহ রাগ নিরাময়: তাআউউয ও অযু।'
                  : '5-step Sunnah anger reset: Ta\'awwudh, Wudu & posture.'}
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-[9px] font-bold text-orange-700 dark:text-orange-300">
              <span>{language === 'bn' ? 'শান্ত হোন' : 'Cool Down'}</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>
        </div>
      </div>

      {/* 3. 4 CIRCULAR PROGRESS RINGS: Salat 100%, Quran 60%, Tasks 40%, Study 75% */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3
            className={`text-xs font-black uppercase tracking-wider ${
              darkMode ? 'text-stone-300' : 'text-[#1B4332]'
            }`}
          >
            {language === 'bn' ? 'দৈনিক লক্ষ্যমাত্রা' : 'Daily Target Rings'}
          </h3>
          <span className="text-[11px] font-bold text-stone-400">
            {totalDone} {language === 'bn' ? 'টি সম্পন্ন আমল' : 'Completed Actions'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {metrics.map((metric) => {
            const circumference = 2 * Math.PI * 34; // r = 34
            const strokeDashoffset = circumference - (metric.percent / 100) * circumference;

            return (
              <div
                key={metric.id}
                id={`metric-card-${metric.id}`}
                className={`rounded-[20px] p-4 border transition-all duration-200 flex flex-col items-center text-center shadow-xs ${
                  darkMode
                    ? 'bg-[#142B20] border-[#1C3B2E]'
                    : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
                }`}
              >
                {/* Circular Progress Gauge */}
                <div className="relative w-22 h-22 my-1 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 80 80">
                    {/* Background Track */}
                    <circle
                      cx="40"
                      cy="40"
                      r="34"
                      className="text-stone-200/80 dark:text-emerald-950/60"
                      strokeWidth="6"
                      stroke="currentColor"
                      fill="transparent"
                    />
                    {/* Glowing Progress Arc */}
                    <circle
                      cx="40"
                      cy="40"
                      r="34"
                      className="transition-all duration-500 ease-out"
                      strokeWidth="6"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      stroke={metric.id === 'tasks' ? '#D4AF37' : '#2D6A4F'}
                      fill="transparent"
                      style={{
                        filter:
                          metric.percent > 0
                            ? 'drop-shadow(0px 0px 3px rgba(212,175,55,0.4))'
                            : 'none',
                      }}
                    />
                  </svg>

                  {/* Center Content */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-base font-black font-mono tracking-tight text-stone-900 dark:text-stone-100">
                      {metric.percent}%
                    </span>
                    <span className="text-[9px] font-bold text-stone-400">
                      {metric.current}/{metric.total}
                    </span>
                  </div>
                </div>

                <div className="mt-1 font-extrabold text-xs text-stone-800 dark:text-stone-200">
                  {metric.title}
                </div>
                <div className="text-[10px] font-semibold text-stone-400 truncate max-w-full">
                  {metric.sub}
                </div>

                {/* Tactile Quick Increment Button */}
                <button
                  id={`btn-increment-${metric.id}`}
                  onClick={() => {
                    playDhikrClick(soundEnabled);
                    onUpdateMetric(metric.id, 1);
                    showToast(`Logged +1 ${metric.title}`);
                  }}
                  className="mt-2 w-full py-1 px-2 rounded-xl text-[11px] font-black transition-all active:scale-95 bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D] hover:bg-[#D4AF37] hover:text-stone-950 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  <span>{language === 'bn' ? 'লগ করুন' : 'Log'} {metric.title}</span>
                </button>
              </div>
            );
          })}

          {/* Additional daily summary cards */}
          <button
            type="button"
            onClick={onOpenExpenseModal}
            className={`rounded-[20px] p-4 border transition-all duration-200 flex flex-col items-center text-center shadow-xs active:scale-[0.98] ${
              darkMode ? 'bg-[#142B20] border-[#1C3B2E]' : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)]'
            }`}
          >
            <div className="w-12 h-12 rounded-full flex items-center justify-center bg-emerald-950/70 text-[#D4AF37] border border-[#D4AF37]/25">
              <DollarSign className="w-5 h-5" />
            </div>
            <div className="mt-2 font-extrabold text-xs text-stone-800 dark:text-stone-200">
              {language === 'bn' ? 'আজকের হিসাব' : 'Today’s Finance'}
            </div>
            <div className="text-[10px] font-semibold text-stone-500 dark:text-stone-400">
              ৳{Math.round(totalExpensesAmount).toLocaleString()} {language === 'bn' ? 'খরচ' : 'spent'}
            </div>
          </button>

          <button
            type="button"
            onClick={onOpenMedicineModal}
            className={`rounded-[20px] p-4 border transition-all duration-200 flex flex-col items-center text-center shadow-xs active:scale-[0.98] ${
              darkMode ? 'bg-[#142B20] border-[#1C3B2E]' : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)]'
            }`}
          >
            <div className="w-12 h-12 rounded-full flex items-center justify-center bg-amber-950/70 text-[#D4AF37] border border-[#D4AF37]/25">
              <Pill className="w-5 h-5" />
            </div>
            <div className="mt-2 font-extrabold text-xs text-stone-800 dark:text-stone-200">
              {language === 'bn' ? 'ঔষধ অবস্থা' : 'Medicine Status'}
            </div>
            <div className="text-[10px] font-semibold text-stone-500 dark:text-stone-400">
              {pendingMedsCount} {language === 'bn' ? 'টি বাকি' : 'pending'}
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
