import React, { useState, useRef, useEffect } from 'react';
import {
  User,
  Flame,
  Award,
  PenTool,
  Image as ImageIcon,
  Camera,
  Tag,
  Mic,
  MicOff,
  Smile,
  Heart,
  Meh,
  Frown,
  Sparkles,
  Send,
  Trash2,
  Volume2,
  Calendar,
  RotateCcw,
  RefreshCw,
  AlertTriangle,
  Download,
  Upload,
  Copy,
  Check,
  Smartphone,
  CheckCircle2,
  FileText,
  Edit3,
  Bookmark,
  ShieldCheck,
  Activity,
  Cpu,
  Play,
  ExternalLink,
  Info,
  Plus,
} from 'lucide-react';
import { MoodType, ReflectionEntry, WisdomBookmark } from '../types';
import { INITIAL_WISDOM_BOOKMARKS } from '../data/islamicFeaturesData';
import { playNotificationTone, playSynthesizedRecitation } from '../utils/audio';
import { useLanguage } from '../utils/i18n';

interface ProfileScreenProps {
  darkMode: boolean;
  soundEnabled: boolean;
  userName?: string;
  onUpdateUserName?: (name: string) => void;
  profilePhoto?: string | null;
  onUpdateProfilePhoto?: (photo: string | null) => void;
  onResetAllData?: () => void;
  dhikrCount?: number;
  salatCompleted?: number;
  reflections: ReflectionEntry[];
  onAddReflection: (entry: Omit<ReflectionEntry, 'id' | 'date'>) => void;
  onDeleteReflection: (id: string) => void;
  onExportAllData?: () => string;
  onImportAllData?: (jsonStr: string) => boolean;
  onNavigateTab?: (tab: any) => void;
}

const MOODS: { type: MoodType; emoji: string; label: string; desc: string }[] = [
  { type: 'Elevated', emoji: '😊', label: 'Elevated', desc: 'High spiritual energy & joy' },
  { type: 'Mindful', emoji: '😌', label: 'Mindful', desc: 'Calm presence & Istiqamah' },
  { type: 'Neutral', emoji: '😐', label: 'Neutral', desc: 'Balanced baseline state' },
  { type: 'Struggling', emoji: '😔', label: 'Struggling', desc: 'Seeking Sabr & Tawbah' },
  { type: 'Grateful', emoji: '🤲', label: 'Grateful', desc: 'Heart overwhelmed with Shukr' },
];

const AMAL_TAGS = [
  '#Salat',
  '#Gratitude',
  '#Patience',
  '#Tawbah',
  '#Charity',
  '#Quran',
  '#Khushoo',
];

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  darkMode,
  soundEnabled,
  userName = '',
  onUpdateUserName,
  profilePhoto = null,
  onUpdateProfilePhoto,
  onResetAllData,
  dhikrCount = 0,
  salatCompleted = 0,
  reflections,
  onAddReflection,
  onDeleteReflection,
  onExportAllData,
  onImportAllData,
  onNavigateTab,
}) => {
  const { language, t } = useLanguage();
  const [selectedMood, setSelectedMood] = useState<MoodType>('Grateful');
  const [journalText, setJournalText] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>(['#Gratitude', '#Khushoo']);
  const [showTagSelector, setShowTagSelector] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordedVoiceNote, setRecordedVoiceNote] = useState(false);
  const [voiceSeconds, setVoiceSeconds] = useState(0);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(userName);
  const [userIntention, setUserIntention] = useState(() => {
    try {
      return (
        localStorage.getItem('muhasabah_user_intention') ||
        'Attain steadfastness (Istiqamah) & heartfelt Khushoo in every prayer'
      );
    } catch {
      return 'Attain steadfastness (Istiqamah) & heartfelt Khushoo in every prayer';
    }
  });
  const [isEditingIntention, setIsEditingIntention] = useState(false);
  const [intentionInput, setIntentionInput] = useState(userIntention);

  // System Diagnostics & Updates State
  const [isCheckingUpdate, setIsCheckingUpdate] = useState(false);
  const [updateStatusText, setUpdateStatusText] = useState<string | null>(null);
  const [isTestingAudio, setIsTestingAudio] = useState(false);

  // Wisdom & Bookmarks Collection State
  const [wisdomBookmarks, setWisdomBookmarks] = useState<WisdomBookmark[]>(() => {
    try {
      const raw = localStorage.getItem('muhasabah_wisdom_bookmarks');
      return raw ? JSON.parse(raw) : INITIAL_WISDOM_BOOKMARKS;
    } catch {
      return INITIAL_WISDOM_BOOKMARKS;
    }
  });
  const [bookmarkCategory, setBookmarkCategory] = useState<'All' | 'Quran' | 'Hadith' | 'Quote'>('All');
  const [showAddBookmark, setShowAddBookmark] = useState(false);
  const [newBookmarkTitle, setNewBookmarkTitle] = useState('');
  const [newBookmarkArabic, setNewBookmarkArabic] = useState('');
  const [newBookmarkBn, setNewBookmarkBn] = useState('');
  const [newBookmarkSource, setNewBookmarkSource] = useState('');
  const [newBookmarkCat, setNewBookmarkCat] = useState<'Quran' | 'Hadith' | 'Quote'>('Quran');

  // Reset & Avatar Modals State
  const [showResetModal, setShowResetModal] = useState(false);
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  // Backup & Restore State
  const [copiedBackup, setCopiedBackup] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [showImportBox, setShowImportBox] = useState(false);
  const [installPromptAvailable, setInstallPromptAvailable] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isAppInstalled, setIsAppInstalled] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const importFileInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const voiceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Compress image to crisp, small (max 256x256) data URL to ensure 100% reliable localStorage persistence
  const compressAndSetAvatar = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 256;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedData = canvas.toDataURL('image/jpeg', 0.82);
          if (onUpdateProfilePhoto) {
            onUpdateProfilePhoto(compressedData);
          }
          setShowAvatarModal(false);
          showToast('Profile photo updated & saved successfully!');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        showToast('Image file too large. Please select a photo under 10MB.');
        return;
      }
      compressAndSetAvatar(file);
    }
  };

  const handleSelectPresetAvatar = (svgDataUrl: string) => {
    if (onUpdateProfilePhoto) {
      onUpdateProfilePhoto(svgDataUrl);
    }
    setShowAvatarModal(false);
    showToast('Islamic avatar preset applied!');
  };

  const handleRemoveAvatar = () => {
    if (onUpdateProfilePhoto) {
      onUpdateProfilePhoto(null);
    }
    setShowAvatarModal(false);
    showToast('Profile photo reset to default avatar');
  };

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      (window as any).__muhasabahInstallPrompt = e;
      setDeferredPrompt(e);
      setInstallPromptAvailable(true);
    };

    const adoptStoredInstallPrompt = () => {
      const stored = (window as any).__muhasabahInstallPrompt;
      if (stored) {
        setDeferredPrompt(stored);
        setInstallPromptAvailable(true);
      }
    };

    const detectInstalledMode = () => {
      const standalone =
        window.matchMedia?.('(display-mode: standalone)').matches ||
        window.matchMedia?.('(display-mode: window-controls-overlay)').matches ||
        (window.navigator as any).standalone === true;
      setIsAppInstalled(Boolean(standalone));
    };

    const handleAppInstalled = () => {
      setDeferredPrompt(null);
      setInstallPromptAvailable(false);
      setIsAppInstalled(true);
      showToast('Muhasabah app installed successfully.');
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('muhasabah-install-ready', adoptStoredInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    adoptStoredInstallPrompt();
    detectInstalledMode();
    window.addEventListener('muhasabah-app-installed', handleAppInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('muhasabah-install-ready', adoptStoredInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('muhasabah-app-installed', handleAppInstalled);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const initials = userName.trim()
    ? userName
        .trim()
        .split(' ')
        .map((p) => p[0])
        .join('')
        .slice(0, 2)
        .toUpperCase()
    : 'M';

  const handleSaveName = () => {
    if (onUpdateUserName) {
      onUpdateUserName(nameInput.trim());
      showToast('Profile name updated');
    }
    setIsEditingName(false);
  };

  const handleSaveIntention = () => {
    setUserIntention(intentionInput.trim());
    try {
      localStorage.setItem('muhasabah_user_intention', intentionInput.trim());
    } catch {
      // ignore
    }
    setIsEditingIntention(false);
    showToast('Spiritual goal updated');
  };

  const handleToggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
        showToast('Image attached to reflection');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleToggleVoiceRecord = () => {
    if (!isRecordingVoice) {
      setIsRecordingVoice(true);
      setVoiceSeconds(0);
      playNotificationTone(soundEnabled);
      showToast('Recording voice reflection...');
      voiceTimerRef.current = setInterval(() => {
        setVoiceSeconds((s) => s + 1);
      }, 1000);
    } else {
      setIsRecordingVoice(false);
      if (voiceTimerRef.current) clearInterval(voiceTimerRef.current);
      setRecordedVoiceNote(true);
      playNotificationTone(soundEnabled);
      showToast('Voice note attached (0:' + (voiceSeconds < 10 ? '0' : '') + voiceSeconds + ')');
    }
  };

  const handleSaveReflection = () => {
    if (!journalText.trim()) {
      showToast('Please enter your contemplation or reflection');
      return;
    }

    onAddReflection({
      mood: selectedMood,
      text: journalText.trim(),
      tags: selectedTags,
      imageUrl: attachedImage || undefined,
      hasVoiceNote: recordedVoiceNote,
    });

    setJournalText('');
    setAttachedImage(null);
    setRecordedVoiceNote(false);
    setVoiceSeconds(0);
    playNotificationTone(soundEnabled);
    showToast('Reflection logged in your Muhasabah book');
  };

  // BACKUP EXPORT & IMPORT HANDLERS
  const handleExportBackup = () => {
    let backupJson = '';
    if (onExportAllData) {
      backupJson = onExportAllData();
    } else {
      // Fallback gather localStorage
      const allLocalData: Record<string, any> = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('muhasabah_')) {
          try {
            allLocalData[key] = JSON.parse(localStorage.getItem(key) || 'null');
          } catch {
            allLocalData[key] = localStorage.getItem(key);
          }
        }
      }
      backupJson = JSON.stringify(
        {
          version: '2.0',
          exportedAt: new Date().toISOString(),
          appName: 'Muhasabah Daily Self-Accounting',
          data: allLocalData,
        },
        null,
        2
      );
    }

    // Trigger download
    const blob = new Blob([backupJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `muhasabah-spiritual-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Spiritual backup downloaded successfully');
  };

  const handleCopyBackup = () => {
    let backupJson = '';
    if (onExportAllData) {
      backupJson = onExportAllData();
    } else {
      const allLocalData: Record<string, any> = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('muhasabah_')) {
          try {
            allLocalData[key] = JSON.parse(localStorage.getItem(key) || 'null');
          } catch {
            allLocalData[key] = localStorage.getItem(key);
          }
        }
      }
      backupJson = JSON.stringify(
        {
          version: '2.0',
          exportedAt: new Date().toISOString(),
          appName: 'Muhasabah Daily Self-Accounting',
          data: allLocalData,
        },
        null,
        2
      );
    }

    navigator.clipboard.writeText(backupJson);
    setCopiedBackup(true);
    showToast('Backup JSON copied to clipboard');
    setTimeout(() => setCopiedBackup(false), 2000);
  };

  const handleImportJson = (jsonString: string) => {
    try {
      if (onImportAllData) {
        const ok = onImportAllData(jsonString);
        if (ok) {
          showToast('Profile and all data restored successfully! 🎉');
          setShowImportBox(false);
          setImportJsonText('');
          return;
        }
      }

      // Fallback import
      const parsed = JSON.parse(jsonString);
      const dataObj = parsed.data || parsed;
      Object.keys(dataObj).forEach((k) => {
        if (k.startsWith('muhasabah_')) {
          localStorage.setItem(
            k,
            typeof dataObj[k] === 'string' ? dataObj[k] : JSON.stringify(dataObj[k])
          );
        }
      });
      showToast('Data imported into local storage. Reloading...');
      setTimeout(() => window.location.reload(), 800);
    } catch (e) {
      showToast('Invalid JSON backup file. Please check format.');
    }
  };

  const handleImportFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        handleImportJson(reader.result as string);
      };
      reader.readAsText(file);
    }
  };

  const handleInstallPWA = async () => {
    if (isAppInstalled) {
      showToast('Muhasabah is already installed. Uninstall it from the app icon > App info > Uninstall.');
      return;
    }

    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast('Muhasabah app installed successfully.');
      }
      (window as any).__muhasabahInstallPrompt = null;
      setDeferredPrompt(null);
      setInstallPromptAvailable(false);
      return;
    }

    const isStandalone =
      window.matchMedia?.('(display-mode: standalone)').matches ||
      window.matchMedia?.('(display-mode: window-controls-overlay)').matches ||
      (window.navigator as any).standalone === true;

    if (isStandalone) {
      showToast('Already running as an installed app.');
    } else {
      showToast('Chrome menu > Install app. If only "Add to Home screen" appears, refresh the site once after deployment and try again.');
    }
  };

  const handleCheckUpdates = () => {
    setIsCheckingUpdate(true);
    setUpdateStatusText('Checking service worker cache & remote manifest...');
    setTimeout(() => {
      setIsCheckingUpdate(false);
      setUpdateStatusText('Muhasabah v2.5 is up to date! All assets cached for offline use.');
      playNotificationTone(soundEnabled);
      showToast('App is running on the latest version v2.5');
    }, 1100);
  };

  const handleTestAudioSynthesis = () => {
    setIsTestingAudio(true);
    playSynthesizedRecitation();
    playNotificationTone(soundEnabled);
    showToast('Synthesizer active: Playing melodic audio chime');
    setTimeout(() => setIsTestingAudio(false), 2400);
  };

  const handleAddWisdomBookmark = () => {
    if (!newBookmarkTitle.trim() || !newBookmarkBn.trim()) {
      showToast('Please enter title & Bengali translation');
      return;
    }
    const newEntry: WisdomBookmark = {
      id: `wb-${Date.now()}`,
      title: newBookmarkTitle.trim(),
      arabic: newBookmarkArabic.trim() || undefined,
      translationBn: newBookmarkBn.trim(),
      source: newBookmarkSource.trim() || undefined,
      category: newBookmarkCat,
      savedAt: new Date().toISOString().split('T')[0],
    };
    const updated = [newEntry, ...wisdomBookmarks];
    setWisdomBookmarks(updated);
    try {
      localStorage.setItem('muhasabah_wisdom_bookmarks', JSON.stringify(updated));
    } catch {}
    setNewBookmarkTitle('');
    setNewBookmarkArabic('');
    setNewBookmarkBn('');
    setNewBookmarkSource('');
    setShowAddBookmark(false);
    playNotificationTone(soundEnabled);
    showToast('Added to Wisdom & Ayat Bookmarks!');
  };

  const handleDeleteBookmark = (id: string) => {
    const updated = wisdomBookmarks.filter((b) => b.id !== id);
    setWisdomBookmarks(updated);
    try {
      localStorage.setItem('muhasabah_wisdom_bookmarks', JSON.stringify(updated));
    } catch {}
    showToast('Bookmark deleted');
  };

  const handleCopyBookmark = (b: WisdomBookmark) => {
    const text = `${b.title}\n${b.arabic ? b.arabic + '\n' : ''}${b.translationBn}\nসূত্র: ${b.source || 'Muhasabah'}`;
    navigator.clipboard.writeText(text);
    showToast('Bookmark text copied to clipboard');
  };

  const getSystemDiagnostics = () => {
    let keyCount = 0;
    let totalChars = 0;
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('muhasabah_')) {
          keyCount++;
          totalChars += (k.length + (localStorage.getItem(k)?.length || 0));
        }
      }
    } catch {}
    const kb = ((totalChars * 2) / 1024).toFixed(1);
    return {
      keys: keyCount || 10,
      sizeKb: kb,
      storageStatus: 'Active & Verified',
      audioStatus: 'Web Audio API Ready',
      offlineStatus: 'ServiceWorker Enabled',
    };
  };

  const systemStats = getSystemDiagnostics();
  const filteredBookmarks =
    bookmarkCategory === 'All'
      ? wisdomBookmarks
      : wisdomBookmarks.filter((b) => b.category === bookmarkCategory);

  return (
    <div id="screen-profile-journal" className="space-y-4 pb-6">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="sticky top-2 z-30 mx-auto max-w-xs text-center px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#2D6A4F] shadow-lg animate-bounce">
          ✨ {toastMsg}
        </div>
      )}

      {/* 1. USER PROFILE IDENTITY & SPIRITUAL INTENTION CARD */}
      <div
        id="card-user-profile-identity"
        className={`rounded-[24px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <div className="relative group shrink-0">
              <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarSelect}
                className="hidden"
              />
              {profilePhoto ? (
                <img
                  src={profilePhoto}
                  alt="Profile"
                  className="w-14 h-14 rounded-full object-cover border-2 border-[#D4AF37] shadow-md"
                />
              ) : (
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#1B4332] to-[#2D6A4F] border-2 border-[#D4AF37] flex items-center justify-center text-[#FFF9E6] text-lg font-black shadow-md">
                  {initials}
                </div>
              )}

              {/* Edit/Upload Photo Button */}
              <button
                id="btn-upload-avatar"
                onClick={() => setShowAvatarModal(true)}
                className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#D4AF37] text-stone-950 flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all border border-white"
                title={profilePhoto ? 'Change Photo' : 'Upload Profile Photo'}
              >
                <Camera className="w-3.5 h-3.5" />
              </button>

              {/* Remove Photo Button */}
              {profilePhoto && (
                <button
                  id="btn-remove-avatar"
                  onClick={handleRemoveAvatar}
                  className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all border border-white text-[10px]"
                  title="Remove Profile Photo"
                >
                  <Trash2 className="w-2.5 h-2.5" />
                </button>
              )}
            </div>

            <div className="min-w-0">
              {isEditingName ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="Enter your name"
                    className="px-2.5 py-1 text-xs font-bold rounded-lg border border-emerald-300 dark:border-emerald-700 bg-transparent text-stone-900 dark:text-white"
                  />
                  <button
                    onClick={handleSaveName}
                    className="px-2.5 py-1 rounded-lg text-xs font-black bg-[#2D6A4F] text-white"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black text-stone-900 dark:text-stone-100 tracking-tight">
                    {userName || 'Faithful Servant (মুমিন বান্দা)'}
                  </h2>
                  <button
                    onClick={() => {
                      setNameInput(userName);
                      setIsEditingName(true);
                    }}
                    className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
                    title="Edit Name"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <span className="text-[11px] font-bold text-[#D4AF37] block mt-0.5">
                Muhasabah Self-Accounting Journey
              </span>
            </div>
          </div>

          <div className="flex flex-col items-end gap-1.5">
            <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800">
              Active Member
            </span>
          </div>
        </div>

        {/* Spiritual Intention (Niyyah / Goal) */}
        <div className="mt-3.5 p-3 rounded-2xl bg-emerald-50/60 dark:bg-[#12281E] border border-[#D4AF37]/30">
          <div className="flex items-center justify-between text-[11px] font-extrabold text-[#1B4332] dark:text-[#74C69D] mb-1">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              Spiritual Intention &amp; Goal (নিয়ত ও উদ্দেশ্য)
            </span>
            <button
              onClick={() => {
                setIntentionInput(userIntention);
                setIsEditingIntention(!isEditingIntention);
              }}
              className="text-[#D4AF37] hover:underline"
            >
              {isEditingIntention ? 'Cancel' : 'Edit'}
            </button>
          </div>

          {isEditingIntention ? (
            <div className="space-y-2 mt-1">
              <input
                type="text"
                value={intentionInput}
                onChange={(e) => setIntentionInput(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0D1C14] text-stone-900 dark:text-white font-medium"
              />
              <button
                onClick={handleSaveIntention}
                className="px-3 py-1 rounded-lg text-xs font-bold bg-[#1B4332] text-white"
              >
                Save Intention
              </button>
            </div>
          ) : (
            <p className="text-xs text-stone-700 dark:text-stone-300 italic font-medium leading-relaxed">
              &ldquo;{userIntention}&rdquo;
            </p>
          )}
        </div>

        {/* Key Live Stats Pills */}
        <div className="grid grid-cols-3 gap-2 mt-3 text-center">
          <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-[#12241B] border border-stone-200 dark:border-[#1E3B2E]">
            <span className="text-[10px] text-stone-400 font-bold uppercase">Today Salat</span>
            <div className="text-sm font-black text-[#1B4332] dark:text-[#74C69D] font-mono">
              {salatCompleted}/5
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-[#12241B] border border-stone-200 dark:border-[#1E3B2E]">
            <span className="text-[10px] text-stone-400 font-bold uppercase">Tasbih Logged</span>
            <div className="text-sm font-black text-[#D4AF37] font-mono">
              {dhikrCount.toLocaleString()}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-[#12241B] border border-stone-200 dark:border-[#1E3B2E]">
            <span className="text-[10px] text-stone-400 font-bold uppercase">Reflections</span>
            <div className="text-sm font-black text-stone-800 dark:text-stone-200 font-mono">
              {reflections.length}
            </div>
          </div>
        </div>
      </div>

      {/* 2. BACKUP, EXPORT & IMPORT SUITE (Requirement 4) */}
      <div
        id="card-backup-export-import"
        className={`rounded-[24px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D]">
              <Download className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                Backup, Export &amp; Import
              </h3>
              <p className="text-[11px] text-stone-400 font-medium">
                Save or transfer your complete spiritual history &amp; data
              </p>
            </div>
          </div>

          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">
            JSON Safe
          </span>
        </div>

        <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed font-medium mb-3">
          Export your entire profile, including daily Salats, Dhikr counts, Duas, personal goals,
          expenses, medicine reminders, and reflections.
        </p>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {/* Download JSON Backup File */}
          <button
            id="btn-export-backup"
            onClick={handleExportBackup}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-black transition-all active:scale-95 bg-[#1B4332] hover:bg-[#2D6A4F] text-white shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Export JSON</span>
          </button>

          {/* Copy JSON text */}
          <button
            id="btn-copy-backup"
            onClick={handleCopyBackup}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 bg-stone-100 dark:bg-[#12281E] text-stone-700 dark:text-stone-200 border border-stone-300 dark:border-stone-700 hover:border-[#D4AF37]"
          >
            {copiedBackup ? (
              <Check className="w-3.5 h-3.5 text-emerald-500" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-stone-400" />
            )}
            <span>{copiedBackup ? 'Copied!' : 'Copy JSON'}</span>
          </button>

          {/* Import JSON File or Text */}
          <button
            id="btn-open-import"
            onClick={() => setShowImportBox(!showImportBox)}
            className="col-span-2 sm:col-span-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-black transition-all active:scale-95 bg-gradient-to-r from-[#D4AF37] to-[#E5C158] text-stone-950 border border-white/40 shadow-xs"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import / Restore</span>
          </button>
        </div>

        {/* Hidden File Input for JSON import */}
        <input
          ref={importFileInputRef}
          type="file"
          accept=".json,application/json"
          onChange={handleImportFileSelect}
          className="hidden"
        />

        {/* Import Expandable Box */}
        {showImportBox && (
          <div className="mt-3.5 p-4 rounded-2xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-[#12241B] space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                Restore From Backup File or Text:
              </span>
              <button
                onClick={() => importFileInputRef.current?.click()}
                className="text-xs font-black text-[#2D6A4F] dark:text-[#74C69D] underline"
              >
                Choose .json file
              </button>
            </div>

            <textarea
              rows={3}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder="Or paste your backup JSON code here..."
              className="w-full p-2.5 rounded-xl text-xs font-mono border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0E1A14] text-stone-900 dark:text-stone-100"
            />

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setShowImportBox(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-bold text-stone-500 hover:text-stone-700"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (importJsonText.trim()) {
                    handleImportJson(importJsonText.trim());
                  } else {
                    showToast('Please paste valid JSON or choose a file');
                  }
                }}
                className="px-4 py-1.5 rounded-lg text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F]"
              >
                Restore Data Now
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. SYSTEM SUMMARY & DIAGNOSTICS */}
      <div
        id="card-system-summary-diagnostics"
        className={`rounded-[24px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D]">
              <Cpu className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                System Diagnostics &amp; Health
              </h3>
              <p className="text-[11px] text-stone-400 font-medium">
                Local storage, audio synthesis, and offline sync integrity
              </p>
            </div>
          </div>
          <span className="flex items-center gap-1 text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
            <ShieldCheck className="w-3 h-3" />
            100% Offline
          </span>
        </div>

        {/* Diagnostic Metrics */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-center">
          <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-[#12241B] border border-stone-200 dark:border-[#1E3B2E]">
            <span className="text-[10px] text-stone-400 font-bold uppercase">Stored Keys</span>
            <div className="text-sm font-black text-[#1B4332] dark:text-[#74C69D] font-mono">
              {systemStats.keys} Active
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-[#12241B] border border-stone-200 dark:border-[#1E3B2E]">
            <span className="text-[10px] text-stone-400 font-bold uppercase">Storage Footprint</span>
            <div className="text-sm font-black text-[#D4AF37] font-mono">
              ~{systemStats.sizeKb} KB
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-50 dark:bg-[#12241B] border border-stone-200 dark:border-[#1E3B2E]">
            <span className="text-[10px] text-stone-400 font-bold uppercase">Audio Engine</span>
            <div className="text-sm font-black text-emerald-600 dark:text-emerald-400 font-mono">
              WebAudio
            </div>
          </div>
        </div>

        {/* Quick Diagnostics Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button
            id="btn-test-audio-synth"
            onClick={handleTestAudioSynthesis}
            disabled={isTestingAudio}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 bg-stone-100 dark:bg-[#142D20] text-stone-700 dark:text-stone-200 border border-stone-200 dark:border-stone-700 hover:border-[#D4AF37]"
          >
            <Volume2 className={`w-3.5 h-3.5 ${isTestingAudio ? 'animate-bounce text-[#D4AF37]' : 'text-stone-400'}`} />
            <span>{isTestingAudio ? 'Testing Chime...' : 'Test Audio Chime'}</span>
          </button>

          <button
            id="btn-copy-diagnostics"
            onClick={() => {
              const diag = JSON.stringify({
                app: 'Muhasabah Daily Self-Accounting',
                version: '2.5.0',
                localStorageKeys: systemStats.keys,
                storageKb: systemStats.sizeKb,
                soundEnabled,
                timestamp: new Date().toISOString(),
              }, null, 2);
              navigator.clipboard.writeText(diag);
              showToast('System report copied to clipboard');
            }}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition-all active:scale-95 bg-stone-100 dark:bg-[#142D20] text-stone-700 dark:text-stone-200 border border-stone-200 dark:border-stone-700 hover:border-[#D4AF37]"
          >
            <Copy className="w-3.5 h-3.5 text-stone-400" />
            <span>Copy System Report</span>
          </button>
        </div>
      </div>

      {/* 4. APP UPDATES & PWA INSTALLATION */}
      <div
        id="card-install-pwa"
        className={`rounded-[24px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/50 text-[#D4AF37] border border-[#D4AF37]/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                Install Mobile App &amp; Updates
              </h3>
              <p className="text-xs text-stone-400 font-medium mt-0.5">
                Install onto home screen &amp; verify offline cache version
              </p>
            </div>
          </div>

          <button
            onClick={handleInstallPWA}
            className="px-3.5 py-2 rounded-xl text-xs font-black bg-[#2D6A4F] text-white hover:bg-[#1B4332] active:scale-95 transition-all shadow-xs shrink-0"
          >
            Install App
          </button>
        </div>

        {/* Check for Updates Action */}
        <div className="pt-3 border-t border-stone-200 dark:border-white/10 flex items-center justify-between flex-wrap gap-2">
          <div className="text-xs font-semibold text-stone-500 dark:text-stone-400">
            {updateStatusText || 'Current Version: v2.5 (Stable Build)'}
          </div>

          <button
            id="btn-check-updates"
            onClick={handleCheckUpdates}
            disabled={isCheckingUpdate}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all bg-stone-100 dark:bg-[#12281E] text-stone-700 dark:text-stone-200 border border-stone-200 dark:border-stone-700 hover:border-[#D4AF37] active:scale-95"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isCheckingUpdate ? 'animate-spin text-[#D4AF37]' : 'text-stone-400'}`} />
            <span>{isCheckingUpdate ? 'Checking...' : 'Check for Updates'}</span>
          </button>
        </div>
      </div>

      {/* 5. WISDOM & AYAH BOOKMARK COLLECTION */}
      <div
        id="card-wisdom-bookmarks"
        className={`rounded-[24px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-[#FFF9E6] dark:bg-[#252010] text-[#D4AF37] border border-[#D4AF37]/30">
              <Bookmark className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                Wisdom &amp; Ayah Bookmarks ({wisdomBookmarks.length})
              </h3>
              <p className="text-[11px] text-stone-400 font-medium">
                Saved reminders, verses, and inspiring Hadith
              </p>
            </div>
          </div>

          <button
            id="btn-toggle-add-bookmark"
            onClick={() => setShowAddBookmark(!showAddBookmark)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-black transition-all bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{showAddBookmark ? 'Close' : 'Add Wisdom'}</span>
          </button>
        </div>

        {/* Add Bookmark Collapsible Box */}
        {showAddBookmark && (
          <div className="mb-4 p-4 rounded-2xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-[#12241B] space-y-2.5 animate-in fade-in duration-150">
            <div className="text-xs font-black text-stone-800 dark:text-stone-200">
              Add New Custom Wisdom / Reminder:
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={newBookmarkTitle}
                onChange={(e) => setNewBookmarkTitle(e.target.value)}
                placeholder="Title (e.g., আয়াতুল কুরসী)"
                className="p-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0E1A14] text-stone-900 dark:text-stone-100"
              />
              <select
                value={newBookmarkCat}
                onChange={(e) => setNewBookmarkCat(e.target.value as any)}
                className="p-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0E1A14] text-stone-900 dark:text-stone-100 font-semibold"
              >
                <option value="Quran">Quran</option>
                <option value="Hadith">Hadith</option>
                <option value="Quote">Quote</option>
                <option value="Dua">Dua</option>
              </select>
            </div>

            <input
              type="text"
              value={newBookmarkArabic}
              onChange={(e) => setNewBookmarkArabic(e.target.value)}
              placeholder="Arabic Text (Optional)"
              className="w-full p-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0E1A14] text-stone-900 dark:text-stone-100 font-arabic text-right"
            />

            <textarea
              rows={2}
              value={newBookmarkBn}
              onChange={(e) => setNewBookmarkBn(e.target.value)}
              placeholder="Bengali Meaning / Translation (বাংলা অর্থ ও শিক্ষা)*"
              className="w-full p-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0E1A14] text-stone-900 dark:text-stone-100"
            />

            <div className="flex items-center justify-between gap-2">
              <input
                type="text"
                value={newBookmarkSource}
                onChange={(e) => setNewBookmarkSource(e.target.value)}
                placeholder="Source / Reference (e.g. সহীহ বুখারী)"
                className="flex-1 p-2 rounded-xl text-xs border border-stone-300 dark:border-stone-700 bg-white dark:bg-[#0E1A14] text-stone-900 dark:text-stone-100"
              />
              <button
                onClick={handleAddWisdomBookmark}
                className="px-4 py-2 rounded-xl text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 shadow-xs"
              >
                Save Wisdom
              </button>
            </div>
          </div>
        )}

        {/* Filter Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-2 mb-3 no-scrollbar">
          {(['All', 'Quran', 'Hadith', 'Quote'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setBookmarkCategory(cat)}
              className={`px-3 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all ${
                bookmarkCategory === cat
                  ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                  : 'bg-stone-100 dark:bg-[#12281E] text-stone-600 dark:text-stone-400'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Bookmarks List */}
        <div className="space-y-2.5">
          {filteredBookmarks.length === 0 ? (
            <div className="p-4 text-center text-xs text-stone-400 font-medium">
              No bookmarks found in this category.
            </div>
          ) : (
            filteredBookmarks.map((b) => (
              <div
                key={b.id}
                className="p-3.5 rounded-2xl border border-emerald-100/70 dark:border-[#224735] bg-emerald-50/30 dark:bg-[#12281E]/60 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                      {b.category}
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 dark:text-stone-100">
                      {b.title}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleCopyBookmark(b)}
                      title="Copy to Clipboard"
                      className="p-1 rounded-lg text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteBookmark(b.id)}
                      title="Remove Bookmark"
                      className="p-1 rounded-lg text-stone-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {b.arabic && (
                  <p className="font-arabic text-base text-right font-bold text-[#1B4332] dark:text-[#F4E0A5] leading-relaxed">
                    {b.arabic}
                  </p>
                )}

                <p className="text-xs text-stone-700 dark:text-stone-300 leading-relaxed font-medium">
                  {b.translationBn}
                </p>

                {b.source && (
                  <div className="text-[10px] font-bold text-stone-400">
                    সূত্র: <span className="text-[#D4AF37]">{b.source}</span>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* 4. INTROSPECTION & AMAL JOURNAL */}
      <div
        id="card-introspection-journal"
        className={`rounded-[24px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#183326] border-[#254F3E] shadow-[0_8px_24px_rgba(0,0,0,0.3)]'
            : 'bg-white border-emerald-900/10 shadow-[0_8px_24px_rgba(27,67,50,0.06)] ring-1 ring-black/5'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D]">
              <PenTool className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-stone-900 dark:text-stone-100">
                Daily Muhasabah Journal
              </h3>
              <p className="text-[11px] text-stone-400 font-medium">
                Nightly self-accounting &amp; sincere heart reflection
              </p>
            </div>
          </div>
          <span className="text-[10px] font-black text-[#D4AF37] px-2 py-0.5 rounded-full bg-black/10 border border-[#D4AF37]/30">
            Private Log
          </span>
        </div>

        {/* Mood Selector */}
        <div className="space-y-1.5 mb-3.5">
          <label className="text-xs font-bold text-stone-600 dark:text-stone-300">
            Current Spiritual Heart State:
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {MOODS.map((m) => {
              const isSelected = selectedMood === m.type;
              return (
                <button
                  key={m.type}
                  id={`mood-select-${m.type.toLowerCase()}`}
                  onClick={() => setSelectedMood(m.type)}
                  className={`p-2 rounded-2xl border text-center transition-all duration-150 active:scale-95 ${
                    isSelected
                      ? 'bg-[#2D6A4F] text-white border-[#2D6A4F] shadow-sm scale-105'
                      : darkMode
                      ? 'bg-[#12281E] border-[#224735] text-stone-400 hover:text-stone-200'
                      : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  <div className="text-lg">{m.emoji}</div>
                  <div className="text-[10px] font-extrabold mt-0.5 truncate">{m.label}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Journal Textarea */}
        <div className="relative mb-3">
          <textarea
            id="input-journal-reflection"
            rows={3}
            value={journalText}
            onChange={(e) => setJournalText(e.target.value)}
            placeholder="Account for today: Did you pray with khushoo? Any slip of the tongue or act of charity to record? What can be improved tomorrow?..."
            className={`w-full p-3.5 rounded-[18px] text-xs border transition-all resize-none focus:outline-none focus:ring-2 focus:ring-[#2D6A4F] ${
              darkMode
                ? 'bg-[#12281E] border-[#224735] text-stone-100 placeholder-stone-500'
                : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
            }`}
          />
        </div>

        {/* Media Attachments & Amal Tags */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              {/* Attach Photo Button */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
              <button
                id="btn-attach-journal-photo"
                onClick={() => fileInputRef.current?.click()}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  attachedImage
                    ? 'bg-[#2D6A4F] text-white border-[#2D6A4F]'
                    : darkMode
                    ? 'bg-[#12281E] border-[#224735] text-stone-300'
                    : 'bg-stone-100 border-stone-200 text-stone-700'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>{attachedImage ? 'Photo Added' : 'Add Photo'}</span>
              </button>

              {/* Voice Record Button */}
              <button
                id="btn-record-voice-note"
                onClick={handleToggleVoiceRecord}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                  isRecordingVoice
                    ? 'bg-rose-600 text-white border-rose-600 animate-pulse'
                    : recordedVoiceNote
                    ? 'bg-amber-600 text-white border-amber-600'
                    : darkMode
                    ? 'bg-[#12281E] border-[#224735] text-stone-300'
                    : 'bg-stone-100 border-stone-200 text-stone-700'
                }`}
              >
                {isRecordingVoice ? (
                  <>
                    <MicOff className="w-3.5 h-3.5" />
                    <span>Stop ({voiceSeconds}s)</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>{recordedVoiceNote ? 'Voice Attached' : 'Voice Memo'}</span>
                  </>
                )}
              </button>
            </div>

            {/* Amal Tags Toggle */}
            <button
              id="btn-toggle-amal-tags"
              onClick={() => setShowTagSelector(!showTagSelector)}
              className="flex items-center gap-1 text-xs font-bold text-[#1B4332] dark:text-[#74C69D] hover:underline"
            >
              <Tag className="w-3.5 h-3.5" />
              <span>{showTagSelector ? 'Hide Tags' : 'Add Tags'}</span>
            </button>
          </div>

          {/* Tag Selector Grid */}
          {showTagSelector && (
            <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-stone-100/70 dark:bg-[#12281E] border border-stone-200 dark:border-[#224735]">
              {AMAL_TAGS.map((tag) => {
                const isSelected = selectedTags.includes(tag);
                return (
                  <button
                    key={tag}
                    onClick={() => handleToggleTag(tag)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                      isSelected
                        ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                        : 'bg-white dark:bg-[#183326] text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Submit Button */}
        <button
          id="btn-submit-reflection"
          onClick={handleSaveReflection}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black text-white bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] hover:from-[#23533E] hover:to-[#388563] active:scale-[0.99] transition-all shadow-md"
        >
          <Send className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Save Today&apos;s Accounting Entry</span>
        </button>
      </div>

      {/* 5. REFLECTION HISTORY LOGS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3
            className={`text-xs font-black uppercase tracking-wider ${
              darkMode ? 'text-stone-300' : 'text-[#1B4332]'
            }`}
          >
            Past Accounting Entries ({reflections.length})
          </h3>
          <span className="text-[11px] font-bold text-stone-400">Chronological</span>
        </div>

        <div className="space-y-2.5">
          {reflections.length === 0 ? (
            <div
              className={`p-6 rounded-[20px] border border-dashed text-center ${
                darkMode
                  ? 'border-[#224735] text-stone-400 bg-[#12281E]/40'
                  : 'border-emerald-200 text-stone-500 bg-emerald-50/40'
              }`}
            >
              <Sparkles className="w-5 h-5 mx-auto mb-1.5 text-[#D4AF37]" />
              <p className="text-xs font-extrabold text-stone-800 dark:text-stone-200">
                No reflections logged yet
              </p>
              <p className="text-[11px] text-stone-400 dark:text-stone-500 mt-0.5">
                Take an honest self-accounting before sleep and record your first entry above.
              </p>
            </div>
          ) : (
            reflections.map((ref) => (
              <div
                key={ref.id}
                className={`p-4 rounded-[20px] border transition-all ${
                  darkMode
                    ? 'bg-[#183326] border-[#254F3E] shadow-[0_4px_16px_rgba(0,0,0,0.2)]'
                    : 'bg-white border-emerald-900/10 shadow-[0_6px_20px_rgba(27,67,50,0.05)] ring-1 ring-black/5'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#E8F5E9] dark:bg-emerald-950/60 text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800">
                      {ref.mood}
                    </span>
                    <span className="text-[11px] text-stone-400 font-semibold">{ref.date}</span>
                  </div>

                  <button
                    onClick={() => {
                      onDeleteReflection(ref.id);
                      showToast('Reflection removed');
                    }}
                    className="p-1 text-stone-400 hover:text-rose-500 transition-colors"
                    title="Delete Entry"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="text-xs text-stone-800 dark:text-stone-200 leading-relaxed font-medium">
                  {ref.text}
                </p>

                {ref.imageUrl && (
                  <img
                    src={ref.imageUrl}
                    alt="Journal attachment"
                    className="mt-2.5 w-full max-h-40 rounded-[14px] object-cover border border-emerald-100 shadow-xs"
                  />
                )}

                <div className="mt-2.5 pt-2 border-t border-emerald-100/60 dark:border-[#224735] flex items-center justify-between">
                  <div className="flex flex-wrap gap-1.5">
                    {ref.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] font-bold text-[#1B4332] dark:text-[#74C69D]"
                      >
                        {t}
                      </span>
                    ))}
                  </div>

                  {ref.hasVoiceNote && (
                    <span className="flex items-center gap-1 text-[10px] text-amber-700 dark:text-amber-400 font-bold">
                      <Volume2 className="w-3 h-3 text-[#D4AF37]" />
                      <span>Voice Note Saved</span>
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 6. PROMINENT GLOBAL RESET / START FRESH BUTTON */}
      <div
        id="card-global-reset-fresh"
        className={`rounded-[20px] p-5 border transition-all ${
          darkMode
            ? 'bg-[#221013] border-rose-900/40 text-white'
            : 'bg-[#FFF5F5] border-rose-200/80 text-rose-950'
        }`}
      >
        <div className="flex items-start gap-3.5 mb-3.5">
          <div className="p-2.5 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold tracking-tight text-rose-900 dark:text-rose-200">
              {language === 'bn' ? 'সকল ডাটা রিসেট / নতুন শুরু' : 'Reset All Data / Start Fresh'}
            </h3>
            <p className="text-xs text-rose-700/80 dark:text-rose-300/70 mt-0.5 leading-relaxed font-medium">
              {language === 'bn'
                ? 'সালাতের টিক, তাসবীহ কাউন্ট ও আজকের রেকর্ড নতুন করে শুরু করুন।'
                : 'Clear all prayer checks, tasbih counts, daily tasks, and journal logs back to pristine zero.'}
            </p>
          </div>
        </div>

        <button
          id="btn-global-reset-all"
          onClick={() => setShowResetModal(true)}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black tracking-wide text-white bg-rose-600 hover:bg-rose-700 active:scale-[0.98] transition-all shadow-md shadow-rose-600/20 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{language === 'bn' ? 'দৈনন্দিন ট্র্যাকার রিসেট করুন' : 'Reset Daily Tracker'}</span>
        </button>

      </div>

      {/* ============================================================ */}
      {/* RESET CONFIRMATION MODAL */}
      {/* ============================================================ */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div
            className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl space-y-4 ${
              darkMode ? 'bg-[#12281E] border-[#2A5C43] text-stone-100' : 'bg-white border-stone-200 text-stone-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/15 text-rose-600 dark:text-rose-400 flex items-center justify-center font-black shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black tracking-tight text-stone-900 dark:text-white">
                  {language === 'bn' ? 'রিসেট নিশ্চিতকরণ' : 'Reset Confirmation'}
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {language === 'bn' ? 'দৈনন্দিন ট্র্যাকার ও চেকমার্ক নতুন করে শুরু করুন' : 'Reset daily trackers and checkmarks'}
                </p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-800 dark:text-rose-200">
                <p className="font-extrabold mb-1">{language === 'bn' ? 'যা রিসেট করা হবে:' : 'Will Be Reset:'}</p>
                <ul className="list-disc pl-4 space-y-0.5 opacity-90 font-medium">
                  <li>{language === 'bn' ? 'আজকের ৫ ওয়াক্ত সালাত চেকমার্ক' : 'Daily 5-time prayer checks'}</li>
                  <li>{language === 'bn' ? 'আজকের ডিজিটাল তাসবিহ গণনা' : 'Daily digital tasbih count (0)'}</li>
                  <li>{language === 'bn' ? 'আজকের দোয়ার পড়া স্ট্যাটাস' : 'Daily Dua completed checks'}</li>
                  <li>{language === 'bn' ? 'আজকের মেডিসিন গ্রহণের হিসাব' : 'Daily medicine intake status'}</li>
                </ul>
              </div>

              <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 dark:text-emerald-200">
                <p className="font-extrabold mb-1 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  {language === 'bn' ? 'নিরাপদে সংরক্ষিত থাকবে:' : 'Safely Preserved:'}
                </p>
                <ul className="list-disc pl-4 space-y-0.5 opacity-90 font-medium">
                  <li>{language === 'bn' ? 'আপনার নাম ও প্রোফাইল ছবি' : 'Name & Profile Photo'}</li>
                  <li>{language === 'bn' ? 'দৈনন্দিন নিয়ত ও শুকরিয়া ডায়েরি' : 'Niyyah & Gratitude records'}</li>
                  <li>{language === 'bn' ? 'মুহাসাবাতুন নাফস আত্ম-পর্যালোচনা' : 'Self-Audit history'}</li>
                  <li>{language === 'bn' ? 'নামাজের সময় সমন্বয় ও লোকেশন' : 'Salat offsets & Location'}</li>
                  <li>{language === 'bn' ? 'দীর্ঘমেয়াদী লক্ষ্য ও হ্যাবিট স্ট্রিকস' : 'Goals & Habit streaks'}</li>
                  <li>{language === 'bn' ? 'মুহাসাবাতুল মাল আয়-ব্যয় ও জরুরি নাম্বার' : 'Finances & Contacts'}</li>
                </ul>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-stone-200 dark:border-white/10">
              <button
                onClick={() => setShowResetModal(false)}
                className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-white/5 transition-all"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  if (onResetAllData) {
                    onResetAllData();
                  }
                  setShowResetModal(false);
                  showToast(language === 'bn' ? 'দৈনন্দিন চেকমার্ক ও কাউন্টার রিসেট হয়েছে!' : 'Daily checkmarks and counters reset!');
                }}
                className="flex-1 py-2.5 px-4 rounded-xl text-xs font-extrabold text-white bg-rose-600 hover:bg-rose-700 active:scale-95 transition-all shadow-md shadow-rose-600/20"
              >
                {language === 'bn' ? 'হ্যাঁ, রিসেট করুন' : 'Confirm Reset'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* PROFILE PHOTO & AVATAR PICKER MODAL */}
      {/* ============================================================ */}
      {showAvatarModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div
            className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl space-y-4 ${
              darkMode ? 'bg-[#12281E] border-[#2A5C43] text-stone-100' : 'bg-white border-stone-200 text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center font-black">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight text-stone-900 dark:text-white">
                    প্রোফাইল ছবি (Profile Avatar)
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    ছবি আপলোড করুন বা ইসলামিক নকশা নির্বাচন করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAvatarModal(false)}
                className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400"
              >
                ✕
              </button>
            </div>

            {/* Upload from Device */}
            <div className="space-y-2 pt-1">
              <button
                onClick={() => avatarInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl text-xs font-extrabold bg-[#1B4332] text-white hover:bg-[#2D6A4F] border border-[#D4AF37]/40 shadow-sm transition-all active:scale-[0.98]"
              >
                <Upload className="w-4 h-4 text-[#D4AF37]" />
                <span>ডিভাইস থেকে ছবি আপলোড করুন (Upload Photo)</span>
              </button>
              <p className="text-[11px] text-center text-stone-400">
                স্বয়ংক্রিয়ভাবে কম্প্রেস করে ডিভাইসে স্থায়ীভাবে সংরক্ষণ করা হবে
              </p>
            </div>

            {/* Islamic Preset Avatars */}
            <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-white/10">
              <span className="text-xs font-black uppercase tracking-wider text-stone-400 block">
                বা ইসলামিক অবতার সিলেক্ট করুন (Preset Avatars):
              </span>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  {
                    id: 'crescent',
                    name: 'Crescent & Star',
                    nameBn: 'চাঁদ ও তারা',
                    svg: (
                      <svg viewBox="0 0 100 100" className="w-10 h-10">
                        <circle cx="50" cy="50" r="48" fill="#1B4332" />
                        <path d="M54 22 A26 26 0 1 0 76 72 A31 31 0 1 1 54 22 Z" fill="#D4AF37" />
                        <polygon points="68,28 71,36 80,36 73,41 76,49 68,44 60,49 63,41 56,36 65,36" fill="#F4E0A5" />
                      </svg>
                    ),
                    dataUrl: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#1B4332"/><path d="M54 22 A26 26 0 1 0 76 72 A31 31 0 1 1 54 22 Z" fill="#D4AF37"/><polygon points="68,28 71,36 80,36 73,41 76,49 68,44 60,49 63,41 56,36 65,36" fill="#F4E0A5"/></svg>'),
                  },
                  {
                    id: 'dome',
                    name: 'Mosque Dome',
                    nameBn: 'মসজিদ মিনার',
                    svg: (
                      <svg viewBox="0 0 100 100" className="w-10 h-10">
                        <circle cx="50" cy="50" r="48" fill="#0E2419" />
                        <path d="M50 18 C46 28 32 38 32 58 L68 58 C68 38 54 28 50 18 Z" fill="#D4AF37" />
                        <rect x="25" y="58" width="50" height="26" rx="3" fill="#D4AF37" opacity="0.9" />
                        <rect x="42" y="65" width="16" height="19" rx="8" fill="#0E2419" />
                        <circle cx="50" cy="14" r="3" fill="#F4E0A5" />
                      </svg>
                    ),
                    dataUrl: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#0E2419"/><path d="M50 18 C46 28 32 38 32 58 L68 58 C68 38 54 28 50 18 Z" fill="#D4AF37"/><rect x="25" y="58" width="50" height="26" rx="3" fill="#D4AF37" opacity="0.9"/><rect x="42" y="65" width="16" height="19" rx="8" fill="#0E2419"/><circle cx="50" cy="14" r="3" fill="#F4E0A5"/></svg>'),
                  },
                  {
                    id: 'star',
                    name: 'Rub el Hizb',
                    nameBn: 'ইসলামিক তারা',
                    svg: (
                      <svg viewBox="0 0 100 100" className="w-10 h-10">
                        <circle cx="50" cy="50" r="48" fill="#143124" />
                        <g transform="translate(50,50)">
                          <rect x="-22" y="-22" width="44" height="44" fill="none" stroke="#D4AF37" strokeWidth="4" rx="4" />
                          <rect x="-22" y="-22" width="44" height="44" fill="none" stroke="#D4AF37" strokeWidth="4" rx="4" transform="rotate(45)" />
                          <circle cx="0" cy="0" r="9" fill="#D4AF37" />
                        </g>
                      </svg>
                    ),
                    dataUrl: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#143124"/><g transform="translate(50,50)"><rect x="-22" y="-22" width="44" height="44" fill="none" stroke="#D4AF37" stroke-width="4" rx="4"/><rect x="-22" y="-22" width="44" height="44" fill="none" stroke="#D4AF37" stroke-width="4" rx="4" transform="rotate(45)"/><circle cx="0" cy="0" r="9" fill="#D4AF37"/></g></svg>'),
                  },
                  {
                    id: 'rosette',
                    name: 'Gold Rosette',
                    nameBn: 'স্বর্ণালী রোজেট',
                    svg: (
                      <svg viewBox="0 0 100 100" className="w-10 h-10">
                        <circle cx="50" cy="50" r="48" fill="#1B4332" />
                        <g transform="translate(50,50) scale(0.8)">
                          <circle cx="0" cy="0" r="28" fill="none" stroke="#D4AF37" strokeWidth="3" />
                          <circle cx="0" cy="0" r="8" fill="#F4E0A5" />
                        </g>
                      </svg>
                    ),
                    dataUrl: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#1B4332"/><g transform="translate(50,50) scale(0.8)"><circle cx="0" cy="0" r="28" fill="none" stroke="#D4AF37" stroke-width="3"/><circle cx="0" cy="0" r="8" fill="#F4E0A5"/></g></svg>'),
                  },
                ].map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => handleSelectPresetAvatar(preset.dataUrl)}
                    className="p-3 rounded-2xl border flex flex-col items-center gap-2 hover:border-[#D4AF37] hover:scale-105 active:scale-95 transition-all bg-stone-500/5 border-stone-500/20"
                  >
                    {preset.svg}
                    <div className="text-center">
                      <span className="text-xs font-bold block">{preset.nameBn}</span>
                      <span className="text-[10px] text-stone-400">{preset.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Remove / Reset Avatar Option */}
            {profilePhoto && (
              <div className="pt-2 border-t border-stone-200 dark:border-white/10">
                <button
                  onClick={handleRemoveAvatar}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 transition-all flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>প্রোফাইল ছবি মুছে ডিফল্ট করুন (Remove Photo)</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
