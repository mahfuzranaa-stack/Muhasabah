import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  Calendar as CalendarIcon,
  Sparkles,
  Clock,
  Cake,
  Heart,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ArrowLeft,
  ExternalLink,
  RefreshCw,
  Globe,
  Sun,
  Moon,
  Info,
  Plus,
  Trash2,
  Edit2,
  Flag,
  Check,
  Hourglass,
  RotateCcw,
} from 'lucide-react';
import { AgeCalculationResult, TargetDayItem } from '../types';
import { INITIAL_TARGET_DAYS } from '../data/islamicFeaturesData';
import { useLanguage } from '../utils/i18n';

interface CalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  savedDob?: string;
  onSaveDob?: (dob: string) => void;
  isScreenMode?: boolean;
  refreshKey?: number;
  hijriAdjustment?: number;
  onHijriAdjustmentChange?: (value: number) => void;
}

// Bengali month names & English transliteration
const BENGALI_MONTHS = [
  { nameBn: 'বৈশাখ', nameEn: 'Boishakh', season: 'গ্রীষ্ম (Summer)' },
  { nameBn: 'জ্যৈষ্ঠ', nameEn: 'Joishtho', season: 'গ্রীষ্ম (Summer)' },
  { nameBn: 'আষাঢ়', nameEn: 'Ashadh', season: 'বর্ষা (Monsoon)' },
  { nameBn: 'শ্রাবণ', nameEn: 'Srabon', season: 'বর্ষা (Monsoon)' },
  { nameBn: 'ভাদ্র', nameEn: 'Bhadro', season: 'শরৎ (Early Autumn)' },
  { nameBn: 'আশ্বিন', nameEn: 'Ashwin', season: 'শরৎ (Early Autumn)' },
  { nameBn: 'কার্তিক', nameEn: 'Kartik', season: 'হেমন্ত (Late Autumn)' },
  { nameBn: 'অগ্রহায়ণ', nameEn: 'Ogrohayon', season: 'হেমন্ত (Late Autumn)' },
  { nameBn: 'পৌষ', nameEn: 'Poush', season: 'শীত (Winter)' },
  { nameBn: 'মাঘ', nameEn: 'Magh', season: 'শীত (Winter)' },
  { nameBn: 'ফাল্গুন', nameEn: 'Falgun', season: 'বসন্ত (Spring)' },
  { nameBn: 'চৈত্র', nameEn: 'Choitro', season: 'বসন্ত (Spring)' },
];

// Hijri month names
const HIJRI_MONTHS = [
  { nameAr: 'المُحَرَّم', nameBn: 'মুহররম', nameEn: 'Muharram', holy: true },
  { nameAr: 'صَفَر', nameBn: 'সফর', nameEn: 'Safar', holy: false },
  { nameAr: 'رَبِيع الأَوَّل', nameBn: 'রবিউল আউয়াল', nameEn: "Rabi' al-Awwal", holy: false },
  { nameAr: 'رَبِيع الآخِر', nameBn: 'রবিউস সানি', nameEn: "Rabi' al-Thani", holy: false },
  { nameAr: 'جُمَادَى الأُولَى', nameBn: 'জমাদিউল আউয়াল', nameEn: 'Jumada al-Awwal', holy: false },
  { nameAr: 'جُمَادَى الآخِرَة', nameBn: 'জমাদিউস সানি', nameEn: 'Jumada al-Thani', holy: false },
  { nameAr: 'رَجَب', nameBn: 'রজব', nameEn: 'Rajab', holy: true },
  { nameAr: 'شَعْبَان', nameBn: 'শাবান', nameEn: "Sha'ban", holy: false },
  { nameAr: 'رَمَضَان', nameBn: 'রমজান', nameEn: 'Ramadan', holy: true },
  { nameAr: 'شَوَّال', nameBn: 'শাওয়াল', nameEn: 'Shawwal', holy: false },
  { nameAr: 'ذُو القَعْدَة', nameBn: 'জ্বিলকদ', nameEn: "Dhu al-Qi'dah", holy: true },
  { nameAr: 'ذُو الحِجَّة', nameBn: 'জ্বিলহজ্জ', nameEn: 'Dhu al-Hijjah', holy: true },
];

// Bangladesh civil Bangla calendar: 14 April is 1 Boishakh.
// First five months = 31 days; Ashwin–Magh = 30; Falgun = 29/30; Chaitra = 30.
export function getBengaliDate(date: Date) {
  const local = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const gy = local.getFullYear();
  const startThisYear = new Date(gy, 3, 14);
  const banglaYear = local >= startThisYear ? gy - 593 : gy - 594;
  const startYear = local >= startThisYear ? gy : gy - 1;
  const start = new Date(startYear, 3, 14);
  let dayIndex = Math.floor((local.getTime() - start.getTime()) / 86400000);
  const leap = gy % 4 === 0 && (gy % 100 !== 0 || gy % 400 === 0);
  const monthLengths = [31, 31, 31, 31, 31, 30, 30, 30, 30, 30, leap ? 30 : 29, 30];
  let monthIndex = 0;
  while (monthIndex < monthLengths.length - 1 && dayIndex >= monthLengths[monthIndex]) {
    dayIndex -= monthLengths[monthIndex];
    monthIndex += 1;
  }
  const bDay = dayIndex + 1;
  const toBnDigits = (n: number) => n.toString().replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[Number(d)]);
  return {
    dayBn: toBnDigits(bDay),
    dayNumber: bDay,
    month: BENGALI_MONTHS[monthIndex],
    yearBn: toBnDigits(banglaYear),
    yearNumber: banglaYear,
    fullBn: `${toBnDigits(bDay)} ${BENGALI_MONTHS[monthIndex].nameBn} ${toBnDigits(banglaYear)} বঙ্গাব্দ`,
    fullEn: `${bDay} ${BENGALI_MONTHS[monthIndex].nameEn} ${banglaYear} Bangabda`,
    season: BENGALI_MONTHS[monthIndex].season,
  };
}

// Calculate Hijri Date using Kuwaiti/Astronomical algorithm
export function getHijriDate(date: Date, adjustment: number = 0) {
  const adjusted = new Date(date.getTime() + Math.round(adjustment) * 86400000);
  const monthNames = HIJRI_MONTHS;
  const toBnDigits = (n: number) => n.toString().replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[Number(d)]);
  try {
    const formatter = new Intl.DateTimeFormat('en-US-u-ca-islamic-umalqura', {
      timeZone: 'Asia/Dhaka', day: 'numeric', month: 'numeric', year: 'numeric',
    });
    const parts = formatter.formatToParts(adjusted);
    const day = Number(parts.find((p) => p.type === 'day')?.value || 0);
    const month = Number(parts.find((p) => p.type === 'month')?.value || 0);
    const year = Number(parts.find((p) => p.type === 'year')?.value || 0);
    const monthObj = monthNames[month - 1] || monthNames[0];
    return {
      day, dayBn: toBnDigits(day), month: monthObj, year, yearBn: toBnDigits(year),
      fullBn: `${toBnDigits(day)} ${monthObj.nameBn} ${toBnDigits(year)} হিজরি`,
      fullEn: `${day} ${monthObj.nameEn} ${year} AH`,
      arabic: `${day} ${monthObj.nameAr} ${year} هـ`,
      isHolyMonth: monthObj.holy,
    };
  } catch {
    return getHijriDateLegacy(date, adjustment);
  }
}

function getHijriDateLegacy(date: Date, adjustment: number = 0) {
  const d = new Date(date.getTime() + Math.round(adjustment) * 86400000);
  const jd = Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000) + 2440588;
  let l = jd - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631);
  l = l - 10631 * n + 354;
  const j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
  l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
  const m = Math.floor((24 * l) / 709);
  const day = l - Math.floor((709 * m) / 24);
  const year = 30 * n + j - 30;
  const monthObj = HIJRI_MONTHS[m - 1] || HIJRI_MONTHS[0];
  const toBnDigits = (x: number) => String(x).replace(/\d/g, (x) => '০১২৩৪৫৬৭৮৯'[Number(x)]);
  return { day, dayBn: toBnDigits(day), month: monthObj, year, yearBn: toBnDigits(year), fullBn: `${toBnDigits(day)} ${monthObj.nameBn} ${toBnDigits(year)} হিজরি`, fullEn: `${day} ${monthObj.nameEn} ${year} AH`, arabic: `${day} ${monthObj.nameAr} ${year} هـ`, isHolyMonth: monthObj.holy };
}

// Age calculation pure function
export function calculateAgeMetrics(dobDate: Date, targetDate: Date = new Date()): AgeCalculationResult | null {
  if (isNaN(dobDate.getTime()) || dobDate > targetDate) return null;

  let years = targetDate.getFullYear() - dobDate.getFullYear();
  let months = targetDate.getMonth() - dobDate.getMonth();
  let days = targetDate.getDate() - dobDate.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonthDays = new Date(targetDate.getFullYear(), targetDate.getMonth(), 0).getDate();
    days += prevMonthDays;
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  // Next birthday
  let nextBday = new Date(targetDate.getFullYear(), dobDate.getMonth(), dobDate.getDate());
  if (nextBday < targetDate) {
    nextBday = new Date(targetDate.getFullYear() + 1, dobDate.getMonth(), dobDate.getDate());
  }

  const diffMs = nextBday.getTime() - targetDate.getTime();
  const nextBirthdayTotalDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  const nextBirthdayMonths = Math.floor(nextBirthdayTotalDays / 30);
  const nextBirthdayDays = nextBirthdayTotalDays % 30;

  // Lived milestones
  const diffTotalMs = targetDate.getTime() - dobDate.getTime();
  const totalDaysLived = Math.floor(diffTotalMs / (1000 * 60 * 60 * 24));
  const totalWeeksLived = Math.floor(totalDaysLived / 7);
  const totalMonthsLived = years * 12 + months;
  const totalHoursLived = Math.floor(diffTotalMs / (1000 * 60 * 60));

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayOfWeek = daysOfWeek[dobDate.getDay()];

  return {
    years,
    months,
    days,
    nextBirthdayMonths,
    nextBirthdayDays,
    nextBirthdayTotalDays,
    totalDaysLived,
    totalWeeksLived,
    totalMonthsLived,
    totalHoursLived,
    dayOfWeek,
  };
}

export const CalendarModal: React.FC<CalendarModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  savedDob = '1998-05-15',
  onSaveDob,
  isScreenMode = false,
  refreshKey = 0,
  hijriAdjustment = 0,
  onHijriAdjustmentChange,
}) => {
  const { language } = useLanguage();
  // Tabs: 'triple' | 'age' | 'countdown'
  const [activeTab, setActiveTab] = useState<'triple' | 'age' | 'countdown'>('triple');

  // Subview for Full Interactive Calendars: 'overview' | 'gregorian' | 'hijri' | 'bangla'
  const [calendarSubView, setCalendarSubView] = useState<'overview' | 'gregorian' | 'hijri' | 'bangla'>('overview');

  // Interactive selected date for triple calendar inspection
  const [selectedCalendarDate, setSelectedCalendarDate] = useState(
    new Date().toISOString().split('T')[0]
  );

  // Month & Year state for full month navigation
  const [gregMonth, setGregMonth] = useState<number>(() => new Date().getMonth());
  const [gregYear, setGregYear] = useState<number>(() => new Date().getFullYear());

  // Keep month/year synchronized when a date is selected
  useEffect(() => {
    const parts = selectedCalendarDate.split('-');
    if (parts.length === 3) {
      const y = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10) - 1;
      if (!isNaN(y) && !isNaN(m)) {
        setGregYear(y);
        setGregMonth(m);
      }
    }
  }, [selectedCalendarDate]);

  // Age form
  const [dobInput, setDobInput] = useState(savedDob);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Target Days / Day Countdown State (Persisted)
  const [targetDays, setTargetDays] = useState<TargetDayItem[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_target_days');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_TARGET_DAYS;
  });

  const [targetCategoryFilter, setTargetCategoryFilter] = useState<string>('All');
  const [showAddTargetForm, setShowAddTargetForm] = useState<boolean>(false);
  const [editingTargetId, setEditingTargetId] = useState<string | null>(null);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formTitleBn, setFormTitleBn] = useState('');
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formCategory, setFormCategory] = useState<'Islamic' | 'Personal' | 'Goal' | 'Family'>('Islamic');
  const [formNotes, setFormNotes] = useState('');

  // Save targets to local storage
  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_target_days', JSON.stringify(targetDays));
    } catch {
      // ignore
    }
  }, [targetDays]);

  const handleSaveTarget = () => {
    if (!formTitle.trim() || !formDate) {
      showToast('Please enter title and target date');
      return;
    }

    if (editingTargetId) {
      setTargetDays((prev) =>
        prev.map((t) =>
          t.id === editingTargetId
            ? {
                ...t,
                title: formTitle.trim(),
                titleBn: formTitleBn.trim() || formTitle.trim(),
                targetDate: formDate,
                category: formCategory,
                notes: formNotes.trim(),
              }
            : t
        )
      );
      showToast('Target date updated successfully!');
    } else {
      const newItem: TargetDayItem = {
        id: 'target-' + Date.now(),
        title: formTitle.trim(),
        titleBn: formTitleBn.trim() || formTitle.trim(),
        targetDate: formDate,
        category: formCategory,
        notes: formNotes.trim(),
      };
      setTargetDays((prev) => [newItem, ...prev]);
      showToast('New target date added!');
    }

    // Reset
    setShowAddTargetForm(false);
    setEditingTargetId(null);
    setFormTitle('');
    setFormTitleBn('');
    setFormNotes('');
  };

  const handleEditTarget = (item: TargetDayItem) => {
    setEditingTargetId(item.id);
    setFormTitle(item.title);
    setFormTitleBn(item.titleBn || item.title);
    setFormDate(item.targetDate);
    setFormCategory(item.category);
    setFormNotes(item.notes || '');
    setShowAddTargetForm(true);
  };

  const handleResetTargets = () => {
    if (!window.confirm('সব Target Tracker রেকর্ড রিসেট করবেন?')) return;
    setTargetDays([]);
    try { localStorage.removeItem('muhasabah_target_days'); } catch {}
    showToast('Target tracker reset হয়েছে');
  };

  const handleDeleteTarget = (id: string) => {
    if (window.confirm('Delete this target date tracker?')) {
      setTargetDays((prev) => prev.filter((t) => t.id !== id));
      showToast('Target date deleted');
    }
  };

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  // Compute triple dates for selected date
  const selectedDateObj = new Date(selectedCalendarDate + 'T00:00:00');
  const hijri = getHijriDate(selectedDateObj, hijriAdjustment);
  const bengali = getBengaliDate(selectedDateObj);

  const englishDateStr = selectedDateObj.toLocaleDateString('en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // Calculate day of year
  const startOfYear = new Date(selectedDateObj.getFullYear(), 0, 1);
  const dayOfYear = Math.floor(
    (selectedDateObj.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24)
  ) + 1;

  // Age result
  const dobDateObj = new Date(dobInput + 'T00:00:00');
  const ageResult = calculateAgeMetrics(dobDateObj);

  const handleSaveDob = () => {
    if (onSaveDob) {
      onSaveDob(dobInput);
      showToast('Date of Birth saved successfully');
    }
  };

  const modalCard = (
    <div
      className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col ${
        isScreenMode ? 'overflow-visible' : 'max-h-[92vh] overflow-hidden'
      } ${
        darkMode
          ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
          : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
      }`}
    >
      {/* Header */}
      <div
        className={`p-4 sm:p-5 border-b flex items-center justify-between ${
          darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-500 flex items-center justify-center font-black shadow-xs">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black tracking-tight">
                {language === 'bn' ? 'দিনপঞ্জিকা ও লক্ষ্য' : 'Calendar & Milestones'}
              </h3>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                {language === 'bn' ? 'সমন্বিত ক্যালেন্ডার' : 'Synced Calendar'}
              </span>
            </div>
            <p className="text-xs text-stone-400 font-medium">
              {language === 'bn'
                ? 'বাংলা • ইংরেজি • হিজরি ত্রিধারার সমন্বিত বর্ষপঞ্জি ও বয়স গণনা'
                : 'Triple Synchronized Calendar (Bengali • English • Hijri) & Age Tool'}
            </p>
          </div>
        </div>
        {!isScreenMode && (
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

        {/* Tab Controls: Triple Calendar vs Age Calculator vs Day Countdown */}
        <div
          className={`grid grid-cols-3 p-1.5 border-b text-center text-xs font-black ${
            darkMode ? 'bg-[#0A1710] border-[#1A3729]' : 'bg-stone-100 border-stone-200'
          }`}
        >
          <button
            onClick={() => setActiveTab('triple')}
            className={`py-2 px-1.5 sm:px-3 rounded-xl transition-all flex items-center justify-center gap-1 text-[11px] sm:text-xs ${
              activeTab === 'triple'
                ? 'bg-[#1B4332] text-white shadow-xs'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
            <span className="truncate">{language === 'bn' ? 'ক্যালেন্ডার' : 'Triple Calendar'}</span>
          </button>
          <button
            onClick={() => setActiveTab('age')}
            className={`py-2 px-1.5 sm:px-3 rounded-xl transition-all flex items-center justify-center gap-1 text-[11px] sm:text-xs ${
              activeTab === 'age'
                ? 'bg-[#1B4332] text-white shadow-xs'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Cake className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span className="truncate">{language === 'bn' ? 'বয়স ক্যালকুলেটর' : 'Age Calculator'}</span>
          </button>
          <button
            onClick={() => setActiveTab('countdown')}
            className={`py-2 px-1.5 sm:px-3 rounded-xl transition-all flex items-center justify-center gap-1 text-[11px] sm:text-xs ${
              activeTab === 'countdown'
                ? 'bg-[#1B4332] text-white shadow-xs'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Hourglass className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{language === 'bn' ? 'কাউন্টডাউন' : 'Day Countdown'}</span>
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 my-2 p-2 rounded-xl bg-blue-600 text-white text-xs font-bold text-center shadow-md animate-bounce">
            {toastMsg}
          </div>
        )}

        {/* Modal Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: TRIPLE CALENDAR (BENGALI, ENGLISH, HIJRI) */}
          {activeTab === 'triple' && (
            <div className="space-y-4">
              {calendarSubView === 'overview' && (
                <>
                  {/* Date Selector / Quick Picker */}
                  <div
                    className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                      darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-stone-50 border-stone-200'
                    }`}
                  >
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-wider text-stone-400 block mb-0.5">
                        Inspect Date in 3 Calendars
                      </label>
                      <input
                        type="date"
                        value={selectedCalendarDate}
                        onChange={(e) => setSelectedCalendarDate(e.target.value)}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                          darkMode
                            ? 'bg-[#142D21] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>

                    <button
                      onClick={() =>
                        setSelectedCalendarDate(new Date().toISOString().split('T')[0])
                      }
                      className="px-3 py-2 rounded-xl text-xs font-bold bg-[#1B4332] text-[#F4E0A5] hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shadow-xs cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Today</span>
                    </button>
                  </div>

                  {/* 1. English (Gregorian) Card */}
                  <div
                    id="card-open-gregorian"
                    onClick={() => setCalendarSubView('gregorian')}
                    className={`p-4 rounded-2xl border relative overflow-hidden transition-all shadow-xs cursor-pointer group hover:scale-[1.01] hover:border-blue-500/70 ${
                      darkMode
                        ? 'bg-[#12281E] border-blue-900/40 text-stone-100'
                        : 'bg-gradient-to-r from-blue-50/70 to-white border-blue-200/80 text-stone-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-black">
                          <Sun className="w-4 h-4" />
                        </div>
                        <h4 className="text-xs font-black uppercase tracking-wider text-blue-500">
                          English (Gregorian) Calendar
                        </h4>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                        Day {dayOfYear} of 365
                      </span>
                    </div>

                    <div className="text-lg sm:text-xl font-black tracking-tight">{englishDateStr}</div>
                    <div className="text-xs text-stone-400 mt-1 flex items-center gap-3">
                      <span>Standard Solar Calendar</span>
                      <span>•</span>
                      <span>Week {Math.ceil(dayOfYear / 7)}</span>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-blue-500/15 flex items-center justify-between text-xs font-extrabold text-blue-500">
                      <span>পূর্ণাঙ্গ ইংরেজি ক্যালেন্ডার খুলুন (Full Month View)</span>
                      <div className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Open</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>

                  {/* 2. Hijri Islamic Calendar Card */}
                  <div
                    id="card-open-hijri"
                    onClick={() => setCalendarSubView('hijri')}
                    className={`p-4 rounded-2xl border relative overflow-hidden transition-all shadow-xs cursor-pointer group hover:scale-[1.01] hover:border-[#D4AF37] ${
                      darkMode
                        ? 'bg-[#12281E] border-[#D4AF37]/40 text-stone-100'
                        : 'bg-gradient-to-r from-amber-50/70 to-white border-amber-200/80 text-stone-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center font-black">
                          <Moon className="w-4 h-4" />
                        </div>
                        <h4 className="text-xs font-black uppercase tracking-wider text-[#D4AF37]">
                          Islamic (Hijri) Calendar • হিজরি
                        </h4>
                      </div>
                      {hijri.isHolyMonth && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">
                          পবিত্র মাস (Ashhurul Hurum)
                        </span>
                      )}
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                      <div className="text-lg sm:text-xl font-black tracking-tight text-[#D4AF37]">
                        {hijri.fullBn}
                      </div>
                      <div className="text-xs font-bold text-stone-400 font-arabic">
                        {hijri.arabic}
                      </div>
                    </div>
                    <div className="text-xs text-stone-400 mt-1 flex items-center gap-3">
                      <span>{hijri.fullEn}</span>
                      <span>•</span>
                      <span>Lunar Cycle Month {hijri.month.nameEn}</span>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-[#D4AF37]/20 flex items-center justify-between text-xs font-extrabold text-[#D4AF37]">
                      <span>পূর্ণাঙ্গ হিজরি ক্যালেন্ডার খুলুন (Full Hijri View)</span>
                      <div className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Open</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>

                  {/* 3. Bengali Calendar Card */}
                  <div
                    id="card-open-bangla"
                    onClick={() => setCalendarSubView('bangla')}
                    className={`p-4 rounded-2xl border relative overflow-hidden transition-all shadow-xs cursor-pointer group hover:scale-[1.01] hover:border-emerald-500 ${
                      darkMode
                        ? 'bg-[#12281E] border-emerald-800/50 text-stone-100'
                        : 'bg-gradient-to-r from-emerald-50/70 to-white border-emerald-200/80 text-stone-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                          <Globe className="w-4 h-4" />
                        </div>
                        <h4 className="text-xs font-black uppercase tracking-wider text-emerald-500">
                          Bengali Calendar • বঙ্গাব্দ (বাংলা একাডেমি)
                        </h4>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        {bengali.season}
                      </span>
                    </div>

                    <div className="text-lg sm:text-xl font-black tracking-tight text-emerald-600 dark:text-emerald-400">
                      {bengali.fullBn}
                    </div>
                    <div className="text-xs text-stone-400 mt-1 flex items-center gap-3">
                      <span>{bengali.fullEn}</span>
                      <span>•</span>
                      <span>ঋতু: {bengali.season}</span>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-emerald-500/20 flex items-center justify-between text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                      <span>পূর্ণাঙ্গ বঙ্গাব্দ ক্যালেন্ডার খুলুন (Full Bangla View)</span>
                      <div className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Open</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>

                  {/* Information Note */}
                  <div className="p-3 rounded-2xl bg-stone-500/10 border border-stone-500/20 text-stone-400 text-xs flex items-start gap-2">
                    <Info className="w-4 h-4 shrink-0 mt-0.5 text-[#D4AF37]" />
                    <p>
                      Calculated based on Bangladesh standard revisions (Bangla Academy for Bengali, astronomical Umm al-Qura coordinates for Hijri). Islamic months are subject to local moon sighting.
                    </p>
                  </div>
                </>
              )}

              {/* ============================================================ */}
              {/* FULL VIEW 1: GREGORIAN MONTH CALENDAR */}
              {/* ============================================================ */}
              {calendarSubView === 'gregorian' && (() => {
                const monthNames = [
                  'January', 'February', 'March', 'April', 'May', 'June',
                  'July', 'August', 'September', 'October', 'November', 'December',
                ];
                const monthNamesBn = [
                  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
                  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর',
                ];
                const daysInMonth = new Date(gregYear, gregMonth + 1, 0).getDate();
                const firstDayOffset = new Date(gregYear, gregMonth, 1).getDay(); // 0 = Sunday
                const weekdays = [
                  { en: 'Sun', bn: 'রবি' },
                  { en: 'Mon', bn: 'সোম' },
                  { en: 'Tue', bn: 'মঙ্গল' },
                  { en: 'Wed', bn: 'বুধ' },
                  { en: 'Thu', bn: 'বৃহঃ' },
                  { en: 'Fri', bn: 'শুক্র' },
                  { en: 'Sat', bn: 'শনি' },
                ];

                const handlePrevMonth = () => {
                  if (gregMonth === 0) {
                    setGregMonth(11);
                    setGregYear((y) => y - 1);
                  } else {
                    setGregMonth((m) => m - 1);
                  }
                };

                const handleNextMonth = () => {
                  if (gregMonth === 11) {
                    setGregMonth(0);
                    setGregYear((y) => y + 1);
                  } else {
                    setGregMonth((m) => m + 1);
                  }
                };

                const todayStr = new Date().toISOString().split('T')[0];

                return (
                  <div className="space-y-4 animate-fade-in">
                    {/* Back button & View Title */}
                    <div className="flex items-center justify-between">
                      <button
                        onClick={() => setCalendarSubView('overview')}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-stone-500/10 hover:bg-stone-500/20 text-stone-700 dark:text-stone-300 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                        <span>মূল ট্রিপল ভিউ (Back)</span>
                      </button>
                      <span className="text-xs font-extrabold text-blue-500">
                        Gregorian Solar Calendar
                      </span>
                    </div>

                    {/* Navigation Header */}
                    <div
                      className={`p-4 rounded-2xl border space-y-3 ${
                        darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-white border-stone-200'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => setGregYear((y) => y - 1)}
                            className="p-1.5 rounded-lg hover:bg-stone-500/15 text-stone-400 hover:text-stone-100"
                            title="Previous Year"
                          >
                            <ChevronsLeft className="w-4 h-4" />
                          </button>
                          <button
                            onClick={handlePrevMonth}
                            className="p-1.5 rounded-lg hover:bg-stone-500/15 text-stone-400 hover:text-stone-100"
                            title="Previous Month"
                          >
                            <ChevronLeft className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Month and Year Dropdowns */}
                        <div className="flex items-center gap-2">
                          <select
                            value={gregMonth}
                            onChange={(e) => setGregMonth(parseInt(e.target.value, 10))}
                            className={`px-2.5 py-1.5 rounded-xl text-xs font-black border focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                              darkMode ? 'bg-[#142D21] border-[#224A37] text-white' : 'bg-white border-stone-300 text-stone-900'
                            }`}
                          >
                            {monthNames.map((name, idx) => (
                              <option key={name} value={idx}>
                                {name} ({monthNamesBn[idx]})
                              </option>
                            ))}
                          </select>

                          <select
                            value={gregYear}
                            onChange={(e) => setGregYear(parseInt(e.target.value, 10))}
                            className={`px-2.5 py-1.5 rounded-xl text-xs font-black border focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                              darkMode ? 'bg-[#142D21] border-[#224A37] text-white' : 'bg-white border-stone-300 text-stone-900'
                            }`}
                          >
                            {Array.from({ length: 110 }, (_, i) => 1950 + i).map((y) => (
                              <option key={y} value={y}>
                                {y}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={handleNextMonth}
                            className="p-1.5 rounded-lg hover:bg-stone-500/15 text-stone-400 hover:text-stone-100"
                            title="Next Month"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setGregYear((y) => y + 1)}
                            className="p-1.5 rounded-lg hover:bg-stone-500/15 text-stone-400 hover:text-stone-100"
                            title="Next Year"
                          >
                            <ChevronsRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Quick jump to Today button */}
                      <div className="flex justify-end">
                        <button
                          onClick={() => {
                            const now = new Date();
                            setGregYear(now.getFullYear());
                            setGregMonth(now.getMonth());
                            setSelectedCalendarDate(now.toISOString().split('T')[0]);
                          }}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30 hover:bg-blue-500/25 transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>আজকের তারিখে যান (Today)</span>
                        </button>
                      </div>
                    </div>

                    {/* 7-column Calendar Grid */}
                    <div
                      className={`p-3 sm:p-4 rounded-2xl border ${
                        darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-white border-stone-200'
                      }`}
                    >
                      {/* Weekday headers */}
                      <div className="grid grid-cols-7 gap-1 mb-2 text-center">
                        {weekdays.map((w, idx) => (
                          <div
                            key={w.en}
                            className={`py-1.5 text-[11px] font-extrabold rounded-lg ${
                              idx === 5
                                ? 'text-emerald-500 dark:text-emerald-400 bg-emerald-500/10'
                                : 'text-stone-500 dark:text-stone-400'
                            }`}
                          >
                            <span>{w.bn}</span>
                            <span className="text-[9px] opacity-70 block">{w.en}</span>
                          </div>
                        ))}
                      </div>

                      {/* Days cells */}
                      <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
                        {/* Empty padding cells before first day */}
                        {Array.from({ length: firstDayOffset }).map((_, i) => (
                          <div key={`empty-${i}`} className="min-h-[56px] rounded-xl bg-transparent" />
                        ))}

                        {/* Month day cells */}
                        {Array.from({ length: daysInMonth }).map((_, i) => {
                          const dayNum = i + 1;
                          const cellDateObj = new Date(gregYear, gregMonth, dayNum);
                          const dateString = `${gregYear}-${String(gregMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                          const isSelected = selectedCalendarDate === dateString;
                          const isToday = todayStr === dateString;
                          const isFriday = cellDateObj.getDay() === 5;

                          const cellHijri = getHijriDate(cellDateObj);
                          const cellBangla = getBengaliDate(cellDateObj);

                          return (
                            <button
                              key={dateString}
                              onClick={() => setSelectedCalendarDate(dateString)}
                              className={`min-h-[58px] p-1 rounded-xl border flex flex-col items-center justify-between text-left transition-all relative cursor-pointer ${
                                isSelected
                                  ? 'bg-blue-600 text-white border-blue-400 shadow-md scale-105 z-10'
                                  : isToday
                                  ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-stone-100'
                                  : isFriday
                                  ? 'bg-emerald-500/5 border-emerald-500/20 hover:border-emerald-500/40'
                                  : 'bg-stone-500/5 border-transparent hover:border-stone-500/30'
                              }`}
                            >
                              {/* Top row: Day number and Today marker */}
                              <div className="w-full flex items-center justify-between px-0.5">
                                <span className={`text-xs sm:text-sm font-black ${isSelected ? 'text-white' : ''}`}>
                                  {dayNum}
                                </span>
                                {isToday && (
                                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" title="Today" />
                                )}
                              </div>

                              {/* Conversion badges */}
                              <div className="w-full space-y-0.5 mt-1 text-[9px] leading-tight">
                                <div
                                  className={`truncate font-semibold ${
                                    isSelected ? 'text-amber-200' : 'text-[#D4AF37]'
                                  }`}
                                  title={`Hijri: ${cellHijri.dayBn} ${cellHijri.month.nameBn}`}
                                >
                                  {cellHijri.dayBn} {cellHijri.month.nameBn.slice(0, 5)}
                                </div>
                                <div
                                  className={`truncate font-semibold ${
                                    isSelected ? 'text-emerald-100' : 'text-emerald-600 dark:text-emerald-400'
                                  }`}
                                  title={`Bangla: ${cellBangla.dayBn} ${cellBangla.month.nameBn}`}
                                >
                                  {cellBangla.dayBn} {cellBangla.month.nameBn.slice(0, 5)}
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Selected Date Synchronized Info Box */}
                    <div
                      className={`p-4 rounded-2xl border space-y-2 ${
                        darkMode ? 'bg-[#12281E] border-blue-900/40' : 'bg-blue-50/60 border-blue-200'
                      }`}
                    >
                      <span className="text-[10px] font-black uppercase tracking-wider text-blue-500 block">
                        Selected Date Synchronized Overview (নির্বাচিত তারিখ)
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                        <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20">
                          <span className="text-[10px] text-blue-400 block font-bold">English (Gregorian)</span>
                          <span className="font-extrabold">{englishDateStr}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20">
                          <span className="text-[10px] text-[#D4AF37] block font-bold">Islamic (Hijri)</span>
                          <span className="font-extrabold">{hijri.fullBn}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                          <span className="text-[10px] text-emerald-400 block font-bold">Bengali (বঙ্গাব্দ)</span>
                          <span className="font-extrabold">{bengali.fullBn}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* ============================================================ */}
              {/* FULL VIEW 2: HIJRI ISLAMIC CALENDAR */}
              {/* ============================================================ */}
              {calendarSubView === 'hijri' && (() => {
                // Hijri days list (1 to 30)
                const hijriDays = Array.from({ length: 30 }, (_, i) => i + 1);

                return (
                  <div className="space-y-4 animate-fade-in">
                    {/* Back button & View Title */}
                    <div className="flex items-center justify-between">
                      <button
                        onClick={() => setCalendarSubView('overview')}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-stone-500/10 hover:bg-stone-500/20 text-stone-700 dark:text-stone-300 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                        <span>মূল ট্রিপল ভিউ (Back)</span>
                      </button>
                      <span className="text-xs font-extrabold text-[#D4AF37]">
                        Islamic Hijri Calendar • হিজরি বর্ষপঞ্জি
                      </span>
                    </div>

                    {/* Hijri Header Card */}
                    <div
                      className={`p-4 rounded-2xl border space-y-3 ${
                        darkMode ? 'bg-[#12281E] border-[#D4AF37]/30' : 'bg-amber-50/70 border-amber-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <button
                          onClick={() => {
                            // Jump back ~29.5 days
                            const cur = new Date(selectedCalendarDate + 'T12:00:00');
                            cur.setDate(cur.getDate() - 30);
                            setSelectedCalendarDate(cur.toISOString().split('T')[0]);
                          }}
                          className="p-2 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/30 text-[#D4AF37] transition-all cursor-pointer"
                          title="পূর্ববর্তী হিজরি মাস (Previous Hijri Month)"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>

                        <div className="text-center">
                          <h3 className="text-base sm:text-lg font-black text-[#D4AF37] tracking-tight">
                            {hijri.month.nameBn} {hijri.yearBn} হিজরি
                          </h3>
                          <p className="text-xs text-stone-400 font-arabic">
                            {hijri.month.nameAr} {hijri.year} هـ • {hijri.month.nameEn}
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            // Jump forward ~29.5 days
                            const cur = new Date(selectedCalendarDate + 'T12:00:00');
                            cur.setDate(cur.getDate() + 30);
                            setSelectedCalendarDate(cur.toISOString().split('T')[0]);
                          }}
                          className="p-2 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/30 text-[#D4AF37] transition-all cursor-pointer"
                          title="পরবর্তী হিজরি মাস (Next Hijri Month)"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Holy Month Badge */}
                      {hijri.isHolyMonth && (
                        <div className="flex justify-center">
                          <span className="text-[11px] font-extrabold px-3 py-1 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">
                            ✨ পবিত্র মাস (আশহুরুল হুরুম - সম্মানিত ৪ মাসের একটি)
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-center gap-2 pt-1">
                        <span className="text-[10px] font-bold text-stone-400">তারিখ সমন্বয়</span>
                        <button onClick={() => onHijriAdjustmentChange?.(Math.max(-2, hijriAdjustment - 1))} disabled={hijriAdjustment <= -2} className="w-7 h-7 rounded-lg border border-[#D4AF37]/30 text-[#D4AF37] disabled:opacity-40">−</button>
                        <span className="min-w-10 text-center text-xs font-black text-[#D4AF37]">{hijriAdjustment > 0 ? `+${hijriAdjustment}` : hijriAdjustment}</span>
                        <button onClick={() => onHijriAdjustmentChange?.(Math.min(2, hijriAdjustment + 1))} disabled={hijriAdjustment >= 2} className="w-7 h-7 rounded-lg border border-[#D4AF37]/30 text-[#D4AF37] disabled:opacity-40">+</button>
                        <button onClick={() => onHijriAdjustmentChange?.(0)} className="px-2 py-1 rounded-lg text-[10px] font-bold bg-[#D4AF37]/10 text-[#D4AF37]">Reset</button>
                      </div>
                    </div>

                    {/* Hijri Special Info Notice: Ayyam al-Beed */}
                    <div className="p-3 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-xs text-stone-300 flex items-start gap-2.5">
                      <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                      <div>
                        <p className="font-extrabold text-[#D4AF37]">
                          আইয়ামে বীজ (Ayyam al-Beed) - ১৩, ১৪ ও ১৫ তারিখ:
                        </p>
                        <p className="text-stone-400 text-[11px] mt-0.5">
                          প্রতি হিজরি মাসের ১৩, ১৪ ও ১৫ তারিখে রোজা রাখা সুন্নাত (পূর্ণিমার আলোকিত দিনসমূহ)। নিচের দিনগুলোতে বিশেষভাবে চিহ্নিত করা হয়েছে।
                        </p>
                      </div>
                    </div>

                    {/* Days Grid for Hijri Month */}
                    <div
                      className={`p-3 sm:p-4 rounded-2xl border ${
                        darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-white border-stone-200'
                      }`}
                    >
                      <div className="grid grid-cols-5 sm:grid-cols-6 gap-2">
                        {hijriDays.map((hDay) => {
                          const isCurrentDay = hijri.day === hDay;
                          const isAyyamBeed = hDay === 13 || hDay === 14 || hDay === 15;

                          // Calculate date offset from current hijri day
                          const dayDiff = hDay - hijri.day;
                          const targetDate = new Date(new Date(selectedCalendarDate + 'T12:00:00').getTime() + dayDiff * 86400000);
                          const targetDateStr = targetDate.toISOString().split('T')[0];
                          const targetGregMonth = targetDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                          const isFriday = targetDate.getDay() === 5;

                          return (
                            <button
                              key={hDay}
                              onClick={() => setSelectedCalendarDate(targetDateStr)}
                              className={`p-2.5 rounded-2xl border flex flex-col items-center justify-between text-center transition-all cursor-pointer relative ${
                                isCurrentDay
                                  ? 'bg-[#D4AF37] text-stone-950 border-[#D4AF37] shadow-lg font-black scale-105'
                                  : isAyyamBeed
                                  ? 'bg-[#D4AF37]/15 border-[#D4AF37]/50 text-stone-100 hover:border-[#D4AF37]'
                                  : isFriday
                                  ? 'bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-500'
                                  : 'bg-stone-500/5 border-transparent hover:border-stone-500/30 text-stone-200'
                              }`}
                            >
                              {/* Ayyam al-Beed Sunnah badge */}
                              {isAyyamBeed && (
                                <span
                                  className={`text-[9px] font-black px-1.5 py-0.2 rounded-full mb-1 ${
                                    isCurrentDay ? 'bg-stone-900 text-[#D4AF37]' : 'bg-[#D4AF37]/30 text-[#D4AF37]'
                                  }`}
                                >
                                  বীজ রোজা
                                </span>
                              )}

                              {/* Hijri Day Number */}
                              <div className="text-base sm:text-lg font-black">
                                {HIJRI_MONTHS[0].nameBn ? (
                                  <span>{['০','১','২','৩','৪','৫','৬','৭','৮','৯'][Math.floor(hDay / 10)] !== '০' ? ['০','১','২','৩','৪','৫','৬','৭','৮','৯'][Math.floor(hDay / 10)] : ''}{['০','১','২','৩','৪','৫','৬','৭','৮','৯'][hDay % 10]}</span>
                                ) : (
                                  hDay
                                )}
                              </div>

                              {/* Gregorian equivalent day */}
                              <span
                                className={`text-[10px] mt-1 font-semibold ${
                                  isCurrentDay ? 'text-stone-900' : 'text-stone-400'
                                }`}
                              >
                                {targetGregMonth}
                              </span>

                              {/* Friday indicator */}
                              {isFriday && (
                                <span className={`text-[8px] font-bold mt-0.5 ${isCurrentDay ? 'text-emerald-950' : 'text-emerald-400'}`}>
                                  জুমুআহ
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* ============================================================ */}
              {/* FULL VIEW 3: BENGALI CALENDAR */}
              {/* ============================================================ */}
              {calendarSubView === 'bangla' && (() => {
                const banglaMonthsList = [
                  { name: 'বৈশাখ', nameEn: 'Boishakh', days: 31, season: 'গ্রীষ্ম (Summer)' },
                  { name: 'জ্যৈষ্ঠ', nameEn: 'Jyoishtho', days: 31, season: 'গ্রীষ্ম (Summer)' },
                  { name: 'আষাঢ়', nameEn: 'Asharh', days: 31, season: 'বর্ষা (Monsoon)' },
                  { name: 'শ্রাবণ', nameEn: 'Srabon', days: 31, season: 'বর্ষা (Monsoon)' },
                  { name: 'ভাদ্র', nameEn: 'Bhadro', days: 31, season: 'শরৎ (Early Autumn)' },
                  { name: 'আশ্বিন', nameEn: 'Ashwin', days: 31, season: 'শরৎ (Early Autumn)' },
                  { name: 'কার্তিক', nameEn: 'Kartik', days: 30, season: 'হেমন্ত (Late Autumn)' },
                  { name: 'অগ্রহায়ণ', nameEn: 'Agrahayan', days: 30, season: 'হেমন্ত (Late Autumn)' },
                  { name: 'পৌষ', nameEn: 'Poush', days: 30, season: 'শীত (Winter)' },
                  { name: 'মাঘ', nameEn: 'Magh', days: 30, season: 'শীত (Winter)' },
                  { name: 'ফাল্গুন', nameEn: 'Falgun', days: 30, season: 'বসন্ত (Spring)' },
                  { name: 'চৈত্র', nameEn: 'Choitro', days: 30, season: 'বসন্ত (Spring)' },
                ];

                const currentBanglaMonthIdx = banglaMonthsList.findIndex(
                  (m) => m.name === bengali.month.nameBn
                );
                const activeMonth = banglaMonthsList[currentBanglaMonthIdx >= 0 ? currentBanglaMonthIdx : 0];
                const daysInBanglaMonth = activeMonth.days;

                return (
                  <div className="space-y-4 animate-fade-in">
                    {/* Back button & View Title */}
                    <div className="flex items-center justify-between">
                      <button
                        onClick={() => setCalendarSubView('overview')}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-stone-500/10 hover:bg-stone-500/20 text-stone-700 dark:text-stone-300 transition-all cursor-pointer"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                        <span>মূল ট্রিপল ভিউ (Back)</span>
                      </button>
                      <span className="text-xs font-extrabold text-emerald-500">
                        Bengali Bangabda • বঙ্গাব্দ বর্ষপঞ্জি
                      </span>
                    </div>

                    {/* Bangla Month Header */}
                    <div
                      className={`p-4 rounded-2xl border space-y-3 ${
                        darkMode ? 'bg-[#12281E] border-emerald-800/40' : 'bg-emerald-50/70 border-emerald-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <button
                          onClick={() => {
                            // Jump back ~30 days
                            const cur = new Date(selectedCalendarDate + 'T12:00:00');
                            cur.setDate(cur.getDate() - 31);
                            setSelectedCalendarDate(cur.toISOString().split('T')[0]);
                          }}
                          className="p-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/30 text-emerald-400 transition-all cursor-pointer"
                          title="পূর্ববর্তী বাংলা মাস (Previous Bangla Month)"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>

                        <div className="text-center">
                          <h3 className="text-base sm:text-lg font-black text-emerald-600 dark:text-emerald-400 tracking-tight">
                            {bengali.month.nameBn} {bengali.yearBn} বঙ্গাব্দ
                          </h3>
                          <p className="text-xs text-stone-400 font-medium">
                            {bengali.month.nameEn} • ঋতু: {bengali.season} (বাংলা একাডেমি মান)
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            // Jump forward ~30 days
                            const cur = new Date(selectedCalendarDate + 'T12:00:00');
                            cur.setDate(cur.getDate() + 31);
                            setSelectedCalendarDate(cur.toISOString().split('T')[0]);
                          }}
                          className="p-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/30 text-emerald-400 transition-all cursor-pointer"
                          title="পরবর্তী বাংলা মাস (Next Bangla Month)"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Season Pill */}
                      <div className="flex justify-center">
                        <span className="text-[11px] font-extrabold px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-500 dark:text-emerald-300 border border-emerald-500/30">
                          {bengali.season}
                        </span>
                      </div>
                    </div>

                    {/* Days Grid for Bangla Month */}
                    <div
                      className={`p-3 sm:p-4 rounded-2xl border ${
                        darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-white border-stone-200'
                      }`}
                    >
                      <div className="grid grid-cols-5 sm:grid-cols-6 gap-2">
                        {Array.from({ length: daysInBanglaMonth }).map((_, i) => {
                          const bDay = i + 1;
                          const isCurrentDay = bengali.dayNumber === bDay;

                          // Calculate date offset from current bangla day
                          const dayDiff = bDay - bengali.dayNumber;
                          const targetDate = new Date(new Date(selectedCalendarDate + 'T12:00:00').getTime() + dayDiff * 86400000);
                          const targetDateStr = targetDate.toISOString().split('T')[0];
                          const targetGreg = targetDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                          const isFriday = targetDate.getDay() === 5;

                          const toBn = (n: number) => {
                            const d = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
                            return n.toString().replace(/\d/g, (x) => d[parseInt(x, 10)]);
                          };

                          return (
                            <button
                              key={bDay}
                              onClick={() => setSelectedCalendarDate(targetDateStr)}
                              className={`p-2.5 rounded-2xl border flex flex-col items-center justify-between text-center transition-all cursor-pointer relative ${
                                isCurrentDay
                                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-lg font-black scale-105'
                                  : isFriday
                                  ? 'bg-emerald-500/10 border-emerald-500/30 hover:border-emerald-500 text-stone-100'
                                  : 'bg-stone-500/5 border-transparent hover:border-stone-500/30 text-stone-200'
                              }`}
                            >
                              {/* Bangla Day Number */}
                              <div className="text-base sm:text-lg font-black">
                                {toBn(bDay)}
                              </div>

                              {/* Gregorian equivalent day */}
                              <span
                                className={`text-[10px] mt-1 font-semibold ${
                                  isCurrentDay ? 'text-emerald-100' : 'text-stone-400'
                                }`}
                              >
                                {targetGreg}
                              </span>

                              {/* Friday indicator */}
                              {isFriday && (
                                <span className={`text-[8px] font-bold mt-0.5 ${isCurrentDay ? 'text-white' : 'text-emerald-400'}`}>
                                  শুক্রবার
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* TAB 2: FUNCTIONAL AGE CALCULATOR TOOL */}
          {activeTab === 'age' && (
            <div className="space-y-4">
              {/* DOB Picker & Save */}
              <div
                className={`p-4 rounded-2xl border space-y-3 ${
                  darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-stone-50 border-stone-200'
                }`}
              >
                <div>
                  <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                    Select Your Date of Birth (জন্ম তারিখ) *
                  </label>
                  <input
                    type="date"
                    value={dobInput}
                    onChange={(e) => setDobInput(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      darkMode
                        ? 'bg-[#142D21] border-[#224A37] text-white'
                        : 'bg-white border-stone-300 text-stone-900'
                    }`}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-stone-400">
                    Saved in your device profile automatically
                  </span>
                  <button
                    onClick={handleSaveDob}
                    className="px-4 py-2 rounded-xl text-xs font-black text-white bg-blue-600 hover:bg-blue-500 active:scale-95 transition-all shadow-xs"
                  >
                    Save DOB
                  </button>
                </div>
              </div>

              {/* Age Output Metrics */}
              {ageResult ? (
                <div className="space-y-3">
                  {/* Years, Months, Days Banner */}
                  <div
                    className={`p-5 rounded-2xl border text-center relative overflow-hidden shadow-md ${
                      darkMode
                        ? 'bg-gradient-to-br from-[#132C1E] to-[#1E4330] border-[#2E6347]'
                        : 'bg-gradient-to-br from-blue-50 via-white to-emerald-50 border-blue-200/70'
                    }`}
                  >
                    <span className="text-[11px] font-black uppercase tracking-widest text-[#D4AF37] block mb-1">
                      Current Precise Age
                    </span>
                    <div className="text-2xl sm:text-3xl font-black text-stone-900 dark:text-stone-100 flex items-center justify-center gap-2">
                      <span>{ageResult.years} Years</span>
                      <span className="text-stone-400">•</span>
                      <span>{ageResult.months} Months</span>
                      <span className="text-stone-400">•</span>
                      <span>{ageResult.days} Days</span>
                    </div>
                    <p className="text-xs text-stone-400 mt-2">
                      Born on a <span className="font-bold text-[#D4AF37]">{ageResult.dayOfWeek}</span>
                    </p>
                  </div>

                  {/* Next Birthday Countdown */}
                  <div
                    className={`p-4 rounded-2xl border flex items-center justify-between ${
                      darkMode ? 'bg-[#12281E] border-purple-900/40' : 'bg-purple-50/70 border-purple-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-black">
                        <Cake className="w-5 h-5" />
                      </div>
                      <div>
                        <h5 className="text-xs font-black text-purple-400 uppercase tracking-wider">
                          Next Birthday In
                        </h5>
                        <p className="text-sm font-black text-stone-900 dark:text-stone-100">
                          {ageResult.nextBirthdayMonths} Months &amp; {ageResult.nextBirthdayDays} Days
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-black px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {ageResult.nextBirthdayTotalDays} Days Left
                    </span>
                  </div>

                  {/* Lived Breakdown Stats */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div
                      className={`p-3 rounded-xl border text-center ${
                        darkMode ? 'bg-[#12281E] border-emerald-900/30' : 'bg-stone-50 border-stone-200'
                      }`}
                    >
                      <span className="text-[10px] text-stone-400 font-bold block">Total Days</span>
                      <span className="text-sm font-black text-emerald-500">
                        {ageResult.totalDaysLived.toLocaleString()}
                      </span>
                    </div>

                    <div
                      className={`p-3 rounded-xl border text-center ${
                        darkMode ? 'bg-[#12281E] border-emerald-900/30' : 'bg-stone-50 border-stone-200'
                      }`}
                    >
                      <span className="text-[10px] text-stone-400 font-bold block">Total Weeks</span>
                      <span className="text-sm font-black text-[#D4AF37]">
                        {ageResult.totalWeeksLived.toLocaleString()}
                      </span>
                    </div>

                    <div
                      className={`p-3 rounded-xl border text-center ${
                        darkMode ? 'bg-[#12281E] border-emerald-900/30' : 'bg-stone-50 border-stone-200'
                      }`}
                    >
                      <span className="text-[10px] text-stone-400 font-bold block">Total Months</span>
                      <span className="text-sm font-black text-blue-400">
                        {ageResult.totalMonthsLived.toLocaleString()}
                      </span>
                    </div>

                    <div
                      className={`p-3 rounded-xl border text-center ${
                        darkMode ? 'bg-[#12281E] border-emerald-900/30' : 'bg-stone-50 border-stone-200'
                      }`}
                    >
                      <span className="text-[10px] text-stone-400 font-bold block">Total Hours</span>
                      <span className="text-sm font-black text-purple-400">
                        {ageResult.totalHoursLived.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <p className="text-center text-[11px] text-stone-400 italic">
                    &quot;Take benefit of five before five: your youth before your old age, your health before your sickness...&quot; (Hadith)
                  </p>
                </div>
              ) : (
                <div className="text-center py-8 text-stone-400 text-xs">
                  Please pick a valid Date of Birth in the past.
                </div>
              )}
            </div>
          )}

          {/* TAB 3: DAY COUNTDOWN / TARGET TRACKER (দিন গণনা ও লক্ষ্য ট্র্যাকার) */}
          {activeTab === 'countdown' && (
            <div className="space-y-4">
              {/* Top Action Bar */}
              <div
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                  darkMode ? 'bg-[#12281E] border-[#1C3B2C]' : 'bg-stone-50 border-stone-200'
                }`}
              >
                <div>
                  <h4 className="text-xs font-black text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                    <Hourglass className="w-4 h-4 text-amber-500" />
                    <span>Target Date &amp; Day Countdown Tracker</span>
                  </h4>
                  <p className="text-[11px] text-stone-400 font-medium mt-0.5">
                    Track days left until Islamic events, personal goals &amp; milestones
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={handleResetTargets}
                    title="Reset Target Tracker"
                    className="p-2 rounded-xl border border-rose-300/60 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setEditingTargetId(null);
                      setFormTitle('');
                      setFormTitleBn('');
                      setFormDate(new Date().toISOString().split('T')[0]);
                      setFormCategory('Islamic');
                      setFormNotes('');
                      setShowAddTargetForm(!showAddTargetForm);
                    }}
                    className="px-3 py-2 rounded-xl text-xs font-black bg-[#1B4332] text-[#F4E0A5] hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddTargetForm ? 'Close' : 'Add Target'}</span>
                  </button>
                </div>
              </div>

              {/* Add / Edit Inline Form */}
              {showAddTargetForm && (
                <div
                  className={`p-4 rounded-2xl border space-y-3 animate-in fade-in duration-200 ${
                    darkMode
                      ? 'bg-[#142C20] border-[#D4AF37]/40 text-stone-100'
                      : 'bg-emerald-50/60 border-emerald-300 text-stone-900'
                  }`}
                >
                  <div className="flex items-center justify-between pb-1 border-b border-stone-300/30">
                    <span className="text-xs font-black text-[#D4AF37] flex items-center gap-1">
                      <Flag className="w-3.5 h-3.5" />
                      {editingTargetId ? 'Edit Target Date' : 'Add New Target Date'}
                    </span>
                    <button
                      onClick={() => setShowAddTargetForm(false)}
                      className="text-stone-400 hover:text-stone-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Event Title (English) *
                      </label>
                      <input
                        type="text"
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        placeholder="e.g. Ramadan 1448 or Quran Khatam"
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Title in Bengali (বাংলা নাম)
                      </label>
                      <input
                        type="text"
                        value={formTitleBn}
                        onChange={(e) => setFormTitleBn(e.target.value)}
                        placeholder="যেমন: পবিত্র রমজান বা কুরআন খতম"
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Target Date *
                      </label>
                      <input
                        type="date"
                        value={formDate}
                        onChange={(e) => setFormDate(e.target.value)}
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Category (বিভাগ)
                      </label>
                      <select
                        value={formCategory}
                        onChange={(e) => setFormCategory(e.target.value as any)}
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      >
                        <option value="Islamic">Islamic (ইসলামিক দিবস)</option>
                        <option value="Goal">Goal (আমল বা ব্যক্তিগত লক্ষ্য)</option>
                        <option value="Personal">Personal (ব্যক্তিগত)</option>
                        <option value="Family">Family (পারিবারিক)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-stone-400 block mb-1">
                      Notes &amp; Preparations (নোট ও প্রস্তুতি)
                    </label>
                    <input
                      type="text"
                      value={formNotes}
                      onChange={(e) => setFormNotes(e.target.value)}
                      placeholder="Special preparations or intention notes..."
                      className={`w-full px-3 py-1.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                        darkMode
                          ? 'bg-[#0E2017] border-[#224A37] text-white'
                          : 'bg-white border-stone-300 text-stone-900'
                      }`}
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={() => setShowAddTargetForm(false)}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold text-stone-400 hover:text-stone-200"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveTarget}
                      className="px-4 py-1.5 rounded-xl text-xs font-black bg-[#D4AF37] text-stone-950 hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shadow-xs"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{editingTargetId ? 'Save Changes' : 'Add Target Tracker'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Category Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {['All', 'Islamic', 'Goal', 'Personal', 'Family'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setTargetCategoryFilter(cat)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                      targetCategoryFilter === cat
                        ? 'bg-[#1B4332] text-[#F4E0A5] shadow-xs'
                        : darkMode
                        ? 'bg-[#12281E] text-stone-400 hover:text-stone-200'
                        : 'bg-stone-100 text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    {cat === 'All' ? 'All Milestones' : cat}
                  </button>
                ))}
              </div>

              {/* Target List */}
              <div className="space-y-2.5">
                {targetDays
                  .filter(
                    (t) => targetCategoryFilter === 'All' || t.category === targetCategoryFilter
                  )
                  .map((t) => {
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    const target = new Date(t.targetDate + 'T00:00:00');
                    const diffTime = target.getTime() - today.getTime();
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    const isPassed = diffDays < 0;
                    const isToday = diffDays === 0;

                    return (
                      <div
                        key={t.id}
                        className={`p-4 rounded-2xl border transition-all relative overflow-hidden ${
                          isToday
                            ? 'bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border-amber-500 shadow-md ring-2 ring-amber-500/30'
                            : isPassed
                            ? darkMode
                              ? 'bg-[#10231A]/60 border-[#1B3829] opacity-80'
                              : 'bg-stone-50 border-stone-200 opacity-85'
                            : darkMode
                            ? 'bg-[#12281E] border-[#224A37] shadow-xs'
                            : 'bg-white border-emerald-900/10 shadow-xs'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                  t.category === 'Islamic'
                                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                    : t.category === 'Goal'
                                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                    : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                }`}
                              >
                                {t.category}
                              </span>

                              <span className="text-[11px] font-semibold text-stone-400">
                                {t.targetDate}
                              </span>
                            </div>

                            <h5 className="text-sm font-black text-stone-900 dark:text-stone-100 mt-1">
                              {t.title}
                            </h5>
                            {t.titleBn && t.titleBn !== t.title && (
                              <span className="text-xs font-bold text-[#D4AF37] block">
                                {t.titleBn}
                              </span>
                            )}

                            {t.notes && (
                              <p className="text-[11px] text-stone-400 mt-1 font-medium leading-relaxed">
                                {t.notes}
                              </p>
                            )}
                          </div>

                          {/* Countdown Badge & Actions */}
                          <div className="flex flex-col items-end shrink-0 gap-2">
                            <div
                              className={`px-3 py-1.5 rounded-2xl text-center shadow-xs ${
                                isToday
                                  ? 'bg-amber-500 text-stone-950 font-black animate-pulse'
                                  : isPassed
                                  ? darkMode
                                    ? 'bg-[#1A3326] text-stone-400'
                                    : 'bg-stone-200 text-stone-600'
                                  : 'bg-[#1B4332] text-[#F4E0A5] border border-[#D4AF37]/30'
                              }`}
                            >
                              <div className="text-base font-black leading-none">
                                {isToday ? 'TODAY' : Math.abs(diffDays)}
                              </div>
                              <span className="text-[9px] font-bold uppercase tracking-tight block mt-0.5">
                                {isToday
                                  ? 'আজকের দিন!'
                                  : isPassed
                                  ? 'Days Passed (অতীত)'
                                  : 'Days Left (বাকি)'}
                              </span>
                            </div>

                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleEditTarget(t)}
                                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-black/10 dark:hover:bg-white/10"
                                title="Edit"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteTarget(t)}
                                className="p-1.5 rounded-lg text-stone-400 hover:text-rose-400 hover:bg-black/10 dark:hover:bg-white/10"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                {targetDays.filter(
                  (t) => targetCategoryFilter === 'All' || t.category === targetCategoryFilter
                ).length === 0 && (
                  <div className="text-center py-8 text-stone-400 text-xs">
                    No milestone targets found in this category. Click &quot;Add Target&quot; to
                    create one!
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
  );

  if (isScreenMode) {
    return <div id="screen-triple-calendar" className="w-full space-y-4">{modalCard}</div>;
  }

  return (
    <div
      id="modal-triple-calendar"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      {modalCard}
    </div>
  );
};
