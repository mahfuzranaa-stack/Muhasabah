import React from 'react';
import { LayoutGrid, Calendar, Target, Wallet, UserCircle2 } from 'lucide-react';
import { TabType } from '../types';
import { useLanguage } from '../utils/i18n';

const MosqueIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M3 21h18M5 21v-8h14v8M4 13l8-6 8 6M9 13V9l3-3 3 3v4M12 3v3M8 21v-4h8v4" />
    <path d="M12 2c1 0 1.5.7 1.5 1.3S13 4.5 12 5c-1-.5-1.5-1.1-1.5-1.7S11 2 12 2Z" />
  </svg>
);

const TasbihIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="7.5" />
    <circle cx="12" cy="4" r="1.2" />
    <circle cx="18" cy="7" r="1.2" />
    <circle cx="19" cy="13" r="1.2" />
    <circle cx="15" cy="19" r="1.2" />
    <circle cx="9" cy="20" r="1.2" />
    <circle cx="5" cy="16" r="1.2" />
    <path d="M12 19.5V23M10 23h4" />
  </svg>
);

interface BottomNavProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  darkMode: boolean;
  salatCountCompleted: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  darkMode,
  salatCountCompleted,
}) => {
  const { language, t } = useLanguage();

  const navItems: {
    id: TabType;
    label: string;
    labelBn: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }[] = [
    { id: 'dashboard', label: 'Home', labelBn: 'মূলপাতা', icon: LayoutGrid },
    {
      id: 'salat',
      label: 'Salat',
      labelBn: 'সালাত',
      icon: MosqueIcon,
      badge: `${salatCountCompleted}/5`,
    },
    { id: 'dhikr', label: 'Dhikr', labelBn: 'জিকির', icon: TasbihIcon },
    { id: 'calendar', label: 'Calendar', labelBn: 'দিনপঞ্জি', icon: Calendar },
    { id: 'goals', label: 'Goals', labelBn: 'লক্ষ্য', icon: Target },
    { id: 'mal', label: 'Al-Mal', labelBn: 'হিসাব', icon: Wallet },
    { id: 'profile', label: 'Profile', labelBn: 'প্রোফাইল', icon: UserCircle2 },
  ];

  return (
    <nav
      id="muhasabah-bottom-nav"
      role="navigation"
      aria-label="Sticky Bottom Navigation"
      className={`sticky bottom-0 left-0 right-0 z-40 shrink-0 border-t px-1.5 py-1.5 transition-colors duration-200 backdrop-blur-md ${
        darkMode
          ? 'bg-[#0A1510]/95 border-[#1E3B2E] shadow-[0_-8px_25px_rgba(0,0,0,0.6)]'
          : 'bg-white/95 border-emerald-900/10 shadow-[0_-8px_24px_rgba(27,67,50,0.08)]'
      }`}
    >
      <div className="flex items-center justify-between max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              id={`tab-btn-${item.id}`}
              onClick={() => onSelectTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 active:scale-95 group flex-1 min-w-0 ${
                isActive
                  ? darkMode
                    ? 'text-[#F5E6B3]'
                    : 'text-[#1B4332]'
                  : darkMode
                  ? 'text-[#94A3B8] hover:text-stone-100'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              {/* Active illuminated pill background with gold/emerald border */}
              {isActive && (
                <span
                  className={`absolute inset-0 rounded-xl -z-10 transition-all shadow-xs border ${
                    darkMode
                      ? 'bg-gradient-to-b from-[#1C3E2F]/90 to-[#12281E]/95 border-[#D4AF37]/60 shadow-[0_0_14px_rgba(212,175,55,0.22)]'
                      : 'bg-gradient-to-b from-emerald-50 to-white border-emerald-600/30 shadow-[0_2px_8px_rgba(45,106,79,0.1)]'
                  }`}
                />
              )}

              <div className="relative">
                <Icon
                  className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform duration-200 ${
                    isActive
                      ? 'scale-110 text-[#D4AF37] stroke-[2.4]'
                      : 'stroke-[1.8] group-hover:scale-105'
                  }`}
                />
                {item.badge && (
                  <span
                    className={`absolute -top-1.5 -right-3.5 px-1 py-0.2 text-[8px] font-black rounded-full leading-tight shadow-xs ${
                      salatCountCompleted === 5
                        ? 'bg-emerald-500 text-white'
                        : 'bg-[#D4AF37] text-stone-950'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[9px] sm:text-[10px] mt-0.5 tracking-tight transition-all truncate max-w-full ${
                  isActive
                    ? darkMode
                      ? 'font-black text-[#F5E6B3]'
                      : 'font-black text-[#1B4332]'
                    : 'font-semibold'
                }`}
              >
                {language === 'bn' ? item.labelBn : item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
