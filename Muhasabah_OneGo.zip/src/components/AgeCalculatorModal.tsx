import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Sparkles,
  Clock,
  Heart,
  Gift,
  Moon,
  Sun,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { AgeCalculationResult } from '../types';

interface AgeCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  savedDob: string;
  onSaveDob: (dob: string) => void;
}

const DAYS_OF_WEEK = [
  'Sunday (রবিবার)',
  'Monday (সোমবার)',
  'Tuesday (মঙ্গলবার)',
  'Wednesday (বুধবার)',
  'Thursday (বৃহস্পতিবার)',
  'Friday (শুক্রবার - ফজিলতপূর্ণ জুমাবার)',
  'Saturday (শনিবার)',
];

export const calculateDetailedAge = (birthDateStr: string) => {
  if (!birthDateStr) return null;
  const birthDate = new Date(birthDateStr);
  const today = new Date();

  if (isNaN(birthDate.getTime()) || birthDate > today) {
    return null;
  }

  // Solar (Gregorian) calculation
  let years = today.getFullYear() - birthDate.getFullYear();
  let months = today.getMonth() - birthDate.getMonth();
  let days = today.getDate() - birthDate.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
    days += prevMonth.getDate();
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  // Next Birthday calculation
  let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  if (nextBirthday < today) {
    nextBirthday = new Date(today.getFullYear() + 1, birthDate.getMonth(), birthDate.getDate());
  }

  const diffTime = nextBirthday.getTime() - today.getTime();
  const nextBirthdayTotalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  let nbMonths = nextBirthday.getMonth() - today.getMonth();
  let nbDays = nextBirthday.getDate() - today.getDate();
  if (nbDays < 0) {
    nbMonths -= 1;
    const prevM = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
    nbDays += prevM.getDate();
  }
  if (nbMonths < 0) {
    nbMonths += 12;
  }

  // Totals lived
  const totalMs = today.getTime() - birthDate.getTime();
  const totalDaysLived = Math.floor(totalMs / (1000 * 60 * 60 * 24));
  const totalWeeksLived = Math.floor(totalDaysLived / 7);
  const totalMonthsLived = years * 12 + months;
  const totalHoursLived = Math.floor(totalMs / (1000 * 60 * 60));

  // Islamic Lunar (Hijri) Age: 1 Lunar year = 354.367 days
  const hijriYearsDecimal = totalDaysLived / 354.367;
  const hijriYears = Math.floor(hijriYearsDecimal);
  const remainingHijriDays = Math.floor((hijriYearsDecimal - hijriYears) * 354.367);
  const hijriMonths = Math.floor(remainingHijriDays / 29.53);
  const hijriDays = Math.floor(remainingHijriDays % 29.53);

  // Spiritual Lifetime Estimates (assuming takleef / puberty around 14 years old)
  const adultYears = Math.max(0, years - 14);
  const adultDays = adultYears * 365.25;
  const lifetimeSalatEstimated = Math.round(adultDays * 5);
  const lifetimeRamadanDaysEstimated = Math.round(adultYears * 29.5);

  const dayOfWeek = DAYS_OF_WEEK[birthDate.getDay()];

  return {
    solar: {
      years,
      months,
      days,
    },
    hijri: {
      years: hijriYears,
      months: hijriMonths,
      days: hijriDays,
    },
    spiritual: {
      lifetimeSalatEstimated,
      lifetimeRamadanDaysEstimated,
      adultYears,
    },
    nextBirthdayMonths: nbMonths,
    nextBirthdayDays: nbDays,
    nextBirthdayTotalDays,
    totalDaysLived,
    totalWeeksLived,
    totalMonthsLived,
    totalHoursLived,
    dayOfWeek,
  };
};

export const AgeCalculatorModal: React.FC<AgeCalculatorModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  savedDob,
  onSaveDob,
}) => {
  const [dob, setDob] = useState<string>(savedDob || '2000-01-01');
  const [result, setResult] = useState(() => calculateDetailedAge(savedDob || '2000-01-01'));

  useEffect(() => {
    const targetDob = savedDob || '2000-01-01';
    setDob(targetDob);
    setResult(calculateDetailedAge(targetDob));
  }, [savedDob]);

  const handleDobChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDob = e.target.value;
    setDob(newDob);
    setResult(calculateDetailedAge(newDob));
    onSaveDob(newDob);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[92vh] rounded-[26px] border shadow-2xl flex flex-col overflow-hidden transition-all ${
          darkMode
            ? 'bg-[#10241A] border-[#224A37] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header with Deep Emerald Gradient */}
        <div className="p-4 border-b border-emerald-800/40 flex items-center justify-between bg-gradient-to-r from-[#1B4332] via-[#245842] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#D4AF37] text-stone-950 shadow-md">
              <Calendar className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Age &amp; Muhasabat al-Umr
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/30 text-[#F5E6B3] border border-[#D4AF37]/50 font-bold">
                  Miladi &amp; Hijri
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Exact Gregorian &amp; Islamic Lunar Age, Lifetime Salat &amp; Countdown
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {/* DOB Input Selector */}
          <div className="p-3.5 rounded-2xl bg-[#E8F5E9]/60 dark:bg-[#152E22] border border-[#D4AF37]/35">
            <label className="text-xs font-black uppercase tracking-wider text-[#1B4332] dark:text-[#F4E0A5] block mb-1.5">
              Select Your Date of Birth (জন্ম তারিখ)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={dob}
                max={new Date().toISOString().split('T')[0]}
                onChange={handleDobChange}
                className="flex-1 px-3 py-2 text-sm font-bold rounded-xl border border-stone-300 dark:border-[#254F3E] bg-white dark:bg-[#0E1E17] text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
            <span className="text-[10px] text-stone-500 dark:text-stone-400 mt-1 block">
              Auto-persisted in local storage for instant age calculation
            </span>
          </div>

          {result && (
            <>
              {/* Twin Display: Gregorian (Solar) & Hijri (Lunar) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {/* 1. Gregorian Age */}
                <div
                  className={`rounded-2xl p-4 border text-center transition-all shadow-sm ${
                    darkMode
                      ? 'bg-gradient-to-br from-[#0B1E15] to-[#153325] border-emerald-800'
                      : 'bg-gradient-to-br from-[#1B4332] to-[#245942] text-white'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-[11px] font-bold text-[#F4E0A5] uppercase tracking-wider mb-1">
                    <Sun className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Solar Age (ইংরেজি বয়স)</span>
                  </div>
                  <div className="text-2xl font-black text-white font-mono">
                    {result.solar.years} <span className="text-xs font-medium text-emerald-200">Y</span>{' '}
                    {result.solar.months} <span className="text-xs font-medium text-emerald-200">M</span>{' '}
                    {result.solar.days} <span className="text-xs font-medium text-emerald-200">D</span>
                  </div>
                  <div className="text-[10px] text-emerald-100/80 mt-1">
                    Solar cycle (365.25 days)
                  </div>
                </div>

                {/* 2. Hijri Lunar Age */}
                <div
                  className={`rounded-2xl p-4 border text-center transition-all shadow-sm ${
                    darkMode
                      ? 'bg-gradient-to-br from-[#1C1605] to-[#2E2408] border-[#D4AF37]/50'
                      : 'bg-gradient-to-br from-[#2E2408] to-[#45360D] text-white'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-[11px] font-bold text-[#F4E0A5] uppercase tracking-wider mb-1">
                    <Moon className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Hijri Lunar Age (হিজরি বয়স)</span>
                  </div>
                  <div className="text-2xl font-black text-[#F4E0A5] font-mono">
                    {result.hijri.years} <span className="text-xs font-medium text-stone-300">Y</span>{' '}
                    {result.hijri.months} <span className="text-xs font-medium text-stone-300">M</span>{' '}
                    {result.hijri.days} <span className="text-xs font-medium text-stone-300">D</span>
                  </div>
                  <div className="text-[10px] text-amber-200/80 mt-1">
                    Lunar cycle (354.36 days, ~3% faster)
                  </div>
                </div>
              </div>

              {/* Day of Birth Badge */}
              <div className="p-3 rounded-xl bg-stone-100 dark:bg-[#142C20] border border-stone-200 dark:border-[#224A37] text-xs flex items-center justify-between">
                <span className="text-stone-500 dark:text-stone-400 font-medium">
                  Born on Day of Week:
                </span>
                <span className="font-extrabold text-[#1B4332] dark:text-[#F4E0A5]">
                  {result.dayOfWeek}
                </span>
              </div>

              {/* Next Birthday Countdown Card */}
              <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-[#2B2713] border border-amber-200 dark:border-amber-800/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-[#D4AF37] text-stone-950">
                    <Gift className="w-4 h-4 font-black" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-300 block">
                      Next Birthday Countdown
                    </span>
                    <div className="text-xs font-black text-amber-950 dark:text-[#FFF9E6]">
                      {result.nextBirthdayMonths > 0
                        ? `${result.nextBirthdayMonths} Months & ${result.nextBirthdayDays} Days Remaining`
                        : `${result.nextBirthdayDays} Days Remaining`}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-base font-black font-mono text-amber-800 dark:text-amber-300">
                    {result.nextBirthdayTotalDays}d
                  </span>
                </div>
              </div>

              {/* Spiritual Lifetime Accounting (Muhasabat al-Umr) */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 px-1">
                  <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span className="text-xs font-black uppercase tracking-wider text-stone-400">
                    Spiritual Lifetime Accounting (জীবনের হিসাব)
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-[#142B20] border border-emerald-200 dark:border-[#224A37]">
                    <span className="text-[10px] font-bold text-stone-500 dark:text-stone-400 block">
                      Est. Fardh Prayers Since Bulugh
                    </span>
                    <span className="text-base font-black font-mono text-[#1B4332] dark:text-[#52B788]">
                      ~{result.spiritual.lifetimeSalatEstimated.toLocaleString()}
                    </span>
                    <span className="text-[9px] text-stone-400 block mt-0.5">
                      {result.spiritual.adultYears} accountable years
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-[#142B20] border border-emerald-200 dark:border-[#224A37]">
                    <span className="text-[10px] font-bold text-stone-500 dark:text-stone-400 block">
                      Est. Ramadan Fasts
                    </span>
                    <span className="text-base font-black font-mono text-[#1B4332] dark:text-[#52B788]">
                      ~{result.spiritual.lifetimeRamadanDaysEstimated.toLocaleString()} Days
                    </span>
                    <span className="text-[9px] text-stone-400 block mt-0.5">
                      Fasting seasons lived
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-stone-50 dark:bg-[#142B20] border border-stone-200 dark:border-[#254F3E]">
                    <span className="text-[10px] font-bold text-stone-500 block">Total Days Lived</span>
                    <span className="text-base font-black font-mono text-stone-800 dark:text-stone-200">
                      {result.totalDaysLived.toLocaleString()} Days
                    </span>
                    <span className="text-[9px] text-stone-400 block mt-0.5">
                      ~{result.totalWeeksLived.toLocaleString()} Weeks
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-stone-50 dark:bg-[#142B20] border border-stone-200 dark:border-[#254F3E]">
                    <span className="text-[10px] font-bold text-stone-500 block">Total Hours</span>
                    <span className="text-base font-black font-mono text-stone-800 dark:text-stone-200">
                      {result.totalHoursLived.toLocaleString()} Hours
                    </span>
                    <span className="text-[9px] text-stone-400 block mt-0.5">
                      Counted seconds of breath
                    </span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] text-center text-[11px] text-stone-500">
          রাসূলুল্লাহ (সা.) বলেছেন: &quot;তোমাদের মধ্যে সর্বোত্তম ব্যক্তি সে, যার হায়াত দীর্ঘ এবং আমল সুন্দর হয়।&quot; (তিরমিজি)
        </div>
      </div>
    </div>
  );
};
