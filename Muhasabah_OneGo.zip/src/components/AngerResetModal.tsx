import React, { useState, useEffect } from 'react';
import {
  X,
  Flame,
  Shield,
  Heart,
  Droplets,
  RotateCcw,
  Sparkles,
  Volume2,
  Check,
  Pause,
  Play,
} from 'lucide-react';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface AngerResetModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

export const AngerResetModal: React.FC<AngerResetModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isBreathing, setIsBreathing] = useState<boolean>(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (secondsRemaining === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      playNotificationTone(soundEnabled);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, secondsRemaining, soundEnabled]);

  useEffect(() => {
    let breathInterval: NodeJS.Timeout;
    if (isBreathing) {
      let count = 0;
      breathInterval = setInterval(() => {
        count = (count + 1) % 19;
        if (count < 4) setBreathPhase('Inhale'); // 4s
        else if (count < 11) setBreathPhase('Hold'); // 7s
        else setBreathPhase('Exhale'); // 8s
      }, 1000);
    }
    return () => clearInterval(breathInterval);
  }, [isBreathing]);

  if (!isOpen) return null;

  const STEPS = [
    {
      step: 1,
      title: 'Seek Refuge (তাআউয পাঠ)',
      arabic: 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ',
      transliteration: "A'udhu billahi minash-shaytanir-rajeem",
      meaning: 'আমি বিতাড়িত শয়তান থেকে আল্লাহর আশ্রয় প্রার্থনা করছি।',
      reference: 'সহিহ বুখারি: ৬১১৫ (রাসূল ﷺ বলেন: আমি এমন একটি বাক্য জানি যা বললে তার রাগ দূর হবে)',
    },
    {
      step: 2,
      title: 'Change Body Posture (শারীরিক অবস্থান পরিবর্তন)',
      arabic: '',
      transliteration: '',
      meaning: 'দাঁড়ানো থাকলে বসে পড়ুন; বসে থাকলে শুয়ে পড়ুন।',
      reference: 'সুনানে আবু দাউদ: ৪৭৮২ (রাসূল ﷺ বলেন: রাগের সময় দাঁড়িয়ে থাকলে বসে পড়ো, রাগ না থামলে শুয়ে পড়ো)',
    },
    {
      step: 3,
      title: 'Perform Cool Wudu (শীতল পানি দিয়ে অজু)',
      arabic: '',
      transliteration: '',
      meaning: 'অজু করে মুখমণ্ডল ও হাত-পা শীতল পানি দিয়ে ধৌত করুন।',
      reference: 'সুনানে আবু দাউদ: ৪৭৮৪ (রাগ শয়তানের পক্ষ থেকে, শয়তান আগুন থেকে সৃষ্ট, আর আগুন নিভে পানি দ্বারা)',
    },
    {
      step: 4,
      title: 'Sacred Silence (নীরবতা অবলম্বন)',
      arabic: '',
      transliteration: '',
      meaning: 'এই মুহূর্তে কোনো অপ্রীতিকর উত্তর বা মন্তব্য করা থেকে জিহ্বাকে সম্পূর্ণ সংযত রাখুন।',
      reference: 'মুসনাদে আহমাদ: ২১৩৬ (যখন তোমাদের কারো রাগ আসে, সে যেন নীরবতা অবলম্বন করে)',
    },
  ];

  return (
    <div
      id="modal-anger-reset"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-500 flex items-center justify-center font-black shadow-xs">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Anger Reset &amp; Calm</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  রাগ নিয়ন্ত্রণ ও প্রশান্তি
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                Sunnah 4-Step Anger Quenching &amp; Diaphragmatic Calm Guide
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Breathing Visualizer */}
          <div
            className={`p-5 rounded-2xl border text-center flex flex-col items-center justify-center relative overflow-hidden ${
              darkMode ? 'bg-[#12281E]/80 border-[#1E4332]' : 'bg-emerald-50/70 border-emerald-200'
            }`}
          >
            <div className="text-xs font-black text-emerald-600 dark:text-emerald-400 mb-2">
              4-7-8 Sunnah Mindfulness Breathing
            </div>

            {/* Pulsing breathing bubble */}
            <div
              className={`w-28 h-28 rounded-full border-4 border-emerald-500 flex flex-col items-center justify-center transition-all duration-1000 ${
                isBreathing
                  ? breathPhase === 'Inhale'
                    ? 'scale-110 bg-emerald-500/20 shadow-lg'
                    : breathPhase === 'Hold'
                    ? 'scale-105 bg-amber-500/20 border-amber-500'
                    : 'scale-90 bg-blue-500/20 border-blue-500'
                  : 'bg-emerald-500/10'
              }`}
            >
              <span className="text-sm font-black text-stone-800 dark:text-stone-100">
                {isBreathing ? breathPhase : 'Calm Mind'}
              </span>
              <span className="text-[10px] text-stone-400 font-bold mt-0.5">
                {isBreathing
                  ? breathPhase === 'Inhale'
                    ? 'Inhale (4s)'
                    : breathPhase === 'Hold'
                    ? 'Hold (7s)'
                    : 'Exhale (8s)'
                  : 'Tap Start'}
              </span>
            </div>

            <div className="flex gap-2 mt-4">
              <button
                onClick={() => {
                  playDhikrClick(soundEnabled);
                  setIsBreathing(!isBreathing);
                }}
                className={`px-4 py-1.5 rounded-xl text-xs font-black transition-all ${
                  isBreathing
                    ? 'bg-rose-500 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                }`}
              >
                {isBreathing ? 'Pause Breathing' : 'Start Breathing Guide'}
              </button>

              <button
                onClick={() => {
                  setIsTimerRunning(!isTimerRunning);
                  if (secondsRemaining === 0) setSecondsRemaining(60);
                }}
                className="px-3 py-1.5 rounded-xl bg-stone-200 dark:bg-stone-700 text-xs font-black text-stone-700 dark:text-stone-200"
              >
                {isTimerRunning ? `Pause (${secondsRemaining}s)` : `1-Min Timer (${secondsRemaining}s)`}
              </button>
            </div>
          </div>

          {/* 4 Sunnah Steps Protocol */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
              Authentic Sunnah Protocol to Quench Anger (৪টি সুন্নাহ আমল)
            </h4>

            {STEPS.map((item) => (
              <div
                key={item.step}
                className={`p-3.5 rounded-2xl border transition-all ${
                  darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500 text-stone-950 font-black text-[10px] flex items-center justify-center">
                    {item.step}
                  </span>
                  <h5 className="text-xs font-black text-stone-900 dark:text-stone-100">
                    {item.title}
                  </h5>
                </div>

                {item.arabic && (
                  <p
                    className="text-right text-base font-bold font-serif leading-relaxed text-emerald-600 dark:text-[#D4AF37] my-1"
                    dir="rtl"
                  >
                    {item.arabic}
                  </p>
                )}

                {item.transliteration && (
                  <p className="text-[11px] text-stone-500 italic">{item.transliteration}</p>
                )}

                <p className="text-xs text-stone-700 dark:text-stone-300 font-medium mt-1">
                  {item.meaning}
                </p>

                <p className="text-[10px] text-stone-400 font-semibold mt-1">{item.reference}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
