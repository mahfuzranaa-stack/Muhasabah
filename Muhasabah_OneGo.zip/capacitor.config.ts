import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.muhasabah.islamiccompanion',
  appName: 'Muhasabah',
  webDir: 'dist',
  android: {
    backgroundColor: '#0E2017',
  },
};

export default config;
