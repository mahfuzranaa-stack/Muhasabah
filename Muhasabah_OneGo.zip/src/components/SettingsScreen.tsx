import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Globe,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  RotateCcw,
  Download,
  Upload,
  ShieldCheck,
  Compass,
  MapPin,
  RefreshCw,
  Info,
  CheckCircle2,
  AlertTriangle,
  Bell,
  Sparkles,
  Smartphone,
  ExternalLink,
  ArrowLeft,
} from 'lucide-react';
import { useLanguage } from '../utils/i18n';
import { LocationConfig } from '../types';
import { playNotificationTone, playDhikrClick } from '../utils/audio';

interface SettingsScreenProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  location: LocationConfig;
  onUpdateLocation: () => void;
  isUpdatingLocation: boolean;
  onOpenOffsetModal?: () => void;
  onOpenLocationModal?: () => void;
  onResetAllData?: () => void;
  onExportAllData?: () => string;
  onImportAllData?: (jsonStr: string) => boolean;
  onNavigateTab?: (tab: any) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  darkMode,
  onToggleDarkMode,
  soundEnabled,
  onToggleSound,
  location,
  onUpdateLocation,
  isUpdatingLocation,
  onOpenOffsetModal,
  onOpenLocationModal,
  onResetAllData,
  onExportAllData,
  onImportAllData,
  onNavigateTab,
}) => {
  const { language, setLanguage, t } = useLanguage();
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleExport = () => {
    if (!onExportAllData) return;
    const jsonStr = onExportAllData();
    try {
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `muhasabah-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(language === 'bn' ? 'ব্যাকআপ ডাউনলোড সম্পন্ন হয়েছে!' : 'Backup downloaded successfully!');
    } catch {
      navigator.clipboard.writeText(jsonStr);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
      showToast(language === 'bn' ? 'ক্লিপবোর্ডে কপি করা হয়েছে' : 'Backup copied to clipboard');
    }
  };

  const handleImport = () => {
    if (!onImportAllData || !importJsonText.trim()) return;
    const success = onImportAllData(importJsonText.trim());
    if (success) {
      setShowImportModal(false);
      setImportJsonText('');
      showToast(language === 'bn' ? 'ডাটা সফলভাবে রিস্টোর হয়েছে!' : 'Data restored successfully!');
    } else {
      showToast(language === 'bn' ? 'ভুল ফরম্যাট! পুনরায় চেষ্টা করুন।' : 'Invalid format. Please try again.');
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-stone-900/95 text-[#D4AF37] font-bold text-xs shadow-2xl border border-[#D4AF37]/40 flex items-center gap-2 backdrop-blur-md">
          <Sparkles className="w-4 h-4 text-[#D4AF37]" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Screen Title Card */}
      <div
        id="card-settings-header"
        className={`p-5 rounded-[24px] border relative overflow-hidden transition-all ${
          darkMode
            ? 'bg-gradient-to-br from-[#12281E] via-[#0D1C15] to-[#0A1611] border-[#224735] text-stone-100 shadow-[0_8px_24px_rgba(0,0,0,0.35)]'
            : 'bg-gradient-to-br from-white via-emerald-50/50 to-stone-50 border-emerald-900/10 text-stone-900 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {onNavigateTab && (
              <button
                id="btn-settings-back"
                onClick={() => onNavigateTab('profile')}
                className="p-2.5 rounded-xl bg-stone-100 dark:bg-[#163024] text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-[#1F4533] active:scale-95 transition-all cursor-pointer"
                title={language === 'bn' ? 'ফিরে যান' : 'Go Back'}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="p-3 rounded-2xl bg-[#1B4332] text-[#D4AF37] border border-[#D4AF37]/30 shadow-xs">
              <SettingsIcon className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight">
                {language === 'bn' ? 'অ্যাপ সেটিংস' : 'App Settings'}
              </h1>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5 font-medium">
                {language === 'bn'
                  ? 'ভাষা, থিম, অডিও ও ডাটা পরিচালনা করুন'
                  : 'Manage language, theme, audio & app data'}
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-[11px] font-black bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30">
            v3.0 Prod
          </span>
        </div>
      </div>

      {/* 1. Language System Toggle */}
      <div
        id="card-settings-language"
        className={`p-5 rounded-[24px] border transition-all ${
          darkMode
            ? 'bg-[#12281E]/90 border-[#224735] text-stone-100'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-[#2D6A4F] dark:text-[#74C69D]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold">
                {language === 'bn' ? 'অ্যাপের ভাষা' : 'App Language'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {language === 'bn'
                  ? 'বাংলা এবং ইংরেজির মধ্যে তাৎক্ষণিক পরিবর্তন'
                  : 'Switch instantly between English & Bengali'}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            id="btn-lang-bn"
            onClick={() => {
              setLanguage('bn');
              playDhikrClick(soundEnabled);
              showToast('ভাষা পরিবর্তন করা হয়েছে: বাংলা');
            }}
            className={`p-3.5 rounded-[18px] border text-left transition-all cursor-pointer ${
              language === 'bn'
                ? 'bg-[#1B4332] text-white border-[#D4AF37] shadow-md ring-2 ring-[#D4AF37]/40'
                : 'bg-stone-50 dark:bg-[#163024] border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:border-emerald-500/40'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-base font-extrabold">বাংলা</span>
              {language === 'bn' && <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />}
            </div>
            <p className="text-[11px] opacity-80 font-medium leading-tight">
              {language === 'bn' ? 'পূর্ণাঙ্গ বাংলা ইন্টারফেস' : 'Complete Bengali interface'}
            </p>
          </button>

          <button
            id="btn-lang-en"
            onClick={() => {
              setLanguage('en');
              playDhikrClick(soundEnabled);
              showToast('Language updated: English');
            }}
            className={`p-3.5 rounded-[18px] border text-left transition-all cursor-pointer ${
              language === 'en'
                ? 'bg-[#1B4332] text-white border-[#D4AF37] shadow-md ring-2 ring-[#D4AF37]/40'
                : 'bg-stone-50 dark:bg-[#163024] border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:border-emerald-500/40'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-base font-extrabold">English</span>
              {language === 'en' && <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />}
            </div>
            <p className="text-[11px] opacity-80 font-medium leading-tight">
              {language === 'bn' ? 'সম্পূর্ণ ইংরেজি ইন্টারফেস' : 'Complete English interface'}
            </p>
          </button>
        </div>
      </div>

      {/* 2. Global Theme (Dark / Pure Charcoal / Light) */}
      <div
        id="card-settings-theme"
        className={`p-5 rounded-[24px] border transition-all ${
          darkMode
            ? 'bg-[#12281E]/90 border-[#224735] text-stone-100'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-[#D4AF37]">
              {darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-sm font-extrabold">
                {language === 'bn' ? 'ভিজ্যুয়াল থিম' : 'Visual Theme'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {language === 'bn'
                  ? 'চারকোল ডার্ক ও এমেরাল্ড লাইট ডিসপ্লে'
                  : 'Deep charcoal dark & emerald light appearance'}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            id="btn-theme-dark"
            onClick={() => {
              if (!darkMode) onToggleDarkMode();
              playDhikrClick(soundEnabled);
              showToast(language === 'bn' ? 'ডার্ক মোড সক্রিয়' : 'Dark Mode Enabled');
            }}
            className={`p-3.5 rounded-[18px] border text-left transition-all cursor-pointer ${
              darkMode
                ? 'bg-[#1B4332] text-white border-[#D4AF37] shadow-md ring-2 ring-[#D4AF37]/40'
                : 'bg-stone-50 dark:bg-[#163024] border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-extrabold flex items-center gap-1.5">
                <Moon className="w-4 h-4 text-[#D4AF37]" />
                {language === 'bn' ? 'ডার্ক মোড' : 'Dark Mode'}
              </span>
              {darkMode && <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />}
            </div>
            <p className="text-[11px] opacity-80 leading-tight">
              {language === 'bn' ? 'চোখের সুরক্ষায় কালো ও গোল্ড' : 'Eye-safe black, emerald & gold'}
            </p>
          </button>

          <button
            id="btn-theme-light"
            onClick={() => {
              if (darkMode) onToggleDarkMode();
              playDhikrClick(soundEnabled);
              showToast(language === 'bn' ? 'লাইট মোড সক্রিয়' : 'Light Mode Enabled');
            }}
            className={`p-3.5 rounded-[18px] border text-left transition-all cursor-pointer ${
              !darkMode
                ? 'bg-[#1B4332] text-white border-[#D4AF37] shadow-md ring-2 ring-[#D4AF37]/40'
                : 'bg-stone-50 dark:bg-[#163024] border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-extrabold flex items-center gap-1.5">
                <Sun className="w-4 h-4 text-[#D4AF37]" />
                {language === 'bn' ? 'লাইট মোড' : 'Light Mode'}
              </span>
              {!darkMode && <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />}
            </div>
            <p className="text-[11px] opacity-80 leading-tight">
              {language === 'bn' ? 'উজ্জ্বল সাদা ও নরম সবুজ' : 'Clean crisp white & soft emerald'}
            </p>
          </button>
        </div>
      </div>

      {/* 3. Audio & Haptic Feedback */}
      <div
        id="card-settings-audio"
        className={`p-5 rounded-[24px] border transition-all ${
          darkMode
            ? 'bg-[#12281E]/90 border-[#224735] text-stone-100'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold">
                {language === 'bn' ? 'অডিও ও সাউন্ড সেটিংস' : 'Audio & Feedback'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {language === 'bn'
                  ? 'তেলাওয়াত, তাসবিহ ক্লিক ও নোটিফিকেশন শব্দ'
                  : 'Recitation audio, tasbih click & chime'}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-2.5">
          <div className="flex items-center justify-between p-3.5 rounded-[18px] bg-stone-50 dark:bg-[#163024] border border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-3">
              {soundEnabled ? (
                <Volume2 className="w-5 h-5 text-emerald-600 dark:text-[#74C69D]" />
              ) : (
                <VolumeX className="w-5 h-5 text-stone-400" />
              )}
              <div>
                <div className="text-xs font-extrabold text-stone-800 dark:text-stone-200">
                  {language === 'bn' ? 'অ্যাপ সাউন্ড ইফেক্ট' : 'App Sound Effects'}
                </div>
                <div className="text-[11px] text-stone-500 dark:text-stone-400">
                  {soundEnabled
                    ? language === 'bn' ? 'ক্লিক ও অ্যালার্ট শব্দ চালু' : 'Click & alert sound enabled'
                    : language === 'bn' ? 'শব্দহীন' : 'Muted'}
                </div>
              </div>
            </div>

            <button
              id="btn-toggle-sound"
              onClick={() => {
                onToggleSound();
                if (!soundEnabled) {
                  setTimeout(() => playNotificationTone(true), 100);
                }
                showToast(
                  !soundEnabled
                    ? language === 'bn' ? 'শব্দ সক্রিয় করা হয়েছে' : 'Sound enabled'
                    : language === 'bn' ? 'শব্দ নিঃশব্দ করা হয়েছে' : 'Sound muted'
                );
              }}
              className={`px-3 py-1.5 rounded-full text-xs font-black transition-all cursor-pointer ${
                soundEnabled
                  ? 'bg-[#1B4332] text-white border border-[#D4AF37]/50'
                  : 'bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
              }`}
            >
              {soundEnabled ? (language === 'bn' ? 'চালু' : 'ON') : (language === 'bn' ? 'বন্ধ' : 'OFF')}
            </button>
          </div>

          <div className="flex items-center justify-between p-3.5 rounded-[18px] bg-stone-50 dark:bg-[#163024] border border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <div className="text-xs font-extrabold text-stone-800 dark:text-stone-200">
                  {language === 'bn' ? 'কুরআন ও দোয়ার অডিও কোয়ালিটি' : 'Quran & Dua Audio Stream'}
                </div>
                <div className="text-[11px] text-stone-500 dark:text-stone-400">
                  {language === 'bn' ? 'মিশারি আল-আফাসী' : 'Mishary Al-Afasy (HQ)'}
                </div>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
              Verified CDN
            </span>
          </div>
        </div>
      </div>

      {/* 4. Location & Prayer Calculation */}
      <div
        id="card-settings-location"
        className={`p-5 rounded-[24px] border transition-all ${
          darkMode
            ? 'bg-[#12281E]/90 border-[#224735] text-stone-100'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold">
                {language === 'bn' ? 'অবস্থান ও সালাত ক্যালকুলেশন' : 'Location & Salat Time'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {language === 'bn'
                  ? 'জিপিএস স্থানাঙ্ক ও ইসলামিক ফাউন্ডেশন বাংলাদেশ হিসাব'
                  : 'GPS coordinates & calculation methodology'}
              </p>
            </div>
          </div>
        </div>

        <div className="p-3.5 rounded-[18px] bg-stone-50 dark:bg-[#163024] border border-stone-200 dark:border-stone-800 mb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-rose-500" />
              <div>
                <div className="text-xs font-bold text-stone-800 dark:text-stone-200">
                  {location.name || 'Dhaka, Bangladesh'}
                </div>
                <div className="text-[10px] font-mono text-stone-400">
                  {location.latitude.toFixed(4)}°N, {location.longitude.toFixed(4)}°E (GMT+6)
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                onUpdateLocation();
                showToast(language === 'bn' ? 'জিপিএস অবস্থান আপডেট হচ্ছে...' : 'Updating GPS location...');
              }}
              disabled={isUpdatingLocation}
              className="p-2 rounded-xl bg-[#1B4332] text-[#D4AF37] hover:bg-[#2D6A4F] transition-all cursor-pointer disabled:opacity-50"
              title="Refresh GPS"
            >
              <RefreshCw className={`w-4 h-4 ${isUpdatingLocation ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {onOpenLocationModal && (
            <button
              onClick={onOpenLocationModal}
              className="p-2.5 rounded-xl bg-stone-100 dark:bg-[#1A382B] text-xs font-bold text-stone-800 dark:text-stone-200 hover:text-[#D4AF37] transition-all text-center cursor-pointer"
            >
              {language === 'bn' ? 'জেলা পরিবর্তন করুন' : 'Change District'}
            </button>
          )}
          {onOpenOffsetModal && (
            <button
              onClick={onOpenOffsetModal}
              className="p-2.5 rounded-xl bg-stone-100 dark:bg-[#1A382B] text-xs font-bold text-stone-800 dark:text-stone-200 hover:text-[#D4AF37] transition-all text-center cursor-pointer"
            >
              {language === 'bn' ? 'ওয়াক্ত অফসেট সমন্বয়' : 'Adjust Waqt Offsets'}
            </button>
          )}
        </div>
      </div>

      {/* 5. Data Backup & Restore */}
      <div
        id="card-settings-backup"
        className={`p-5 rounded-[24px] border transition-all ${
          darkMode
            ? 'bg-[#12281E]/90 border-[#224735] text-stone-100'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold">
                {language === 'bn' ? 'ডাটা ব্যাকআপ ও রিস্টোর' : 'Data Backup & Restore'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {language === 'bn'
                  ? 'আপনার সমস্ত আমল ও হিসাব সুরক্ষিত রাখুন'
                  : 'Export or restore complete user records'}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            id="btn-export-data"
            onClick={handleExport}
            className="p-3.5 rounded-[18px] bg-stone-50 dark:bg-[#163024] border border-stone-200 dark:border-stone-800 flex items-center justify-center gap-2 text-xs font-bold text-stone-800 dark:text-stone-200 hover:border-emerald-500 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4 text-emerald-600 dark:text-[#74C69D]" />
            <span>{language === 'bn' ? 'ব্যাকআপ ডাউনলোড' : 'Export Backup'}</span>
          </button>

          <button
            id="btn-import-data"
            onClick={() => setShowImportModal(true)}
            className="p-3.5 rounded-[18px] bg-stone-50 dark:bg-[#163024] border border-stone-200 dark:border-stone-800 flex items-center justify-center gap-2 text-xs font-bold text-stone-800 dark:text-stone-200 hover:border-[#D4AF37] cursor-pointer transition-all"
          >
            <Upload className="w-4 h-4 text-[#D4AF37]" />
            <span>{language === 'bn' ? 'ডাটা রিস্টোর' : 'Restore Data'}</span>
          </button>
        </div>
      </div>

      {/* 6. Danger Zone: Reset All Data */}
      <div
        id="card-settings-reset"
        className={`p-5 rounded-[24px] border transition-all ${
          darkMode
            ? 'bg-rose-950/20 border-rose-900/40 text-stone-100'
            : 'bg-rose-50/50 border-rose-200 text-stone-900'
        }`}
      >
        <div className="flex items-start gap-3 mb-3">
          <div className="p-2 rounded-xl bg-rose-500/15 text-rose-600 dark:text-rose-400 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-rose-900 dark:text-rose-300">
              {language === 'bn' ? 'সকল ডাটা রিসেট' : 'Reset All Application Data'}
            </h3>
            <p className="text-xs text-rose-700/80 dark:text-rose-400/80 mt-0.5">
              {language === 'bn'
                ? 'সালাতের রেকর্ড, তাসবিহ কাউন্ট ও সমস্ত হিস্টোরি মুছে পুনরায় শুরু করুন।'
                : 'Clear all prayer checks, tasbih counts, daily tasks, and start fresh.'}
            </p>
          </div>
        </div>

        <button
          id="btn-trigger-reset-confirm"
          onClick={() => setShowResetConfirm(true)}
          className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-all shadow-xs cursor-pointer flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{language === 'bn' ? 'সকল ডাটা মুছে নতুন সূচনা করুন' : 'Reset Everything & Start Fresh'}</span>
        </button>
      </div>

      {/* 7. About App Card */}
      <div
        id="card-settings-about"
        className={`p-5 rounded-[24px] border text-center transition-all ${
          darkMode
            ? 'bg-[#0E1E16] border-[#224735] text-stone-300'
            : 'bg-stone-100/70 border-stone-200 text-stone-600'
        }`}
      >
        <div className="w-12 h-12 mx-auto mb-2 rounded-2xl bg-[#1B4332] border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37] font-black text-xl shadow-md">
          م
        </div>
        <h3 className="font-extrabold text-stone-900 dark:text-stone-100 text-base">
          Muhasabah (মুহাসাবাহ)
        </h3>
        <p className="text-xs text-[#1B4332] dark:text-[#74C69D] font-bold mt-0.5">
          {language === 'bn'
            ? 'দৈনন্দিন আত্মশুদ্ধি ও আমল হিসাবের নির্ভরযোগ্য প্ল্যাটফর্ম'
            : 'Daily Self-Accounting & Spiritual Productivity'}
        </p>

        <p className="text-[11px] text-stone-400 dark:text-stone-400 mt-2 max-w-sm mx-auto leading-relaxed">
          {language === 'bn'
            ? 'হযরত উমর ইবনুল খাত্তাব (রা.) বলেছেন: "তোমাদের থেকে হিসাব নেওয়ার আগেই নিজেদের হিসাব নিজেরাই গ্রহণ করো।"'
            : '"Hold yourselves accountable before you are held accountable." — Umar ibn al-Khattab (RA)'}
        </p>

        <a
          id="btn-download-android-app"
          href="/Muhasabah.apk"
          download
          className="mt-4 w-full max-w-xs mx-auto py-2.5 rounded-xl bg-[#1B4332] hover:bg-[#24563F] text-white font-extrabold text-xs transition-all shadow-md flex items-center justify-center gap-2"
        >
          <Smartphone className="w-4 h-4" />
          <span>{language === 'bn' ? 'Android App ডাউনলোড' : 'Download Android App'}</span>
        </a>

        <div className="mt-3 pt-3 border-t border-stone-200 dark:border-stone-800 flex items-center justify-center gap-4 text-[11px] font-bold text-stone-400">
          <span>{language === 'bn' ? 'শতভাগ অফলাইন' : '100% Offline-First'}</span>
          <span>•</span>
          <span>{language === 'bn' ? 'বিজ্ঞাপনমুক্ত' : 'No Ads'}</span>
          <span>•</span>
          <span>{language === 'bn' ? 'নিরাপদ প্রাইভেসি' : 'Privacy Guaranteed'}</span>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="w-full max-w-sm p-6 rounded-[28px] bg-white dark:bg-[#163024] border border-rose-500/40 shadow-2xl text-center">
            <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-extrabold text-stone-900 dark:text-stone-100">
              {language === 'bn' ? 'আপনি কি নিশ্চিত?' : 'Are you absolutely sure?'}
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1.5 leading-relaxed">
              {language === 'bn'
                ? 'এই কাজটি আপনার সমস্ত সালাত, তাসবিহ ও দৈনন্দিন হিস্টোরি মুছে ফেলবে।'
                : 'This will reset all your prayer checks, dhikr counts, and journal entries back to pristine state.'}
            </p>

            <div className="flex gap-2.5 mt-5">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 text-xs font-bold text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  setShowResetConfirm(false);
                  if (onResetAllData) onResetAllData();
                  showToast(language === 'bn' ? 'সফলভাবে রিসেট করা হয়েছে!' : 'Reset successful!');
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md cursor-pointer"
              >
                {language === 'bn' ? 'হ্যাঁ, রিসেট করুন' : 'Yes, Reset'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Restore JSON Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="w-full max-w-md p-6 rounded-[28px] bg-white dark:bg-[#163024] border border-[#D4AF37]/40 shadow-2xl">
            <h3 className="text-base font-extrabold text-stone-900 dark:text-stone-100 mb-1">
              {language === 'bn' ? 'ব্যাকআপ ডাটা পেস্ট করুন' : 'Paste Backup JSON'}
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">
              {language === 'bn'
                ? 'পূর্ববর্তী ব্যাকআপ ফাইলের সম্পূর্ণ JSON টেক্সট এখানে পেস্ট করুন:'
                : 'Paste previously exported Muhasabah JSON content here:'}
            </p>
            <textarea
              rows={6}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder='{"version": "3.0", "state": { ... }}'
              className="w-full p-3 rounded-xl border border-stone-200 dark:border-[#224735] bg-stone-50 dark:bg-[#0E1E16] text-xs font-mono text-stone-900 dark:text-stone-100 resize-none focus:outline-hidden focus:ring-2 focus:ring-[#D4AF37]"
            />
            <div className="flex gap-2.5 mt-4">
              <button
                onClick={() => setShowImportModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 text-xs font-bold text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={handleImport}
                disabled={!importJsonText.trim()}
                className="flex-1 py-2.5 rounded-xl bg-[#1B4332] hover:bg-[#2D6A4F] text-[#D4AF37] text-xs font-bold shadow-md cursor-pointer disabled:opacity-50"
              >
                {language === 'bn' ? 'রিস্টোর করুন' : 'Restore'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
