import React from 'react';
import { X, Clock, Plus, Minus, RotateCcw, Check } from 'lucide-react';
import { PrayerItem } from '../types';

interface SalatOffsetModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  prayers: PrayerItem[];
  onAdjustOffset: (prayerId: string, deltaMinutes: number) => void;
  onAdjustAllOffsets?: (deltaMinutes: number) => void;
  onResetOffsets: () => void;
}

export const SalatOffsetModal: React.FC<SalatOffsetModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  prayers,
  onAdjustOffset,
  onAdjustAllOffsets,
  onResetOffsets,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-md max-h-[90vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header with Deep Emerald Gradient */}
        <div className="p-4 border-b border-emerald-100/60 dark:border-[#254F3E] flex items-center justify-between bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#D4AF37] text-stone-950 shadow-md">
              <Clock className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Prayer Time Offsets
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 text-[#FFF9E6] font-bold">
                  &plusmn; Minutes
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Fine-tune prayer start/end minutes for your local mosque
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          <p className="text-xs text-stone-500 dark:text-stone-400">
            Adjust individual prayer times by adding or subtracting minutes to match your local mosque adhan schedule exactly:
          </p>

          {/* Quick All Adjustment */}
          {onAdjustAllOffsets && (
            <div className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
              darkMode ? 'bg-[#183427] border-[#254F3E]' : 'bg-emerald-50/70 border-emerald-200/60'
            }`}>
              <span className="font-bold text-stone-700 dark:text-stone-300">
                Adjust All Times:
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onAdjustAllOffsets(-5)}
                  className="px-2 py-1 rounded-md text-[11px] font-bold bg-stone-200 dark:bg-[#12261E] hover:bg-stone-300 dark:hover:bg-[#1E3A2B] active:scale-95 transition-all"
                >
                  -5m
                </button>
                <button
                  onClick={() => onAdjustAllOffsets(-1)}
                  className="px-2 py-1 rounded-md text-[11px] font-bold bg-stone-200 dark:bg-[#12261E] hover:bg-stone-300 dark:hover:bg-[#1E3A2B] active:scale-95 transition-all"
                >
                  -1m
                </button>
                <button
                  onClick={() => onAdjustAllOffsets(1)}
                  className="px-2 py-1 rounded-md text-[11px] font-bold bg-[#2D6A4F] text-white hover:bg-[#1B4332] active:scale-95 transition-all"
                >
                  +1m
                </button>
                <button
                  onClick={() => onAdjustAllOffsets(5)}
                  className="px-2 py-1 rounded-md text-[11px] font-bold bg-[#2D6A4F] text-white hover:bg-[#1B4332] active:scale-95 transition-all"
                >
                  +5m
                </button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {prayers.map((prayer) => {
              const offset = prayer.offsetMinutes || 0;

              return (
                <div
                  key={prayer.id}
                  className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                    darkMode
                      ? 'bg-[#142B20] border-[#1C3B2E]'
                      : 'bg-stone-50 border-stone-200/80'
                  }`}
                >
                  <div>
                    <div className="font-extrabold text-xs text-stone-900 dark:text-stone-100 flex items-center gap-2">
                      <span>{prayer.name}</span>
                      <span className="text-[11px] font-arabic font-bold text-[#D4AF37]">
                        {prayer.arabic}
                      </span>
                    </div>
                    <div className="text-[11px] text-stone-400 font-mono mt-0.5">
                      Base: {prayer.baseTime || prayer.time} → <span className="font-bold text-emerald-400">{prayer.time}</span>
                    </div>
                  </div>

                  {/* Offset controls */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onAdjustOffset(prayer.id, -1)}
                      className="w-7 h-7 rounded-lg bg-stone-200 dark:bg-[#1E3A2B] text-stone-700 dark:text-stone-200 flex items-center justify-center font-bold hover:bg-stone-300 transition-all active:scale-90"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="w-12 text-center text-xs font-mono font-black text-[#1B4332] dark:text-[#74C69D]">
                      {offset > 0 ? `+${offset}` : offset} min
                    </span>

                    <button
                      onClick={() => onAdjustOffset(prayer.id, 1)}
                      className="w-7 h-7 rounded-lg bg-[#1B4332] text-white flex items-center justify-center font-bold hover:bg-[#2D6A4F] transition-all active:scale-90 shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer info & Reset */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] flex items-center justify-between">
          <button
            onClick={onResetOffsets}
            className="flex items-center gap-1 text-[11px] font-bold text-stone-500 hover:text-stone-800 dark:hover:text-stone-200"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All Offsets</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 shadow-xs"
          >
            Apply &amp; Done
          </button>
        </div>
      </div>
    </div>
  );
};
