import React, { useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  BookOpen,
  CheckCircle2,
  Circle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Flame,
  Award,
  BookMarked,
  Share2,
  Bookmark,
  Shuffle,
  Music,
  Play,
  Pause,
  Square,
} from 'lucide-react';
import { DuaItem, SurahLibraryItem, WisdomBookmark } from '../types';
import { EXPANDED_QURAN_LIBRARY, INITIAL_WISDOM_BOOKMARKS } from '../data/islamicFeaturesData';
import { useLanguage } from '../utils/i18n';
import {
  playDhikrClick,
  playNotificationTone,
  playRecitationAudio,
  playAyahAudio,
  stopRecitationAudio,
  pauseRecitationAudio,
  resumeRecitationAudio,
  seekRecitationAudio,
  playDuaAudio,
  stopAllAudio,
  AudioProgressInfo,
} from '../utils/audio';

interface DhikrScreenProps {
  darkMode: boolean;
  soundEnabled: boolean;
  dhikrCount: number;
  duas: DuaItem[];
  onIncrementDhikr: (count?: number) => void;
  onResetDhikr: () => void;
  onToggleDua: (id: string) => void;
}

const DHIKR_PHRASES = [
  { text: 'سُبْحَانَ اللَّهِ', en: 'SubhanAllah', bn: 'আল্লাহ পবিত্র ও মহিমান্বিত' },
  { text: 'الْحَمْدُ لِلَّهِ', en: 'Alhamdulillah', bn: 'সমস্ত প্রশংসা আল্লাহর জন্য' },
  { text: 'لَا إِلَهَ إِلَّا اللَّهُ', en: 'La ilaha illallah', bn: 'আল্লাহ ছাড়া কোনো উপাস্য নেই' },
  { text: 'اللَّهُ أَكْبَرُ', en: 'Allahu Akbar', bn: 'আল্লাহ মহান' },
  {
    text: 'أَسْتَغْفِرُ اللَّهَ',
    en: 'Astaghfirullah',
    bn: 'আমি আল্লাহর কাছে ক্ষমা চাই',
  },
  {
    text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    en: 'La hawla wa la quwwata illa billah',
    bn: 'আল্লাহ ছাড়া কারো শক্তি বা সামর্থ্য নেই',
  },
];

const DAILY_DHIKR_POOL = [
  {
    title: 'Dhikr of the Day: Subhanallahi wa bihamdihi',
    titleBn: 'সুবহানাল্লাহি ওয়া বিহামদিহী, সুবহানাল্লাহিল আযীম',
    arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    transliteration: 'Subhanallahi wa bihamdihi, Subhanallahil Azeem',
    transliterationBn: 'সুবহানাল্লাহি ওয়া বিহামদিহী, সুবহানাল্লাহিল আযীম',
    meaningBn: 'আল্লাহর পবিত্রতা ঘোষণা করছি তাঁর প্রশংসার সাথে, মহান আল্লাহর পবিত্রতা ঘোষণা করছি।',
    fazilatBn: 'রাসূলুল্লাহ (সা.) বলেছেন: দুটি বাক্য এমন যা জিহ্বায় উচ্চারণে খুবই সহজ, মীযানের পাল্লায় অত্যন্ত ভারী এবং পরম দয়াময় আল্লাহর কাছে অতি প্রিয়। (সহীহ বুখারী ৬৬৮২)',
    recommendedCount: 100,
  },
  {
    title: 'Dhikr of the Day: Sayyidul Istighfar',
    titleBn: 'সাইয়্যিদুল ইস্তিগফার (শ্রেষ্ঠ ক্ষমা প্রার্থনা)',
    arabic: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ',
    transliteration: "Allahumma Anta Rabbi la ilaha illa Anta, khalaqtani wa ana 'abduka...",
    transliterationBn: 'আল্লাহুম্মা আনতা রব্বী লা ইলাহা ইল্লা আনতা, খালাক্বতানী ওয়া আনা আবদুকা...',
    meaningBn: 'হে আল্লাহ! আপনি আমার রব, আপনি ছাড়া সত্য কোনো উপাস্য নেই। আপনি আমাকে সৃষ্টি করেছেন এবং আমি আপনার বান্দা...',
    fazilatBn: 'যে ব্যক্তি দৃঢ় বিশ্বাসের সাথে দিনে এটি পাঠ করবে এবং সন্ধ্যার আগে মারা যাবে, সে জান্নাতীদের অন্তর্ভুক্ত হবে। (সহীহ বুখারী ৬৩০৬)',
    recommendedCount: 3,
  },
  {
    title: 'Dhikr of the Day: La hawla wa la quwwata illa billah',
    titleBn: 'লা হাওলা ওয়া লা কুওয়াতা ইল্লা বিল্লাহ',
    arabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ',
    transliteration: "La hawla wa la quwwata illa billahil 'Aliyyil 'Azeem",
    transliterationBn: 'লা হাওলা ওয়া লা কুওয়াতা ইল্লা বিল্লাহিল আলিয়্যিল আযীম',
    meaningBn: 'আল্লাহ ছাড়া পাপ থেকে ফেরার এবং সৎকাজ করার কোনো শক্তি ও সামর্থ্য নেই।',
    fazilatBn: 'রাসূলুল্লাহ (সা.) বলেছেন: এটি জান্নাতের রত্নভাণ্ডারসমূহের মধ্যকার একটি বিশেষ রত্নভাণ্ডার। (সহীহ বুখারী ৪২০৫)',
    recommendedCount: 100,
  },
  {
    title: 'Dhikr of the Day: Durood Sharif (Salawat)',
    titleBn: 'দরূদ শরীফ (রাসূল সা.-এর ওপর সালাত)',
    arabic: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ',
    transliteration: 'Allahumma salli ala Muhammadin wa ala ali Muhammad',
    transliterationBn: 'আল্লাহুম্মা সাল্লি আলা মুহাম্মাদিওঁ ওয়া আলা আলি মুহাম্মাদ',
    meaningBn: 'হে আল্লাহ! মুহাম্মদ (সা.) এবং তাঁর পরিবারের ওপর রহমত বর্ষণ করুন।',
    fazilatBn: 'যে ব্যক্তি আমার ওপর একবার দরূদ পাঠ করবে, আল্লাহ তার ওপর দশটি রহমত নাযিল করবেন, দশটি গুনাহ মাফ করবেন এবং তার মর্যাদা দশ গুণ বৃদ্ধি করবেন। (নাসাঈ ১২৯৭)',
    recommendedCount: 100,
  },
  {
    title: 'Dhikr of the Day: Tahleel (Kalima Tayyibah)',
    titleBn: 'কালিমা তাইয়্যিবাহ ও একত্ববাদ',
    arabic: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    transliteration: 'La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu, wa Huwa ala kulli shay-in qadeer',
    transliterationBn: 'লা ইলাহা ইল্লাল্লাহু ওয়াহদাহু লা শারীকা লাহু, লাহুল মুলকু ওয়া লাহুল হামদু, ওয়াহুওয়া আলা কুল্লি শাইয়িন ক্বাদীর',
    meaningBn: 'আল্লাহ ছাড়া সত্য কোনো উপাস্য নেই, তিনি একক, তাঁর কোনো অংশীদার নেই; রাজত্ব কেবল তাঁরই, সমস্ত প্রশংসাও তাঁর এবং তিনি সর্ববিষয়ে সর্বশক্তিমান।',
    fazilatBn: 'দিনে ১০০ বার পাঠ করলে ১০ জন দাস মুক্ত করার সওয়াব পাওয়া যায়, ১০০ সওয়াব লেখা হয় এবং ১০০ গুনাহ মিটিয়ে দেওয়া হয়। (সহীহ বুখারী ৩২৯৩)',
    recommendedCount: 100,
  },
];

export const DhikrScreen: React.FC<DhikrScreenProps> = ({
  darkMode,
  soundEnabled,
  dhikrCount,
  duas,
  onIncrementDhikr,
  onResetDhikr,
  onToggleDua,
}) => {
  const { language, t } = useLanguage();
  const [selectedPhraseIdx, setSelectedPhraseIdx] = useState(0);
  const [customPhrase, setCustomPhrase] = useState<{ text: string; en: string; bn: string } | null>(null);
  const selectedPhrase = customPhrase || DHIKR_PHRASES[selectedPhraseIdx];

  // Dynamic Dhikr of the day index
  const todayDay = new Date().getDate();
  const [dhikrDayIdx, setDhikrDayIdx] = useState(todayDay % DAILY_DHIKR_POOL.length);
  const activeDhikrOfTheDay = DAILY_DHIKR_POOL[dhikrDayIdx];

  // Expanded Quran Library selection (defaults to Surah Al-Fatihah, first in Quran)
  const [selectedSurahId, setSelectedSurahId] = useState<string>('surah_fatihah');
  const [showSurahVerses, setShowSurahVerses] = useState(true);
  const activeSurah = EXPANDED_QURAN_LIBRARY.find((s) => s.id === selectedSurahId) || EXPANDED_QURAN_LIBRARY[0];

  const [audioProgress, setAudioProgress] = useState<AudioProgressInfo>({
    currentTime: 0,
    duration: 0,
    progressPercent: 0,
    isPlaying: false,
    isPaused: false,
  });
  const [audioUnavailable, setAudioUnavailable] = useState(false);
  const [targetCycle, setTargetCycle] = useState(33);
  const [expandedDuaId, setExpandedDuaId] = useState<string | null>('ayatul_kursi');
  const [buttonPressed, setButtonPressed] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [playingDuaId, setPlayingDuaId] = useState<string | null>(null);
  const [playingAyahNumber, setPlayingAyahNumber] = useState<number | null>(null);

  // Stop audio on unmount to prevent leaks
  useEffect(() => {
    return () => {
      stopAllAudio();
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleSelectSurah = (surahId: string) => {
    if (selectedSurahId === surahId) return;
    // CRITICAL: Stop previous audio immediately when switching Surahs
    stopAllAudio();
    setSelectedSurahId(surahId);
    setAudioProgress({
      currentTime: 0,
      duration: 0,
      progressPercent: 0,
      isPlaying: false,
      isPaused: false,
      currentUrl: undefined,
      currentId: undefined,
    });
    setAudioUnavailable(false);
    setPlayingAyahNumber(null);
    setPlayingDuaId(null);
    playDhikrClick(soundEnabled);
  };

  const handleAudioToggle = () => {
    // STRICT CHECK: Verify whether any currently playing or paused audio belongs to THIS exact Surah
    const isThisSurahAudio =
      (audioProgress.isPlaying || audioProgress.isPaused) &&
      (audioProgress.currentUrl === activeSurah.audioUrl ||
        audioProgress.currentId === activeSurah.id ||
        audioProgress.currentId === activeSurah.audioUrl);

    if (audioProgress.isPlaying && isThisSurahAudio) {
      pauseRecitationAudio();
      showToast('Tilawat Paused');
    } else if (audioProgress.isPaused && isThisSurahAudio) {
      resumeRecitationAudio();
      showToast(`Resumed ${activeSurah.nameBn}`);
    } else {
      // Clean slate - stop all existing audio to ensure NO old Surah audio (like Al-Mulk) persists
      stopAllAudio();
      setPlayingDuaId(null);
      setPlayingAyahNumber(null);
      setAudioUnavailable(false);

      if (!activeSurah.audioUrl) {
        setAudioUnavailable(true);
        showToast('Audio unavailable');
        return;
      }

      const res = playRecitationAudio(
        activeSurah.audioUrl,
        () => {
          setAudioProgress({
            currentTime: 0,
            duration: 0,
            progressPercent: 0,
            isPlaying: false,
            isPaused: false,
            currentUrl: undefined,
            currentId: undefined,
          });
        },
        (info) => {
          setAudioProgress(info);
        },
        (errMsg) => {
          setAudioUnavailable(true);
          showToast(errMsg || 'Audio unavailable');
        }
      );

      if (res.success) {
        playNotificationTone(soundEnabled);
        showToast(`Playing ${activeSurah.nameBn} Tilawat`);
      } else {
        setAudioUnavailable(true);
        showToast(res.error || 'Audio unavailable');
      }
    }
  };

  const handleAudioStop = () => {
    stopRecitationAudio();
    setAudioProgress({
      currentTime: 0,
      duration: 0,
      progressPercent: 0,
      isPlaying: false,
      isPaused: false,
      currentUrl: undefined,
      currentId: undefined,
    });
    showToast('Tilawat Stopped');
  };

  const handleSeekChange = (newSec: number) => {
    seekRecitationAudio(newSec);
    setAudioProgress((prev) => ({
      ...prev,
      currentTime: newSec,
      progressPercent: prev.duration > 0 ? (newSec / prev.duration) * 100 : 0,
    }));
  };

  const handlePlayAyah = (verse: { ayahNumber: number; arabic: string; transliterationBn?: string; audioUrl?: string }) => {
    if (playingAyahNumber === verse.ayahNumber) {
      stopAllAudio();
      setPlayingAyahNumber(null);
      showToast(`Ayah ${verse.ayahNumber} audio stopped`);
    } else {
      stopAllAudio();
      setAudioProgress({
        currentTime: 0,
        duration: 0,
        progressPercent: 0,
        isPlaying: false,
        isPaused: false,
      });
      setPlayingDuaId(null);
      setPlayingAyahNumber(verse.ayahNumber);
      playNotificationTone(soundEnabled);
      showToast(`Playing Ayah ${verse.ayahNumber}`);

      playAyahAudio(
        verse.audioUrl,
        verse.arabic,
        verse.transliterationBn,
        () => {
          setPlayingAyahNumber(null);
          setAudioProgress({
            currentTime: 0,
            duration: 0,
            progressPercent: 0,
            isPlaying: false,
            isPaused: false,
            currentUrl: undefined,
            currentId: undefined,
          });
        },
        (info) => {
          setAudioProgress(info);
        },
        (errMsg) => {
          setPlayingAyahNumber(null);
          showToast(errMsg || 'Audio unavailable');
        }
      );
    }
  };

  const handleApplyDhikrOfTheDay = () => {
    setCustomPhrase({
      text: activeDhikrOfTheDay.arabic,
      en: activeDhikrOfTheDay.transliteration,
      bn: activeDhikrOfTheDay.meaningBn,
    });
    setTargetCycle(activeDhikrOfTheDay.recommendedCount);
    playNotificationTone(soundEnabled);
    showToast(`Loaded "${activeDhikrOfTheDay.titleBn}" into Tasbih!`);
  };

  const handleBookmarkAyah = (verse: { ayahNumber: number; arabic: string; transliterationBn?: string; meaningBn: string }) => {
    try {
      const raw = localStorage.getItem('muhasabah_wisdom_bookmarks');
      const existing: WisdomBookmark[] = raw ? JSON.parse(raw) : INITIAL_WISDOM_BOOKMARKS;
      const newBookmark: WisdomBookmark = {
        id: `wb-${Date.now()}`,
        title: `${activeSurah.nameBn} (${activeSurah.number}:${verse.ayahNumber})`,
        arabic: verse.arabic,
        translationBn: verse.meaningBn,
        translationEn: verse.transliterationBn,
        source: `Al-Quran ${activeSurah.number}:${verse.ayahNumber}`,
        category: 'Quran',
        savedAt: new Date().toISOString().split('T')[0],
      };
      localStorage.setItem('muhasabah_wisdom_bookmarks', JSON.stringify([newBookmark, ...existing]));
      playNotificationTone(soundEnabled);
      showToast(`Saved Ayah ${verse.ayahNumber} to Wisdom Bookmarks!`);
    } catch {
      showToast('Saved to Bookmarks');
    }
  };

  const handlePlayDua = (dua: DuaItem) => {
    if (playingDuaId === dua.id) {
      if (audioProgress.isPlaying) {
        pauseRecitationAudio();
        showToast(`${dua.title} paused`);
      } else if (audioProgress.isPaused) {
        resumeRecitationAudio();
        showToast(`Resumed ${dua.title}`);
      } else {
        stopAllAudio();
        setPlayingDuaId(null);
        showToast(`${dua.title} audio stopped`);
      }
    } else {
      stopAllAudio();
      setAudioProgress({
        currentTime: 0,
        duration: 0,
        progressPercent: 0,
        isPlaying: false,
        isPaused: false,
      });
      setPlayingAyahNumber(null);
      setPlayingDuaId(dua.id);
      showToast(`Playing recitation: ${dua.title}`);
      playDuaAudio(
        dua.id,
        dua.audioUrl,
        () => {
          setPlayingDuaId(null);
          setAudioProgress({
            currentTime: 0,
            duration: 0,
            progressPercent: 0,
            isPlaying: false,
            isPaused: false,
          });
        },
        (info) => {
          setAudioProgress(info);
        },
        (errMsg) => {
          setPlayingDuaId(null);
          showToast(errMsg || 'Audio unavailable');
        }
      );
    }
  };

  const handleTapDhikr = () => {
    playDhikrClick(soundEnabled);
    setButtonPressed(true);
    setTimeout(() => setButtonPressed(false), 120);
    onIncrementDhikr(1);

    const nextCount = dhikrCount + 1;
    if (nextCount % targetCycle === 0) {
      playNotificationTone(soundEnabled);
      showToast(`Masha'Allah! Completed cycle of ${targetCycle}`);
    }
  };

  const formatAudioTime = (totalSec: number) => {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const filteredDuas = duas.filter((d) => {
    if (filterCategory === 'All') return true;
    return d.category === filterCategory;
  });

  return (
    <div id="screen-dhikr-tracker" className="space-y-4 pb-6">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="sticky top-2 z-30 mx-auto max-w-xs text-center px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#2D6A4F] shadow-lg animate-bounce">
          ✨ {toastMsg}
        </div>
      )}

      {/* ============================================================ */}
      {/* 1. DYNAMIC DHIKR OF THE DAY (দৈনিক বিশেষ যিকির) */}
      {/* ============================================================ */}
      <div
        id="card-dhikr-of-the-day"
        className={`rounded-[24px] p-5 border relative overflow-hidden transition-all shadow-md ${
          darkMode
            ? 'bg-gradient-to-br from-[#122A1E] via-[#163627] to-[#0D1D15] border-[#D4AF37]/40 text-white'
            : 'bg-gradient-to-br from-[#F5E6B3]/35 via-white to-emerald-50/70 border-[#D4AF37]/50 text-stone-900'
        }`}
      >
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37]">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#B8860B] dark:text-[#D4AF37]">
                {language === 'bn' ? 'আজকের বিশেষ যিকির' : 'Dhikr of the Day'}
              </span>
              <h3 className="font-extrabold text-sm text-stone-900 dark:text-white">
                {language === 'bn' ? activeDhikrOfTheDay.titleBn : activeDhikrOfTheDay.title}
              </h3>
            </div>
          </div>

          <button
            id="btn-shuffle-dhikr-day"
            onClick={() => {
              setDhikrDayIdx((prev) => (prev + 1) % DAILY_DHIKR_POOL.length);
              playDhikrClick(soundEnabled);
            }}
            className="p-2 rounded-xl bg-black/10 dark:bg-white/10 hover:bg-black/20 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-white/10 transition-all active:scale-95 flex items-center gap-1 text-[11px] font-bold"
            title={language === 'bn' ? 'পরবর্তী যিকির' : 'Next Dhikr'}
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'পরবর্তী' : 'Next'}</span>
          </button>
        </div>

        {/* Arabic Text with elevated typography */}
        <div className="p-3.5 rounded-2xl bg-black/5 dark:bg-black/30 border border-[#D4AF37]/30 text-right my-2">
          <p className="font-arabic text-xl sm:text-2xl font-bold text-[#1B4332] dark:text-[#F4E0A5] leading-relaxed">
            {activeDhikrOfTheDay.arabic}
          </p>
        </div>

        <div className="text-xs text-stone-700 dark:text-stone-300 font-semibold mb-1">
          <span className="text-[#B8860B] dark:text-[#D4AF37] font-bold">
            {language === 'bn' ? 'উচ্চারণ: ' : 'Pronunciation: '}
          </span>
          {language === 'bn' ? activeDhikrOfTheDay.transliterationBn : activeDhikrOfTheDay.transliteration}
        </div>

        <div className="text-xs text-stone-600 dark:text-stone-300 mb-2 leading-relaxed">
          <span className="font-bold text-stone-800 dark:text-stone-200">
            {language === 'bn' ? 'অর্থ: ' : 'Meaning: '}
          </span>
          {activeDhikrOfTheDay.meaningBn}
        </div>

        <div className="p-2.5 rounded-xl bg-[#FFF9E6] dark:bg-[#201C0F] border border-[#D4AF37]/30 text-[11px] text-stone-700 dark:text-stone-300 leading-relaxed font-medium">
          <span className="font-bold text-[#9A7B1C] dark:text-[#F4E0A5]">
            {language === 'bn' ? 'ফজিলত: ' : 'Virtue: '}
          </span>
          {activeDhikrOfTheDay.fazilatBn}
        </div>

        <div className="mt-3 flex items-center justify-between gap-2 pt-2 border-t border-stone-200 dark:border-white/10">
          <span className="text-[11px] text-stone-500 dark:text-stone-400 font-bold">
            {language === 'bn'
              ? `লক্ষ্য: ${activeDhikrOfTheDay.recommendedCount} বার`
              : `Target: ${activeDhikrOfTheDay.recommendedCount} times`}
          </span>
          <button
            id="btn-apply-daily-dhikr-tasbih"
            onClick={handleApplyDhikrOfTheDay}
            className="px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition-all active:scale-95 bg-[#1B4332] text-white hover:bg-[#2D6A4F] border border-[#D4AF37] shadow-sm flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{language === 'bn' ? 'তাসবীহে যুক্ত করুন' : 'Apply to Tasbih'}</span>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 2. EXPANDED QURAN LIBRARY & TILAWAT CARD */}
      {/* ============================================================ */}
      <div
        id="card-quran-recitation"
        className={`rounded-[24px] p-5 border transition-all shadow-[0_12px_32px_rgba(27,67,50,0.18)] ${
          darkMode
            ? 'bg-gradient-to-br from-[#0F261C] via-[#163527] to-[#1B4332] border-[#D4AF37]/40 text-white'
            : 'bg-gradient-to-br from-[#1B4332] via-[#225540] to-[#2D6A4F] border-[#D4AF37]/50 text-white'
        }`}
      >
        <div className="flex items-start justify-between relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-widest bg-black/25 text-[#F5E6B3] border border-[#D4AF37]/40 backdrop-blur-md">
                <BookOpen className="w-3 h-3 text-[#D4AF37]" />
                {language === 'bn' ? 'কুরআন লাইব্রেরি ও তিলাওয়াত' : 'Quran Library & Tilawat'}
              </span>
              <span className="text-[11px] font-bold text-[#F3DF95]">
                Mishary Rashid Alafasy
              </span>
            </div>
            <h3 className="text-xl font-black tracking-tight text-white drop-shadow-xs">
              {language === 'bn' ? activeSurah.nameBn : activeSurah.nameEn}
            </h3>
            <p className="text-xs text-emerald-100/90 font-medium mt-0.5">
              {language === 'bn'
                ? `${activeSurah.nameEn} • ${activeSurah.totalVerses} আয়াত • ${activeSurah.revelationType === 'Meccan' ? 'মাক্কী' : 'মাদানী'}`
                : `${activeSurah.nameEn} • ${activeSurah.totalVerses} Ayahs • ${activeSurah.revelationType}`}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-toggle-audio-recitation"
              onClick={handleAudioToggle}
              className={`p-3 rounded-2xl backdrop-blur-md transition-all active:scale-90 border shadow-md flex items-center justify-center ${
                audioProgress.isPlaying
                  ? 'bg-[#D4AF37] text-stone-950 border-white/60 animate-pulse'
                  : audioProgress.isPaused
                  ? 'bg-[#D4AF37]/80 text-stone-950 border-[#D4AF37]'
                  : 'bg-black/20 text-[#FFF9E6] border-[#D4AF37]/40 hover:bg-black/35'
              }`}
              title={audioProgress.isPlaying ? 'Pause Tilawat' : 'Play Tilawat'}
            >
              {audioProgress.isPlaying ? (
                <Pause className="w-5 h-5 font-black" />
              ) : (
                <Play className="w-5 h-5 font-black" />
              )}
            </button>
            {(audioProgress.isPlaying || audioProgress.isPaused) && (
              <button
                id="btn-stop-audio-recitation"
                onClick={handleAudioStop}
                className="p-2.5 rounded-2xl bg-black/30 hover:bg-black/50 border border-white/20 text-stone-200 transition-all active:scale-90 shadow-sm"
                title="Stop and Reset"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Surah Selector Carousel */}
        <div className="mt-3.5 pt-2 border-t border-white/15 flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {EXPANDED_QURAN_LIBRARY.map((surah) => {
            const isSelected = selectedSurahId === surah.id;
            return (
              <button
                key={surah.id}
                onClick={() => handleSelectSurah(surah.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border shrink-0 ${
                  isSelected
                    ? 'bg-[#D4AF37] text-stone-950 border-white font-extrabold shadow-sm'
                    : 'bg-black/25 text-emerald-100/90 border-white/10 hover:bg-black/40'
                }`}
              >
                {surah.number}. {surah.nameBn.split(' ')[1] || surah.nameBn}
              </button>
            );
          })}
        </div>

        {/* Dynamic Animated Audio Waveform & Seek Controls */}
        <div className="mt-3 pt-3 border-t border-[#D4AF37]/20 space-y-2">
          {/* Animated Waveform Bars */}
          <div className="flex items-end gap-1 h-6 w-full">
            {[25, 45, 20, 70, 35, 85, 50, 25, 75, 40, 95, 30, 65, 20, 80, 50, 30, 60, 40, 70].map(
              (height, idx) => (
                <div
                  key={idx}
                  className={`flex-1 rounded-full transition-all duration-300 ${
                    audioProgress.isPlaying
                      ? 'bg-gradient-to-t from-[#D4AF37] to-[#FFF9E6]'
                      : 'bg-white/20'
                  }`}
                  style={{
                    height: audioProgress.isPlaying
                      ? `${Math.min(100, Math.max(15, (height + Math.floor(audioProgress.currentTime * 6 + idx * 5) % 55)))}%`
                      : '20%',
                  }}
                />
              )
            )}
          </div>

          {/* Real Seek Slider */}
          <div className="space-y-1">
            <input
              type="range"
              min={0}
              max={audioProgress.duration > 0 ? audioProgress.duration : 100}
              step={0.5}
              value={audioProgress.currentTime}
              onChange={(e) => handleSeekChange(parseFloat(e.target.value))}
              disabled={!audioProgress.isPlaying && !audioProgress.isPaused}
              className="w-full h-1.5 bg-black/40 rounded-lg appearance-none cursor-pointer accent-[#D4AF37] focus:outline-none disabled:opacity-35"
              title="Seek Tilawat Audio"
            />
            <div className="flex items-center justify-between text-[11px] font-mono text-[#F4E0A5] font-bold px-0.5">
              <span>{formatAudioTime(Math.floor(audioProgress.currentTime))}</span>
              {audioUnavailable ? (
                <span className="text-rose-300 font-sans font-bold">Audio unavailable</span>
              ) : (
                <span>
                  {audioProgress.duration > 0
                    ? formatAudioTime(Math.floor(audioProgress.duration))
                    : audioProgress.isPlaying
                    ? 'Loading...'
                    : '--:--'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Key Ayats Reader */}
        <div className="mt-3 pt-2">
          <button
            onClick={() => setShowSurahVerses(!showSurahVerses)}
            className="flex items-center justify-between w-full text-xs font-extrabold text-[#F4E0A5] py-1"
          >
            <span>{language === 'bn' ? 'নির্বাচিত আয়াতসমূহ পাঠ করুন' : 'Read Selected Ayahs'}</span>
            {showSurahVerses ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showSurahVerses && (
            <div className="space-y-2 mt-2">
              {activeSurah.keyVerses.map((v) => (
                <div
                  key={v.ayahNumber}
                  className="p-3.5 rounded-2xl bg-black/25 border border-white/15 backdrop-blur-sm"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-[#D4AF37] text-stone-950">
                        {language === 'bn' ? `আয়াত ${v.ayahNumber}` : `Ayah ${v.ayahNumber}`}
                      </span>
                      <button
                        id={`btn-play-ayah-${v.ayahNumber}`}
                        onClick={() => handlePlayAyah(v)}
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 transition-all border ${
                          playingAyahNumber === v.ayahNumber
                            ? 'bg-[#D4AF37] text-stone-950 border-white animate-pulse'
                            : 'bg-black/30 text-emerald-200 border-white/20 hover:bg-black/50'
                        }`}
                        title={language === 'bn' ? 'এই আয়াতের তিলাওয়াত শুনুন' : 'Listen to this Ayah'}
                      >
                        {playingAyahNumber === v.ayahNumber ? (
                          <>
                            <Volume2 className="w-3 h-3" />
                            <span>{language === 'bn' ? 'চলছে...' : 'Playing...'}</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3 h-3" />
                            <span>{language === 'bn' ? 'তিলাওয়াত শুনুন' : 'Play Ayah'}</span>
                          </>
                        )}
                      </button>
                    </div>
                    <button
                      onClick={() => handleBookmarkAyah(v)}
                      className="p-1 rounded-lg text-emerald-200 hover:text-[#D4AF37] transition-colors"
                      title={language === 'bn' ? 'হিকমাহ বুকমার্কে সেভ করুন' : 'Save to Wisdom Bookmarks'}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="font-arabic text-xl font-bold text-right text-white leading-loose mb-2">
                    {v.arabic}
                  </p>
                  {v.transliterationBn && (
                    <p className="text-xs text-[#F5E6B3] font-medium leading-relaxed mb-1">
                      {v.transliterationBn}
                    </p>
                  )}
                  <p className="text-xs text-emerald-100/90 leading-relaxed font-light">
                    {v.meaningBn}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3. TACTILE DIGITAL TASBIH COUNTER */}
      {/* ============================================================ */}
      <div
        id="card-digital-tasbih"
        className={`rounded-[20px] p-5 border text-center relative overflow-hidden transition-all shadow-[0_8px_24px_rgba(27,67,50,0.08)] ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-900/10 text-stone-900'
        }`}
      >
        {/* Reset Counter Action */}
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-black uppercase tracking-wider text-stone-400">
            {language === 'bn' ? 'ডিজিটাল তাসবীহ' : 'Digital Tasbih'}
          </span>
          <button
            onClick={() => {
              onResetDhikr();
              showToast(language === 'bn' ? 'তাসবীহ কাউন্টার শূন্য করা হয়েছে' : 'Dhikr counter reset to 0');
            }}
            className="flex items-center gap-1 text-[11px] font-bold text-stone-400 hover:text-red-500 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'রিসেট' : 'Reset'}</span>
          </button>
        </div>

        {/* Phrase Selector Tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-2 no-scrollbar mb-2">
          {DHIKR_PHRASES.map((phrase, idx) => {
            const isSelected = !customPhrase && selectedPhraseIdx === idx;
            return (
              <button
                key={idx}
                onClick={() => {
                  setCustomPhrase(null);
                  setSelectedPhraseIdx(idx);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950 shadow-xs'
                    : 'bg-stone-100 dark:bg-[#163024] text-stone-600 dark:text-stone-300'
                }`}
              >
                {language === 'bn' ? phrase.bn.split(' ')[0] || phrase.en : phrase.en}
              </button>
            );
          })}
        </div>

        {/* Active Phrase Arabic Display */}
        <div className="font-arabic text-2xl font-bold my-1 text-[#1B4332] dark:text-[#F4E0A5]">
          {selectedPhrase.text}
        </div>
        <div className="text-xs text-stone-500 dark:text-stone-400 font-semibold">
          {language === 'bn' ? selectedPhrase.bn : `${selectedPhrase.en} — ${selectedPhrase.bn}`}
        </div>

        {/* Giant Digital Counter Display */}
        <div className="my-4">
          <div
            id="dhikr-counter-display"
            className="text-5xl font-black font-mono tracking-tight text-[#1B4332] dark:text-[#74C69D] drop-shadow-xs"
          >
            {dhikrCount.toLocaleString()}
          </div>
          <div className="text-xs font-bold text-stone-400 mt-1">
            {language === 'bn' ? 'বর্তমান চক্র: ' : 'Current Cycle: '}
            <span className="text-[#D4AF37] font-mono">{dhikrCount % targetCycle}</span> /{' '}
            {targetCycle}
          </div>
        </div>

        {/* Large Tactile + DHIKR Button with Luxury Gradient & Gold Ring */}
        <div className="flex justify-center my-3">
          <button
            id="btn-increment-dhikr"
            onClick={handleTapDhikr}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center font-extrabold text-white transition-all duration-150 select-none shadow-xl border-4 ${
              buttonPressed
                ? 'scale-90 bg-gradient-to-tr from-[#163527] to-[#1B4332] border-[#D4AF37] shadow-inner'
                : 'scale-100 bg-gradient-to-tr from-[#1B4332] via-[#24543E] to-[#2D6A4F] border-[#D4AF37]/70 hover:scale-105 shadow-[0_12px_32px_rgba(27,67,50,0.35)] ring-4 ring-[#D4AF37]/20'
            }`}
          >
            <span className="text-2xl font-black tracking-wider text-[#FFF9E6]">
              {language === 'bn' ? '+ যিকির' : '+ DHIKR'}
            </span>
            <span className="text-[11px] font-bold text-[#D4AF37] mt-0.5">
              {language === 'bn' ? 'গণনা করতে স্পর্শ করুন' : 'Tap to Count'}
            </span>
          </button>
        </div>

        {/* Target Selector */}
        <div className="flex items-center justify-center gap-2 mt-4 pt-3 border-t border-emerald-100/80 dark:border-[#224735]">
          <span className="text-[11px] font-bold text-stone-400">
            {language === 'bn' ? 'চক্রের লক্ষ্য:' : 'Target Cycle:'}
          </span>
          {[33, 99, 100, 1000].map((num) => (
            <button
              key={num}
              onClick={() => {
                setTargetCycle(num);
                showToast(language === 'bn' ? `চক্রের লক্ষ্য ${num} সেট করা হয়েছে` : `Target cycle set to ${num}`);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-extrabold transition-all ${
                targetCycle === num
                  ? 'bg-[#D4AF37] text-stone-950 shadow-xs ring-1 ring-black/10'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-stone-800'
              }`}
            >
              {num}
            </button>
          ))}
        </div>
      </div>

      {/* ============================================================ */}
      {/* 4. COMPREHENSIVE AUTHENTIC DUAS & PRAYERS */}
      {/* ============================================================ */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3
              className={`text-xs font-black uppercase tracking-wider ${
                darkMode ? 'text-stone-300' : 'text-[#1B4332]'
              }`}
            >
              {language === 'bn' ? 'প্রয়োজনীয় দু‘আ ও মুনাজাত' : 'Authentic Duas & Munajat'}
            </h3>
            <span className="text-[11px] font-semibold text-stone-400">
              {language === 'bn'
                ? 'আরবি পাঠ, বাংলা উচ্চারণ, অর্থ ও ফজিলত সহ'
                : 'Complete with Arabic, English Pronunciation, Meaning & Virtues'}
            </span>
          </div>

          <div className="flex gap-1">
            {[
              { id: 'All', en: 'All', bn: 'সকল' },
              { id: 'Essential', en: 'Essential', bn: 'জরুরি' },
              { id: 'Forgiveness', en: 'Forgiveness', bn: 'ক্ষমা' },
              { id: 'Quranic', en: 'Quranic', bn: 'কুরআনিক' },
              { id: 'Morning', en: 'Morning', bn: 'সকাল-সন্ধ্যা' },
              { id: 'Protection', en: 'Protection', bn: 'সুরক্ষা' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFilterCategory(cat.id)}
                className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold transition-all ${
                  filterCategory === cat.id
                    ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                    : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                }`}
              >
                {language === 'bn' ? cat.bn : cat.en}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {filteredDuas.map((dua) => {
            const isExpanded = expandedDuaId === dua.id;

            return (
              <div
                key={dua.id}
                id={`dua-card-${dua.id}`}
                className={`rounded-[20px] border transition-all duration-200 overflow-hidden ${
                  dua.completed
                    ? darkMode
                      ? 'bg-[#183326] border-[#254F3E]'
                      : 'bg-emerald-50/50 border-emerald-300 shadow-[0_6px_20px_rgba(27,67,50,0.05)]'
                    : darkMode
                    ? 'bg-[#142B20] border-[#1C3B2E]'
                    : 'bg-white border-stone-200/90 shadow-xs'
                }`}
              >
                {/* Header Row */}
                <div
                  className="p-4 flex items-center justify-between cursor-pointer"
                  onClick={() => setExpandedDuaId(isExpanded ? null : dua.id)}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleDua(dua.id);
                        showToast(
                          language === 'bn'
                            ? `${dua.bengaliTitle} ${!dua.completed ? 'পঠিত চিহ্নিত' : 'অসম্পূর্ণ চিহ্নিত'}`
                            : `${dua.title} marked ${!dua.completed ? 'read' : 'pending'}`
                        );
                      }}
                      className="p-1 rounded-full text-[#1B4332] dark:text-[#74C69D] shrink-0"
                    >
                      {dua.completed ? (
                        <CheckCircle2 className="w-5 h-5 fill-[#74C69D] text-[#1B4332] dark:fill-emerald-950/60" />
                      ) : (
                        <Circle className="w-5 h-5 text-stone-300 hover:text-[#D4AF37]" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-sm text-stone-900 dark:text-stone-100 tracking-tight truncate">
                        {language === 'bn' ? dua.bengaliTitle : dua.title}
                      </div>
                      <div className="text-xs text-[#1B4332] dark:text-[#74C69D] font-bold truncate">
                        {language === 'bn' ? dua.title : dua.bengaliTitle}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePlayDua(dua);
                      }}
                      title={language === 'bn' ? 'তিলাওয়াত শুনুন' : 'Listen to audio recitation'}
                      className={`p-1.5 rounded-xl border transition-all ${
                        playingDuaId === dua.id
                          ? 'bg-[#D4AF37] text-stone-950 border-white/60 animate-pulse shadow-sm'
                          : 'bg-stone-100 dark:bg-[#163024] text-stone-500 dark:text-stone-300 hover:text-[#D4AF37] border-transparent'
                      }`}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#E8F5E9] dark:bg-[#1E3E30] text-[#1B4332] dark:text-[#74C69D] border border-emerald-200 dark:border-emerald-800">
                      {dua.target}x
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-stone-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-stone-400" />
                    )}
                  </div>
                </div>

                {/* Expanded Content: 1. Arabic, 2. Pronunciation, 3. Meaning, 4. Fazilat */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 border-t border-emerald-100/70 dark:border-[#224735] space-y-3">
                    {/* 1. Arabic Text */}
                    <div className="p-3.5 rounded-[16px] bg-[#E8F5E9]/60 dark:bg-[#12281E] border border-[#D4AF37]/30 text-right">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1 text-left">
                        {language === 'bn' ? 'মূল আরবি পাঠ:' : 'Arabic Text:'}
                      </div>
                      <p className="font-arabic text-xl sm:text-2xl font-bold text-stone-900 dark:text-stone-100 leading-loose">
                        {dua.arabic}
                      </p>
                    </div>

                    {/* 2. Pronunciation */}
                    <div className="p-3 rounded-xl bg-amber-50/60 dark:bg-[#1C2C20] border border-amber-200/70 dark:border-amber-900/40">
                      <div className="text-[10px] font-black uppercase tracking-wider text-amber-800 dark:text-[#D4AF37] mb-1">
                        {language === 'bn' ? 'উচ্চারণ:' : 'Pronunciation:'}
                      </div>
                      <p className="text-xs font-semibold text-stone-800 dark:text-stone-200 leading-relaxed">
                        {dua.transliterationBn || dua.transliteration}
                      </p>
                    </div>

                    {/* 3. Meaning */}
                    <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-[#152D21] border border-emerald-200/70 dark:border-[#224735]">
                      <div className="text-[10px] font-black uppercase tracking-wider text-[#1B4332] dark:text-[#74C69D] mb-1">
                        {language === 'bn' ? 'অর্থ:' : 'Meaning:'}
                      </div>
                      <p className="text-xs text-stone-700 dark:text-stone-200 leading-relaxed">
                        {dua.translationBn}
                      </p>
                    </div>

                    {/* 4. Fazilat */}
                    {dua.fazilat && (
                      <div className="p-3 rounded-xl bg-[#FFF9E6] dark:bg-[#252010] border border-[#D4AF37]/50">
                        <div className="text-[10px] font-black uppercase tracking-wider text-[#9A7B1C] dark:text-[#F4E0A5] mb-1 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-[#D4AF37]" />
                          {language === 'bn' ? 'ফজিলত ও গুরুত্ব:' : 'Virtue & Significance:'}
                        </div>
                        <p className="text-xs text-stone-800 dark:text-stone-200 leading-relaxed font-medium">
                          {dua.fazilat}
                        </p>
                      </div>
                    )}

                    {/* Audio Narration Action Bar with Play, Pause, Stop, Duration and Seek Slider */}
                    <div className="pt-2.5 border-t border-emerald-100/60 dark:border-[#224735] space-y-2">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePlayDua(dua);
                            }}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                              playingDuaId === dua.id
                                ? audioProgress.isPaused
                                  ? 'bg-amber-500 text-stone-950 hover:bg-amber-400'
                                  : 'bg-[#D4AF37] text-stone-950 hover:bg-[#c49f27]'
                                : 'bg-[#1B4332] text-white hover:bg-[#2D6A4F]'
                            }`}
                          >
                            {playingDuaId === dua.id && !audioProgress.isPaused ? (
                              <>
                                <Pause className="w-3.5 h-3.5 fill-current" />
                                <span>{language === 'bn' ? 'পজ' : 'Pause'}</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5 fill-current" />
                                <span>
                                  {playingDuaId === dua.id
                                    ? (language === 'bn' ? 'চালান' : 'Resume')
                                    : (language === 'bn' ? 'তিলাওয়াত শুনুন' : 'Play Recitation')}
                                </span>
                              </>
                            )}
                          </button>

                          {playingDuaId === dua.id && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                stopAllAudio();
                                setPlayingDuaId(null);
                                setAudioProgress({
                                  currentTime: 0,
                                  duration: 0,
                                  progressPercent: 0,
                                  isPlaying: false,
                                  isPaused: false,
                                });
                              }}
                              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-rose-600/80 hover:bg-rose-600 text-white transition-all shadow-xs cursor-pointer"
                              title={language === 'bn' ? 'বন্ধ করুন' : 'Stop audio'}
                            >
                              <Square className="w-3 h-3 fill-current" />
                              <span>{language === 'bn' ? 'থামান' : 'Stop'}</span>
                            </button>
                          )}
                        </div>

                        <span className="text-[11px] font-bold text-stone-400">
                          {playingDuaId === dua.id && audioProgress.duration > 0 ? (
                            <span className="font-mono text-emerald-600 dark:text-[#D4AF37]">
                              {Math.floor(audioProgress.currentTime / 60)}:
                              {String(Math.floor(audioProgress.currentTime % 60)).padStart(2, '0')} /{' '}
                              {Math.floor(audioProgress.duration / 60)}:
                              {String(Math.floor(audioProgress.duration % 60)).padStart(2, '0')}
                            </span>
                          ) : (
                            <>
                              {language === 'bn' ? 'বিভাগ: ' : 'Category: '}
                              <span className="text-[#D4AF37] font-extrabold">{dua.category}</span>
                            </>
                          )}
                        </span>
                      </div>

                      {playingDuaId === dua.id && (
                        <div className="flex items-center gap-2 pt-1">
                          <input
                            type="range"
                            min={0}
                            max={audioProgress.duration || 1}
                            step={0.1}
                            value={audioProgress.currentTime || 0}
                            onChange={(e) => handleSeekChange(parseFloat(e.target.value))}
                            className="w-full h-1.5 bg-stone-200 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-[#D4AF37]"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

