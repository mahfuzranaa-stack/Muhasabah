import React, { useState, useEffect, useRef } from 'react';
import {
  TabType,
  PrayerItem,
  MetricProgress,
  DuaItem,
  ReflectionEntry,
  EmergencyContact,
  ExpenseRecord,
  MedicineReminder,
  ObservanceDay,
  LocationConfig,
} from './types';
import {
  INITIAL_PRAYERS,
  INITIAL_METRICS,
  INITIAL_DUAS,
  INITIAL_REFLECTIONS,
  INITIAL_EMERGENCY_CONTACTS,
  INITIAL_EXPENSES,
  INITIAL_MEDICINES,
  INITIAL_OBSERVANCE_DAYS,
  INITIAL_LOCATION,
} from './data/initialData';
import { HeaderBar } from './components/HeaderBar';
import { BottomNav } from './components/BottomNav';
import { DashboardScreen } from './components/DashboardScreen';
import { SalatScreen } from './components/SalatScreen';
import { DhikrScreen } from './components/DhikrScreen';
import { GoalsScreen } from './components/GoalsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { CalendarScreen } from './components/CalendarScreen';
import { MuhasabatAlMalScreen } from './components/MuhasabatAlMalScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { MyDayModal } from './components/MyDayModal';
import { LanguageProvider } from './utils/i18n';
import { DayIntelligenceCard } from './components/DayIntelligenceCard';

// Spiritual Accountability & Inner Peace Modals
import { SelfAuditModal } from './components/SelfAuditModal';
import { DailyNiyyahModal } from './components/DailyNiyyahModal';
import { IstighfarLedgerModal } from './components/IstighfarLedgerModal';
import { GratitudeJournalModal } from './components/GratitudeJournalModal';
import { GoodDeedTrackerModal } from './components/GoodDeedTrackerModal';
import { AudioSanctuaryModal } from './components/AudioSanctuaryModal';
import { VowTrackerModal } from './components/VowTrackerModal';
import { AngerResetModal } from './components/AngerResetModal';

// 6 Master Feature Modals & Utilities
import { EmergencyNumbersModal } from './components/EmergencyNumbersModal';
import { ExpenseTrackerModal } from './components/ExpenseTrackerModal';
import { NewsSectionModal } from './components/NewsSectionModal';
import { MedicineReminderModal } from './components/MedicineReminderModal';
import { AgeCalculatorModal } from './components/AgeCalculatorModal';
import {
  NextImportantDayModal,
  formatStrictCountdown,
} from './components/NextImportantDayModal';
import { LocationModal } from './components/LocationModal';
import { SalatOffsetModal } from './components/SalatOffsetModal';
import {
  calculatePrayerTimes,
  minutesToTimeString,
  timeStringToMinutes,
  BANGLADESH_LOCATIONS,
} from './utils/qibla';

// Persistent storage helper (AsyncStorage / localStorage equivalent)
const loadSavedData = <T,>(key: string, fallback: T): T => {
  try {
    const saved = localStorage.getItem(`muhasabah_${key}`);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error(`Error loading key: ${key}`, e);
  }
  return fallback;
};

const persistData = <T,>(key: string, value: T) => {
  try {
    localStorage.setItem(`muhasabah_${key}`, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving key: ${key}`, e);
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [darkMode, setDarkMode] = useState<boolean>(() =>
    loadSavedData('darkMode', true)
  );
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() =>
    loadSavedData('soundEnabled', true)
  );
  const [phoneFrameMode, setPhoneFrameMode] = useState<boolean>(true);

  // Core Application State with Zero-State / Fresh Start
  const [prayers, setPrayers] = useState<PrayerItem[]>(() =>
    loadSavedData('prayers', INITIAL_PRAYERS)
  );
  const [metrics, setMetrics] = useState<MetricProgress[]>(() =>
    loadSavedData('metrics', INITIAL_METRICS)
  );
  const [dhikrCount, setDhikrCount] = useState<number>(() =>
    loadSavedData('dhikrCount', 0)
  );
  const [duas, setDuas] = useState<DuaItem[]>(() => {
    const saved = loadSavedData('duas', INITIAL_DUAS);
    return saved.map((item: DuaItem) => {
      const match = INITIAL_DUAS.find((d) => d.id === item.id);
      return {
        ...item,
        audioUrl: match?.audioUrl || item.audioUrl,
      };
    });
  });
  const [reflections, setReflections] = useState<ReflectionEntry[]>(() =>
    loadSavedData('reflections', INITIAL_REFLECTIONS)
  );
  const [userName, setUserName] = useState<string>(() =>
    loadSavedData('userName', '')
  );
  const [profilePhoto, setProfilePhoto] = useState<string | null>(() => {
    try {
      return localStorage.getItem('muhasabah_profile_photo') || null;
    } catch {
      return null;
    }
  });

  const handleUpdateProfilePhoto = (photo: string | null) => {
    setProfilePhoto(photo);
    try {
      if (photo) {
        localStorage.setItem('muhasabah_profile_photo', photo);
      } else {
        localStorage.removeItem('muhasabah_profile_photo');
      }
    } catch (e) {
      console.error('Failed to save profile photo', e);
    }
  };

  // 6 Master Features Persistent State
  const [contacts, setContacts] = useState<EmergencyContact[]>(() =>
    loadSavedData('contacts', INITIAL_EMERGENCY_CONTACTS)
  );
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() =>
    loadSavedData('expenses', INITIAL_EXPENSES)
  );
  const [medicines, setMedicines] = useState<MedicineReminder[]>(() =>
    loadSavedData('medicines', INITIAL_MEDICINES)
  );
  const [savedDob, setSavedDob] = useState<string>(() =>
    loadSavedData('savedDob', '2000-01-01')
  );
  const [observanceDays, setObservanceDays] = useState<ObservanceDay[]>(() =>
    loadSavedData('observanceDays', INITIAL_OBSERVANCE_DAYS)
  );
  const [location, setLocation] = useState<LocationConfig>(() =>
    loadSavedData('location', INITIAL_LOCATION)
  );
  const [hijriAdjustment, setHijriAdjustment] = useState<number>(() =>
    loadSavedData('hijriAdjustment', 0)
  );
  const [isUpdatingLocation, setIsUpdatingLocation] = useState<boolean>(false);
  const mainScrollRef = useRef<HTMLElement | null>(null);
  const [timeRefreshKey, setTimeRefreshKey] = useState(0);
  const pullStartYRef = useRef<number | null>(null);
  const pullDistanceRef = useRef(0);
  const pullTriggeredRef = useRef(false);

  // Remove only the known demo records shipped by older builds; preserve user-created records.
  useEffect(() => {
    const demoExpenseIds = new Set(['sav-1', 'sav-2', 'exp-1', 'exp-2', 'exp-3', 'exp-4']);
    const demoMedicineIds = new Set(['med-1', 'med-2', 'med-3', 'med-4']);
    const demoObservanceIds = new Set([
      'obs-ramadan', 'obs-shab-e-qadr', 'obs-eid-ul-fitr', 'obs-victory-day',
      'obs-mother-language', 'obs-independence-day', 'obs-pahela-baishakh', 'obs-eid-ul-adha'
    ]);
    setExpenses((prev) => prev.filter((item) => !demoExpenseIds.has(item.id)));
    setMedicines((prev) => prev.filter((item) => !demoMedicineIds.has(item.id)));
    setObservanceDays((prev) => prev.filter((item) => !demoObservanceIds.has(item.id)));
  }, []);

  // Each tab starts at the top instead of inheriting the previous tab's scroll position.
  useEffect(() => {
    const main = mainScrollRef.current;
    if (!main) return;
    main.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, [activeTab]);

  // Modals Visibility
  const [isMyDayOpen, setIsMyDayOpen] = useState<boolean>(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState<boolean>(false);
  const [isExpenseOpen, setIsExpenseOpen] = useState<boolean>(false);
  const [isNewsOpen, setIsNewsOpen] = useState<boolean>(false);
  const [isMedicineOpen, setIsMedicineOpen] = useState<boolean>(false);
  const [isAgeCalcOpen, setIsAgeCalcOpen] = useState<boolean>(false);
  const [isCountdownOpen, setIsCountdownOpen] = useState<boolean>(false);
  const [isLocationOpen, setIsLocationOpen] = useState<boolean>(false);
  const [isOffsetOpen, setIsOffsetOpen] = useState<boolean>(false);

  // Spiritual Accountability Modals Visibility
  const [isSelfAuditOpen, setIsSelfAuditOpen] = useState<boolean>(false);
  const [isNiyyahOpen, setIsNiyyahOpen] = useState<boolean>(false);
  const [isIstighfarOpen, setIsIstighfarOpen] = useState<boolean>(false);
  const [isGratitudeOpen, setIsGratitudeOpen] = useState<boolean>(false);
  const [isDeedsOpen, setIsDeedsOpen] = useState<boolean>(false);
  const [isAudioSanctuaryOpen, setIsAudioSanctuaryOpen] = useState<boolean>(false);
  const [isVowOpen, setIsVowOpen] = useState<boolean>(false);
  const [isAngerResetOpen, setIsAngerResetOpen] = useState<boolean>(false);

  // Synchronize with persistent storage on updates
  useEffect(() => persistData('darkMode', darkMode), [darkMode]);
  useEffect(() => persistData('soundEnabled', soundEnabled), [soundEnabled]);
  useEffect(() => persistData('prayers', prayers), [prayers]);
  useEffect(() => persistData('metrics', metrics), [metrics]);
  useEffect(() => persistData('dhikrCount', dhikrCount), [dhikrCount]);
  useEffect(() => persistData('duas', duas), [duas]);
  useEffect(() => persistData('reflections', reflections), [reflections]);
  useEffect(() => persistData('userName', userName), [userName]);
  useEffect(() => persistData('contacts', contacts), [contacts]);
  useEffect(() => persistData('expenses', expenses), [expenses]);
  useEffect(() => persistData('medicines', medicines), [medicines]);
  useEffect(() => persistData('savedDob', savedDob), [savedDob]);
  useEffect(() => persistData('observanceDays', observanceDays), [observanceDays]);
  useEffect(() => persistData('location', location), [location]);
  useEffect(() => persistData('hijriAdjustment', hijriAdjustment), [hijriAdjustment]);

  // Recalculate prayer times when location changes, preserving completed, jamaah, and offsets
  useEffect(() => {
    const freshCalculated = calculatePrayerTimes(location.latitude, location.longitude, new Date(), location.timezoneOffset || 6);
    setPrayers((prev) =>
      freshCalculated.map((fresh) => {
        const existing = prev.find((p) => p.id === fresh.id);
        const offset = existing?.offsetMinutes || 0;
        const baseTime = fresh.baseTime || fresh.time;
        const adjustedTime = offset !== 0
          ? minutesToTimeString(timeStringToMinutes(baseTime) + offset)
          : baseTime;
        return {
          ...fresh,
          baseTime,
          time: adjustedTime,
          offsetMinutes: offset,
          completed: existing ? existing.completed : false,
          jamaah: existing ? existing.jamaah : false,
        };
      })
    );
  }, [location.latitude, location.longitude, location.timezoneOffset, timeRefreshKey]);

  // Synchronize Dark Mode class on documentElement
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Global Reset Action: resets all states and clears persistent data
  // Intentional Daily Reset: resets today's checkmarks & counters while strictly preserving
  // Profile, Niyyah, Gratitude, Self-Audit, Prayer adjustments, Goals & Habits
  const handleResetAllData = () => {
    // Preserve offsetMinutes on prayers
    setPrayers((prev) =>
      prev.map((p) => ({ ...p, completed: false, jamaah: false }))
    );
    setMetrics(
      INITIAL_METRICS.map((m) => ({
        ...m,
        current: 0,
        percent: 0,
        sub:
          m.id === 'salat'
            ? '0/5 Completed'
            : m.id === 'quran'
            ? '0 Verses Read'
            : m.id === 'tasks'
            ? '0/8 Completed'
            : '0m Logged',
      }))
    );
    setDhikrCount(0);
    setDuas((prev) => prev.map((d) => ({ ...d, completed: false })));
    setMedicines((prev) =>
      prev.map((m) => ({
        ...m,
        takenToday: false,
        lastTakenTime: undefined,
        snoozedUntil: undefined,
      }))
    );

    // Update only the daily tracker keys in localStorage
    ['metrics', 'dhikrCount', 'my_day_tasks'].forEach((k) =>
      localStorage.removeItem(`muhasabah_${k}`)
    );
    // React persistence effects below save the reset state once the state updates commit.
    // Avoid duplicate manual writes here, which could race with those effects.
  };

  // Handle Prayer Checkmark Toggling
  const handleTogglePrayer = (id: string) => {
    setPrayers((prev) => {
      const next = prev.map((p) => (p.id === id ? { ...p, completed: !p.completed } : p));
      const completedCount = next.filter((p) => p.completed).length;

      // Also update the Salat metric ring in real-time
      setMetrics((mPrev) =>
        mPrev.map((m) =>
          m.id === 'salat'
            ? {
                ...m,
                current: completedCount,
                percent: Math.round((completedCount / m.total) * 100),
                sub: `${completedCount}/${m.total} Completed`,
              }
            : m
        )
      );
      return next;
    });
  };

  const handleToggleJamaah = (id: string) => {
    setPrayers((prev) =>
      prev.map((p) => (p.id === id ? { ...p, jamaah: !p.jamaah } : p))
    );
  };

  // Centralized Prayer Offset Handling: changes reflect everywhere across the entire app
  const handleAdjustOffset = (prayerId: string, deltaMinutes: number) => {
    setPrayers((prev) =>
      prev.map((p) => {
        if (p.id !== prayerId) return p;
        const currentOffset = p.offsetMinutes || 0;
        const newOffset = currentOffset + deltaMinutes;
        const baseTime = p.baseTime || (p.offsetMinutes ? minutesToTimeString(timeStringToMinutes(p.time) - p.offsetMinutes) : p.time);
        const baseMin = timeStringToMinutes(baseTime);
        const newTime = minutesToTimeString(baseMin + newOffset);
        return {
          ...p,
          baseTime,
          time: newTime,
          offsetMinutes: newOffset,
        };
      })
    );
  };

  const handleAdjustAllOffsets = (deltaMinutes: number) => {
    setPrayers((prev) =>
      prev.map((p) => {
        const currentOffset = p.offsetMinutes || 0;
        const newOffset = currentOffset + deltaMinutes;
        const baseTime = p.baseTime || (p.offsetMinutes ? minutesToTimeString(timeStringToMinutes(p.time) - p.offsetMinutes) : p.time);
        const baseMin = timeStringToMinutes(baseTime);
        const newTime = minutesToTimeString(baseMin + newOffset);
        return {
          ...p,
          baseTime,
          time: newTime,
          offsetMinutes: newOffset,
        };
      })
    );
  };

  const handleResetOffsets = () => {
    setPrayers((prev) =>
      prev.map((p) => {
        const baseTime = p.baseTime || (p.offsetMinutes ? minutesToTimeString(timeStringToMinutes(p.time) - p.offsetMinutes) : p.time);
        return {
          ...p,
          baseTime,
          time: baseTime,
          offsetMinutes: 0,
        };
      })
    );
  };

  // Metric Adjustments
  const handleUpdateMetric = (id: string, delta: number) => {
    setMetrics((prev) =>
      prev.map((m) => {
        if (m.id !== id) return m;
        const nextVal = Math.min(m.total, Math.max(0, m.current + delta));
        const nextPercent = Math.round((nextVal / m.total) * 100);
        let sub = m.sub;
        if (id === 'quran') sub = `${nextVal} Verses Read`;
        else if (id === 'tasks') sub = `${nextVal}/${m.total} Completed`;
        else if (id === 'study') sub = `${Math.floor(nextVal / 60)}h ${nextVal % 60}m Logged`;
        return { ...m, current: nextVal, percent: nextPercent, sub };
      })
    );
  };

  const handleQuickAddAyah = () => {
    handleUpdateMetric('quran', 1);
  };

  // Dhikr Counter Actions
  const handleIncrementDhikr = (count: number = 1) => {
    setDhikrCount((prev) => prev + count);
  };

  const handleResetDhikr = () => {
    setDhikrCount(0);
  };

  // Dua Toggle
  const handleToggleDua = (id: string) => {
    setDuas((prev) =>
      prev.map((d) => (d.id === id ? { ...d, completed: !d.completed } : d))
    );
  };

  // Reflections
  const handleAddReflection = (entry: Omit<ReflectionEntry, 'id' | 'date'>) => {
    const newEntry: ReflectionEntry = {
      ...entry,
      id: `ref-${Date.now()}`,
      date: 'Today, Just now',
    };
    setReflections([newEntry, ...reflections]);
  };

  const handleDeleteReflection = (id: string) => {
    setReflections(reflections.filter((r) => r.id !== id));
  };

  // Emergency Numbers Handlers
  const handleAddContact = (contact: Omit<EmergencyContact, 'id'>) => {
    const newContact: EmergencyContact = {
      ...contact,
      id: `contact-${Date.now()}`,
    };
    setContacts((prev) => [newContact, ...prev]);
  };

  const handleEditContact = (id: string, updated: Partial<EmergencyContact>) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updated } : c))
    );
  };

  const handleDeleteContact = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  const handleResetContacts = () => {
    setContacts(INITIAL_EMERGENCY_CONTACTS);
  };

  // Expense Handlers
  const handleAddExpense = (expense: Omit<ExpenseRecord, 'id'>) => {
    const newExpense: ExpenseRecord = {
      ...expense,
      id: `exp-${Date.now()}`,
    };
    setExpenses((prev) => [newExpense, ...prev]);
  };

  const handleUpdateExpense = (updated: ExpenseRecord) => {
    setExpenses((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  const handleResetExpenses = () => {
    setExpenses([]);
  };

  // Medicine Handlers
  const handleAddMedicine = (med: Omit<MedicineReminder, 'id'>) => {
    const newMed: MedicineReminder = {
      ...med,
      id: `med-${Date.now()}`,
    };
    setMedicines((prev) => [newMed, ...prev]);
  };

  const handleToggleTakeDose = (id: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMedicines((prev) =>
      prev.map((m) =>
        m.id === id
          ? {
              ...m,
              takenToday: !m.takenToday,
              lastTakenTime: !m.takenToday ? timeStr : undefined,
              snoozedUntil: undefined,
            }
          : m
      )
    );
  };

  const handleSnoozeDose = (id: string) => {
    const now = new Date();
    const snoozeTime = new Date(now.getTime() + 5 * 60 * 1000);
    const snoozeStr = snoozeTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMedicines((prev) =>
      prev.map((m) => (m.id === id ? { ...m, snoozedUntil: snoozeStr } : m))
    );
  };

  const handleDeleteMedicine = (id: string) => {
    setMedicines((prev) => prev.filter((m) => m.id !== id));
  };

  const handleResetMedicines = () => {
    setMedicines([]);
  };

  // Observance Days Handlers
  const handleAddObservanceDay = (day: Omit<ObservanceDay, 'id'>) => {
    const newDay: ObservanceDay = {
      ...day,
      id: `obs-${Date.now()}`,
    };
    setObservanceDays((prev) => [...prev, newDay]);
  };

  const handleDeleteObservanceDay = (id: string) => {
    setObservanceDays((prev) => prev.filter((d) => d.id !== id));
  };

  const handleResetObservanceDays = () => {
    setObservanceDays([]);
  };

  // Location Sync Handler
  const handleUpdateLocation = (newLoc: LocationConfig) => {
    setLocation(newLoc);
  };

  const refreshTimeFeatures = () => {
    setTimeRefreshKey((prev) => prev + 1);
    setPrayers((prev) => {
      const fresh = calculatePrayerTimes(
        location.latitude,
        location.longitude,
        new Date(),
        location.timezoneOffset || 6
      );
      return fresh.map((item) => {
        const existing = prev.find((p) => p.id === item.id);
        const offset = existing?.offsetMinutes || 0;
        const baseTime = item.baseTime || item.time;
        return {
          ...item,
          baseTime,
          time: offset ? minutesToTimeString(timeStringToMinutes(baseTime) + offset) : baseTime,
          offsetMinutes: offset,
          completed: existing?.completed || false,
          jamaah: existing?.jamaah || false,
        };
      });
    });
  };

  const handleGpsLocationUpdate = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsUpdatingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        let closestDistrict = 'My GPS Location';
        let minDistance = Infinity;
        for (const loc of BANGLADESH_LOCATIONS) {
          const dLat = loc.latitude - latitude;
          const dLng = loc.longitude - longitude;
          const distance = Math.sqrt(dLat * dLat + dLng * dLng);
          if (distance < minDistance) {
            minDistance = distance;
            closestDistrict = loc.name;
          }
        }
        const displayName =
          minDistance < 0.35
            ? closestDistrict
            : `GPS (${latitude.toFixed(2)}°N, ${longitude.toFixed(2)}°E)`;
        setLocation({
          ...location,
          latitude: Number(latitude.toFixed(4)),
          longitude: Number(longitude.toFixed(4)),
          name: displayName,
          country: 'Bangladesh',
          timezoneOffset: 6,
        });
        setIsUpdatingLocation(false);
        setTimeRefreshKey((prev) => prev + 1);
      },
      (error) => {
        console.warn('Geolocation error:', error);
        setIsUpdatingLocation(false);
      },
      { timeout: 10000, enableHighAccuracy: true, maximumAge: 30000 }
    );
  };

  // Full State Backup Export Handler
  const handleExportAllData = (): string => {
    let customGoalsData = null;
    let achievementsData = null;
    let dailyPlannerData = null;
    let dailyNiyyahData = null;
    let selfAuditData = null;
    let gratitudeData = null;
    let istighfarData = null;
    let wisdomBookmarksData = null;
    try {
      customGoalsData = JSON.parse(localStorage.getItem('muhasabah_custom_goals_v2') || '[]');
      achievementsData = JSON.parse(localStorage.getItem('muhasabah_achievements_v2') || '[]');
      dailyPlannerData = JSON.parse(localStorage.getItem('muhasabah_daily_planner_state') || '{}');
      dailyNiyyahData = JSON.parse(localStorage.getItem('muhasabah_daily_niyyah_records') || '[]');
      selfAuditData = JSON.parse(localStorage.getItem('muhasabah_self_audit_records') || '[]');
      gratitudeData = JSON.parse(localStorage.getItem('muhasabah_gratitude_entries') || '[]');
      istighfarData = JSON.parse(localStorage.getItem('muhasabah_istighfar_records') || '[]');
      wisdomBookmarksData = JSON.parse(localStorage.getItem('muhasabah_wisdom_bookmarks') || '[]');
    } catch {
      // ignore
    }

    const backup = {
      version: '3.0',
      exportedAt: new Date().toISOString(),
      appName: 'Muhasabah Daily Self-Accounting',
      state: {
        userName,
        prayers,
        metrics,
        dhikrCount,
        duas,
        reflections,
        contacts,
        expenses,
        medicines,
        savedDob,
        observanceDays,
        location,
        hijriAdjustment,
        customGoals: customGoalsData,
        achievements: achievementsData,
        dailyPlanner: dailyPlannerData,
        dailyNiyyah: dailyNiyyahData,
        selfAudit: selfAuditData,
        gratitude: gratitudeData,
        istighfar: istighfarData,
        wisdomBookmarks: wisdomBookmarksData,
      },
    };
    return JSON.stringify(backup, null, 2);
  };

  // Full State Backup Import Handler
  const handleImportAllData = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      const data = parsed.state || parsed.data || parsed;
      if (data.userName !== undefined) {
        setUserName(data.userName);
        persistData('userName', data.userName);
      }
      if (Array.isArray(data.prayers)) {
        setPrayers(data.prayers);
        persistData('prayers', data.prayers);
      }
      if (Array.isArray(data.metrics)) {
        setMetrics(data.metrics);
        persistData('metrics', data.metrics);
      }
      if (typeof data.dhikrCount === 'number') {
        setDhikrCount(data.dhikrCount);
        persistData('dhikrCount', data.dhikrCount);
      }
      if (Array.isArray(data.duas)) {
        setDuas(data.duas);
        persistData('duas', data.duas);
      }
      if (Array.isArray(data.reflections)) {
        setReflections(data.reflections);
        persistData('reflections', data.reflections);
      }
      if (Array.isArray(data.contacts)) {
        setContacts(data.contacts);
        persistData('contacts', data.contacts);
      }
      if (Array.isArray(data.expenses)) {
        setExpenses(data.expenses);
        persistData('expenses', data.expenses);
      }
      if (Array.isArray(data.medicines)) {
        setMedicines(data.medicines);
        persistData('medicines', data.medicines);
      }
      if (data.savedDob) {
        setSavedDob(data.savedDob);
        persistData('savedDob', data.savedDob);
      }
      if (Array.isArray(data.observanceDays)) {
        setObservanceDays(data.observanceDays);
        persistData('observanceDays', data.observanceDays);
      }
      if (data.location) {
        setLocation(data.location);
        persistData('location', data.location);
      }
      if (typeof data.hijriAdjustment === 'number') {
        const value = Math.max(-2, Math.min(2, Math.round(data.hijriAdjustment)));
        setHijriAdjustment(value);
        persistData('hijriAdjustment', value);
      }
      if (data.customGoals) {
        localStorage.setItem(
          'muhasabah_custom_goals_v2',
          typeof data.customGoals === 'string' ? data.customGoals : JSON.stringify(data.customGoals)
        );
      }
      if (data.achievements) {
        localStorage.setItem(
          'muhasabah_achievements_v2',
          typeof data.achievements === 'string' ? data.achievements : JSON.stringify(data.achievements)
        );
      }
      if (data.dailyPlanner) {
        localStorage.setItem(
          'muhasabah_daily_planner_state',
          typeof data.dailyPlanner === 'string' ? data.dailyPlanner : JSON.stringify(data.dailyPlanner)
        );
      }
      if (data.dailyNiyyah) {
        localStorage.setItem(
          'muhasabah_daily_niyyah_records',
          typeof data.dailyNiyyah === 'string' ? data.dailyNiyyah : JSON.stringify(data.dailyNiyyah)
        );
      }
      if (data.selfAudit) {
        localStorage.setItem(
          'muhasabah_self_audit_records',
          typeof data.selfAudit === 'string' ? data.selfAudit : JSON.stringify(data.selfAudit)
        );
      }
      if (data.gratitude) {
        localStorage.setItem(
          'muhasabah_gratitude_entries',
          typeof data.gratitude === 'string' ? data.gratitude : JSON.stringify(data.gratitude)
        );
      }
      if (data.istighfar) {
        localStorage.setItem(
          'muhasabah_istighfar_records',
          typeof data.istighfar === 'string' ? data.istighfar : JSON.stringify(data.istighfar)
        );
      }
      if (data.wisdomBookmarks) {
        localStorage.setItem(
          'muhasabah_wisdom_bookmarks',
          typeof data.wisdomBookmarks === 'string' ? data.wisdomBookmarks : JSON.stringify(data.wisdomBookmarks)
        );
      }
      return true;
    } catch (e) {
      console.error('Import failed', e);
      return false;
    }
  };

  const salatCountCompleted = prayers.filter((p) => p.completed).length;
  const totalExpensesAmount = expenses
    .filter((e) => !e.type || e.type === 'expense')
    .reduce((sum, e) => sum + e.amount, 0);
  const pendingMedsCount = medicines.filter((m) => !m.takenToday).length;

  // Calculate nearest observance day for dashboard summary
  const sortedUpcomingDays = observanceDays
    .map((d) => ({ ...d, countdown: formatStrictCountdown(d.date) }))
    .filter((d) => !d.countdown.isPassed || d.countdown.isToday)
    .sort((a, b) => a.countdown.daysRemaining - b.countdown.daysRemaining);

  const nearestUpcomingDay = sortedUpcomingDays[0] || {
    title: 'Holy Ramadan',
    countdown: { label: 'Upcoming' },
  };

  return (
    <LanguageProvider>
      <div
        id="muhasabah-root"
        className={`h-[100dvh] min-h-[100dvh] w-full overflow-hidden transition-colors duration-200 flex flex-col items-center justify-center ${
          darkMode ? 'bg-[#0B120E] text-[#F4F6F5] muhasabah-dark' : 'bg-[#F1F6F3] text-stone-900 muhasabah-light'
        }`}
      >
      {/* Device / Container Frame Wrapper */}
      <div
        className={`w-full transition-all duration-300 ${
          phoneFrameMode
            ? 'max-w-[420px] my-0 sm:my-6 rounded-none sm:rounded-[38px] shadow-2xl border-0 sm:border-8 sm:border-stone-900/90 dark:sm:border-[#1E3B2E]/80 overflow-hidden relative'
            : 'max-w-2xl min-h-screen sm:my-4 sm:rounded-2xl border-0 sm:border border-emerald-100 dark:border-[#1E3B2E]'
        } flex flex-col h-full min-h-0 ${
          darkMode ? 'bg-[#0D1612]' : 'bg-white'
        }`}
        style={{
          boxShadow: phoneFrameMode
            ? '0 25px 50px -12px rgba(11, 18, 14, 0.6), 0 0 0 1px rgba(30, 59, 46, 0.4)'
            : undefined,
        }}
      >
        {/* Global Header Bar (Status bar removed to prevent overlap & visual clutter) */}
        {activeTab === 'dashboard' && (
          <div className="shrink-0 relative z-40">
            <HeaderBar
              darkMode={darkMode}
              onOpenMyDay={() => setIsMyDayOpen(true)}
              onOpenSettings={() => setActiveTab('settings')}
              locationName={location.name}
              latitude={location.latitude}
              longitude={location.longitude}
              onRefreshTimeFeatures={refreshTimeFeatures}
              timeRefreshKey={timeRefreshKey}
              hijriAdjustment={hijriAdjustment}
            />
          </div>
        )}

        {/* Compact page title on every screen except Home and Profile */}
        {activeTab !== 'dashboard' && activeTab !== 'profile' && (
          <div className={`shrink-0 px-4 py-2.5 border-b flex items-center justify-center ${
            darkMode ? 'bg-[#12281E] border-[#1C3B2E]' : 'bg-white border-emerald-100'
          }`}>
            <div className="flex items-center gap-2.5">
              <img src="/assets/icon.png" alt="Muhasabah" className="w-8 h-8 rounded-xl object-cover shadow-sm" />
              <span className={`text-xl sm:text-2xl font-black tracking-[0.18em] uppercase ${darkMode ? 'text-[#F4E0A5]' : 'text-[#1B4332]'}`}>
                MUHASABAH
              </span>
            </div>
          </div>
        )}

        {/* Main Viewport Content Area */}
        <main
          ref={mainScrollRef}
          className="flex-1 min-h-0 w-full overflow-y-auto overscroll-contain px-4 pt-3 pb-2 scroll-smooth"
          onTouchStart={(e) => {
            pullStartYRef.current = e.touches[0]?.clientY ?? null;
            pullDistanceRef.current = 0;
            pullTriggeredRef.current = false;
          }}
          onTouchMove={(e) => {
            const main = mainScrollRef.current;
            const startY = pullStartYRef.current;
            if (!main || startY === null || main.scrollTop > 0 || pullTriggeredRef.current) return;
            pullDistanceRef.current = Math.max(0, e.touches[0]?.clientY - startY);
          }}
          onTouchEnd={() => {
            if (pullDistanceRef.current > 70 && !pullTriggeredRef.current) {
              pullTriggeredRef.current = true;
              refreshTimeFeatures();
            }
            pullStartYRef.current = null;
            pullDistanceRef.current = 0;
          }}
        >
          {activeTab === 'dashboard' && (
            <DashboardScreen
              darkMode={darkMode}
              soundEnabled={soundEnabled}
              metrics={metrics}
              prayers={prayers}
              dhikrCount={dhikrCount}
              totalExpensesAmount={totalExpensesAmount}
              pendingMedsCount={pendingMedsCount}
              nextEventTitle={nearestUpcomingDay.title}
              nextEventCountdown={nearestUpcomingDay.countdown.label}
              onUpdateMetric={handleUpdateMetric}
              onNavigateTab={(tab) => setActiveTab(tab)}
              onQuickAddAyah={handleQuickAddAyah}
              onOpenMyDay={() => setIsMyDayOpen(true)}
              onIncrementDhikr={handleIncrementDhikr}
              onOpenEmergencyModal={() => setIsEmergencyOpen(true)}
              onOpenExpenseModal={() => setIsExpenseOpen(true)}
              onOpenNewsModal={() => setIsNewsOpen(true)}
              onOpenMedicineModal={() => setIsMedicineOpen(true)}
              onOpenAgeCalcModal={() => setIsAgeCalcOpen(true)}
              onOpenCountdownModal={() => setIsCountdownOpen(true)}
              onOpenSelfAuditModal={() => setIsSelfAuditOpen(true)}
              onOpenNiyyahModal={() => setIsNiyyahOpen(true)}
              onOpenIstighfarModal={() => setIsIstighfarOpen(true)}
              onOpenGratitudeModal={() => setIsGratitudeOpen(true)}
              onOpenDeedsModal={() => setIsDeedsOpen(true)}
              onOpenAudioSanctuaryModal={() => setIsAudioSanctuaryOpen(true)}
              onOpenVowModal={() => setIsVowOpen(true)}
              onOpenAngerResetModal={() => setIsAngerResetOpen(true)}
            />
          )}

          {activeTab === 'salat' && (
            <SalatScreen
              darkMode={darkMode}
              soundEnabled={soundEnabled}
              prayers={prayers}
              location={location}
              onTogglePrayer={handleTogglePrayer}
              onToggleJamaah={handleToggleJamaah}
              onOpenOffsetModal={() => setIsOffsetOpen(true)}
              onOpenLocationModal={() => setIsLocationOpen(true)}
              onAdjustOffset={handleAdjustOffset}
              onUpdateLocation={handleGpsLocationUpdate}
              isUpdatingLocation={isUpdatingLocation}
            />
          )}

          {activeTab === 'dhikr' && (
            <DhikrScreen
              darkMode={darkMode}
              soundEnabled={soundEnabled}
              dhikrCount={dhikrCount}
              onIncrementDhikr={handleIncrementDhikr}
              onResetDhikr={handleResetDhikr}
              duas={duas}
              onToggleDua={handleToggleDua}
            />
          )}

          {activeTab === 'calendar' && (
            <CalendarScreen
              darkMode={darkMode}
              soundEnabled={soundEnabled}
              metrics={metrics}
              savedDob={savedDob}
              onSaveDob={setSavedDob}
              refreshKey={timeRefreshKey}
              hijriAdjustment={hijriAdjustment}
              onHijriAdjustmentChange={(value) => setHijriAdjustment(Math.max(-2, Math.min(2, value)))}
            />
          )}

          {activeTab === 'mal' && (
            <MuhasabatAlMalScreen
              darkMode={darkMode}
              finances={expenses}
              onAddRecord={handleAddExpense}
              onDeleteRecord={handleDeleteExpense}
            />
          )}

          {activeTab === 'goals' && (
            <GoalsScreen
              darkMode={darkMode}
              metrics={metrics}
              soundEnabled={soundEnabled}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileScreen
              darkMode={darkMode}
              soundEnabled={soundEnabled}
              userName={userName}
              onUpdateUserName={setUserName}
              profilePhoto={profilePhoto}
              onUpdateProfilePhoto={handleUpdateProfilePhoto}
              onResetAllData={handleResetAllData}
              dhikrCount={dhikrCount}
              salatCompleted={salatCountCompleted}
              reflections={reflections}
              onAddReflection={handleAddReflection}
              onDeleteReflection={handleDeleteReflection}
              onExportAllData={handleExportAllData}
              onImportAllData={handleImportAllData}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsScreen
              darkMode={darkMode}
              onToggleDarkMode={() => setDarkMode(!darkMode)}
              soundEnabled={soundEnabled}
              onToggleSound={() => setSoundEnabled(!soundEnabled)}
              location={location}
              onUpdateLocation={handleGpsLocationUpdate}
              isUpdatingLocation={isUpdatingLocation}
              onOpenOffsetModal={() => setIsOffsetOpen(true)}
              onOpenLocationModal={() => setIsLocationOpen(true)}
              onResetAllData={handleResetAllData}
              onExportAllData={handleExportAllData}
              onImportAllData={handleImportAllData}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}
        </main>

        {/* Bottom Navigation Dock */}
        <BottomNav
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          darkMode={darkMode}
          salatCountCompleted={salatCountCompleted}
        />

      </div>

      {/* Quick "+ MY DAY" Planner Modal */}
      <MyDayModal
        isOpen={isMyDayOpen}
        onClose={() => setIsMyDayOpen(false)}
        darkMode={darkMode}
        onTaskAdded={() => handleUpdateMetric('tasks', 1)}
      />

      {/* 1. Emergency Numbers Modal */}
      <EmergencyNumbersModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        darkMode={darkMode}
        contacts={contacts}
        onAddContact={handleAddContact}
        onUpdateContact={handleEditContact}
        onDeleteContact={handleDeleteContact}
        onResetContacts={handleResetContacts}
      />

      {/* 2. Expense Tracker Modal */}
      <ExpenseTrackerModal
        isOpen={isExpenseOpen}
        onClose={() => setIsExpenseOpen(false)}
        darkMode={darkMode}
        expenses={expenses}
        onAddExpense={handleAddExpense}
        onUpdateExpense={handleUpdateExpense}
        onDeleteExpense={handleDeleteExpense}
        onResetExpenses={handleResetExpenses}
      />

      {/* 3. News Section Modal */}
      <NewsSectionModal
        isOpen={isNewsOpen}
        onClose={() => setIsNewsOpen(false)}
        darkMode={darkMode}
      />

      {/* 4. Medicine Reminder Modal */}
      <MedicineReminderModal
        isOpen={isMedicineOpen}
        onClose={() => setIsMedicineOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
        medicines={medicines}
        onAddMedicine={handleAddMedicine}
        onToggleTakeDose={handleToggleTakeDose}
        onSnoozeDose={handleSnoozeDose}
        onDeleteMedicine={handleDeleteMedicine}
        onResetMedicines={handleResetMedicines}
      />

      {/* 5. Age Calculator Modal */}
      <AgeCalculatorModal
        isOpen={isAgeCalcOpen}
        onClose={() => setIsAgeCalcOpen(false)}
        darkMode={darkMode}
        savedDob={savedDob}
        onSaveDob={setSavedDob}
      />

      {/* 6. Next Important Day Modal */}
      <NextImportantDayModal
        isOpen={isCountdownOpen}
        onClose={() => setIsCountdownOpen(false)}
        darkMode={darkMode}
        days={observanceDays}
        onAddDay={handleAddObservanceDay}
        onDeleteDay={handleDeleteObservanceDay}
        onResetDays={handleResetObservanceDays}
      />

      {/* Location Sync Modal */}
      <LocationModal
        isOpen={isLocationOpen}
        onClose={() => setIsLocationOpen(false)}
        darkMode={darkMode}
        currentLocation={location}
        onUpdateLocation={handleUpdateLocation}
      />

      {/* Prayer Time Offset Modal */}
      <SalatOffsetModal
        isOpen={isOffsetOpen}
        onClose={() => setIsOffsetOpen(false)}
        darkMode={darkMode}
        prayers={prayers}
        onAdjustOffset={handleAdjustOffset}
        onAdjustAllOffsets={handleAdjustAllOffsets}
        onResetOffsets={handleResetOffsets}
      />

      {/* 7. Self-Audit (মুহাসাবাতুন নাফস) Modal */}
      <SelfAuditModal
        isOpen={isSelfAuditOpen}
        onClose={() => setIsSelfAuditOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
        onAuditSaved={() => handleUpdateMetric('tasks', 1)}
      />

      {/* 8. Daily Niyyah & Intention Renewer Modal */}
      <DailyNiyyahModal
        isOpen={isNiyyahOpen}
        onClose={() => setIsNiyyahOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
        onNiyyahUpdated={() => handleUpdateMetric('tasks', 1)}
      />

      {/* 9. Istighfar & Repentance Ledger Modal */}
      <IstighfarLedgerModal
        isOpen={isIstighfarOpen}
        onClose={() => setIsIstighfarOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
      />

      {/* 10. Gratitude Journal (শুকরিয়া ডায়েরি) Modal */}
      <GratitudeJournalModal
        isOpen={isGratitudeOpen}
        onClose={() => setIsGratitudeOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
        onGratitudeLogged={() => handleUpdateMetric('tasks', 1)}
      />

      {/* 11. Good Deed & Sirr Tracker Modal */}
      <GoodDeedTrackerModal
        isOpen={isDeedsOpen}
        onClose={() => setIsDeedsOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
        onDeedAdded={() => handleUpdateMetric('tasks', 1)}
      />

      {/* 12. Audio Sanctuary & Rain/Azan Ambience Modal */}
      <AudioSanctuaryModal
        isOpen={isAudioSanctuaryOpen}
        onClose={() => setIsAudioSanctuaryOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
      />

      {/* 13. Vow & Kaffarah Tracker Modal */}
      <VowTrackerModal
        isOpen={isVowOpen}
        onClose={() => setIsVowOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
      />

      {/* 14. Anger Reset Protocol Modal */}
      <AngerResetModal
        isOpen={isAngerResetOpen}
        onClose={() => setIsAngerResetOpen(false)}
        darkMode={darkMode}
        soundEnabled={soundEnabled}
      />
      </div>
    </LanguageProvider>
  );
}
