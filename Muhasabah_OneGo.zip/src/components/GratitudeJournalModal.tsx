import React, { useState, useEffect } from 'react';
import {
  X,
  Heart,
  Plus,
  Trash2,
  Edit2,
  Check,
  Sparkles,
  Calendar,
  Filter,
  Eye,
} from 'lucide-react';
import { GratitudeRecord } from '../types';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface GratitudeJournalModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
  onGratitudeLogged?: () => void;
}

const INITIAL_GRATITUDE: GratitudeRecord[] = [
  {
    id: 'grat-1',
    date: new Date().toISOString().split('T')[0],
    category: 'Spiritual',
    text: 'ফজরের সালাত সময়মতো পড়ার তাওফিক ও অন্তরে পরম প্রশান্তি পাওয়ার জন্য আলহামদুলিল্লাহ।',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'grat-2',
    date: new Date().toISOString().split('T')[0],
    category: 'Health',
    text: 'শারীরিক সুস্থতা ও পরিবারের সকলকে নিরাপদে রাখার জন্য মহান আল্লাহর দরবারে শুকরিয়া।',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'grat-3',
    date: new Date().toISOString().split('T')[0],
    category: 'Sustenance',
    text: 'টেবিলে হালাল খাবারের ব্যবস্থা ও বরকতময় রিজিকের জন্য আলহামদুলিল্লাহ।',
    createdAt: new Date().toISOString(),
  },
];

const CATEGORIES: GratitudeRecord['category'][] = [
  'Spiritual',
  'Health',
  'Family',
  'Sustenance',
  'Trial Averted',
  'Peace',
];

const CATEGORY_BN: Record<GratitudeRecord['category'], string> = {
  'Spiritual': 'ইমান ও হিদায়াত',
  'Health': 'সুস্থতা ও শক্তি',
  'Family': 'পরিবার ও প্রিয়জন',
  'Sustenance': 'হালাল রিজিক',
  'Trial Averted': 'বিপদ থেকে রক্ষা',
  'Peace': 'মনের প্রশান্তি',
};

export const GratitudeJournalModal: React.FC<GratitudeJournalModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
  onGratitudeLogged,
}) => {
  const [entries, setEntries] = useState<GratitudeRecord[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_gratitude_entries');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_GRATITUDE;
  });

  const todayStr = new Date().toISOString().split('T')[0];
  const [text, setText] = useState('');
  const [category, setCategory] = useState<GratitudeRecord['category']>('Spiritual');
  const [date, setDate] = useState(todayStr);

  // Filters
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');
  const [selectedDateFilter, setSelectedDateFilter] = useState<'All' | 'Today' | 'Custom'>('All');
  const [customFilterDate, setCustomFilterDate] = useState<string>(todayStr);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_gratitude_entries', JSON.stringify(entries));
    } catch {
      // ignore
    }
  }, [entries]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      showToast('অনুগ্রহ করে আল্লাহর নিয়ামতের শুকরিয়া লিখে সংরক্ষণ করুন');
      return;
    }

    playNotificationTone(soundEnabled);

    if (editingId) {
      setEntries((prev) =>
        prev.map((item) =>
          item.id === editingId
            ? {
                ...item,
                text: text.trim(),
                category,
                date,
              }
            : item
        )
      );
      setEditingId(null);
      showToast('শুকরিয়ার এন্ট্রি আপডেট করা হয়েছে!');
    } else {
      // Multiple entries per day supported with unique timestamp IDs
      const newItem: GratitudeRecord = {
        id: 'grat-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
        date,
        text: text.trim(),
        category,
        createdAt: new Date().toISOString(),
      };
      setEntries((prev) => [newItem, ...prev]);
      showToast('আলহামদুলিল্লাহ! নিয়ামতের শুকরিয়া লিপিবদ্ধ হয়েছে');
      if (onGratitudeLogged) {
        onGratitudeLogged();
      }
    }

    setText('');
  };

  const handleDelete = (id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
    setDeleteConfirmId(null);
    showToast('শুকরিয়ার এন্ট্রি মুছে ফেলা হয়েছে');
  };

  const handleEdit = (item: GratitudeRecord) => {
    setEditingId(item.id);
    setText(item.text);
    setCategory(item.category);
    setDate(item.date);
  };

  // Multi-criteria filtering
  const filteredEntries = entries.filter((e) => {
    // Category check
    if (selectedCategoryFilter !== 'All' && e.category !== selectedCategoryFilter) {
      return false;
    }
    // Date check
    if (selectedDateFilter === 'Today' && e.date !== todayStr) {
      return false;
    }
    if (selectedDateFilter === 'Custom' && e.date !== customFilterDate) {
      return false;
    }
    return true;
  });

  const todayEntriesCount = entries.filter((e) => e.date === todayStr).length;

  return (
    <div
      id="modal-gratitude-journal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-xl rounded-[28px] border shadow-2xl flex flex-col max-h-[94vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-black shadow-xs">
              <Heart className="w-5 h-5 fill-amber-500/20" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Gratitude Journal</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-500 border border-amber-500/30">
                  শুকরিয়া • আলহামদুলিল্লাহ
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                &ldquo;যদি তোমরা কৃতজ্ঞতা স্বীকার করো, তবে আমি অবশ্যই তোমাদের বাড়িয়ে দেব&rdquo; (সূরা ইবরাহীম: ৭)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="p-2.5 bg-amber-600 text-white text-xs font-bold text-center animate-in fade-in">
            {toastMsg}
          </div>
        )}

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Daily Streak & Prompt Banner */}
          <div
            className={`p-3.5 rounded-2xl border flex items-center justify-between ${
              darkMode ? 'bg-[#12281E]/60 border-[#1E4332]' : 'bg-[#FFFBEB] border-amber-200'
            }`}
          >
            <div>
              <span className="text-xs font-black text-amber-600 dark:text-amber-400 block">
                আজকের শুকরিয়ার সংখ্যা (Daily Shukr)
              </span>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                প্রতিদিন অন্তত ৩টি সুনির্দিষ্ট নিয়ামতের কথা স্মরণ করুন।
              </p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-amber-500">{todayEntriesCount}</span>
              <span className="text-[10px] text-stone-400 block font-bold">আজ লিপিবদ্ধ</span>
            </div>
          </div>

          {/* Form Input */}
          <form
            onSubmit={handleSave}
            className={`p-4 rounded-2xl border space-y-3 ${
              darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-stone-700 dark:text-stone-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{editingId ? 'শুকরিয়া সম্পাদনা করুন' : 'আমি আল্লাহর প্রতি কৃতজ্ঞ যে... (আলহামদুলিল্লাহ)'}</span>
              </span>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`text-xs px-2.5 py-1 rounded-xl border font-semibold ${
                  darkMode
                    ? 'bg-[#163324] border-[#224C38] text-stone-200'
                    : 'bg-stone-50 border-stone-200 text-stone-800'
                }`}
              />
            </div>

            {/* Category selection */}
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                    category === cat
                      ? 'bg-amber-500 text-stone-950 shadow-xs font-black'
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {CATEGORY_BN[cat]}
                </button>
              ))}
            </div>

            <textarea
              rows={2}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="যেমন: সুস্থভাবে ফজরের নামাজে দাঁড়ানোর তাওফিক, মায়ের মুখে হাসি, কঠিন সংকট থেকে মুক্তি..."
              className={`w-full p-3 rounded-xl border text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden ${
                darkMode
                  ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                  : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
              }`}
            />

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-98 text-stone-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{editingId ? 'আপডেট করুন' : 'লিপিবদ্ধ করুন (Log Shukr)'}</span>
            </button>
          </form>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            {/* Date filter pills */}
            <div className="flex items-center gap-1">
              <span className="text-[11px] font-bold text-stone-400 mr-1">তারিখ:</span>
              <button
                onClick={() => setSelectedDateFilter('All')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedDateFilter === 'All'
                    ? 'bg-amber-500 text-stone-950 shadow-xs'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-500'
                }`}
              >
                সকল
              </button>
              <button
                onClick={() => setSelectedDateFilter('Today')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedDateFilter === 'Today'
                    ? 'bg-amber-500 text-stone-950 shadow-xs'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-500'
                }`}
              >
                আজকে ({todayEntriesCount})
              </button>
              <button
                onClick={() => setSelectedDateFilter('Custom')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedDateFilter === 'Custom'
                    ? 'bg-amber-500 text-stone-950 shadow-xs'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-500'
                }`}
              >
                নির্দিষ্ট তারিখ
              </button>
              {selectedDateFilter === 'Custom' && (
                <input
                  type="date"
                  value={customFilterDate}
                  onChange={(e) => setCustomFilterDate(e.target.value)}
                  className="text-xs px-2 py-0.5 rounded-lg border ml-1 font-medium"
                />
              )}
            </div>

            {/* Category filter dropdown */}
            <div className="flex items-center gap-1">
              <select
                value={selectedCategoryFilter}
                onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border ${
                  darkMode ? 'bg-[#142D21] border-[#1F4432] text-stone-200' : 'bg-white border-stone-200'
                }`}
              >
                <option value="All">সকল বিভাগ</option>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {CATEGORY_BN[c]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Past Gratitude Logs */}
          <div className="space-y-2 pt-1">
            <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
              শুকরিয়ার ইতিহাস ({filteredEntries.length})
            </h4>

            {filteredEntries.length === 0 ? (
              <div className="text-center py-6 border border-dashed rounded-2xl border-stone-200 dark:border-stone-800">
                <Heart className="w-6 h-6 mx-auto mb-1 text-stone-400" />
                <p className="text-xs text-stone-400">
                  নির্বাচিত ফিল্টারে কোনো শুকরিয়ার রেকর্ড পাওয়া যায়নি।
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredEntries.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border flex flex-col gap-1.5 transition-all ${
                      darkMode ? 'bg-[#12281E]/60 border-[#1E4332]' : 'bg-white border-stone-200 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                          {CATEGORY_BN[item.category] || item.category}
                        </span>
                        <span className="text-[10px] text-stone-400 font-semibold">{item.date}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleEdit(item)}
                          className="p-1 text-stone-400 hover:text-amber-500 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {deleteConfirmId === item.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleDelete(item.id)}
                              className="px-2 py-0.5 rounded text-[10px] font-black bg-rose-600 text-white"
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-1.5 py-0.5 rounded text-[10px] text-stone-400"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(item.id)}
                            className="p-1 text-stone-400 hover:text-rose-500 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-stone-800 dark:text-stone-200 font-medium leading-relaxed">
                      &ldquo;{item.text}&rdquo;
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
