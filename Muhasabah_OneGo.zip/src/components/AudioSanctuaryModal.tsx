import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Volume1,
  Play,
  Pause,
  Square,
  CloudRain,
  Wind,
  Waves,
  Bird,
  Sparkles,
  RotateCcw,
  Headphones,
  Upload,
  Trash2,
  Music,
  FolderPlus,
  AlertCircle,
  FileAudio,
} from 'lucide-react';
import {
  startAmbientSound,
  stopAmbientSound,
  isAmbientPlaying,
  getCurrentAmbientType,
  playDhikrClick,
} from '../utils/audio';
import {
  UserAudioTrack,
  getAllUserAudios,
  saveUserAudio,
  deleteUserAudio,
} from '../utils/audioStorage';

interface AudioSanctuaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

type SoundType = 'rain' | 'wind' | 'stream' | 'birds';

interface AmbientOption {
  id: SoundType;
  title: string;
  titleBn: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
}

const AMBIENT_OPTIONS: AmbientOption[] = [
  {
    id: 'rain',
    title: 'Gentle Rain',
    titleBn: 'শান্ত বারিধারা',
    desc: 'Calming rain drops washing away worldly fatigue.',
    icon: CloudRain,
  },
  {
    id: 'wind',
    title: 'Desert Breeze',
    titleBn: 'মরু সমীরণ',
    desc: 'Gentle warm wind evoking stillness and solitude.',
    icon: Wind,
  },
  {
    id: 'stream',
    title: 'Flowing Stream',
    titleBn: 'পাহাড়ি ঝরনাধারা',
    desc: 'Continuous crystal water murmur encouraging deep reflection.',
    icon: Waves,
  },
  {
    id: 'birds',
    title: 'Dawn Birds',
    titleBn: 'ভোরের পাখির কলতান',
    desc: 'Sweet morning birds praising their Creator before sunrise.',
    icon: Bird,
  },
];

function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

export const AudioSanctuaryModal: React.FC<AudioSanctuaryModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [activeTab, setActiveTab] = useState<'ambient' | 'personal'>('ambient');

  // Ambient sound state
  const [activeSound, setActiveSound] = useState<SoundType | null>(() => {
    return (getCurrentAmbientType() as SoundType) || null;
  });
  const [isAmbPlaying, setIsAmbPlaying] = useState<boolean>(isAmbientPlaying());
  const [dhikrCount, setDhikrCount] = useState<number>(0);

  // Personal library state
  const [personalTracks, setPersonalTracks] = useState<UserAudioTrack[]>([]);
  const [activePersonalTrack, setActivePersonalTrack] = useState<UserAudioTrack | null>(null);
  const [personalAudioUrl, setPersonalAudioUrl] = useState<string | null>(null);
  const [isPersonalPlaying, setIsPersonalPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [audioPlaybackError, setAudioPlaybackError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [customAudioName, setCustomAudioName] = useState<string>('');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load user audios on open
  useEffect(() => {
    if (isOpen) {
      setIsAmbPlaying(isAmbientPlaying());
      setActiveSound((getCurrentAmbientType() as SoundType) || null);
      loadTracks();
    }
  }, [isOpen]);

  const loadTracks = async () => {
    try {
      const tracks = await getAllUserAudios();
      setPersonalTracks(tracks);
    } catch (e) {
      console.warn('Failed to load user audios', e);
    }
  };

  // Revoke previous object URL on change
  useEffect(() => {
    return () => {
      if (personalAudioUrl) {
        URL.revokeObjectURL(personalAudioUrl);
      }
    };
  }, [personalAudioUrl]);

  if (!isOpen) return null;

  // Ambient sound toggles
  const handleToggleSound = (type: SoundType) => {
    // If personal audio is playing, pause it to prevent clash
    if (audioRef.current && !audioRef.current.paused) {
      audioRef.current.pause();
      setIsPersonalPlaying(false);
    }

    if (activeSound === type && isAmbPlaying) {
      stopAmbientSound();
      setIsAmbPlaying(false);
      setActiveSound(null);
    } else {
      startAmbientSound(type);
      setActiveSound(type);
      setIsAmbPlaying(true);
    }
  };

  const handleStopAmbient = () => {
    stopAmbientSound();
    setIsAmbPlaying(false);
    setActiveSound(null);
  };

  const handleTasbihTap = () => {
    playDhikrClick(soundEnabled);
    setDhikrCount((prev) => prev + 1);
  };

  // Personal Track Playback
  const handleSelectTrack = (track: UserAudioTrack) => {
    // Stop ambient sound
    if (isAmbPlaying) {
      handleStopAmbient();
    }

    if (activePersonalTrack?.id === track.id && audioRef.current) {
      if (isPersonalPlaying) {
        audioRef.current.pause();
        setIsPersonalPlaying(false);
      } else {
        audioRef.current.play().catch(console.warn);
        setIsPersonalPlaying(true);
      }
      return;
    }

    // New track
    if (personalAudioUrl) {
      URL.revokeObjectURL(personalAudioUrl);
    }
    const url = URL.createObjectURL(track.blob);
    setPersonalAudioUrl(url);
    setActivePersonalTrack(track);
    setCurrentTime(0);

    setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.src = url;
        audioRef.current.volume = isMuted ? 0 : volume;
        audioRef.current.play().then(() => {
          setIsPersonalPlaying(true);
        }).catch((err) => {
          console.warn('Playback error', err);
          setIsPersonalPlaying(false);
        });
      }
    }, 50);
  };

  const handleTogglePlayPause = () => {
    if (!audioRef.current || !activePersonalTrack) return;
    if (isPersonalPlaying) {
      audioRef.current.pause();
      setIsPersonalPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => {
          setIsPersonalPlaying(true);
          setAudioPlaybackError(null);
        })
        .catch((err) => {
          console.warn('Playback error', err);
          setIsPersonalPlaying(false);
          setAudioPlaybackError('This audio is currently unavailable.');
        });
    }
  };

  const handleStopPersonalAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsPersonalPlaying(false);
    setCurrentTime(0);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
    setCurrentTime(targetTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    setIsMuted(newVol === 0);
    if (audioRef.current) {
      audioRef.current.volume = newVol;
    }
  };

  const handleToggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.volume = volume || 0.5;
      setIsMuted(false);
    } else {
      audioRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  // Upload handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: 50MB
    if (file.size > 50 * 1024 * 1024) {
      setUploadError('ফাইল সাইজ ৫০ মেগাবাইটের চেয়ে কম হতে হবে।');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      const trackName = customAudioName.trim() || file.name.replace(/\.[^/.]+$/, '');
      const savedTrack = await saveUserAudio(trackName, file);
      setPersonalTracks((prev) => [savedTrack, ...prev]);
      setCustomAudioName('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: unknown) {
      console.error('Storage error', err);
      const msg = err instanceof Error ? err.message : 'ফাইল সংরক্ষণ করতে সমস্যা হয়েছে।';
      setUploadError(msg);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteTrack = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (activePersonalTrack?.id === id) {
      handleStopPersonalAudio();
      setActivePersonalTrack(null);
      if (personalAudioUrl) {
        URL.revokeObjectURL(personalAudioUrl);
        setPersonalAudioUrl(null);
      }
    }
    try {
      await deleteUserAudio(id);
      setPersonalTracks((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      console.warn('Failed to delete track', err);
    }
  };

  return (
    <div
      id="modal-audio-sanctuary"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        onTimeUpdate={() => {
          if (audioRef.current) {
            setCurrentTime(audioRef.current.currentTime);
          }
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) {
            setDuration(audioRef.current.duration);
          }
        }}
        onEnded={() => {
          setIsPersonalPlaying(false);
          setCurrentTime(0);
        }}
        onError={() => {
          setIsPersonalPlaying(false);
          setAudioPlaybackError('This audio is currently unavailable.');
        }}
      />

      <div
        className={`w-full max-w-xl rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-500 flex items-center justify-center font-black shadow-xs">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight">Audio Sanctuary</h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  অডিও প্রশান্তি
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                Ambient nature peace &amp; personal Islamic audio library
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 dark:border-[#1E4332] px-4 pt-2 gap-2 bg-stone-50/50 dark:bg-[#12281E]/40">
          <button
            onClick={() => setActiveTab('ambient')}
            className={`pb-2.5 px-3 text-xs font-black transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'ambient'
                ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400'
                : 'border-transparent text-stone-400 hover:text-stone-700 dark:hover:text-stone-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>প্রকৃতি ও সুর (Ambient Peace)</span>
          </button>
          <button
            onClick={() => setActiveTab('personal')}
            className={`pb-2.5 px-3 text-xs font-black transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'personal'
                ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400'
                : 'border-transparent text-stone-400 hover:text-stone-700 dark:hover:text-stone-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>ব্যক্তিগত অডিও লাইব্রেরি (Personal Library)</span>
            {personalTracks.length > 0 && (
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300">
                {personalTracks.length}
              </span>
            )}
          </button>
        </div>

        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* TAB 1: AMBIENT PEACE */}
          {activeTab === 'ambient' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Ambient Grid */}
              <div className="grid grid-cols-2 gap-3">
                {AMBIENT_OPTIONS.map((opt) => {
                  const Icon = opt.icon;
                  const isThisActive = activeSound === opt.id && isAmbPlaying;

                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleToggleSound(opt.id)}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between min-h-[110px] transition-all duration-200 active:scale-98 cursor-pointer ${
                        isThisActive
                          ? 'bg-cyan-500/15 border-cyan-500/50 shadow-md ring-2 ring-cyan-500/30'
                          : darkMode
                          ? 'bg-[#12281E]/60 border-[#1E4332] hover:border-cyan-500/30'
                          : 'bg-stone-50 border-stone-200 hover:border-cyan-500/30'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                            isThisActive
                              ? 'bg-cyan-500 text-white animate-pulse'
                              : 'bg-stone-200 dark:bg-stone-800 text-stone-500'
                          }`}
                        >
                          <Icon className="w-5 h-5" />
                        </div>

                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isThisActive
                              ? 'bg-cyan-500 text-white'
                              : 'bg-stone-200 dark:bg-stone-800 text-stone-400'
                          }`}
                        >
                          {isThisActive ? 'Playing' : 'Play'}
                        </span>
                      </div>

                      <div>
                        <h4 className="text-xs font-black text-stone-900 dark:text-stone-100 mt-2">
                          {opt.title}
                        </h4>
                        <p className="text-[10px] text-cyan-600 dark:text-cyan-400 font-semibold">
                          {opt.titleBn}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Master Ambient Status */}
              {isAmbPlaying && (
                <div
                  className={`p-3.5 rounded-2xl border flex items-center justify-between animate-in fade-in ${
                    darkMode ? 'bg-[#142D21] border-cyan-500/30' : 'bg-cyan-50 border-cyan-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Volume2 className="w-5 h-5 text-cyan-500 animate-pulse" />
                    <div>
                      <span className="text-xs font-black text-cyan-700 dark:text-cyan-300 block">
                        Now Playing Ambient Stream
                      </span>
                      <p className="text-[10px] text-stone-400">Continuous soothing background loop</p>
                    </div>
                  </div>

                  <button
                    onClick={handleStopAmbient}
                    className="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-500 border border-rose-500/30 text-xs font-bold hover:bg-rose-500 hover:text-white transition-all cursor-pointer"
                  >
                    Stop Sound
                  </button>
                </div>
              )}

              {/* In-Sanctuary Digital Tasbih */}
              <div
                className={`p-4 rounded-2xl border text-center space-y-2 ${
                  darkMode ? 'bg-[#12281E]/40 border-[#1E4332]' : 'bg-white border-stone-200'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-stone-400 font-bold">
                  <span>Sanctuary Dhikr Counter</span>
                  <button
                    onClick={() => setDhikrCount(0)}
                    className="hover:text-rose-400 transition-colors cursor-pointer"
                    title="Reset"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={handleTasbihTap}
                  className="w-full py-5 rounded-2xl bg-gradient-to-b from-emerald-600/10 to-teal-600/20 hover:from-emerald-600/20 active:scale-98 border border-emerald-500/20 transition-all flex flex-col items-center justify-center cursor-pointer select-none"
                >
                  <span className="text-4xl font-black text-emerald-500 dark:text-[#D4AF37]">
                    {dhikrCount}
                  </span>
                  <span className="text-[11px] font-bold text-stone-400 mt-1">
                    Tap anywhere to count SubhanAllah / Alhamdulillah / Allahu Akbar
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: PERSONAL AUDIO LIBRARY */}
          {activeTab === 'personal' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Upload Card */}
              <div
                className={`p-4 rounded-2xl border ${
                  darkMode ? 'bg-[#12281E]/60 border-[#1E4332]' : 'bg-stone-50 border-stone-200'
                }`}
              >
                <div className="flex items-center gap-2 mb-2 text-xs font-black text-stone-800 dark:text-stone-200">
                  <FolderPlus className="w-4 h-4 text-cyan-500" />
                  <span>নিজের অডিও যোগ করুন (Upload Audio)</span>
                </div>
                <p className="text-[11px] text-stone-400 mb-3">
                  তিলাওয়াত, আযান, দুআ বা নসীহত অডিও ফাইল (.mp3, .wav, .m4a, .ogg) যুক্ত করে ডিভাইসে নিরাপদে সংরক্ষণ করুন।
                </p>

                <div className="space-y-2">
                  <input
                    type="text"
                    value={customAudioName}
                    onChange={(e) => setCustomAudioName(e.target.value)}
                    placeholder="অডিওর শিরোনাম বা বর্ণনা (ঐচ্ছিক)"
                    className={`w-full px-3 py-2 rounded-xl text-xs border font-medium ${
                      darkMode
                        ? 'bg-[#0F241A] border-[#1C3E2D] text-stone-100 placeholder-stone-500'
                        : 'bg-white border-stone-200 text-stone-900 placeholder-stone-400'
                    }`}
                  />

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="audio/*,.mp3,.wav,.m4a,.ogg,.aac"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="audio-file-upload-input"
                  />

                  <label
                    htmlFor="audio-file-upload-input"
                    className="w-full py-2.5 px-4 rounded-xl border border-dashed border-cyan-500/50 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{isUploading ? 'সংরক্ষণ হচ্ছে...' : 'ডিভাইস থেকে অডিও নির্বাচন করুন (Choose File)'}</span>
                  </label>
                </div>

                {uploadError && (
                  <div className="mt-2.5 p-2 rounded-xl bg-rose-500/10 text-rose-500 border border-rose-500/20 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{uploadError}</span>
                  </div>
                )}
              </div>

              {/* Active Audio Player (if a track is selected) */}
              {activePersonalTrack && (
                <div
                  className={`p-4 rounded-2xl border space-y-3 shadow-md ${
                    darkMode
                      ? 'bg-gradient-to-br from-[#12281E] to-[#173827] border-cyan-500/40'
                      : 'bg-gradient-to-br from-cyan-50 to-emerald-50 border-cyan-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-cyan-500 text-white flex items-center justify-center shrink-0">
                        <FileAudio className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-black truncate text-stone-900 dark:text-stone-100">
                          {activePersonalTrack.name}
                        </h4>
                        <span className="text-[10px] text-stone-400 truncate block">
                          {activePersonalTrack.fileName}
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-600 dark:text-cyan-300">
                      {isPersonalPlaying ? 'চলছে' : 'স্থগিত'}
                    </span>
                  </div>

                  {audioPlaybackError && (
                    <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 dark:text-rose-400 text-xs font-bold flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{audioPlaybackError}</span>
                    </div>
                  )}

                  {/* Scrubber / Seek bar */}
                  <div className="space-y-1">
                    <input
                      type="range"
                      min={0}
                      max={duration || 100}
                      step={0.1}
                      value={currentTime}
                      onChange={handleSeek}
                      className="w-full accent-cyan-500 cursor-pointer h-1.5 bg-stone-200 dark:bg-stone-700 rounded-lg"
                    />
                    <div className="flex justify-between text-[10px] text-stone-400 font-mono">
                      <span>{formatTime(currentTime)}</span>
                      <span>{formatTime(duration)}</span>
                    </div>
                  </div>

                  {/* Control buttons */}
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleTogglePlayPause}
                        className="w-10 h-10 rounded-full bg-cyan-500 text-white flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer"
                        title={isPersonalPlaying ? 'Pause' : 'Play'}
                      >
                        {isPersonalPlaying ? (
                          <Pause className="w-5 h-5 fill-white" />
                        ) : (
                          <Play className="w-5 h-5 fill-white ml-0.5" />
                        )}
                      </button>

                      <button
                        onClick={handleStopPersonalAudio}
                        className="w-8 h-8 rounded-full bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-300 flex items-center justify-center hover:bg-rose-500 hover:text-white transition-all cursor-pointer"
                        title="Stop"
                      >
                        <Square className="w-3.5 h-3.5 fill-current" />
                      </button>
                    </div>

                    {/* Volume Slider */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleToggleMute}
                        className="text-stone-400 hover:text-cyan-500 transition-colors cursor-pointer"
                        title={isMuted ? 'Unmute' : 'Mute'}
                      >
                        {isMuted ? (
                          <VolumeX className="w-4 h-4 text-rose-400" />
                        ) : volume > 0.5 ? (
                          <Volume2 className="w-4 h-4" />
                        ) : (
                          <Volume1 className="w-4 h-4" />
                        )}
                      </button>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={isMuted ? 0 : volume}
                        onChange={handleVolumeChange}
                        className="w-16 sm:w-24 accent-cyan-500 cursor-pointer h-1 bg-stone-200 dark:bg-stone-700 rounded-lg"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Uploaded Audio List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-black text-stone-700 dark:text-stone-300 px-1">
                  <span>সংরক্ষিত অডিও তালিকা ({personalTracks.length})</span>
                </div>

                {personalTracks.length === 0 ? (
                  <div
                    className={`p-6 rounded-2xl border text-center ${
                      darkMode ? 'bg-[#12281E]/30 border-[#1E4332]' : 'bg-stone-50 border-stone-200'
                    }`}
                  >
                    <Music className="w-8 h-8 text-stone-400 mx-auto mb-2 opacity-50" />
                    <p className="text-xs font-bold text-stone-500 dark:text-stone-400">
                      কোনো ব্যক্তিগত অডিও যুক্ত করা হয়নি।
                    </p>
                    <p className="text-[10px] text-stone-400 mt-1">
                      উপরের বাটন থেকে আপনার প্রিয় তিলাওয়াত বা দুআ ফাইল আপলোড করুন।
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[220px] overflow-y-auto">
                    {personalTracks.map((track) => {
                      const isThisActive = activePersonalTrack?.id === track.id;
                      const isThisPlaying = isThisActive && isPersonalPlaying;

                      return (
                        <div
                          key={track.id}
                          onClick={() => handleSelectTrack(track)}
                          className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                            isThisActive
                              ? 'border-cyan-500 bg-cyan-500/10 font-bold shadow-xs'
                              : darkMode
                              ? 'bg-[#142D21]/60 border-[#1E4332] hover:border-cyan-500/40'
                              : 'bg-white border-stone-200 hover:border-cyan-500/40'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <button
                              type="button"
                              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                                isThisPlaying
                                  ? 'bg-cyan-500 text-white animate-pulse'
                                  : 'bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-300'
                              }`}
                            >
                              {isThisPlaying ? (
                                <Pause className="w-4 h-4 fill-white" />
                              ) : (
                                <Play className="w-4 h-4 fill-current ml-0.5" />
                              )}
                            </button>
                            <div className="min-w-0">
                              <h5 className="text-xs truncate text-stone-900 dark:text-stone-100">
                                {track.name}
                              </h5>
                              <span className="text-[9px] text-stone-400">
                                {(track.fileSize / (1024 * 1024)).toFixed(1)} MB •{' '}
                                {new Date(track.dateAdded).toLocaleDateString()}
                              </span>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => handleDeleteTrack(track.id, e)}
                            className="p-1.5 text-stone-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                            title="Delete this audio"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
