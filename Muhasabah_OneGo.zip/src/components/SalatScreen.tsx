import React, { useState, useEffect } from 'react';
import {
  Clock,
  CheckCircle2,
  Circle,
  RotateCw,
  Bell,
  BellOff,
  MapPin,
  Sliders,
  Sparkles,
  Compass,
  Sun,
  Sunrise,
  CloudSun,
  Sunset,
  Moon,
  ShieldAlert,
  AlertTriangle,
  Plus,
  Minus,
  Users,
  Check,
  Calendar,
  Layers,
  ChevronRight,
  Info,
} from 'lucide-react';
import { PrayerItem, LocationConfig } from '../types';
import { playNotificationTone, playDhikrClick } from '../utils/audio';
import { useLanguage } from '../utils/i18n';
import {
  calculateQibla,
  getProhibitedTimes,
  getNawafilPrayers,
  getCurrentMakruhStatus,
  getActivePrayerId,
  getHijriDate,
  timeStringToMinutes,
  minutesToTimeString,
} from '../utils/qibla';
import { QiblaCompassModal } from './QiblaCompassModal';

interface SalatScreenProps {
  darkMode: boolean;
  soundEnabled: boolean;
  prayers: PrayerItem[];
  location: LocationConfig;
  onTogglePrayer: (id: string) => void;
  onToggleJamaah: (id: string) => void;
  onOpenOffsetModal: () => void;
  onOpenLocationModal: () => void;
  onAdjustOffset?: (prayerId: string, deltaMinutes: number) => void;
  onUpdateLocation?: () => void;
  isUpdatingLocation?: boolean;
}

const PRAYER_DISPLAY_NAMES: Record<
  string,
  {
    en: string;
    bn: string;
    arabic: string;
    rakats: string;
  }
> = {
  fajr: {
    en: 'Fajr',
    bn: 'ফজর',
    arabic: 'الفجر',
    rakats: '২ সুন্নত + ২ ফরজ',
  },
  dhuhr: {
    en: 'Dhuhr',
    bn: 'যোহর',
    arabic: 'الظهر',
    rakats: '৪ সুন্নত + ৪ ফরজ + ২ সুন্নত + ২ নফল',
  },
  asr: {
    en: 'Asr',
    bn: 'আসর',
    arabic: 'العصر',
    rakats: '৪ সুন্নত + ৪ ফরজ',
  },
  maghrib: {
    en: 'Maghrib',
    bn: 'মাগরিব',
    arabic: 'المغرب',
    rakats: '৩ ফরজ + ২ সুন্নত + ২ নফল',
  },
  isha: {
    en: 'Isha',
    bn: 'এশা',
    arabic: 'العشاء',
    rakats: '৪ ফরজ + ২ সুন্নত + ২ নফল + ৩ বিতর',
  },
};

const JumuahModeCard: React.FC<{ darkMode: boolean; jumuahTime?: string }> = ({ darkMode, jumuahTime }) => {
  const d = new Date();
  const isFriday = d.getDay() === 5;
  const today = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const key = `muhasabah_jumuah_checklist_${today}`;
  const items = [
    ['kahf', '📖 সূরা আল-কাহফ'], ['darood', 'ﷺ বেশি বেশি দরুদ'],
    ['ghusl', '🚿 গোসল ও পরিচ্ছন্নতা'], ['early', '🕌 আগে মসজিদে যাওয়ার প্রস্তুতি'],
    ['khutbah', '🎧 খুতবা মনোযোগ দিয়ে শোনা'],
  ] as const;
  const [checked, setChecked] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem(key) || '{}'); } catch { return {}; }
  });
  const toggle = (id: string) => {
    const next = { ...checked, [id]: !checked[id] }; setChecked(next);
    localStorage.setItem(key, JSON.stringify(next));
  };
  const done = items.filter(([id]) => checked[id]).length;
  return <div className={`mt-4 rounded-[24px] border p-4 ${darkMode ? 'bg-[#102A1E] border-[#D4AF37]/30' : 'bg-amber-50/70 border-amber-200'}`}>
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-2"><div className="w-9 h-9 rounded-xl bg-[#D4AF37]/15 flex items-center justify-center"><Moon className="w-5 h-5 text-[#D4AF37]" /></div><div><h3 className={`text-sm font-black ${darkMode ? 'text-stone-100' : 'text-[#1B4332]'}`}>🕌 Jumu'ah Mode</h3><p className="text-[10px] text-stone-400">{isFriday ? 'আজ শুক্রবার — বিশেষ প্রস্তুতি' : 'শুক্রবারে বিশেষভাবে সক্রিয় হবে'}</p></div></div>
      <span className="text-[10px] font-black text-[#D4AF37]">{isFriday ? `${done}/${items.length}` : 'শুক্রবার'}</span>
    </div>
    <div className="mt-3 grid grid-cols-1 gap-1.5">
      <div className="flex items-center justify-between rounded-xl px-3 py-2 bg-black/10 text-xs font-bold"><span>🕐 জুমুআর সময়</span><span className="text-[#D4AF37]">{jumuahTime || '—'}</span></div>
      {items.map(([id, label]) => <button key={id} onClick={() => toggle(id)} className={`flex items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-bold bg-black/5 dark:bg-white/5 ${!isFriday ? 'opacity-55 cursor-default' : 'cursor-pointer'}`} disabled={!isFriday}><span className={`w-4 h-4 rounded-full border flex items-center justify-center ${checked[id] ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-stone-400'}`}>{checked[id] ? '✓' : ''}</span><span>{label}</span></button>)}
    </div>
  </div>;
};

export const SalatScreen: React.FC<SalatScreenProps> = ({
  darkMode,
  soundEnabled,
  prayers,
  location,
  onTogglePrayer,
  onToggleJamaah,
  onOpenOffsetModal,
  onOpenLocationModal,
  onAdjustOffset,
  onUpdateLocation,
  isUpdatingLocation = false,
}) => {
  const { language, t } = useLanguage();
  const [azanAlertEnabled, setAzanAlertEnabled] = useState(true);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [showQiblaModal, setShowQiblaModal] = useState(false);
  const [salatView, setSalatView] = useState<'salat' | 'jumuah'>('salat');

  // Nawafil state
  const [nawafilDone, setNawafilDone] = useState<{ [id: string]: boolean }>({
    tahajjud: false,
    ishraq: false,
    chasht: false,
    awwabin: false,
  });

  // Calculate live countdown to next prayer & Makruh status
  const [countdown, setCountdown] = useState<string>('00:00:00');
  const [makruhStatus, setMakruhStatus] = useState(getCurrentMakruhStatus());
  const [activePrayerId, setActivePrayerId] = useState(getActivePrayerId(prayers));

  const qiblaAngle = calculateQibla(location.latitude, location.longitude);
  const completedCount = prayers.filter((p) => p.completed).length;

  // Strict chronological order: Fajr -> Dhuhr -> Asr -> Maghrib -> Isha
  const prayerOrder = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const orderedPrayers = prayerOrder
    .map((id) => prayers.find((p) => p.id === id))
    .filter((p): p is PrayerItem => Boolean(p));

  const activePrayer =
    orderedPrayers.find((p) => p.id === activePrayerId) || orderedPrayers[0];

  const currentPrayerIndex = orderedPrayers.findIndex((p) => p.id === activePrayer.id);
  const nextPrayerIndex =
    currentPrayerIndex >= 0 ? (currentPrayerIndex + 1) % orderedPrayers.length : 0;
  const nextPrayer = orderedPrayers[nextPrayerIndex] || orderedPrayers[0];

  // Live timer ticker for active prayer and high-precision countdown
  useEffect(() => {
    const updateTimes = () => {
      const now = new Date();
      setMakruhStatus(getCurrentMakruhStatus(now));
      setActivePrayerId(getActivePrayerId(prayers, now));

      // Calculate countdown to next prayer start time
      const currentSeconds =
        now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
      const nextStartMinutes = timeStringToMinutes(
        nextPrayer.startTime || nextPrayer.time
      );
      let targetSeconds = nextStartMinutes * 60;

      // Wrap if target is on next calendar day (e.g., Isha to Fajr)
      if (targetSeconds <= currentSeconds) {
        targetSeconds += 24 * 3600;
      }

      const diffSec = Math.max(0, targetSeconds - currentSeconds);
      const hr = Math.floor(diffSec / 3600);
      const min = Math.floor((diffSec % 3600) / 60);
      const sec = diffSec % 60;

      setCountdown(
        `${hr < 10 ? '0' : ''}${hr}:${min < 10 ? '0' : ''}${min}:${
          sec < 10 ? '0' : ''
        }${sec}`
      );
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, [prayers, nextPrayer]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleToggleAzan = () => {
    const next = !azanAlertEnabled;
    setAzanAlertEnabled(next);
    playNotificationTone(soundEnabled);
    showToast(next ? 'Azan Sound Alerts Enabled' : 'Azan Alerts Muted');
  };

  const handleQuickOffset = (prayerId: string, delta: number) => {
    if (onAdjustOffset) {
      onAdjustOffset(prayerId, delta);
      playDhikrClick(soundEnabled);
      showToast(`Centralized offset adjusted ${delta > 0 ? '+1' : '-1'}m`);
    } else {
      onOpenOffsetModal();
    }
  };

  // Helper to determine exact prayer status: Active Now | Completed | Expired/Missed | Upcoming
  const getPrayerStatus = (
    prayer: PrayerItem
  ): {
    statusKey: 'active' | 'completed' | 'missed' | 'upcoming';
    labelEn: string;
    labelBn: string;
  } => {
    if (prayer.completed) {
      return {
        statusKey: 'completed',
        labelEn: 'COMPLETED',
        labelBn: 'সম্পন্ন',
      };
    }
    if (prayer.id === activePrayerId) {
      return {
        statusKey: 'active',
        labelEn: 'ACTIVE NOW',
        labelBn: 'চলমান ওয়াক্ত',
      };
    }

    const now = new Date();
    const currentMin = now.getHours() * 60 + now.getMinutes();
    const startMin = timeStringToMinutes(prayer.startTime || prayer.time);
    const endMin = timeStringToMinutes(prayer.endTime || prayer.time);

    // Special handling for overnight Isha
    if (prayer.id === 'isha') {
      // Isha starts around 7:20 PM and ends at sunrise/fajr (around 4:30 AM)
      if (currentMin >= startMin || currentMin < endMin) {
        return {
          statusKey: 'active',
          labelEn: 'ACTIVE NOW',
          labelBn: 'চলমান ওয়াক্ত',
        };
      }
      return {
        statusKey: 'upcoming',
        labelEn: 'UPCOMING',
        labelBn: 'আসন্ন',
      };
    }

    if (currentMin > endMin) {
      return {
        statusKey: 'missed',
        labelEn: 'EXPIRED / MISSED',
        labelBn: 'ওয়াক্ত শেষ / কাজা',
      };
    }

    return {
      statusKey: 'upcoming',
      labelEn: 'UPCOMING',
      labelBn: 'আসন্ন',
    };
  };

  const getPrayerIcon = (id: string, isActive: boolean) => {
    const baseClass = 'w-7 h-7 shrink-0';
    switch (id) {
      case 'fajr':
        return <Sunrise className={`${baseClass} text-amber-300`} />;
      case 'dhuhr':
        return <Sun className={`${baseClass} text-yellow-300`} />;
      case 'asr':
        return <CloudSun className={`${baseClass} text-emerald-300`} />;
      case 'maghrib':
        return <Sunset className={`${baseClass} text-orange-300`} />;
      case 'isha':
        return <Moon className={`${baseClass} text-teal-300`} />;
      default:
        return <Clock className={`${baseClass} text-emerald-300`} />;
    }
  };

  return (
    <div
      id="screen-salat-tracker"
      className="min-h-screen bg-[#070D0B] text-stone-100 p-3 sm:p-5 max-w-4xl mx-auto space-y-6 pb-28"
    >
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-full text-xs font-black text-stone-950 bg-[#D4AF37] border border-white/60 shadow-2xl flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 fill-stone-950" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* ============================================================ */}
      {/* MASTER HEADER: Clean, Spacious, High-Contrast Dark Theme    */}
      {/* ============================================================ */}
      <header
        id="salat-master-dashboard-header"
        className="rounded-[28px] p-6 sm:p-7 relative overflow-hidden shadow-2xl border border-[#1E4333] bg-gradient-to-br from-[#122B20] via-[#0E2119] to-[#081510] text-white"
      >
        {/* Subtle Ambient Emerald Glow */}
        <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full bg-emerald-500/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-56 h-56 rounded-full bg-[#D4AF37]/10 blur-3xl pointer-events-none" />

        {/* Top Header Row: Location, Hijri Date, Controls */}
        <div className="flex items-center justify-between gap-3 flex-wrap relative z-10 pb-5 border-b border-white/10">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Location Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-black/40 text-emerald-200 border border-emerald-500/30 backdrop-blur-md">
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>
                {location.name}, {location.country}
              </span>
            </div>

            {/* Hijri Date */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-black/40 text-[#F5E6B3] border border-[#D4AF37]/30 backdrop-blur-md">
              <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{getHijriDate(new Date()).fullText}</span>
            </div>
          </div>

          {/* Quick Header Actions: Compass, Azan, Offsets */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Qibla Compass Trigger */}
            <button
              id="btn-open-qibla-compass"
              onClick={() => setShowQiblaModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-black/40 hover:bg-black/60 border border-[#D4AF37]/50 text-white text-xs font-bold transition-all active:scale-95 shadow-sm"
              title="Open Holy Qibla Compass"
            >
              <Compass
                className="w-4 h-4 text-[#D4AF37]"
                style={{ transform: `rotate(${qiblaAngle}deg)` }}
              />
              <span>
                Qibla <span className="text-[#F4E0A5]">{qiblaAngle}°</span>
              </span>
            </button>

            {/* Azan Alert Sound Toggle */}
            <button
              id="btn-salat-azan-toggle"
              onClick={handleToggleAzan}
              className={`p-2 rounded-xl transition-all active:scale-95 border ${
                azanAlertEnabled
                  ? 'bg-[#D4AF37] text-stone-950 border-white/40'
                  : 'bg-black/40 text-stone-400 border-white/10'
              }`}
              title={azanAlertEnabled ? 'Azan Sound Enabled' : 'Azan Sound Muted'}
            >
              {azanAlertEnabled ? (
                <Bell className="w-4 h-4 fill-stone-950 stroke-stone-950" />
              ) : (
                <BellOff className="w-4 h-4 text-stone-400" />
              )}
            </button>

            {/* Centralized Offset Modal Trigger */}
            <button
              id="btn-salat-offsets"
              onClick={onOpenOffsetModal}
              className="p-2 rounded-xl bg-black/40 hover:bg-black/60 text-[#F5E6B3] border border-[#D4AF37]/40 transition-all active:scale-95"
              title="Global Prayer Offset Manager"
            >
              <Sliders className="w-4 h-4 text-[#D4AF37]" />
            </button>
          </div>
        </div>

        {/* Makruh Period Warning Banner (if active) */}
        {makruhStatus.isMakruh && (
          <div
            id="salat-makruh-warning-banner"
            className="mt-4 p-4 rounded-2xl bg-rose-950/80 border border-rose-400/80 text-white relative z-10 shadow-lg"
          >
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-6 h-6 text-rose-300 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white">
                    {language === 'bn' ? 'মাকরূহ ওয়াক্ত' : 'Makruh Waqt'}
                  </span>
                  <h3 className="font-black text-sm text-rose-100">
                    {language === 'bn' ? 'সালাতের নিষিদ্ধ সময়' : 'Prohibited Prayer Period'}
                  </h3>
                </div>
                <div className="text-xs font-bold text-rose-200 mt-1">
                  {makruhStatus.name} • {language === 'bn' ? 'ওয়াক্ত সীমা:' : 'Time:'} {makruhStatus.timeRange}
                </div>
                <p className="text-xs text-rose-100/90 mt-1 leading-relaxed">
                  {makruhStatus.reason} {language === 'bn' ? 'এই সময়ে যেকোনো ফরজ, ওয়াজিব কিংবা নফল নামাজ নিষিদ্ধ।' : 'All obligatory, wajib, and voluntary prayers are strictly prohibited during this time.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Main Header Information: Current Waqt & Next Prayer */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-5 relative z-10 items-center">
          {/* Left Column: Current Waqt */}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-[11px] font-black tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/60 inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                {language === 'bn' ? 'বর্তমান ওয়াক্ত' : 'CURRENT WAQT'}
              </span>
            </div>

            <div className="flex items-baseline gap-3 pt-1">
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white font-mono">
                {language === 'bn' ? (PRAYER_DISPLAY_NAMES[activePrayer.id]?.bn || activePrayer.name) : (PRAYER_DISPLAY_NAMES[activePrayer.id]?.en || activePrayer.name)}
              </h1>
              <span className="text-2xl font-arabic text-[#D4AF37] font-bold">
                {activePrayer.arabic}
              </span>
            </div>

            <div className="flex items-baseline gap-2 pt-1">
              <span className="text-2xl sm:text-3xl font-black font-mono text-[#F4E0A5] tracking-tight">
                {activePrayer.time}
              </span>
              <span className="text-xs text-stone-300 font-medium">
                ({language === 'bn' ? 'ওয়াক্ত' : 'Waqt'}: {activePrayer.startTime} – {activePrayer.endTime})
              </span>
            </div>
          </div>

          {/* Right Column: Next Prayer, Countdown, Completed Count */}
          <div className="grid grid-cols-2 gap-3 bg-black/35 rounded-2xl p-4 border border-white/10">
            {/* Next Prayer Box */}
            <div className="space-y-1">
              <span className="text-[11px] uppercase tracking-wider font-extrabold text-stone-400 block">
                {language === 'bn' ? 'পরবর্তী ওয়াক্ত' : 'Next Prayer'}
              </span>
              <div className="font-extrabold text-base text-white flex items-center gap-1.5">
                <span>{language === 'bn' ? (PRAYER_DISPLAY_NAMES[nextPrayer.id]?.bn || nextPrayer.name) : (PRAYER_DISPLAY_NAMES[nextPrayer.id]?.en || nextPrayer.name)}</span>
                <span className="text-xs text-[#D4AF37] font-arabic">
                  {nextPrayer.arabic}
                </span>
              </div>
              <div className="text-xs font-mono font-bold text-emerald-300">
                {nextPrayer.startTime || nextPrayer.time}
              </div>
            </div>

            {/* Countdown Box */}
            <div className="space-y-1 text-right">
              <span className="text-[11px] uppercase tracking-wider font-extrabold text-stone-400 block">
                {language === 'bn' ? 'কাউন্টডাউন' : 'Countdown'}
              </span>
              <div className="font-black text-xl font-mono text-[#D4AF37] tracking-tight">
                {countdown}
              </div>
              <span className="text-[10px] text-stone-400 font-medium">
                {language === 'bn' ? 'পরবর্তী ওয়াক্ত পর্যন্ত' : 'Until next prayer'}
              </span>
            </div>

            {/* Completed Prayers Bar */}
            <div className="col-span-2 pt-2 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs text-stone-300 font-medium">
                {language === 'bn' ? 'আজকের আদায়কৃত সালাত:' : "Today's Completed Salat:"}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-emerald-400 font-mono">
                  {completedCount} / 5 {language === 'bn' ? 'টি সম্পন্ন' : 'Completed'}
                </span>
                <div className="w-16 h-2 rounded-full bg-white/15 overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 transition-all duration-300"
                    style={{ width: `${(completedCount / 5) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Location GPS and City Switch Sub-row */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-stone-300 flex-wrap gap-2 relative z-10">
          <span>
            Lat: {location.latitude.toFixed(4)}° • Long: {location.longitude.toFixed(4)}°
          </span>
          <div className="flex items-center gap-2">
            {onUpdateLocation && (
              <button
                id="btn-salat-gps-update"
                onClick={onUpdateLocation}
                disabled={isUpdatingLocation}
                className="flex items-center gap-1 px-3 py-1 rounded-xl bg-black/40 hover:bg-black/60 border border-emerald-400/40 text-emerald-200 text-xs font-semibold transition-all active:scale-95"
              >
                <RotateCw
                  className={`w-3.5 h-3.5 ${isUpdatingLocation ? 'animate-spin' : ''}`}
                />
                <span>
                  {isUpdatingLocation
                    ? language === 'bn'
                      ? 'আপডেট হচ্ছে...'
                      : 'Updating...'
                    : language === 'bn'
                    ? 'জিপিএস অটো-সিঙ্ক'
                    : 'GPS Auto-Sync'}
                </span>
              </button>
            )}

            <button
              onClick={onOpenLocationModal}
              className="px-3 py-1 rounded-xl bg-black/30 hover:bg-black/50 border border-white/15 text-stone-300 text-xs font-semibold transition-all active:scale-95"
            >
              {language === 'bn' ? 'শহর পরিবর্তন' : 'Change City'}
            </button>
          </div>
        </div>
      </header>

      {/* Salat / Jumu'ah side-by-side tab, like the Calendar secondary tools. */}
      <div className="sticky top-0 z-20 -mx-1 px-1 py-1">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar rounded-2xl bg-[#0E2119] border border-[#1E4333] p-1">
          <button
            onClick={() => setSalatView('salat')}
            className={`shrink-0 flex-1 min-w-[130px] rounded-xl px-4 py-2 text-xs font-black transition-all ${salatView === 'salat' ? 'bg-[#D4AF37] text-stone-950 shadow-sm' : 'text-stone-300 bg-white/5'}`}
          >🕌 {language === 'bn' ? 'সালাত' : 'Salat'}</button>
          <button
            onClick={() => setSalatView('jumuah')}
            className={`shrink-0 flex-1 min-w-[130px] rounded-xl px-4 py-2 text-xs font-black transition-all ${salatView === 'jumuah' ? 'bg-[#D4AF37] text-stone-950 shadow-sm' : 'text-stone-300 bg-white/5'}`}
          >🕌 {language === 'bn' ? 'জুমা' : "Jumu'ah"}</button>
        </div>
      </div>

      {salatView === 'jumuah' ? (
        <JumuahModeCard darkMode={darkMode} jumuahTime={prayers.find((p) => p.id === 'dhuhr')?.time} />
      ) : (
        <>
      {/* ============================================================ */}
      {/* 5 OBLIGATORY PRAYER CARDS: Large, Full Width, Dark Islamic  */}
      {/* Order: Fajr -> Dhuhr -> Asr -> Maghrib -> Isha               */}
      {/* ============================================================ */}
      <section className="space-y-5">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <div className="w-2 h-5 rounded-full bg-emerald-400" />
            <h2 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
              <span>{language === 'bn' ? '৫ ওয়াক্ত সালাত' : '5 Daily Obligatory Prayers'}</span>
            </h2>
          </div>
          <span className="text-xs font-mono font-bold text-[#D4AF37]">
            {completedCount}/5 {language === 'bn' ? 'সম্পন্ন' : 'COMPLETED'}
          </span>
        </div>

        {orderedPrayers.map((prayer) => {
          const details = PRAYER_DISPLAY_NAMES[prayer.id] || {
            en: prayer.name,
            bn: prayer.name,
            arabic: prayer.arabic,
            rakats: 'ফরজ ও সুন্নত',
          };
          const status = getPrayerStatus(prayer);
          const isActive = status.statusKey === 'active';
          const isCompleted = prayer.completed;

          return (
            <article
              key={prayer.id}
              id={`prayer-card-${prayer.id}`}
              className={`w-full rounded-[26px] p-5 sm:p-6 transition-all duration-200 relative overflow-hidden ${
                isActive
                  ? 'bg-gradient-to-br from-[#16382A] via-[#102D21] to-[#0B1E16] border-2 border-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.25)]'
                  : isCompleted
                  ? 'bg-gradient-to-br from-[#0E1F18] via-[#0A1712] to-[#07110D] border border-emerald-900/60 shadow-lg'
                  : 'bg-gradient-to-br from-[#0F1E18] via-[#0B1712] to-[#070F0B] border border-[#1C382B] shadow-lg'
              } before:absolute before:left-0 before:top-4 before:bottom-4 before:w-1.5 before:rounded-r-full ${
                isActive
                  ? 'before:bg-gradient-to-b before:from-emerald-300 before:to-teal-400 before:shadow-[0_0_12px_rgba(52,211,153,0.9)]'
                  : isCompleted
                  ? 'before:bg-emerald-600'
                  : 'before:bg-gradient-to-b before:from-emerald-500 before:to-teal-600'
              }`}
            >
              {/* TOP ROW: Icon + Prayer Name + Large Prayer Time + Status Badge */}
              <div className="flex items-center justify-between gap-3 flex-wrap">
                {/* Left: Icon + Name */}
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 shrink-0">
                    {getPrayerIcon(prayer.id, isActive)}
                  </div>

                  <div>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                        {language === 'bn' ? details.bn : details.en}
                      </h3>
                      <span className="text-lg font-arabic font-bold text-[#D4AF37]">
                        {details.arabic}
                      </span>
                    </div>
                    <div className="text-xs text-stone-300 font-medium mt-0.5">
                      {details.rakats}
                    </div>
                  </div>
                </div>

                {/* Right: Large Prayer Time & Status Badge */}
                <div className="flex items-center gap-3 ml-auto">
                  {/* Status Badge */}
                  <div className="text-right">
                    {isActive && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-500/25 text-emerald-300 border border-emerald-400 shadow-xs">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        {language === 'bn' ? 'ওয়াক্ত চলছে' : 'ACTIVE NOW'}
                      </span>
                    )}
                    {isCompleted && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-950/60 text-emerald-400 border border-emerald-500/40">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        {language === 'bn' ? 'সম্পন্ন' : 'COMPLETED'}
                      </span>
                    )}
                    {status.statusKey === 'missed' && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-rose-950/50 text-rose-300 border border-rose-800/50">
                        {language === 'bn' ? 'ওয়াক্ত শেষ' : 'EXPIRED'}
                      </span>
                    )}
                    {status.statusKey === 'upcoming' && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-black/40 text-stone-300 border border-stone-700/60">
                        {language === 'bn' ? 'আসন্ন' : 'UPCOMING'}
                      </span>
                    )}
                  </div>

                  {/* Large High-Contrast Prayer Time */}
                  <div
                    className={`text-2xl sm:text-3xl font-black font-mono tracking-tight ${
                      isActive ? 'text-emerald-300' : 'text-[#F4E0A5]'
                    }`}
                  >
                    {prayer.time}
                  </div>
                </div>
              </div>

              {/* MIDDLE ROW: 3 Equal Rounded Information Boxes */}
              {/* Prayer Time | Waqt Start | Waqt End */}
              <div className="mt-5 grid grid-cols-3 gap-2.5 sm:gap-3">
                {/* Box 1: Prayer Time */}
                <div className="p-3 sm:p-3.5 rounded-2xl bg-black/40 border border-white/10 text-center flex flex-col justify-center">
                  <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider">
                    {language === 'bn' ? 'সালাতের সময়' : 'Prayer Time'}
                  </span>
                  <div
                    className={`text-base sm:text-xl font-black font-mono mt-1.5 ${
                      isActive ? 'text-emerald-300' : 'text-white'
                    }`}
                  >
                    {prayer.time}
                  </div>
                </div>

                {/* Box 2: Waqt Start */}
                <div className="p-3 sm:p-3.5 rounded-2xl bg-black/40 border border-white/10 text-center flex flex-col justify-center">
                  <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider">
                    {language === 'bn' ? 'ওয়াক্ত শুরু' : 'Waqt Start'}
                  </span>
                  <div className="text-base sm:text-xl font-black font-mono text-white mt-1.5">
                    {prayer.startTime || prayer.time}
                  </div>
                </div>

                {/* Box 3: Waqt End */}
                <div className="p-3 sm:p-3.5 rounded-2xl bg-black/40 border border-white/10 text-center flex flex-col justify-center">
                  <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider">
                    {language === 'bn' ? 'ওয়াক্ত শেষ' : 'Waqt End'}
                  </span>
                  <div className="text-base sm:text-xl font-black font-mono text-stone-200 mt-1.5">
                    {prayer.endTime || '—'}
                  </div>
                </div>
              </div>

              {/* BOTTOM ROW: Centralized Time Adjustment Controls + Jama'ah + Completion Toggle */}
              <div className="mt-4 pt-3.5 border-t border-white/10 flex items-center justify-between gap-3 flex-wrap">
                {/* Centralized Time Adjustment: [ - ] 0m [ + ] */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-stone-300">
                    {language === 'bn' ? 'সময় সমন্বয়:' : 'Time Offset:'}
                  </span>
                  <div className="flex items-center bg-black/40 rounded-xl p-1 border border-white/15">
                    <button
                      id={`btn-offset-minus-${prayer.id}`}
                      onClick={() => handleQuickOffset(prayer.id, -1)}
                      className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/15 active:scale-90 text-stone-200 transition-all cursor-pointer"
                      title={language === 'bn' ? '১ মিনিট কমান' : 'Decrease 1 min'}
                    >
                      <Minus className="w-4 h-4 font-black" />
                    </button>

                    <span className="min-w-[48px] text-center text-xs font-mono font-black px-1 text-[#D4AF37]">
                      {prayer.offsetMinutes && prayer.offsetMinutes > 0
                        ? `+${prayer.offsetMinutes}m`
                        : `${prayer.offsetMinutes || 0}m`}
                    </span>

                    <button
                      id={`btn-offset-plus-${prayer.id}`}
                      onClick={() => handleQuickOffset(prayer.id, 1)}
                      className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/15 active:scale-90 text-stone-200 transition-all cursor-pointer"
                      title={language === 'bn' ? '১ মিনিট বাড়ান' : 'Increase 1 min'}
                    >
                      <Plus className="w-4 h-4 font-black" />
                    </button>
                  </div>
                </div>

                {/* Right Action Buttons: Jama'ah and Mark Completed */}
                <div className="flex items-center gap-2.5 ml-auto">
                  {/* Jama'ah Congregation Button */}
                  <button
                    id={`btn-jamaah-${prayer.id}`}
                    onClick={() => {
                      onToggleJamaah(prayer.id);
                      playDhikrClick(soundEnabled);
                      showToast(
                        prayer.jamaah
                          ? (language === 'bn' ? `${details.bn}-এর জামা'আত ট্যাগ মুছে ফেলা হয়েছে` : `Removed Jama'ah tag for ${prayer.name}`)
                          : (language === 'bn' ? `আলহামদুলিল্লাহ! ${details.bn}-এর জামা'আত যুক্ত হয়েছে` : `Alhamdulillah! Jama'ah logged for ${prayer.name}`)
                      );
                    }}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all active:scale-95 cursor-pointer ${
                      prayer.jamaah
                        ? 'bg-emerald-600/30 border-emerald-400 text-emerald-300'
                        : 'bg-black/30 border-white/15 text-stone-400 hover:text-stone-200'
                    }`}
                    title={prayer.jamaah ? (language === 'bn' ? "জামা'আত রেকর্ড করা আছে" : "Jama'ah logged") : (language === 'bn' ? "জামা'আত রেকর্ড করুন" : "Log Jama'ah")}
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? "জামা'আত" : "Jama'ah"}</span>
                  </button>

                  {/* Completion Toggle Button */}
                  <button
                    id={`btn-toggle-prayer-${prayer.id}`}
                    onClick={() => {
                      onTogglePrayer(prayer.id);
                      playDhikrClick(soundEnabled);
                      showToast(
                        prayer.completed
                          ? (language === 'bn' ? `${details.bn} অসম্পূর্ণ চিহ্নিত করা হয়েছে` : `Marked ${prayer.name} incomplete`)
                          : (language === 'bn' ? `আলহামদুলিল্লাহ! ${details.bn} সালাত আদায় সম্পন্ন!` : `Alhamdulillah! Completed ${prayer.name} prayer.`)
                      );
                    }}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all active:scale-95 cursor-pointer border ${
                      isCompleted
                        ? 'bg-[#10B981] border-[#34D399] text-stone-950 shadow-md'
                        : 'bg-white/10 hover:bg-white/20 border-white/20 text-white'
                    }`}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-stone-950" />
                        <span>{language === 'bn' ? 'সম্পন্ন ✓' : 'Completed ✓'}</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-4 h-4 text-stone-300" />
                        <span>{language === 'bn' ? 'সালাত আদায় করেছি' : 'Mark as Prayed'}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </section>

      {/* ============================================================ */}
      {/* NAWAFIL & VOLUNTARY PRAYERS: Same Premium Dark Card Styling   */}
      {/* Tahajjud, Ishraq, Chasht, Awwabin                            */}
      {/* ============================================================ */}
      <section className="space-y-4 pt-4">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <div className="w-2 h-5 rounded-full bg-[#D4AF37]" />
            <h2 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
              <span>{language === 'bn' ? 'নফল ও সুন্নত সালাত' : 'Nawafil & Voluntary Prayers'}</span>
            </h2>
          </div>
          <span className="text-xs text-[#D4AF37] font-semibold">
            {language === 'bn' ? 'তাহাজ্জুদ • ইশরাক • চাশত • আউওয়াবীন' : 'Tahajjud • Ishraq • Chasht • Awwabin'}
          </span>
        </div>

        {getNawafilPrayers().map((nawafil) => {
          const isDone = nawafilDone[nawafil.id];

          return (
            <article
              key={nawafil.id}
              className={`w-full rounded-[26px] p-5 sm:p-6 transition-all duration-200 relative overflow-hidden bg-gradient-to-br from-[#0F1E18] via-[#0B1712] to-[#070F0B] border ${
                isDone ? 'border-emerald-500/70' : 'border-[#1C382B]'
              } shadow-lg before:absolute before:left-0 before:top-4 before:bottom-4 before:w-1.5 before:rounded-r-full before:bg-gradient-to-b before:from-[#D4AF37] before:to-emerald-500`}
            >
              {/* Top Row: Icon + Name + Time Range */}
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-black/40 border border-white/10 shrink-0">
                    <Moon className="w-6 h-6 text-[#D4AF37]" />
                  </div>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-xl font-black text-white tracking-tight">
                        {language === 'bn' ? nawafil.nameBn : nawafil.name}
                      </h3>
                    </div>
                    <div className="text-xs text-emerald-300 font-mono mt-0.5">
                      {language === 'bn' ? 'ওয়াক্ত:' : 'Waqt:'} {nawafil.timeRange}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setNawafilDone((prev) => ({
                      ...prev,
                      [nawafil.id]: !prev[nawafil.id],
                    }));
                    playDhikrClick(soundEnabled);
                    showToast(
                      isDone
                        ? (language === 'bn' ? `${nawafil.nameBn} অসম্পূর্ণ চিহ্নিত করা হয়েছে` : `Marked ${nawafil.name} incomplete`)
                        : (language === 'bn' ? `আলহামদুলিল্লাহ! ${nawafil.nameBn} আদায় সম্পন্ন!` : `Alhamdulillah! Completed ${nawafil.name}.`)
                    );
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all active:scale-95 cursor-pointer border ${
                    isDone
                      ? 'bg-[#10B981] border-[#34D399] text-stone-950 shadow-md'
                      : 'bg-white/10 hover:bg-white/20 border-white/20 text-white'
                  }`}
                >
                  {isDone ? (language === 'bn' ? 'সম্পন্ন ✓' : 'Completed ✓') : (language === 'bn' ? 'আদায় করেছি' : 'Mark Done')}
                </button>
              </div>

              {/* 3 Information Boxes: Preferred Time | Rakats | Description */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-center">
                <div className="p-3 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
                    {language === 'bn' ? 'উত্তম সময়' : 'Preferred Time'}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#F4E0A5] mt-1 block">
                    {nawafil.timeRange}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
                    {language === 'bn' ? 'রাকাত সংখ্যা' : 'Rakats'}
                  </span>
                  <span className="text-xs font-bold text-white mt-1 block">
                    {nawafil.rakats}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-black/40 border border-white/10 text-left sm:text-center">
                  <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
                    {language === 'bn' ? 'ফজিলত ও মর্যাদা' : 'Virtue & Merit'}
                  </span>
                  <span className="text-xs text-stone-300 line-clamp-2 mt-0.5 block">
                    {nawafil.description}
                  </span>
                </div>
              </div>
            </article>
          );
        })}
      </section>

      {/* ============================================================ */}
      {/* PROHIBITED & MAKRUH TIMES REFERENCE                          */}
      {/* ============================================================ */}
      <section className="space-y-3 pt-3">
        <div className="flex items-center gap-2 px-2">
          <div className="w-2 h-5 rounded-full bg-rose-500" />
          <h2 className="text-lg font-black text-rose-300 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <span>{language === 'bn' ? 'সালাতের ৩টি নিষিদ্ধ ওয়াক্ত' : '3 Prohibited Prayer Times'}</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {getProhibitedTimes().map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-rose-950/30 border border-rose-900/50 text-stone-200"
            >
              <div className="text-sm font-black text-rose-200">
                {language === 'bn' ? item.nameBn : item.name}
              </div>
              <div className="text-xs font-mono font-bold text-rose-400 mt-1">
                {item.timeRange}
              </div>
              <p className="text-xs text-stone-300 mt-1.5 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </section>

        </>
      )}

      {/* Qibla Compass Modal */}
      {showQiblaModal && (
        <QiblaCompassModal
          isOpen={showQiblaModal}
          onClose={() => setShowQiblaModal(false)}
          darkMode={darkMode}
          location={location}
          onOpenLocationModal={onOpenLocationModal}
          onUpdateLocation={onUpdateLocation}
          isUpdatingLocation={isUpdatingLocation}
        />
      )}
    </div>
  );
};
