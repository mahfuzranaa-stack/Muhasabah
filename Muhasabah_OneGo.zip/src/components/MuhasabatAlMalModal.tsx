import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Award,
  Calendar,
  Tag,
  Search,
  Check,
  PiggyBank,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  AlertCircle,
  HeartHandshake,
  EyeOff,
  Eye,
  Edit2,
} from 'lucide-react';
import { ExpenseRecord, SadaqahItem } from '../types';
import { INITIAL_SADAQAH } from '../data/islamicFeaturesData';

interface MuhasabatAlMalModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  finances: ExpenseRecord[];
  onAddRecord: (record: Omit<ExpenseRecord, 'id'>) => void;
  onDeleteRecord: (id: string) => void;
  isScreenMode?: boolean;
}

// Savings Categories
const SAVE_CATEGORIES = [
  'Salary / Earnings',
  'Business Profit',
  'Halal Investment',
  'Gift / Hadya',
  'Pocket Money',
  'Sadaqah Saved',
  'Emergency Fund',
  'Other Savings',
];

// Expense Categories
const EXPENSE_CATEGORIES = [
  'Food & Groceries',
  'Transport',
  'Family & Household',
  'Utility Bills',
  'Health & Medicine',
  'Education & Books',
  'Charity / Sadaqah',
  'Shopping',
  'Other Expense',
];

// Level thresholds based on Net Savings (৳ BDT)
export interface SavingsLevel {
  level: number;
  title: string;
  titleBn: string;
  minSavings: number;
  maxSavings: number;
  color: string;
  badge: string;
  description: string;
}

export const SAVINGS_LEVELS: SavingsLevel[] = [
  {
    level: 0,
    title: 'Mubtadi',
    titleBn: 'মুসতাদি (সূচনাকারী)',
    minSavings: 0,
    maxSavings: 1000,
    color: '#94A3B8',
    badge: '🌱 Level 0',
    description: 'Save ৳1,000 net to unlock Level 1 (Muqtisid).',
  },
  {
    level: 1,
    title: 'Muqtisid',
    titleBn: 'মুকতাসিদ (মিতব্যয়ী)',
    minSavings: 1000,
    maxSavings: 5000,
    color: '#52B788',
    badge: '🥉 Level 1',
    description: 'Prudent saver building initial financial discipline.',
  },
  {
    level: 2,
    title: 'Muktasib',
    titleBn: 'মুকতাসিব (পরিশ্রমী সঞ্চয়ী)',
    minSavings: 5000,
    maxSavings: 15000,
    color: '#2D6A4F',
    badge: '🥈 Level 2',
    description: 'Disciplined halal wealth accumulator.',
  },
  {
    level: 3,
    title: 'Munfiq',
    titleBn: 'মুনফিক (উদার সেবক)',
    minSavings: 15000,
    maxSavings: 50000,
    color: '#D4AF37',
    badge: '🥇 Level 3',
    description: 'Substantial savings enabling generous charity and peace of mind.',
  },
  {
    level: 4,
    title: 'Ameen',
    titleBn: 'আমিন (সম্পদের বিশ্বস্ত অভিভাবক)',
    minSavings: 50000,
    maxSavings: 100000,
    color: '#8B5CF6',
    badge: '💎 Level 4',
    description: 'High financial security following Islamic wealth principles.',
  },
  {
    level: 5,
    title: 'Mutawakkil',
    titleBn: 'মুতাওয়াক্কিল (সর্বোচ্চ স্তর)',
    minSavings: 100000,
    maxSavings: Infinity,
    color: '#EAB308',
    badge: '👑 Level 5+',
    description: 'Exemplary halal savings milestone with sustained barakah.',
  },
];

export function getSavingsLevel(netSavings: number): {
  currentLevel: SavingsLevel;
  nextLevel: SavingsLevel | null;
  progressPercent: number;
} {
  const safeSavings = Math.max(0, netSavings);
  let currentLevel = SAVINGS_LEVELS[0];

  for (let i = SAVINGS_LEVELS.length - 1; i >= 0; i--) {
    if (safeSavings >= SAVINGS_LEVELS[i].minSavings) {
      currentLevel = SAVINGS_LEVELS[i];
      break;
    }
  }

  const nextLevel =
    currentLevel.level < SAVINGS_LEVELS.length - 1
      ? SAVINGS_LEVELS[currentLevel.level + 1]
      : null;

  let progressPercent = 100;
  if (nextLevel) {
    const range = nextLevel.minSavings - currentLevel.minSavings;
    const progress = safeSavings - currentLevel.minSavings;
    progressPercent = Math.min(100, Math.max(0, Math.round((progress / range) * 100)));
  }

  return { currentLevel, nextLevel, progressPercent };
}

export const MuhasabatAlMalModal: React.FC<MuhasabatAlMalModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  finances,
  onAddRecord,
  onDeleteRecord,
  isScreenMode = false,
}) => {
  // Tabs: 'overview' | 'save' | 'expense' | 'sadaqah' | 'ledger'
  const [activeTab, setActiveTab] = useState<'overview' | 'save' | 'expense' | 'sadaqah' | 'ledger'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form states
  const [amount, setAmount] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(SAVE_CATEGORIES[0]);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Sadaqah Log State (Persisted)
  const [sadaqahList, setSadaqahList] = useState<SadaqahItem[]>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_sadaqah_log');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_SADAQAH;
  });

  const [sadaqahFilter, setSadaqahFilter] = useState<string>('All');
  const [showAddSadaqahForm, setShowAddSadaqahForm] = useState<boolean>(false);
  const [editingSadaqahId, setEditingSadaqahId] = useState<string | null>(null);

  // Sadaqah Form fields
  const [sadTitle, setSadTitle] = useState('');
  const [sadAmount, setSadAmount] = useState('');
  const [sadDate, setSadDate] = useState(new Date().toISOString().split('T')[0]);
  const [sadCategory, setSadCategory] = useState<SadaqahItem['category']>('Secret');
  const [sadIsAnonymous, setSadIsAnonymous] = useState<boolean>(true);
  const [sadNotes, setSadNotes] = useState('');

  // Persist Sadaqah list
  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_sadaqah_log', JSON.stringify(sadaqahList));
    } catch {
      // ignore
    }
  }, [sadaqahList]);

  const handleSaveSadaqah = () => {
    const num = parseFloat(sadAmount);
    if (!sadTitle.trim() || isNaN(num) || num <= 0) {
      showToast('Please enter title and valid Sadaqah amount');
      return;
    }

    const catBnMap: Record<string, string> = {
      'Secret': 'গোপন সাদাকা',
      'Relatives': 'আত্মীয়স্বজন',
      'Poor & Needy': 'দরিদ্র ও মিসকিন',
      'Mosque & Madrasa': 'মসজিদ-মাদ্রাসা',
      'Water Well': 'কূপ খনন / পানি',
      'Emergency Aid': 'বিপদগ্রস্ত মানুষ / এতিম',
      'Other': 'অন্যান্য দান',
    };

    if (editingSadaqahId) {
      setSadaqahList((prev) =>
        prev.map((s) =>
          s.id === editingSadaqahId
            ? {
                ...s,
                title: sadTitle.trim(),
                amount: num,
                date: sadDate,
                category: sadCategory,
                categoryBn: catBnMap[sadCategory] || sadCategory,
                isAnonymous: sadIsAnonymous,
                notes: sadNotes.trim() || undefined,
              }
            : s
        )
      );
      showToast('Sadaqah entry updated successfully');
    } else {
      const newItem: SadaqahItem = {
        id: 'sad-' + Date.now(),
        title: sadTitle.trim(),
        amount: num,
        date: sadDate,
        category: sadCategory,
        categoryBn: catBnMap[sadCategory] || sadCategory,
        isAnonymous: sadIsAnonymous,
        notes: sadNotes.trim() || undefined,
      };
      setSadaqahList((prev) => [newItem, ...prev]);
      showToast('💖 Sadaqah recorded! May Allah accept your charity.');
    }

    // Reset form
    setShowAddSadaqahForm(false);
    setEditingSadaqahId(null);
    setSadTitle('');
    setSadAmount('');
    setSadNotes('');
  };

  const handleEditSadaqah = (item: SadaqahItem) => {
    setEditingSadaqahId(item.id);
    setSadTitle(item.title);
    setSadAmount(item.amount.toString());
    setSadDate(item.date);
    setSadCategory(item.category);
    setSadIsAnonymous(item.isAnonymous);
    setSadNotes(item.notes || '');
    setShowAddSadaqahForm(true);
  };

  const handleDeleteSadaqah = (id: string) => {
    if (window.confirm('Delete this Sadaqah entry?')) {
      setSadaqahList((prev) => prev.filter((s) => s.id !== id));
      showToast('Sadaqah entry deleted');
    }
  };

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  // Calculations
  const totalSaved = finances
    .filter((f) => f.type === 'save')
    .reduce((sum, f) => sum + f.amount, 0);

  const totalExpense = finances
    .filter((f) => f.type !== 'save') // default is expense
    .reduce((sum, f) => sum + f.amount, 0);

  const netSavings = totalSaved - totalExpense;
  const { currentLevel, nextLevel, progressPercent } = getSavingsLevel(netSavings);

  const handleSaveRecord = (type: 'save' | 'expense') => {
    const numAmount = parseFloat(amount);
    if (!title.trim() || isNaN(numAmount) || numAmount <= 0) {
      showToast('Please enter valid title and amount');
      return;
    }

    onAddRecord({
      type,
      title: title.trim(),
      amount: numAmount,
      category,
      date,
      note: note.trim() || undefined,
    });

    // Reset form
    setTitle('');
    setAmount('');
    setNote('');
    showToast(type === 'save' ? '✨ Halal Savings added! Level updated' : '💸 Expense recorded. Net balance updated');
    setActiveTab('overview');
  };

  const filteredFinances = finances.filter((f) => {
    const matchesSearch =
      f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.note && f.note.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSearch;
  });

  const modalCard = (
    <div
      className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col ${
        isScreenMode ? 'overflow-visible' : 'max-h-[92vh] overflow-hidden'
      } ${
        darkMode
          ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
          : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
      }`}
    >
      {/* Header */}
      <div
        className={`p-4 sm:p-5 border-b flex items-center justify-between ${
          darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center font-black shadow-xs">
            <PiggyBank className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black tracking-tight">Muhasabat al-Mal</h3>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">
                محاسبة المال
              </span>
            </div>
            <p className="text-xs text-stone-400 font-medium">
              Islamic Financial Self-Accounting &amp; Gamified Savings Level
            </p>
          </div>
        </div>
        {!isScreenMode && (
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

        {/* Sub-Navigation: Overview, Money Save, Expense, Sadaqah Log, Ledger */}
        <div
          className={`grid grid-cols-5 p-1.5 border-b text-center text-[11px] sm:text-xs font-black ${
            darkMode ? 'bg-[#0A1710] border-[#1A3729]' : 'bg-stone-100 border-stone-200'
          }`}
        >
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-2 px-0.5 sm:px-1 rounded-xl transition-all ${
              activeTab === 'overview'
                ? 'bg-[#1B4332] text-white shadow-xs'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => {
              setActiveTab('save');
              setCategory(SAVE_CATEGORIES[0]);
            }}
            className={`py-2 px-0.5 sm:px-1 rounded-xl transition-all flex items-center justify-center gap-0.5 ${
              activeTab === 'save'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-emerald-500 hover:text-emerald-400'
            }`}
          >
            <TrendingUp className="w-3 h-3 shrink-0" />
            <span className="truncate">Save</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('expense');
              setCategory(EXPENSE_CATEGORIES[0]);
            }}
            className={`py-2 px-0.5 sm:px-1 rounded-xl transition-all flex items-center justify-center gap-0.5 ${
              activeTab === 'expense'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-rose-500 hover:text-rose-400'
            }`}
          >
            <TrendingDown className="w-3 h-3 shrink-0" />
            <span className="truncate">Expense</span>
          </button>
          <button
            onClick={() => setActiveTab('sadaqah')}
            className={`py-2 px-0.5 sm:px-1 rounded-xl transition-all flex items-center justify-center gap-0.5 ${
              activeTab === 'sadaqah'
                ? 'bg-[#D4AF37] text-stone-950 shadow-xs'
                : 'text-amber-400 hover:text-amber-300'
            }`}
          >
            <HeartHandshake className="w-3 h-3 shrink-0" />
            <span className="truncate">Sadaqah</span>
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            className={`py-2 px-0.5 sm:px-1 rounded-xl transition-all ${
              activeTab === 'ledger'
                ? 'bg-[#1B4332] text-white shadow-xs'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            Ledger ({finances.length})
          </button>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 my-2 p-2 rounded-xl bg-emerald-600 text-white text-xs font-bold text-center shadow-md animate-bounce">
            {toastMsg}
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: OVERVIEW & LEVEL SYSTEM */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              {/* Gamified Level Card */}
              <div
                className={`rounded-2xl p-5 border relative overflow-hidden transition-all shadow-md ${
                  darkMode
                    ? 'bg-gradient-to-br from-[#12281E] to-[#1C3E2F] border-[#2A5641]'
                    : 'bg-gradient-to-br from-[#E8F5E9] via-white to-[#F4FAF5] border-emerald-900/10'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className="px-3 py-1 rounded-full text-xs font-black text-white shadow-xs"
                      style={{ backgroundColor: currentLevel.color }}
                    >
                      {currentLevel.badge}
                    </span>
                    <div>
                      <h4 className="text-sm font-black tracking-tight">{currentLevel.title}</h4>
                      <p className="text-[11px] text-stone-400">{currentLevel.titleBn}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">
                      Net Savings Balance
                    </span>
                    <span
                      className={`text-xl font-black ${
                        netSavings >= 0 ? 'text-emerald-500' : 'text-rose-500'
                      }`}
                    >
                      ৳ {netSavings.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Progress Bar towards Next Level */}
                {nextLevel ? (
                  <div className="space-y-1.5 pt-2 border-t border-emerald-900/10 dark:border-emerald-800/40">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-stone-400">Next: {nextLevel.badge} ({nextLevel.title})</span>
                      <span className="font-bold text-[#D4AF37]">
                        ৳ {Math.max(0, nextLevel.minSavings - netSavings).toLocaleString()} more needed ({progressPercent}%)
                      </span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-stone-200 dark:bg-black/30 overflow-hidden p-0.5">
                      <div
                        className="h-full rounded-full transition-all duration-500 bg-gradient-to-r from-emerald-500 to-[#D4AF37]"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="text-xs font-bold text-[#D4AF37] flex items-center gap-1.5 pt-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Maximum Savings Level Reached! MashaAllah.</span>
                  </div>
                )}

                <p className="text-xs text-stone-400 mt-2 italic">
                  💡 Note: Adding expenses dynamically reduces your net savings and adjusts your level accordingly!
                </p>
              </div>

              {/* 3 Metric Cards: Total Saved, Total Expense, Net Balance */}
              <div className="grid grid-cols-3 gap-2.5">
                <div
                  className={`p-3.5 rounded-2xl border text-center ${
                    darkMode ? 'bg-[#12281E] border-emerald-900/30' : 'bg-emerald-50 border-emerald-200'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-emerald-500 text-xs font-black mb-1">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>Total Saved</span>
                  </div>
                  <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                    ৳{totalSaved.toLocaleString()}
                  </span>
                </div>

                <div
                  className={`p-3.5 rounded-2xl border text-center ${
                    darkMode ? 'bg-[#12281E] border-rose-900/30' : 'bg-rose-50 border-rose-200'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-rose-500 text-xs font-black mb-1">
                    <ArrowDownRight className="w-3.5 h-3.5" />
                    <span>Total Spent</span>
                  </div>
                  <span className="text-base font-black text-rose-600 dark:text-rose-400">
                    ৳{totalExpense.toLocaleString()}
                  </span>
                </div>

                <div
                  className={`p-3.5 rounded-2xl border text-center ${
                    darkMode ? 'bg-[#12281E] border-[#D4AF37]/30' : 'bg-amber-50 border-amber-200'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-[#D4AF37] text-xs font-black mb-1">
                    <Wallet className="w-3.5 h-3.5" />
                    <span>Net Balance</span>
                  </div>
                  <span className="text-base font-black text-stone-900 dark:text-stone-100">
                    ৳{netSavings.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Quick Actions Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => {
                    setActiveTab('save');
                    setCategory(SAVE_CATEGORIES[0]);
                  }}
                  className="py-3 px-4 rounded-xl font-black text-xs text-white bg-emerald-600 hover:bg-emerald-500 flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>Deposit / Money Save</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab('expense');
                    setCategory(EXPENSE_CATEGORIES[0]);
                  }}
                  className="py-3 px-4 rounded-xl font-black text-xs text-white bg-rose-600 hover:bg-rose-500 flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>Add Expense</span>
                </button>
              </div>

              {/* Level Roadmap Preview */}
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
                  Savings Level Roadmap
                </h4>
                <div className="space-y-1.5">
                  {SAVINGS_LEVELS.map((lvl) => {
                    const isAchieved = netSavings >= lvl.minSavings;
                    const isCurrent = currentLevel.level === lvl.level;

                    return (
                      <div
                        key={lvl.level}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition-all ${
                          isCurrent
                            ? 'bg-[#1B4332] text-white border-[#D4AF37]'
                            : isAchieved
                            ? 'bg-emerald-950/20 border-emerald-900/30 text-stone-300'
                            : 'opacity-50 border-stone-800 text-stone-500'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-black">{lvl.badge}</span>
                          <div>
                            <span className="font-bold">{lvl.title}</span>
                            <span className="text-[10px] text-stone-400 ml-1.5">{lvl.titleBn}</span>
                          </div>
                        </div>
                        <span className="font-black text-[11px]">
                          ৳{lvl.minSavings.toLocaleString()} {lvl.maxSavings !== Infinity ? `- ৳${lvl.maxSavings.toLocaleString()}` : '+'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MONEY SAVE (INCOME / SAVINGS FORM) */}
          {activeTab === 'save' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveRecord('save');
              }}
              className="space-y-3.5"
            >
              <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
                <TrendingUp className="w-4 h-4 shrink-0" />
                <span>Halal savings directly boosts your Net Balance and Levels Up your status!</span>
              </div>

              <div>
                <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                  Savings Amount (৳ BDT) *
                </label>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 5000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className={`w-full px-4 py-3 rounded-xl border text-lg font-black focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-white border-stone-200 text-stone-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                  Title / Source *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Monthly Salary, Freelance project, Eid Gift"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-white border-stone-200 text-stone-900'
                  }`}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                      darkMode
                        ? 'bg-[#142D21] border-[#224A37] text-white'
                        : 'bg-white border-stone-200 text-stone-900'
                    }`}
                  >
                    {SAVE_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                      darkMode
                        ? 'bg-[#142D21] border-[#224A37] text-white'
                        : 'bg-white border-stone-200 text-stone-900'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                  Note / Intention (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Intending to use for Hajj savings or emergency fund"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className={`w-full px-4 py-2 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-white border-stone-200 text-stone-900'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl text-sm font-black text-white bg-emerald-600 hover:bg-emerald-500 active:scale-98 shadow-md transition-all flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Confirm &amp; Deposit Savings (+৳)</span>
              </button>
            </form>
          )}

          {/* TAB 3: EXPENSE FORM */}
          {activeTab === 'expense' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveRecord('expense');
              }}
              className="space-y-3.5"
            >
              <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>Mindful spending: expenses subtract from your net savings and may lower your Level.</span>
              </div>

              <div>
                <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                  Expense Amount (৳ BDT) *
                </label>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 750"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className={`w-full px-4 py-3 rounded-xl border text-lg font-black focus:outline-none focus:ring-2 focus:ring-rose-500 ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-white border-stone-200 text-stone-900'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                  Expense Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Grocery bazaar, CNG fare, Electricity bill"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-white border-stone-200 text-stone-900'
                  }`}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 ${
                      darkMode
                        ? 'bg-[#142D21] border-[#224A37] text-white'
                        : 'bg-white border-stone-200 text-stone-900'
                    }`}
                  >
                    {EXPENSE_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 ${
                      darkMode
                        ? 'bg-[#142D21] border-[#224A37] text-white'
                        : 'bg-white border-stone-200 text-stone-900'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-black text-stone-400 uppercase tracking-wider block mb-1">
                  Note (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Paid at Karwan Bazar"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className={`w-full px-4 py-2 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-white border-stone-200 text-stone-900'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl text-sm font-black text-white bg-rose-600 hover:bg-rose-500 active:scale-98 shadow-md transition-all flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Record Expense (-৳)</span>
              </button>
            </form>
          )}

          {/* TAB 4: SADAQAH LOG (সাদাকা ও গোপন দান ট্র্যাকার) */}
          {activeTab === 'sadaqah' && (
            <div className="space-y-4">
              {/* Sadaqah Header & Stats Banner */}
              <div
                className={`p-4 rounded-2xl border relative overflow-hidden ${
                  darkMode
                    ? 'bg-gradient-to-br from-[#12281E] to-[#0A1710] border-[#D4AF37]/30'
                    : 'bg-gradient-to-br from-amber-50 to-emerald-50 border-amber-200'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                      <HeartHandshake className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-stone-900 dark:text-stone-100">
                        Sadaqah Log (সাদাকা ও গোপন দান)
                      </h4>
                      <p className="text-[11px] text-stone-400 font-medium">
                        Track voluntary charity, secret giving &amp; water wells
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setEditingSadaqahId(null);
                      setSadTitle('');
                      setSadAmount('');
                      setSadDate(new Date().toISOString().split('T')[0]);
                      setSadCategory('Secret');
                      setSadIsAnonymous(true);
                      setSadNotes('');
                      setShowAddSadaqahForm(!showAddSadaqahForm);
                    }}
                    className="px-3 py-1.5 rounded-xl text-xs font-black bg-[#D4AF37] text-stone-950 hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddSadaqahForm ? 'Close' : 'Record Sadaqah'}</span>
                  </button>
                </div>

                {/* Stats Breakdown */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <div
                    className={`p-2.5 rounded-xl border ${
                      darkMode ? 'bg-[#152E22] border-[#224A37]' : 'bg-white border-amber-200/60'
                    }`}
                  >
                    <span className="text-[10px] font-bold text-stone-400 block uppercase">
                      Total Sadaqah
                    </span>
                    <span className="text-base font-black text-[#D4AF37]">
                      ৳{sadaqahList.reduce((acc, curr) => acc + curr.amount, 0).toLocaleString()}
                    </span>
                  </div>

                  <div
                    className={`p-2.5 rounded-xl border ${
                      darkMode ? 'bg-[#152E22] border-[#224A37]' : 'bg-white border-amber-200/60'
                    }`}
                  >
                    <span className="text-[10px] font-bold text-stone-400 block uppercase">
                      Secret Giving
                    </span>
                    <span className="text-base font-black text-emerald-400 flex items-center gap-1">
                      <EyeOff className="w-3.5 h-3.5 inline" />
                      <span>
                        {sadaqahList.filter((s) => s.isAnonymous).length} Entries (
                        {Math.round(
                          (sadaqahList.filter((s) => s.isAnonymous).length /
                            Math.max(1, sadaqahList.length)) *
                            100
                        )}
                        %)
                      </span>
                    </span>
                  </div>

                  <div
                    className={`p-2.5 rounded-xl border col-span-2 sm:col-span-1 ${
                      darkMode ? 'bg-[#152E22] border-[#224A37]' : 'bg-white border-amber-200/60'
                    }`}
                  >
                    <span className="text-[10px] font-bold text-stone-400 block uppercase">
                      Total Records
                    </span>
                    <span className="text-base font-black text-stone-300">
                      {sadaqahList.length} Donations
                    </span>
                  </div>
                </div>

                {/* Hadith Quote */}
                <p className="mt-3 text-[11px] text-stone-400 italic bg-black/10 dark:bg-black/30 p-2 rounded-xl">
                  &quot;গোপন সাদাকা প্রতিপালকের ক্রোধ নির্বাপিত করে এবং অপমৃত্যু থেকে রক্ষা করে।&quot; (সুনান আত-তিরমিযী)
                </p>
              </div>

              {/* Add / Edit Inline Form */}
              {showAddSadaqahForm && (
                <div
                  className={`p-4 rounded-2xl border space-y-3 animate-in fade-in duration-200 ${
                    darkMode
                      ? 'bg-[#142C20] border-[#D4AF37]/50 text-stone-100'
                      : 'bg-amber-50/70 border-amber-300 text-stone-900'
                  }`}
                >
                  <div className="flex items-center justify-between pb-1 border-b border-stone-300/30">
                    <span className="text-xs font-black text-[#D4AF37] flex items-center gap-1">
                      <HeartHandshake className="w-3.5 h-3.5" />
                      {editingSadaqahId ? 'Edit Sadaqah Record' : 'Record New Sadaqah'}
                    </span>
                    <button
                      onClick={() => setShowAddSadaqahForm(false)}
                      className="text-stone-400 hover:text-stone-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Sadaqah Purpose / Beneficiary *
                      </label>
                      <input
                        type="text"
                        value={sadTitle}
                        onChange={(e) => setSadTitle(e.target.value)}
                        placeholder="e.g. এতিমখানায় খাবার দান or গোপনে আত্মীয়কে সাহায্য"
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Amount (৳ BDT) *
                      </label>
                      <input
                        type="number"
                        value={sadAmount}
                        onChange={(e) => setSadAmount(e.target.value)}
                        placeholder="৳ 500"
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Category (খাত)
                      </label>
                      <select
                        value={sadCategory}
                        onChange={(e) => setSadCategory(e.target.value as any)}
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      >
                        <option value="Secret">গোপন সাদাকা (Secret Giving)</option>
                        <option value="Relatives">আত্মীয়স্বজন (Needy Kin)</option>
                        <option value="Poor & Needy">দরিদ্র ও মিসকিন (Poor &amp; Needy)</option>
                        <option value="Mosque & Madrasa">মসজিদ-মাদ্রাসা (Mosque/Madrasa)</option>
                        <option value="Water Well">কূপ খনন / সুপেয় পানি (Water Well)</option>
                        <option value="Emergency Aid">বিপদগ্রস্ত মানুষ / এতিম (Emergency)</option>
                        <option value="Other">অন্যান্য কল্যাণমূলক দান (Other)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-400 block mb-1">
                        Date *
                      </label>
                      <input
                        type="date"
                        value={sadDate}
                        onChange={(e) => setSadDate(e.target.value)}
                        className={`w-full px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                          darkMode
                            ? 'bg-[#0E2017] border-[#224A37] text-white'
                            : 'bg-white border-stone-300 text-stone-900'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Secret toggle */}
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-black/10 dark:bg-black/20 border border-stone-500/20">
                    <input
                      type="checkbox"
                      id="secret-checkbox"
                      checked={sadIsAnonymous}
                      onChange={(e) => setSadIsAnonymous(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 accent-amber-500 cursor-pointer"
                    />
                    <label
                      htmlFor="secret-checkbox"
                      className="text-xs font-semibold text-stone-300 cursor-pointer flex items-center gap-1.5"
                    >
                      <EyeOff className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>গোপন দান (Secret charity — Keep strictly confidential between you &amp; Allah)</span>
                    </label>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-stone-400 block mb-1">
                      Intention or Private Notes (নিয়ত ও বিশেষ দোয়া)
                    </label>
                    <input
                      type="text"
                      value={sadNotes}
                      onChange={(e) => setSadNotes(e.target.value)}
                      placeholder="e.g. অসুস্থতা আরোগ্যের নিয়তে সাদাকা..."
                      className={`w-full px-3 py-1.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                        darkMode
                          ? 'bg-[#0E2017] border-[#224A37] text-white'
                          : 'bg-white border-stone-300 text-stone-900'
                      }`}
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={() => setShowAddSadaqahForm(false)}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold text-stone-400 hover:text-stone-200"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveSadaqah}
                      className="px-4 py-1.5 rounded-xl text-xs font-black bg-[#D4AF37] text-stone-950 hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 shadow-xs"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{editingSadaqahId ? 'Update Record' : 'Save Sadaqah'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Category Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {[
                  'All',
                  'Secret',
                  'Relatives',
                  'Poor & Needy',
                  'Mosque & Madrasa',
                  'Water Well',
                  'Emergency Aid',
                ].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSadaqahFilter(cat)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                      sadaqahFilter === cat
                        ? 'bg-[#D4AF37] text-stone-950 shadow-xs'
                        : darkMode
                        ? 'bg-[#12281E] text-stone-400 hover:text-stone-200'
                        : 'bg-stone-100 text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    {cat === 'All' ? 'All Sadaqah' : cat === 'Secret' ? '🔒 Secret Only' : cat}
                  </button>
                ))}
              </div>

              {/* Sadaqah Records List */}
              <div className="space-y-2.5">
                {sadaqahList
                  .filter((s) => {
                    if (sadaqahFilter === 'All') return true;
                    if (sadaqahFilter === 'Secret') return s.isAnonymous || s.category === 'Secret';
                    return s.category === sadaqahFilter;
                  })
                  .map((item) => (
                    <div
                      key={item.id}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        darkMode
                          ? 'bg-[#12281E] border-[#224A37]'
                          : 'bg-white border-emerald-900/10 shadow-xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                item.isAnonymous
                                  ? 'bg-amber-500/20 text-[#D4AF37] border border-amber-500/30'
                                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              }`}
                            >
                              {item.categoryBn || item.category}
                            </span>

                            {item.isAnonymous && (
                              <span className="text-[10px] font-bold text-amber-400 flex items-center gap-0.5 bg-amber-500/10 px-1.5 py-0.5 rounded">
                                <EyeOff className="w-3 h-3" />
                                <span>গোপন সাদাকা</span>
                              </span>
                            )}

                            <span className="text-[11px] font-semibold text-stone-400">
                              {item.date}
                            </span>
                          </div>

                          <h5 className="text-sm font-black text-stone-900 dark:text-stone-100 mt-1">
                            {item.title}
                          </h5>

                          {item.notes && (
                            <p className="text-[11px] text-stone-400 mt-0.5 font-medium leading-relaxed italic">
                              &quot;{item.notes}&quot;
                            </p>
                          )}
                        </div>

                        {/* Amount & Actions */}
                        <div className="flex flex-col items-end shrink-0 gap-1.5">
                          <span className="text-base font-black text-[#D4AF37]">
                            ৳{item.amount.toLocaleString()}
                          </span>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleEditSadaqah(item)}
                              className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-black/10 dark:hover:bg-white/10"
                              title="Edit record"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteSadaqah(item.id)}
                              className="p-1.5 rounded-lg text-stone-400 hover:text-rose-400 hover:bg-black/10 dark:hover:bg-white/10"
                              title="Delete record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                {sadaqahList.filter((s) => {
                  if (sadaqahFilter === 'All') return true;
                  if (sadaqahFilter === 'Secret') return s.isAnonymous || s.category === 'Secret';
                  return s.category === sadaqahFilter;
                }).length === 0 && (
                  <div className="text-center py-8 text-stone-400 text-xs">
                    No Sadaqah records found for this filter.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: LEDGER (ALL TRANSACTIONS) */}
          {activeTab === 'ledger' && (
            <div className="space-y-3">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                <input
                  type="text"
                  placeholder="Search transactions by title or category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full pl-9 pr-4 py-2 rounded-xl border text-xs focus:outline-none ${
                    darkMode
                      ? 'bg-[#142D21] border-[#224A37] text-white'
                      : 'bg-stone-50 border-stone-200 text-stone-900'
                  }`}
                />
              </div>

              {/* Transactions List */}
              {filteredFinances.length === 0 ? (
                <div className="text-center py-10 text-stone-400 text-xs">
                  No transactions recorded yet. Start with a "Money Save" or "Expense"!
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredFinances.map((item) => {
                    const isSave = item.type === 'save';

                    return (
                      <div
                        key={item.id}
                        className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                          darkMode
                            ? 'bg-[#12281E] border-[#1C3B2C] hover:border-emerald-700/50'
                            : 'bg-white border-stone-200 hover:border-emerald-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                              isSave
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : 'bg-rose-500/20 text-rose-400'
                            }`}
                          >
                            {isSave ? (
                              <ArrowUpRight className="w-4 h-4" />
                            ) : (
                              <ArrowDownRight className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <h5 className="text-xs font-black">{item.title}</h5>
                            <div className="flex items-center gap-2 text-[10px] text-stone-400">
                              <span>{item.category}</span>
                              <span>•</span>
                              <span>{item.date}</span>
                            </div>
                            {item.note && (
                              <p className="text-[10px] text-stone-500 italic mt-0.5">{item.note}</p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span
                            className={`text-sm font-black ${
                              isSave ? 'text-emerald-500' : 'text-rose-500'
                            }`}
                          >
                            {isSave ? '+৳' : '-৳'}
                            {item.amount.toLocaleString()}
                          </span>

                          {deleteConfirmId === item.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => {
                                  onDeleteRecord(item.id);
                                  setDeleteConfirmId(null);
                                  showToast('Transaction deleted');
                                }}
                                className="px-2 py-1 rounded-md bg-rose-600 text-white text-[10px] font-black"
                              >
                                Delete
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(null)}
                                className="px-1.5 py-1 text-stone-400 text-[10px]"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirmId(item.id)}
                              className="p-1 rounded-lg text-stone-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                              title="Delete transaction"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
  );

  if (isScreenMode) {
    return <div id="screen-muhasabat-al-mal" className="w-full space-y-4">{modalCard}</div>;
  }

  return (
    <div
      id="modal-muhasabat-al-mal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      {modalCard}
    </div>
  );
};
