import React, { useState } from 'react';
import {
  X,
  HeartPulse,
  Sparkles,
  Volume2,
  Copy,
  Check,
  RotateCcw,
  BookOpen,
  Shield,
  Activity,
} from 'lucide-react';
import { EmotionalHealingItem } from '../types';
import { INITIAL_EMOTIONAL_HEALING } from '../data/islamicFeaturesData';
import { playDhikrClick } from '../utils/audio';

interface EmotionalHealingModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled: boolean;
}

export const EmotionalHealingModal: React.FC<EmotionalHealingModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled,
}) => {
  const [selectedEmotion, setSelectedEmotion] = useState<string>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [repeatCounters, setRepeatCounters] = useState<Record<string, number>>({});
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleCopyDua = (item: EmotionalHealingItem) => {
    const text = `${item.titleEn} (${item.titleBn})\n\n${item.arabic}\n\n${item.transliteration}\n\nঅর্থ: ${item.meaningBn}\n\nআমল: ${item.actionAdvice}\nরেফারেন্স: ${item.reference}`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    showToast('Copied healing dua & advice to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleIncrementRepeat = (id: string) => {
    playDhikrClick(soundEnabled);
    setRepeatCounters((prev) => ({
      ...prev,
      [id]: (prev[id] || 0) + 1,
    }));
  };

  const handlePlayVoice = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
      showToast('Playing Arabic recitation');
    } else {
      playDhikrClick(soundEnabled);
      showToast('Audio synthesis ready');
    }
  };

  const emotions = [
    'All',
    'Anxiety & Stress',
    'Sadness & Depression',
    'Anger',
    'Fear & Uncertainty',
    'Guilt & Repentance',
    'Gratitude & Joy',
  ];

  const filtered = INITIAL_EMOTIONAL_HEALING.filter((item) => {
    if (selectedEmotion === 'All') return true;
    return item.emotion === selectedEmotion;
  });

  return (
    <div
      id="modal-emotional-healing"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-lg rounded-[28px] border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-rose-900 to-rose-700 text-rose-200 flex items-center justify-center font-black shadow-xs border border-rose-500/30">
              <HeartPulse className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                <span>Spiritual First Aid &amp; Ruqyah</span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400">
                  মানসিক আরোগ্য
                </span>
              </h3>
              <p className="text-xs text-stone-400 font-medium">
                Prophetic remedies &amp; Quranic prescriptions for emotional states
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Emotion Filter Selector */}
        <div
          className={`px-4 py-2.5 border-b flex items-center gap-1.5 overflow-x-auto no-scrollbar ${
            darkMode ? 'bg-[#0A1710] border-[#1A3729]' : 'bg-stone-50 border-stone-200'
          }`}
        >
          {emotions.map((emo) => (
            <button
              key={emo}
              onClick={() => setSelectedEmotion(emo)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                selectedEmotion === emo
                  ? 'bg-rose-700 text-white shadow-xs'
                  : darkMode
                  ? 'bg-[#12281E] text-stone-400 hover:text-stone-200'
                  : 'bg-stone-100 text-stone-600 hover:text-stone-900'
              }`}
            >
              {emo === 'All' ? 'All Emotions' : emo}
            </button>
          ))}
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="mx-4 my-2 p-2 rounded-xl bg-emerald-600 text-white text-xs font-bold text-center shadow-md animate-bounce">
            {toastMsg}
          </div>
        )}

        {/* Scrollable Prescriptions List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {filtered.map((item) => {
            const count = repeatCounters[item.id] || 0;
            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition-all ${
                  darkMode
                    ? 'bg-[#12281E] border-rose-900/30'
                    : 'bg-white border-rose-200/60 shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30">
                      {item.emotion}
                    </span>
                    <h4 className="text-sm font-black text-stone-900 dark:text-stone-100 mt-1">
                      {item.titleEn}
                    </h4>
                    <span className="text-xs font-bold text-[#D4AF37]">
                      {item.titleBn}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handlePlayVoice(item.arabic)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-emerald-400 hover:bg-black/10 dark:hover:bg-white/10"
                      title="Play Recitation"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleCopyDua(item)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-black/10 dark:hover:bg-white/10"
                      title="Copy to Clipboard"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Arabic Calligraphy Box */}
                <div className="my-2.5 p-3 rounded-xl bg-black/10 dark:bg-black/30 border border-rose-500/20 text-center font-arabic text-xl font-bold text-[#1B4332] dark:text-[#F4E0A5] leading-relaxed">
                  {item.arabic}
                </div>

                <p className="text-[11px] text-stone-500 dark:text-stone-400 italic mb-1.5 font-medium">
                  &quot;{item.transliteration}&quot;
                </p>

                <p className="text-xs text-stone-700 dark:text-stone-300 font-semibold leading-relaxed mb-2">
                  <span className="text-rose-500 font-bold">অর্থ: </span>
                  {item.meaningBn}
                </p>

                {/* Prophetic Prescription & Advice */}
                <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 space-y-1">
                  <div className="text-[11px] font-bold text-rose-400 flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5" />
                    <span>চিকিৎসা ও আমল (Prescription):</span>
                  </div>
                  <p className="text-xs text-stone-800 dark:text-stone-200 font-medium">
                    {item.actionAdvice}
                  </p>
                  <span className="text-[10px] text-stone-400 block pt-0.5">
                    উৎস: {item.reference}
                  </span>
                </div>

                {/* Repeat Counter Bar */}
                <div className="mt-3 pt-2.5 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-400">
                    পাঠ করা হয়েছে: <strong className="text-rose-400">{count}</strong> বার
                  </span>

                  <button
                    onClick={() => handleIncrementRepeat(item.id)}
                    className="px-3 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-[#F4E0A5] hover:brightness-110 active:scale-95 transition-all shadow-xs"
                  >
                    +১ বার পাঠ
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
