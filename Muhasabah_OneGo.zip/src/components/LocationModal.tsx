import React, { useState } from 'react';
import {
  X,
  MapPin,
  Compass,
  Navigation,
  Check,
  RotateCw,
  Search,
  Globe,
} from 'lucide-react';
import { LocationConfig } from '../types';
import { BANGLADESH_LOCATIONS, calculateQibla } from '../utils/qibla';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  currentLocation: LocationConfig;
  onUpdateLocation: (loc: LocationConfig) => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  currentLocation,
  onUpdateLocation,
}) => {
  const [detectingGps, setDetectingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your device browser');
      return;
    }

    setDetectingGps(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setDetectingGps(false);
        const lat = Math.round(pos.coords.latitude * 10000) / 10000;
        const lng = Math.round(pos.coords.longitude * 10000) / 10000;

        // Find closest known city or use GPS format
        let closestCity = 'My GPS Location';
        let minDistance = Infinity;

        for (const loc of BANGLADESH_LOCATIONS) {
          const dLat = loc.latitude - lat;
          const dLng = loc.longitude - lng;
          const dist = Math.sqrt(dLat * dLat + dLng * dLng);
          if (dist < minDistance) {
            minDistance = dist;
            closestCity = loc.name;
          }
        }

        const displayName = minDistance < 0.35 ? closestCity : `GPS (${lat.toFixed(2)}°N, ${lng.toFixed(2)}°E)`;

        const newLoc: LocationConfig = {
          name: displayName,
          country: 'Bangladesh',
          latitude: lat,
          longitude: lng,
          timezoneOffset: 6,
        };
        onUpdateLocation(newLoc);
        onClose();
      },
      (err) => {
        setDetectingGps(false);
        setGpsError(`GPS access notice: ${err.message}. You can select any district below.`);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleSelectPreset = (loc: (typeof BANGLADESH_LOCATIONS)[0]) => {
    onUpdateLocation({
      name: loc.name,
      country: loc.country,
      latitude: loc.latitude,
      longitude: loc.longitude,
      timezoneOffset: loc.timezoneOffset,
    });
    onClose();
  };

  const currentQibla = calculateQibla(currentLocation.latitude, currentLocation.longitude);

  const filteredLocations = BANGLADESH_LOCATIONS.filter((l) =>
    l.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-md max-h-[90vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header with Deep Emerald Gradient */}
        <div className="p-4 border-b border-emerald-100/60 dark:border-[#254F3E] flex items-center justify-between bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#52B788] text-stone-950 shadow-md">
              <MapPin className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Sync Location
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#D4AF37] text-stone-950 font-black">
                  GPS &amp; Districts
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Auto-syncs prayer times, azan alerts &amp; accurate Qibla compass
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Container */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3.5">
          {/* Active Location Info */}
          <div className="p-3.5 rounded-2xl bg-[#E8F5E9]/80 dark:bg-[#163024] border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-stone-500 dark:text-stone-400">
                Active Synced City
              </span>
              <div className="text-base font-extrabold text-[#1B4332] dark:text-[#74C69D]">
                {currentLocation.name}, {currentLocation.country}
              </div>
              <div className="text-[11px] text-stone-500 dark:text-stone-400 font-mono mt-0.5">
                {currentLocation.latitude}° N, {currentLocation.longitude}° E
              </div>
            </div>

            <div className="text-right bg-white dark:bg-[#0E1E17] px-3 py-2 rounded-xl border border-emerald-200 dark:border-[#254F3E]">
              <span className="text-[9px] font-bold text-stone-400 block uppercase">
                Qibla Angle
              </span>
              <span className="text-base font-black text-[#D4AF37] font-mono">
                {currentQibla}° W
              </span>
            </div>
          </div>

          {/* GPS Auto-Detect Button */}
          <button
            onClick={handleDetectGPS}
            disabled={detectingGps}
            className="w-full p-3 rounded-2xl border border-[#D4AF37]/50 bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white flex items-center justify-center gap-2 font-black text-xs hover:opacity-95 active:scale-98 transition-all shadow-sm"
          >
            <Navigation className={`w-4 h-4 ${detectingGps ? 'animate-spin' : ''}`} />
            <span>{detectingGps ? 'Detecting via Device GPS...' : 'Auto-Detect via Device GPS'}</span>
          </button>

          {gpsError && (
            <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 text-amber-800 dark:text-amber-200 text-xs">
              {gpsError}
            </div>
          )}

          {/* Search Districts */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-stone-500 dark:text-stone-400">
                Select Bangladesh District
              </span>
              <span className="text-[10px] text-stone-400">Sirajganj, Dhaka, etc.</span>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search district name..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-200 dark:border-[#254F3E] bg-stone-50 dark:bg-[#0E1E17] text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
              {filteredLocations.map((loc) => {
                const isSelected = currentLocation.name === loc.name;
                const locQibla = calculateQibla(loc.latitude, loc.longitude);

                return (
                  <button
                    key={loc.name}
                    onClick={() => handleSelectPreset(loc)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1B4332] text-white border-[#D4AF37] shadow-xs'
                        : 'bg-stone-50 dark:bg-[#142B20] border-stone-200 dark:border-[#254F3E] text-stone-800 dark:text-stone-200 hover:bg-emerald-50'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold text-xs">{loc.name}</div>
                      <div
                        className={`text-[10px] font-mono ${
                          isSelected ? 'text-[#F4E0A5]' : 'text-stone-400'
                        }`}
                      >
                        Qibla {locQibla}°
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-[#D4AF37]" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] text-center text-[11px] text-stone-500">
          Updating location instantly recalculates all prayer times and compass bearings.
        </div>
      </div>
    </div>
  );
};
