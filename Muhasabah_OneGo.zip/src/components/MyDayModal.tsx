import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  CheckCircle2,
  Circle,
  Sparkles,
  Calendar,
  Clock,
  BookOpen,
  Target,
  Trash2,
  Edit2,
  Star,
  BarChart2,
  Check,
  ChevronRight,
  ChevronLeft,
  Sun,
  Moon,
  Shield,
  RotateCcw,
  TrendingUp,
  AlertCircle,
  Flag,
  ListTodo,
} from 'lucide-react';
import {
  PlannerTask,
  PlannerGoal,
  DayPlanData,
  PlannerTaskCategory,
  PlannerTaskPriority,
} from '../types';
import { playDhikrClick, playNotificationTone } from '../utils/audio';

interface MyDayModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  soundEnabled?: boolean;
  onTaskAdded?: (taskName: string) => void;
}

const CATEGORY_LABELS: Record<PlannerTaskCategory, { label: string; color: string }> = {
  Fardh: {
    label: 'ফরজ ও ওয়াজিব',
    color: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
  },
  Sunnah: {
    label: 'সুন্নাত ও নফল',
    color: 'bg-teal-500/15 text-teal-600 dark:text-teal-400 border-teal-500/30',
  },
  Work: {
    label: 'কাজ ও শিক্ষা',
    color: 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30',
  },
  Khair: {
    label: 'কল্যাণ ও খিদমত',
    color: 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30',
  },
  Personal: {
    label: 'ব্যক্তিগত',
    color: 'bg-stone-500/15 text-stone-600 dark:text-stone-300 border-stone-500/30',
  },
};

const PRIORITY_LABELS: Record<PlannerTaskPriority, { label: string; color: string }> = {
  High: { label: 'জরুরি / উচ্চ', color: 'text-rose-500 bg-rose-500/10 border-rose-500/30' },
  Medium: { label: 'মাঝারি', color: 'text-amber-500 bg-amber-500/10 border-amber-500/30' },
  Low: { label: 'সাধারণ', color: 'text-stone-400 bg-stone-500/10 border-stone-500/30' },
};

const DEFAULT_TASKS_TODAY: PlannerTask[] = [
  {
    id: 't-1',
    createdAt: new Date().toISOString(),
    date: new Date().toISOString().split('T')[0],
    title: 'ফজর সালাত ও সকালের মাসনুন আদকার আদায়',
    category: 'Fardh',
    priority: 'High',
    completed: true,
    time: '05:30 AM',
  },
  {
    id: 't-2',
    createdAt: new Date().toISOString(),
    date: new Date().toISOString().split('T')[0],
    title: 'সূরা আল-মুলক ও দৈনিক কুরআন তেলাওয়াত',
    category: 'Sunnah',
    priority: 'High',
    completed: true,
    time: '06:30 AM',
  },
  {
    id: 't-3',
    createdAt: new Date().toISOString(),
    date: new Date().toISOString().split('T')[0],
    title: 'হালাল জীবিকা ও কর্মক্ষেত্রে পূর্ণ নিষ্ঠার সাথে দায়িত্ব পালন',
    category: 'Work',
    priority: 'Medium',
    completed: false,
    time: '09:30 AM',
  },
  {
    id: 't-4',
    createdAt: new Date().toISOString(),
    date: new Date().toISOString().split('T')[0],
    title: 'পরিবার ও পিতা-মাতার সাথে সময় দেওয়া এবং খিদমত',
    category: 'Khair',
    priority: 'Medium',
    completed: false,
    time: '07:00 PM',
  },
];

const DEFAULT_GOALS_TODAY: PlannerGoal[] = [
  {
    id: 'g-1',
    title: 'পাঁচ ওয়াক্ত সালাত প্রথম ওয়াক্তে একাগ্রতার সাথে আদায়',
    category: 'Worship',
    completed: true,
  },
  {
    id: 'g-2',
    title: 'কর্মক্ষেত্রে সততা বজায় রাখা ও সময়ের সঠিক সদ্ব্যবহার করা',
    category: 'Work',
    completed: false,
  },
  {
    id: 'g-3',
    title: 'কারো গিবত না করা ও রাগ নিয়ন্ত্রণ রাখা',
    category: 'Personal',
    completed: false,
  },
];

export const MyDayModal: React.FC<MyDayModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  soundEnabled = true,
  onTaskAdded,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [currentDate, setCurrentDate] = useState<string>(todayStr);

  // Store all plans indexed by date: Record<string, DayPlanData>
  const [plansByDate, setPlansByDate] = useState<Record<string, DayPlanData>>(() => {
    try {
      const saved = localStorage.getItem('muhasabah_daily_planner_state');
      if (saved) {
        const parsed = JSON.parse(saved);
        const cleaned = { ...parsed };
        Object.keys(cleaned).forEach((dateKey) => {
          const plan = cleaned[dateKey];
          if (!plan || typeof plan !== 'object') return;
          cleaned[dateKey] = {
            ...plan,
            goals: Array.isArray(plan.goals) ? plan.goals.filter((g: PlannerGoal) => !['g-1','g-2','g-3'].includes(g.id)) : [],
            tasks: Array.isArray(plan.tasks) ? plan.tasks.filter((t: PlannerTask) => !['t-1','t-2','t-3','t-4'].includes(t.id)) : [],
          };
        });
        return cleaned;
      }
    } catch {
      // ignore
    }
    return {
      [todayStr]: {
        date: todayStr,
        niyyah: 'আজকের প্রতিটি কাজ আল্লাহ তায়ালার সন্তুষ্টি, তাকওয়া ও আখিরাতের সফলতার নিয়তে পালন করব।',
        dailyPlan: 'সকালে ফজরের পর কুরআন অধ্যয়ন, দুপুরে নিষ্ঠার সাথে কাজ, সন্ধ্যায় পরিবারকে সময় এবং রাতে আত্মসমালোচনা।',
        goals: [],
        islamicGoal: '',
        worldlyGoal: '',
        quranTarget: '',
        quranTargetCompleted: false,
        tasks: [],
        reflection: '',
        barakahRating: 0,
      },
    };
  });

  // Current Day Plan with backward-compatible defaults
  const rawPlan = plansByDate[currentDate];
  const resetCurrentPlan = () => {
    const emptyPlan: DayPlanData = {
      date: currentDate,
      niyyah: '',
      dailyPlan: '',
      goals: [],
      islamicGoal: '',
      worldlyGoal: '',
      quranTarget: '',
      quranTargetCompleted: false,
      tasks: [],
      reflection: '',
      barakahRating: 0,
    };
    setPlansByDate((prev) => {
      const next = { ...prev, [currentDate]: emptyPlan };
      try { localStorage.setItem('muhasabah_daily_planner_state', JSON.stringify(next)); } catch {}
      return next;
    });
  };

  const currentPlan: DayPlanData = {
    date: currentDate,
    niyyah: rawPlan?.niyyah ?? 'আল্লাহর সন্তুষ্টি ও আখিরাতের কল্যাণের উদ্দেশ্যে দিনের শুরু করছি।',
    dailyPlan: rawPlan?.dailyPlan ?? '',
    goals: rawPlan?.goals && rawPlan.goals.length > 0
      ? rawPlan.goals
      : rawPlan?.islamicGoal || rawPlan?.worldlyGoal
      ? [
          ...(rawPlan.islamicGoal ? [{ id: 'g-iso-' + currentDate, title: rawPlan.islamicGoal, category: 'Worship' as const, completed: false }] : []),
          ...(rawPlan.worldlyGoal ? [{ id: 'g-wld-' + currentDate, title: rawPlan.worldlyGoal, category: 'Work' as const, completed: false }] : []),
        ]
      : [],
    islamicGoal: rawPlan?.islamicGoal ?? '',
    worldlyGoal: rawPlan?.worldlyGoal ?? '',
    quranTarget: rawPlan?.quranTarget ?? '',
    quranTargetCompleted: rawPlan?.quranTargetCompleted ?? false,
    tasks: rawPlan?.tasks ?? [],
    reflection: rawPlan?.reflection ?? '',
    barakahRating: rawPlan?.barakahRating ?? 4,
  };

  // Active Tab inside Planner: 'morning' | 'tasks' | 'review'
  const [plannerTab, setPlannerTab] = useState<'morning' | 'tasks' | 'review'>('morning');

  // Task Filter state: 'all' | 'pending' | 'completed'
  const [taskFilter, setTaskFilter] = useState<'all' | 'pending' | 'completed'>('all');

  // Form State for new/edit task
  const [taskTitle, setTaskTitle] = useState('');
  const [taskCategory, setTaskCategory] = useState<PlannerTaskCategory>('Sunnah');
  const [taskPriority, setTaskPriority] = useState<PlannerTaskPriority>('Medium');
  const [taskTime, setTaskTime] = useState('');
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);

  // Form State for new goal
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState<PlannerGoal['category']>('Worship');
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);
  const [editingGoalTitle, setEditingGoalTitle] = useState('');

  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteGoalConfirmId, setDeleteGoalConfirmId] = useState<string | null>(null);

  // Persist whenever plansByDate changes
  useEffect(() => {
    try {
      localStorage.setItem('muhasabah_daily_planner_state', JSON.stringify(plansByDate));
    } catch {
      // ignore
    }
  }, [plansByDate]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2800);
  };

  const updateCurrentPlan = (updates: Partial<DayPlanData>) => {
    setPlansByDate((prev) => {
      const existing = prev[currentDate] || currentPlan;
      return {
        ...prev,
        [currentDate]: {
          ...existing,
          ...updates,
        },
      };
    });
  };

  // Date Navigation Helpers
  const shiftDate = (days: number) => {
    const current = new Date(currentDate + 'T12:00:00');
    current.setDate(current.getDate() + days);
    const newDateStr = current.toISOString().split('T')[0];
    setCurrentDate(newDateStr);
    playDhikrClick(soundEnabled);
  };

  const formatDateBn = (dateStr: string) => {
    const d = new Date(dateStr + 'T12:00:00');
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' };
    const enStr = d.toLocaleDateString('en-US', options);
    const isToday = dateStr === todayStr;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const isYesterday = dateStr === yesterday.toISOString().split('T')[0];
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const isTomorrow = dateStr === tomorrow.toISOString().split('T')[0];

    const tag = isToday ? ' (আজ)' : isYesterday ? ' (গতকাল)' : isTomorrow ? ' (আগামীকাল)' : '';
    return `${enStr}${tag}`;
  };

  // Task Operations
  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) {
      showToast('কাজের শিরোনাম লিখুন');
      return;
    }

    playNotificationTone(soundEnabled);

    if (editingTaskId) {
      const updatedTasks = currentPlan.tasks.map((t) =>
        t.id === editingTaskId
          ? {
              ...t,
              title: taskTitle.trim(),
              category: taskCategory,
              priority: taskPriority,
              time: taskTime.trim() || undefined,
              updatedAt: new Date().toISOString(),
            }
          : t
      );
      updateCurrentPlan({ tasks: updatedTasks });
      setEditingTaskId(null);
      showToast('টাস্ক আপডেট করা হয়েছে');
    } else {
      const newTask: PlannerTask = {
        id: 'task-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
        createdAt: new Date().toISOString(),
        date: currentDate,
        title: taskTitle.trim(),
        category: taskCategory,
        priority: taskPriority,
        completed: false,
        time: taskTime.trim() || undefined,
      };
      updateCurrentPlan({ tasks: [newTask, ...currentPlan.tasks] });
      showToast('নতুন গুরুত্বপূর্ণ কাজ যুক্ত হয়েছে');
      if (onTaskAdded) onTaskAdded(taskTitle.trim());
    }

    setTaskTitle('');
    setTaskTime('');
  };

  const handleToggleTask = (id: string) => {
    playDhikrClick(soundEnabled);
    const updatedTasks = currentPlan.tasks.map((t) =>
      t.id === id ? { ...t, completed: !t.completed, updatedAt: new Date().toISOString() } : t
    );
    updateCurrentPlan({ tasks: updatedTasks });
  };

  const handleDeleteTask = (id: string) => {
    const updatedTasks = currentPlan.tasks.filter((t) => t.id !== id);
    updateCurrentPlan({ tasks: updatedTasks });
    setDeleteConfirmId(null);
    showToast('টাস্ক মুছে ফেলা হয়েছে');
  };

  const handleEditTask = (t: PlannerTask) => {
    setEditingTaskId(t.id);
    setTaskTitle(t.title);
    setTaskCategory(t.category);
    setTaskPriority(t.priority);
    setTaskTime(t.time || '');
    setPlannerTab('tasks');
  };

  // Goal Operations (Multiple goals)
  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTitle.trim()) return;

    playNotificationTone(soundEnabled);
    const newGoal: PlannerGoal = {
      id: 'goal-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      title: newGoalTitle.trim(),
      category: newGoalCategory,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    updateCurrentPlan({ goals: [...currentPlan.goals, newGoal] });
    setNewGoalTitle('');
    showToast('নতুন লক্ষ্য যুক্ত করা হয়েছে');
  };

  const handleToggleGoal = (id: string) => {
    playDhikrClick(soundEnabled);
    const updated = currentPlan.goals.map((g) =>
      g.id === id ? { ...g, completed: !g.completed } : g
    );
    updateCurrentPlan({ goals: updated });
  };

  const handleDeleteGoal = (id: string) => {
    const updated = currentPlan.goals.filter((g) => g.id !== id);
    updateCurrentPlan({ goals: updated });
    setDeleteGoalConfirmId(null);
    showToast('লক্ষ্য মুছে ফেলা হয়েছে');
  };

  const handleSaveEditGoal = (id: string) => {
    if (!editingGoalTitle.trim()) return;
    const updated = currentPlan.goals.map((g) =>
      g.id === id ? { ...g, title: editingGoalTitle.trim() } : g
    );
    updateCurrentPlan({ goals: updated });
    setEditingGoalId(null);
    setEditingGoalTitle('');
    showToast('লক্ষ্য আপডেট হয়েছে');
  };

  // Niyyah quick templates
  const applyNiyyahTemplate = (text: string) => {
    playDhikrClick(soundEnabled);
    updateCurrentPlan({ niyyah: text });
    showToast('নিয়ত যুক্ত হয়েছে');
  };

  // Task & Goal Calculations for End-of-Day Analysis
  const totalTasks = currentPlan.tasks.length;
  const completedTasks = currentPlan.tasks.filter((t) => t.completed).length;
  const incompleteTasks = Math.max(0, totalTasks - completedTasks);
  const completionPercent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const incompletePercent = totalTasks > 0 ? 100 - completionPercent : 0;

  const totalGoals = currentPlan.goals.length;
  const completedGoals = currentPlan.goals.filter((g) => g.completed).length;

  // Filtered Tasks
  const filteredTasks = currentPlan.tasks.filter((t) => {
    if (taskFilter === 'pending') return !t.completed;
    if (taskFilter === 'completed') return t.completed;
    return true;
  });

  return (
    <div
      id="modal-my-day-planner"
      role="dialog"
      aria-modal="true"
      aria-labelledby="planner-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        className={`w-full max-w-xl rounded-[28px] border shadow-2xl flex flex-col max-h-[94vh] overflow-hidden ${
          darkMode
            ? 'bg-[#0E2017] border-[#1F4432] text-stone-100 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
            : 'bg-white border-emerald-900/10 text-stone-900 shadow-[0_20px_50px_rgba(27,67,50,0.15)]'
        }`}
      >
        {/* Header */}
        <div
          className={`p-4 sm:p-5 border-b flex items-center justify-between ${
            darkMode ? 'border-[#1C3B2C] bg-[#12281E]' : 'border-emerald-900/10 bg-[#E8F5E9]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-[#D4AF37]/20 text-emerald-600 dark:text-[#D4AF37] flex items-center justify-center font-black shadow-xs">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="planner-modal-title" className="text-base font-black tracking-tight">
                  Daily Planner (দৈনিক পরিকল্পনাকারী)
                </h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                  আত্মমুহাসাবাহ
                </span>
              </div>
              <p className="text-xs text-stone-400 font-medium">
                সকালের সংকল্প, লক্ষ্য, করণীয় কাজ ও সান্ধ্যকালীন ফলাফল
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => { if (window.confirm('আজকের Planner রেকর্ড রিসেট করবেন?')) resetCurrentPlan(); }}
              title="Reset today’s planner"
              className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-rose-500 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 text-stone-400 hover:text-stone-100 transition-colors cursor-pointer"
              aria-label="Close Daily Planner"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Date Selector Header: Independent Separation by Date */}
        <div className="px-4 py-2.5 bg-stone-50 dark:bg-[#12281E]/60 border-b border-stone-200 dark:border-[#1E4332] flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => shiftDate(-1)}
              className="p-1 rounded-lg border border-stone-200 dark:border-[#224C38] hover:bg-stone-200 dark:hover:bg-[#183928] text-stone-600 dark:text-stone-300 transition-colors"
              title="পূর্ববর্তী দিন"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentDate(todayStr)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                currentDate === todayStr
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-[#163324] text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-[#224C38]'
              }`}
            >
              আজ
            </button>

            <button
              onClick={() => shiftDate(1)}
              className="p-1 rounded-lg border border-stone-200 dark:border-[#224C38] hover:bg-stone-200 dark:hover:bg-[#183928] text-stone-600 dark:text-stone-300 transition-colors"
              title="পরবর্তী দিন"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <input
              type="date"
              value={currentDate}
              onChange={(e) => setCurrentDate(e.target.value)}
              className={`text-xs px-2 py-1 rounded-xl border font-bold ${
                darkMode
                  ? 'bg-[#163324] border-[#224C38] text-stone-200'
                  : 'bg-white border-stone-200 text-stone-800'
              }`}
            />
          </div>

          {/* Quick Progress Badge */}
          <div className="text-right shrink-0">
            <span className="text-[11px] font-black text-emerald-600 dark:text-[#D4AF37]">
              {completedTasks}/{totalTasks} টাস্ক ({completionPercent}%)
            </span>
          </div>
        </div>

        {/* Active Day Banner */}
        <div className="px-4 py-1.5 bg-emerald-500/10 border-b border-emerald-500/20 text-center text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
          তারিখ: {formatDateBn(currentDate)}
        </div>

        {/* 3 Main Tabs: Morning / Tasks / Analysis */}
        <div className="flex border-b border-stone-200 dark:border-[#1C3B2C] bg-stone-100/60 dark:bg-[#0E2017]">
          <button
            onClick={() => setPlannerTab('morning')}
            className={`flex-1 py-2.5 text-xs font-black flex items-center justify-center gap-1.5 transition-all border-b-2 cursor-pointer ${
              plannerTab === 'morning'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-[#12281E]'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-300'
            }`}
          >
            <Sun className="w-3.5 h-3.5 text-amber-500" />
            <span>সকাল ও লক্ষ্য (Morning)</span>
          </button>

          <button
            onClick={() => setPlannerTab('tasks')}
            className={`flex-1 py-2.5 text-xs font-black flex items-center justify-center gap-1.5 transition-all border-b-2 cursor-pointer ${
              plannerTab === 'tasks'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-[#12281E]'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-300'
            }`}
          >
            <ListTodo className="w-3.5 h-3.5 text-blue-500" />
            <span>গুরুত্বপূর্ণ কাজ ({totalTasks})</span>
          </button>

          <button
            onClick={() => setPlannerTab('review')}
            className={`flex-1 py-2.5 text-xs font-black flex items-center justify-center gap-1.5 transition-all border-b-2 cursor-pointer ${
              plannerTab === 'review'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-[#12281E]'
                : 'border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-300'
            }`}
          >
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
            <span>ফলাফল ও বিশ্লেষণ (Night)</span>
          </button>
        </div>

        {/* Toast Notification */}
        {toastMsg && (
          <div className="p-2 bg-emerald-600 text-white text-xs font-bold text-center animate-in fade-in">
            ✨ {toastMsg}
          </div>
        )}

        {/* Tab Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* ============================================================ */}
          {/* TAB 1: MORNING NIYYAH, GOALS & DAILY PLAN */}
          {/* ============================================================ */}
          {plannerTab === 'morning' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* 1. Daily Niyyah Box */}
              <div
                className={`p-4 rounded-2xl border ${
                  darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-[#F4FAF5] border-emerald-100'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-[#D4AF37]">
                    <Sparkles className="w-4 h-4" />
                    <span>আজকের নিয়ত ও সংকল্প (Daily Niyyah)</span>
                  </div>
                  <span className="text-[10px] text-stone-400 font-bold">ইখলাস</span>
                </div>
                <p className="text-[11px] text-stone-500 dark:text-stone-400 mb-2">
                  &quot;What is my intention for today?&quot; — আজকের দিনে আমার নিয়ত ও উদ্দেশ্য কী?
                </p>
                <textarea
                  rows={2}
                  value={currentPlan.niyyah}
                  onChange={(e) => updateCurrentPlan({ niyyah: e.target.value })}
                  placeholder="আজকের দিনের কাজের খাঁটি নিয়ত লিখুন..."
                  className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden leading-relaxed ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                      : 'bg-white border-stone-200 text-stone-900 placeholder-stone-400'
                  }`}
                />

                {/* Quick Niyyah Chips */}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="text-[10px] text-stone-400 font-bold self-center mr-1">পরামর্শ:</span>
                  {[
                    'আল্লাহর সন্তুষ্টি ও ইখলাস',
                    'হালাল রিজিক ও নিষ্ঠা',
                    'পিতা-মাতা ও পরিবারের খেদমত',
                    'সবর ও রাগ নিয়ন্ত্রণ',
                  ].map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      onClick={() => applyNiyyahTemplate(chip + ' সহ আজকের দিন অতিবাহিত করব ইনশাআল্লাহ।')}
                      className="px-2 py-0.5 rounded-lg text-[10px] font-bold border border-emerald-500/20 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 transition-colors cursor-pointer"
                    >
                      + {chip}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Goals Section (আজকের লক্ষ্য — Multiple Goals supported) */}
              <div
                className={`p-4 rounded-2xl border ${
                  darkMode ? 'bg-[#12281E]/90 border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-emerald-500" />
                    <h4 className="text-xs font-black text-stone-800 dark:text-stone-200">
                      আজকের লক্ষ্য (Today&apos;s Goals)
                    </h4>
                  </div>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                    {completedGoals}/{totalGoals} অর্জিত
                  </span>
                </div>
                <p className="text-[11px] text-stone-500 dark:text-stone-400 mb-3">
                  &quot;What do I want to accomplish today?&quot; — আজকে আমি কী অর্জন করতে চাই?
                </p>

                {/* Add Goal Input */}
                <form onSubmit={handleAddGoal} className="flex gap-2 mb-3">
                  <input
                    type="text"
                    value={newGoalTitle}
                    onChange={(e) => setNewGoalTitle(e.target.value)}
                    placeholder="যেমন: পাঁচ ওয়াক্ত সালাত জামাআতে আদায় / কাজটি দুপুর ২টার মধ্যে শেষ..."
                    className={`flex-1 p-2 rounded-xl border text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                      darkMode
                        ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                        : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                    }`}
                  />
                  <select
                    value={newGoalCategory}
                    onChange={(e) => setNewGoalCategory(e.target.value as PlannerGoal['category'])}
                    className={`text-[11px] font-bold px-2 rounded-xl border ${
                      darkMode ? 'bg-[#0E2017] border-[#1E4332] text-stone-200' : 'bg-stone-50 border-stone-200'
                    }`}
                  >
                    <option value="Worship">ইবাদত</option>
                    <option value="Work">কাজ</option>
                    <option value="Personal">ব্যক্তিগত</option>
                    <option value="Knowledge">ইলম</option>
                  </select>
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>যোগ</span>
                  </button>
                </form>

                {/* Goals List */}
                {currentPlan.goals.length === 0 ? (
                  <div className="text-center py-4 border border-dashed rounded-xl border-stone-200 dark:border-stone-800 text-[11px] text-stone-400">
                    আজকের কোনো বিশেষ লক্ষ্য এখনো নির্ধারণ করা হয়নি।
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    {currentPlan.goals.map((goal) => (
                      <div
                        key={goal.id}
                        className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 transition-all ${
                          goal.completed
                            ? 'bg-emerald-50/50 dark:bg-[#10241A] border-emerald-200 dark:border-emerald-900/40'
                            : darkMode
                            ? 'bg-[#0E2017] border-[#1E4332]'
                            : 'bg-stone-50 border-stone-200'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => handleToggleGoal(goal.id)}
                          className="flex items-center gap-2 flex-1 text-left cursor-pointer"
                        >
                          {goal.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                          ) : (
                            <Circle className="w-4 h-4 text-stone-400 shrink-0" />
                          )}
                          {editingGoalId === goal.id ? (
                            <input
                              type="text"
                              value={editingGoalTitle}
                              onChange={(e) => setEditingGoalTitle(e.target.value)}
                              onBlur={() => handleSaveEditGoal(goal.id)}
                              onKeyDown={(e) => e.key === 'Enter' && handleSaveEditGoal(goal.id)}
                              autoFocus
                              className="text-xs p-1 rounded bg-white dark:bg-[#142D21] border border-emerald-500 w-full"
                            />
                          ) : (
                            <span
                              className={`text-xs font-semibold ${
                                goal.completed ? 'line-through text-stone-400' : 'text-stone-800 dark:text-stone-100'
                              }`}
                            >
                              {goal.title}
                            </span>
                          )}
                        </button>

                        <div className="flex items-center gap-1 shrink-0">
                          {goal.category && (
                            <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-stone-200/60 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                              {goal.category === 'Worship'
                                ? 'ইবাদত'
                                : goal.category === 'Work'
                                ? 'কাজ'
                                : goal.category === 'Personal'
                                ? 'ব্যক্তিগত'
                                : 'সাধারণ'}
                            </span>
                          )}
                          <button
                            onClick={() => {
                              setEditingGoalId(goal.id);
                              setEditingGoalTitle(goal.title);
                            }}
                            className="p-1 text-stone-400 hover:text-emerald-500 transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                          {deleteGoalConfirmId === goal.id ? (
                            <button
                              onClick={() => handleDeleteGoal(goal.id)}
                              className="px-1.5 py-0.5 text-[9px] font-black rounded bg-rose-600 text-white"
                            >
                              Del
                            </button>
                          ) : (
                            <button
                              onClick={() => setDeleteGoalConfirmId(goal.id)}
                              className="p-1 text-stone-400 hover:text-rose-500 transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 3. Daily Plan (আজকের পরিকল্পনা — General Plan for the Day) */}
              <div
                className={`p-4 rounded-2xl border ${
                  darkMode ? 'bg-[#12281E]/80 border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-black text-blue-600 dark:text-blue-400">
                    <Flag className="w-4 h-4" />
                    <span>আজকের সামগ্রিক পরিকল্পনা (Daily Plan)</span>
                  </div>
                  <span className="text-[10px] text-stone-400 font-bold">Editable & Persisted</span>
                </div>
                <p className="text-[11px] text-stone-500 dark:text-stone-400 mb-2">
                  দিনের সার্বিক সময়সূচি, বিশেষ অ্যাপয়েন্টমেন্ট বা সাধারণ পরিকল্পনার রূপরেখা:
                </p>
                <textarea
                  rows={3}
                  value={currentPlan.dailyPlan}
                  onChange={(e) => updateCurrentPlan({ dailyPlan: e.target.value })}
                  placeholder="যেমন: সকাল ৯টা-দুপুর ১টা: মূল অ্যাসাইনমেন্ট সম্পন্ন করা। আসরের পর: আত্মীয়দের খোঁজ নেওয়া..."
                  className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden leading-relaxed ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                      : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                  }`}
                />
              </div>

              {/* 4. Quran Study Target */}
              <div
                className={`p-3.5 rounded-2xl border ${
                  darkMode ? 'bg-[#142D21]/80 border-[#1F4432]' : 'bg-white border-emerald-200 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5 text-xs font-black text-emerald-700 dark:text-emerald-300">
                    <BookOpen className="w-4 h-4 text-emerald-500" />
                    <span>দৈনিক কুরআন / ইলম টার্গেট (Quran Target)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      playDhikrClick(soundEnabled);
                      updateCurrentPlan({ quranTargetCompleted: !currentPlan.quranTargetCompleted });
                    }}
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-black flex items-center gap-1 transition-all cursor-pointer ${
                      currentPlan.quranTargetCompleted
                        ? 'bg-emerald-600 text-white'
                        : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'
                    }`}
                  >
                    <Check className="w-3 h-3" />
                    <span>{currentPlan.quranTargetCompleted ? 'সম্পন্ন হয়েছে' : 'বাকি'}</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={currentPlan.quranTarget}
                  onChange={(e) => updateCurrentPlan({ quranTarget: e.target.value })}
                  placeholder="যেমন: সূরা মুলক অর্থসহ পাঠ ও সূরা আর-রহমানের প্রথম ১০ আয়াত মুখস্থ"
                  className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                      : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                  }`}
                />
              </div>

              {/* Advance to Tasks Button */}
              <button
                type="button"
                onClick={() => setPlannerTab('tasks')}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                <span>পরবর্তী: আজকের গুরুত্বপূর্ণ কাজ ও টাস্ক পরিচালনা</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 2: IMPORTANT TASKS (গুরুত্বপূর্ণ কাজ) */}
          {/* ============================================================ */}
          {plannerTab === 'tasks' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Task Add / Edit Form */}
              <form
                onSubmit={handleSaveTask}
                className={`p-3.5 rounded-2xl border space-y-2.5 ${
                  darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                    <ListTodo className="w-4 h-4" />
                    <span>{editingTaskId ? 'টাস্ক সম্পাদনা করুন (Edit Task)' : 'নতুন গুরুত্বপূর্ণ কাজ যোগ করুন'}</span>
                  </span>
                  {editingTaskId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingTaskId(null);
                        setTaskTitle('');
                        setTaskTime('');
                      }}
                      className="text-[10px] text-stone-400 hover:text-stone-600 underline cursor-pointer"
                    >
                      বাতিল
                    </button>
                  )}
                </div>

                <p className="text-[11px] text-stone-500 dark:text-stone-400">
                  &quot;What must I complete today?&quot; — আজকে আমাকে আবশ্যকভাবে কী সম্পন্ন করতে হবে?
                </p>

                <input
                  type="text"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  placeholder="কাজের শিরোনাম (যেমন: যোহরের পর ২০ মিনিট কুরআন অধ্যয়ন / অফিসের ফাইল প্রস্তুত)..."
                  className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                      : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                  }`}
                />

                {/* Category & Priority & Time Row */}
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] font-bold text-stone-400 block mb-1">ক্যাটাগরি</label>
                    <select
                      value={taskCategory}
                      onChange={(e) => setTaskCategory(e.target.value as PlannerTaskCategory)}
                      className={`w-full text-[11px] font-bold p-1.5 rounded-lg border ${
                        darkMode ? 'bg-[#0E2017] border-[#1E4332] text-stone-200' : 'bg-stone-50 border-stone-200'
                      }`}
                    >
                      {(Object.keys(CATEGORY_LABELS) as PlannerTaskCategory[]).map((cat) => (
                        <option key={cat} value={cat}>
                          {CATEGORY_LABELS[cat].label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-stone-400 block mb-1">অগ্রাধিকার</label>
                    <select
                      value={taskPriority}
                      onChange={(e) => setTaskPriority(e.target.value as PlannerTaskPriority)}
                      className={`w-full text-[11px] font-bold p-1.5 rounded-lg border ${
                        darkMode ? 'bg-[#0E2017] border-[#1E4332] text-stone-200' : 'bg-stone-50 border-stone-200'
                      }`}
                    >
                      {(Object.keys(PRIORITY_LABELS) as PlannerTaskPriority[]).map((p) => (
                        <option key={p} value={p}>
                          {PRIORITY_LABELS[p].label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-stone-400 block mb-1">সময় (ঐচ্ছিক)</label>
                    <input
                      type="text"
                      value={taskTime}
                      onChange={(e) => setTaskTime(e.target.value)}
                      placeholder="যেমন: 10:30 AM"
                      className={`w-full text-[11px] font-bold p-1.5 rounded-lg border ${
                        darkMode ? 'bg-[#0E2017] border-[#1E4332] text-stone-200' : 'bg-stone-50 border-stone-200'
                      }`}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{editingTaskId ? 'টাস্ক আপডেট করুন (Save Changes)' : 'টাস্ক যুক্ত করুন (Save Task)'}</span>
                </button>
              </form>

              {/* Tasks List & Filter Controls */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider text-stone-400">
                    আজকের কাজের তালিকা ({completedTasks}/{totalTasks})
                  </h4>

                  {/* Filter Pill */}
                  <div className="flex items-center gap-1 bg-stone-100 dark:bg-[#12281E] p-0.5 rounded-lg border border-stone-200 dark:border-[#1E4332]">
                    <button
                      onClick={() => setTaskFilter('all')}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-md transition-all ${
                        taskFilter === 'all'
                          ? 'bg-white dark:bg-[#1C3E2F] text-emerald-600 dark:text-emerald-400 shadow-xs'
                          : 'text-stone-400'
                      }`}
                    >
                      সকল ({totalTasks})
                    </button>
                    <button
                      onClick={() => setTaskFilter('pending')}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-md transition-all ${
                        taskFilter === 'pending'
                          ? 'bg-white dark:bg-[#1C3E2F] text-amber-500 shadow-xs'
                          : 'text-stone-400'
                      }`}
                    >
                      বাকি ({incompleteTasks})
                    </button>
                    <button
                      onClick={() => setTaskFilter('completed')}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-md transition-all ${
                        taskFilter === 'completed'
                          ? 'bg-white dark:bg-[#1C3E2F] text-emerald-500 shadow-xs'
                          : 'text-stone-400'
                      }`}
                    >
                      সম্পন্ন ({completedTasks})
                    </button>
                  </div>
                </div>

                {filteredTasks.length === 0 ? (
                  <div className="text-center py-8 border border-dashed rounded-2xl border-stone-200 dark:border-stone-800">
                    <Target className="w-6 h-6 mx-auto mb-1 text-stone-400" />
                    <p className="text-xs text-stone-400">
                      {taskFilter === 'completed'
                        ? 'কোনো সম্পন্ন কাজ নেই।'
                        : taskFilter === 'pending'
                        ? 'মাশাআল্লাহ! কোনো কাজ বাকি নেই।'
                        : 'কোনো কাজ যোগ করা হয়নি। নতুন কাজ যোগ করুন।'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredTasks.map((task) => (
                      <div
                        key={task.id}
                        className={`p-3 rounded-2xl border flex items-start justify-between gap-2.5 transition-all ${
                          task.completed
                            ? 'bg-emerald-50/40 dark:bg-[#10241A] border-emerald-200 dark:border-emerald-900/50'
                            : darkMode
                            ? 'bg-[#12281E]/60 border-[#1E4332]'
                            : 'bg-white border-stone-200 shadow-xs'
                        }`}
                      >
                        {/* Checkbox: Toggle Complete / Re-open Incomplete */}
                        <button
                          type="button"
                          onClick={() => handleToggleTask(task.id)}
                          className="mt-0.5 text-emerald-600 dark:text-emerald-400 shrink-0 cursor-pointer"
                          title={task.completed ? 'কাজটি পুনরায় খুলুন (Mark Incomplete)' : 'কাজটি সম্পন্ন চিহ্নিত করুন (Mark Complete)'}
                        >
                          {task.completed ? (
                            <CheckCircle2 className="w-5 h-5 fill-emerald-100 dark:fill-emerald-950" />
                          ) : (
                            <Circle className="w-5 h-5 text-stone-300 dark:text-stone-600 hover:text-emerald-500" />
                          )}
                        </button>

                        {/* Title & Metadata */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                            <span
                              className={`text-[9px] font-black px-1.5 py-0.5 rounded-md border ${
                                CATEGORY_LABELS[task.category]?.color || ''
                              }`}
                            >
                              {CATEGORY_LABELS[task.category]?.label || task.category}
                            </span>
                            <span
                              className={`text-[9px] font-black px-1.5 py-0.5 rounded-md border ${
                                PRIORITY_LABELS[task.priority]?.color || ''
                              }`}
                            >
                              {PRIORITY_LABELS[task.priority]?.label || task.priority}
                            </span>
                            {task.time && (
                              <span className="text-[10px] text-stone-400 flex items-center gap-0.5 font-medium">
                                <Clock className="w-3 h-3" />
                                <span>{task.time}</span>
                              </span>
                            )}
                          </div>
                          <p
                            className={`text-xs font-semibold leading-relaxed ${
                              task.completed
                                ? 'line-through text-stone-400 dark:text-stone-500'
                                : 'text-stone-800 dark:text-stone-100'
                            }`}
                          >
                            {task.title}
                          </p>
                        </div>

                        {/* Actions: Edit & Delete */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => handleEditTask(task)}
                            className="p-1 text-stone-400 hover:text-emerald-500 transition-colors cursor-pointer"
                            title="সম্পাদনা করুন (Edit)"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {deleteConfirmId === task.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleDeleteTask(task.id)}
                                className="px-1.5 py-0.5 rounded text-[9px] font-black bg-rose-600 text-white cursor-pointer"
                              >
                                মুছুন
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(null)}
                                className="px-1 py-0.5 rounded text-[9px] text-stone-400 cursor-pointer"
                              >
                                বাতিল
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirmId(task.id)}
                              className="p-1 text-stone-400 hover:text-rose-500 transition-colors cursor-pointer"
                              title="মুছে ফেলুন (Delete)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 3: END-OF-DAY ANALYSIS (আজকের পরিকল্পনার ফলাফল) */}
          {/* ============================================================ */}
          {plannerTab === 'review' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Accountability Header Banner */}
              <div
                className={`p-4 rounded-2xl border ${
                  darkMode
                    ? 'bg-gradient-to-br from-[#12241B] to-[#152F23] border-[#1E4332]'
                    : 'bg-gradient-to-br from-emerald-50/70 to-teal-50/70 border-emerald-100'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <BarChart2 className="w-5 h-5 text-emerald-500" />
                    <div>
                      <h4 className="text-sm font-black tracking-tight text-stone-800 dark:text-stone-100">
                        আজকের পরিকল্পনার ফলাফল (End-of-Day Analysis)
                      </h4>
                      <p className="text-[11px] text-stone-500 dark:text-stone-400">
                        «আজকের পরিকল্পনা কতটুকু পূরণ করতে পেরেছি?»
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-stone-400">{currentDate}</span>
                </div>

                {/* Dual-Segmented Progress Bar */}
                <div className="space-y-1.5 my-3">
                  <div className="flex justify-between text-xs font-black">
                    <span className="text-emerald-600 dark:text-emerald-400">
                      সম্পন্ন: {completionPercent}% ({completedTasks} টি কাজ)
                    </span>
                    <span className="text-rose-500 dark:text-rose-400">
                      অসমাপ্ত: {incompletePercent}% ({incompleteTasks} টি কাজ)
                    </span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-stone-200 dark:bg-stone-800 overflow-hidden flex shadow-inner">
                    <div
                      style={{ width: `${completionPercent}%` }}
                      className="bg-gradient-to-r from-emerald-600 to-teal-500 h-full transition-all duration-500"
                    />
                    <div
                      style={{ width: `${incompletePercent}%` }}
                      className="bg-rose-500/80 h-full transition-all duration-500"
                    />
                  </div>
                </div>

                {/* Detailed Analysis 4-Grid Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center mt-3">
                  {/* Total Tasks */}
                  <div className="p-3 rounded-xl bg-white/80 dark:bg-[#0E2017] border border-stone-200 dark:border-[#1E4332]">
                    <span className="text-[10px] text-stone-400 font-bold block uppercase tracking-wider">
                      মোট কাজ (Total)
                    </span>
                    <span className="text-lg font-black text-stone-800 dark:text-stone-100 mt-0.5 block">
                      {totalTasks}
                    </span>
                    <span className="text-[9px] text-stone-400">পরিকল্পিত কাজ</span>
                  </div>

                  {/* Completed Tasks */}
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block uppercase tracking-wider">
                      সম্পন্ন (Done)
                    </span>
                    <span className="text-lg font-black text-emerald-600 dark:text-emerald-400 mt-0.5 block">
                      {completedTasks} ({completionPercent}%)
                    </span>
                    <span className="text-[9px] text-emerald-700 dark:text-emerald-300">সফলভাবে সমাপ্ত</span>
                  </div>

                  {/* Incomplete Tasks */}
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900">
                    <span className="text-[10px] text-rose-600 dark:text-rose-400 font-bold block uppercase tracking-wider">
                      বাকি (Incomplete)
                    </span>
                    <span className="text-lg font-black text-rose-600 dark:text-rose-400 mt-0.5 block">
                      {incompleteTasks} ({incompletePercent}%)
                    </span>
                    <span className="text-[9px] text-rose-700 dark:text-rose-300">পরবর্তী দিনে শিফট</span>
                  </div>

                  {/* Goals Met */}
                  <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
                    <span className="text-[10px] text-amber-700 dark:text-[#D4AF37] font-bold block uppercase tracking-wider">
                      লক্ষ্য অর্জন (Goals)
                    </span>
                    <span className="text-lg font-black text-amber-700 dark:text-[#D4AF37] mt-0.5 block">
                      {completedGoals}/{totalGoals}
                    </span>
                    <span className="text-[9px] text-amber-800 dark:text-amber-200">
                      {totalGoals > 0 ? `${Math.round((completedGoals / totalGoals) * 100)}% অর্জিত` : 'নির্ধারিত নেই'}
                    </span>
                  </div>
                </div>

                {/* Motivational Islamic Feedback Note */}
                <div className="mt-3 p-2.5 rounded-xl bg-stone-100/80 dark:bg-[#10241A] border border-stone-200 dark:border-[#1E4332] text-xs font-semibold text-stone-700 dark:text-stone-300">
                  {completionPercent === 100 && totalTasks > 0 ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                      🌟 মাশাআল্লাহ! আজকের সমস্ত পরিকল্পিত কাজ সফলভাবে সমাপ্ত হয়েছে। আল্লাহ আপনার শ্রমে বরকত দিন!
                    </span>
                  ) : completionPercent >= 70 ? (
                    <span className="text-emerald-600 dark:text-emerald-400">
                      ✨ আলহামদুলিল্লাহ! দিনের অধিকাংশ গুরুত্বপূর্ণ কাজ সম্পন্ন হয়েছে। বাকি কাজগুলো আগামীকালের জন্য নির্ধারণ করুন।
                    </span>
                  ) : completionPercent >= 40 ? (
                    <span className="text-amber-600 dark:text-amber-400">
                      ⚖️ মধ্যম অগ্রগতি। সময় ব্যবস্থাপনায় আরো মনোযোগী হওয়া দরকার এবং অহেতুক ব্যস্ততা পরিহার করুন।
                    </span>
                  ) : (
                    <span className="text-rose-600 dark:text-rose-400">
                      ⚠️ ঘাটতি বেশি ছিল। আল্লাহর কাছে তাওবাহ করে আগামীকাল ফজরের পর থেকে নতুন নিষ্ঠা নিয়ে শুরু করুন।
                    </span>
                  )}
                </div>

                {/* Barakah Rating (1 to 5 Stars) */}
                <div className="pt-3 mt-3 border-t border-stone-200 dark:border-[#1F4432] flex items-center justify-between">
                  <div>
                    <span className="text-xs font-black text-stone-800 dark:text-stone-200 block">
                      দিনের বরকত রেটিং (Barakah Rating):
                    </span>
                    <span className="text-[10px] text-stone-400">
                      {currentPlan.barakahRating === 5
                        ? 'মাশাআল্লাহ! সর্বোচ্চ ফলপ্রসূ ও বরকতময় দিন'
                        : currentPlan.barakahRating >= 4
                        ? 'আলহামদুলিল্লাহ, ভালো দিন কেটেছে'
                        : 'ঘাটতি ছিল, আগামীকাল ইস্তিগফার ও নিষ্ঠা বাড়াব'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => {
                          playDhikrClick(soundEnabled);
                          updateCurrentPlan({ barakahRating: star });
                        }}
                        className="p-1 hover:scale-110 transition-transform cursor-pointer"
                        title={`${star} Star`}
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= currentPlan.barakahRating
                              ? 'text-[#D4AF37] fill-[#D4AF37]'
                              : 'text-stone-300 dark:text-stone-600'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Reflection on Time Spent & Shortcomings */}
              <div
                className={`p-3.5 rounded-2xl border ${
                  darkMode ? 'bg-[#142D21] border-[#1F4432]' : 'bg-white border-stone-200 shadow-xs'
                }`}
              >
                <label className="text-xs font-black text-stone-800 dark:text-stone-200 flex items-center gap-1.5 mb-1.5">
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                  <span>সময় ব্যবহারের সান্ধ্যকালীন আত্মমুহাসাবাহ (Night Reflection)</span>
                </label>
                <textarea
                  rows={3}
                  value={currentPlan.reflection}
                  onChange={(e) => updateCurrentPlan({ reflection: e.target.value })}
                  placeholder="আজকের দিনটি কীভাবে কাজে লাগল? কোথায় অলসতা বা সময় নষ্ট ছিল? আগামীকালের সংকল্প কী?..."
                  className={`w-full p-2.5 rounded-xl border text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden leading-relaxed ${
                    darkMode
                      ? 'bg-[#0E2017] border-[#1E4332] text-stone-100 placeholder-stone-500'
                      : 'bg-stone-50 border-stone-200 text-stone-900 placeholder-stone-400'
                  }`}
                />
              </div>

              {/* Save Plan Button */}
              <button
                type="button"
                onClick={() => {
                  playNotificationTone(soundEnabled);
                  showToast('দিনের পরিকল্পনা ও আত্মবিশ্লেষণ সফলভাবে সংরক্ষিত হয়েছে!');
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] hover:from-[#23533E] hover:to-[#388563] text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                <Check className="w-4 h-4 text-[#D4AF37]" />
                <span>আজকের সম্পূর্ণ প্ল্যান ও ফলাফল সংরক্ষণ করুন</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
