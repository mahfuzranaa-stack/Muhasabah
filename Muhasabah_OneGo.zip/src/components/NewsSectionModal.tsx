import React, { useState } from 'react';
import {
  X,
  Newspaper,
  ExternalLink,
  Share2,
  RefreshCw,
  Search,
  Clock,
  Globe,
  Filter,
} from 'lucide-react';
import { NewsArticle } from '../types';
import { INITIAL_NEWS } from '../data/initialData';

interface NewsSectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  articles?: NewsArticle[];
  onRefresh?: () => void;
}

const SOURCES: NewsArticle['source'][] = [
  'Prothom Alo',
  'The Daily Star',
  'bdnews24',
  'BBC Bangla',
  'Reuters',
];

const CATEGORIES: NewsArticle['category'][] = [
  'Bangladesh',
  'International',
  'Politics',
  'Business',
  'Technology',
  'Sports',
  'Health',
  'World',
];

export const NewsSectionModal: React.FC<NewsSectionModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  articles = INITIAL_NEWS,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSource, setSelectedSource] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [refreshing, setRefreshing] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleManualRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      if (onRefresh) onRefresh();
      setRefreshing(false);
      showToast('News feed refreshed successfully with latest reports');
    }, 600);
  };

  const handleShare = (article: NewsArticle) => {
    if (navigator.share) {
      navigator
        .share({
          title: article.title,
          text: article.summary,
          url: article.url,
        })
        .catch(() => {
          // ignore
        });
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(`${article.title}\n${article.url}`);
      showToast('Headline & link copied to clipboard!');
    }
  };

  const safeArticles = articles || INITIAL_NEWS;
  const filteredArticles = safeArticles.filter((a) => {
    const matchesSearch =
      a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSource =
      selectedSource === 'All' || a.source === selectedSource;
    const matchesCategory =
      selectedCategory === 'All' || a.category === selectedCategory;
    return matchesSearch && matchesSource && matchesCategory;
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg max-h-[90vh] rounded-[24px] border shadow-2xl flex flex-col overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150 ${
          darkMode
            ? 'bg-[#12261E] border-[#254F3E] text-white'
            : 'bg-white border-emerald-100 text-stone-900'
        }`}
      >
        {/* Header with Deep Emerald Gradient */}
        <div className="p-4 border-b border-emerald-100/60 dark:border-[#254F3E] flex items-center justify-between bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#52B788] text-stone-950 shadow-md">
              <Newspaper className="w-5 h-5 font-black" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
                Trusted News Feed
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#D4AF37] text-stone-950 font-black">
                  Verified
                </span>
              </h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                National &amp; global headlines from reputable journalism sources
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleManualRefresh}
              className={`p-2 rounded-xl hover:bg-white/10 text-white/90 transition-all ${
                refreshing ? 'animate-spin' : ''
              }`}
              title="Refresh News"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all active:scale-95"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toast */}
        {toastMsg && (
          <div className="px-4 py-2 bg-[#2D6A4F] text-white text-xs font-bold text-center animate-fade-in">
            ✨ {toastMsg}
          </div>
        )}

        {/* Scrollable Body */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3.5">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search headlines or topics..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-200 dark:border-[#254F3E] bg-stone-50 dark:bg-[#0E1E17] text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
            />
          </div>

          {/* Sources Filter Pills */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1 text-[11px] font-bold text-stone-400">
              <Globe className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>News Source:</span>
            </div>
            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {['All', ...SOURCES].map((src) => (
                <button
                  key={src}
                  onClick={() => setSelectedSource(src)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all ${
                    selectedSource === src
                      ? 'bg-[#1B4332] text-white dark:bg-[#D4AF37] dark:text-stone-950'
                      : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {src}
                </button>
              ))}
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1 text-[11px] font-bold text-stone-400">
              <Filter className="w-3.5 h-3.5 text-[#52B788]" />
              <span>Category:</span>
            </div>
            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {['All', ...CATEGORIES].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold whitespace-nowrap transition-all ${
                    selectedCategory === cat
                      ? 'bg-[#2D6A4F] text-white'
                      : 'bg-stone-100 dark:bg-[#163024] text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Articles List */}
          <div className="space-y-3">
            {filteredArticles.length === 0 ? (
              <div className="text-center py-8 text-xs text-stone-400">
                No articles found matching criteria
              </div>
            ) : (
              filteredArticles.map((article) => (
                <div
                  key={article.id}
                  className={`rounded-[20px] border overflow-hidden transition-all shadow-sm hover:shadow-md ${
                    darkMode
                      ? 'bg-[#142B20] border-[#1C3B2E]'
                      : 'bg-white border-stone-200/90'
                  }`}
                >
                  {/* Article Image */}
                  <div className="h-36 w-full relative overflow-hidden bg-stone-200 dark:bg-stone-800">
                    <img
                      src={article.imageUrl}
                      alt={article.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-black/70 text-white backdrop-blur-xs">
                        {article.source}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#D4AF37] text-stone-950">
                        {article.category}
                      </span>
                    </div>
                  </div>

                  {/* Body */}
                  <div className="p-3.5 space-y-2">
                    <h4 className="font-extrabold text-sm text-stone-900 dark:text-stone-100 leading-snug">
                      {article.title}
                    </h4>

                    <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed line-clamp-3">
                      {article.summary}
                    </p>

                    <div className="pt-2 border-t border-stone-100 dark:border-[#254F3E] flex items-center justify-between">
                      <div className="flex items-center gap-1 text-[11px] text-stone-400">
                        <Clock className="w-3 h-3" />
                        <span>{article.publishedTime}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleShare(article)}
                          className="p-1.5 rounded-lg text-stone-400 hover:text-[#1B4332] dark:hover:text-[#F4E0A5] transition-all"
                          title="Share Article"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>

                        <a
                          href={article.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 px-3 py-1 rounded-xl text-xs font-black bg-[#1B4332] text-white hover:bg-[#2D6A4F] active:scale-95 transition-all shadow-xs"
                        >
                          <span>Read</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-emerald-100/50 dark:border-[#254F3E] bg-stone-50/70 dark:bg-[#0E1E17] text-center text-[11px] text-stone-500">
          Curated live feeds from independent journalistic news services
        </div>
      </div>
    </div>
  );
};
