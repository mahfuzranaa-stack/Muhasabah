# Muhasabah — Android APK (one-go setup)

এই project-এর মূল `src/` UI/logic ইচ্ছাকৃতভাবে পরিবর্তন করা হয়নি। Android-এর জন্য শুধু Capacitor packaging layer যোগ করা হয়েছে।

## একবারে build

### Windows
`build-android.bat debug` চালালে debug APK তৈরি হয়ে `public/Muhasabah.apk`-এ কপি হবে।

### macOS/Linux
`./build-android.sh debug` চালালে একই কাজ হবে।

Release-এর জন্য `build-android.bat` বা `./build-android.sh` ব্যবহার করুন। Release APK publish করার আগে নিজের signing key দিয়ে sign করতে হবে।

## Netlify
Build-এর পর `public/Muhasabah.apk` থাকলে website থেকে `/Muhasabah.apk` download করা যাবে।

## প্রয়োজন
Node.js + npm, Java 17+, Android Studio/Android SDK।

**মূল অ্যাপের React/Vite source নতুন করে rewrite করা হয়নি।**
