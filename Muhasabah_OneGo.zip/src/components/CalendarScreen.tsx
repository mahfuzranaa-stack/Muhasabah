import React from 'react';
import { CalendarModal } from './CalendarModal';
import { MetricProgress } from '../types';

interface CalendarScreenProps {
  darkMode: boolean;
  soundEnabled: boolean;
  metrics?: MetricProgress[];
  savedDob?: string;
  onSaveDob?: (dob: string) => void;
  refreshKey?: number;
  hijriAdjustment?: number;
  onHijriAdjustmentChange?: (value: number) => void;
}

export const CalendarScreen: React.FC<CalendarScreenProps> = ({
  darkMode,
  soundEnabled: _soundEnabled,
  metrics: _metrics = [],
  savedDob = '1998-05-15',
  onSaveDob,
  refreshKey = 0,
  hijriAdjustment = 0,
  onHijriAdjustmentChange,
}) => {
  return (
    <div id="screen-calendar-master" className="space-y-4 pb-6">
      <CalendarModal
        isOpen={true}
        isScreenMode={true}
        onClose={() => {}}
        darkMode={darkMode}
        savedDob={savedDob}
        onSaveDob={onSaveDob}
        refreshKey={refreshKey}
        hijriAdjustment={hijriAdjustment}
        onHijriAdjustmentChange={onHijriAdjustmentChange}
      />
    </div>
  );
};

